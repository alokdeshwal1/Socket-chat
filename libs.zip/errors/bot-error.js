/**
 * Constructs a new Bot.Error object with the given code and message.
 * @class Bot.Error
 * @constructor
 * @param {Number} code An error code constant from <code>Bot.Error</code>.
 * @param {String} message A detailed description of the error.
 */
'use strict';

class BotError extends Error {
  constructor(code, message) {
    super(message);
    this.name = this.constructor.name;
    this.message = message;
    this.code = code;
    Error.captureStackTrace(this, this.constructor.name);
  }
}

/**
 * Error code indicating some error other than those enumerated here.
 * @property OTHER_CAUSE
 * @static
 * @final
 */
BotError.OTHER_CAUSE = -1;

/**
 * Error code indicating that something has gone wrong with the server.
 * @property INTERNAL_SERVER_ERROR
 * @static
 * @final
 */
BotError.INTERNAL_SERVER_ERROR = 1;


/**
 * Error code indicating the bot's failed to initialize an Interaction
 * @property INTERACTION_FAILED_INITIALIZATION
 * @static
 * @final
 */
BotError.INTERACTION_FAILED_INITIALIZATION = 100;
BotError.INTERACTION_BACK_ERROR = 101;


/**
 * Error code indicating the bot's action state message is missing
 * @property STATE_MESSAGE_MISSING
 * @static
 * @final
 */
BotError.STATE_MESSAGE_MISSING = 300;

/**
 * Error code indicating the bot's strange behavior where outcome has no matching state
 * @property OUTCOME_WITHOUT_STATE
 * @static
 * @final
 */
BotError.OUTCOME_WITHOUT_STATE = 301;


/**
 * Error code indicating the bot's action entity validation is invalid
 * @property INVALID_ENTITY_VALIDATION
 * @static
 * @final
 */
BotError.INVALID_ENTITY_VALIDATION = 302;


/**
 * Error code indicating the bot's interaction context is not fulfilled
 * @property UNFULFILLED_ACTION_CONTEXT
 * @static
 * @final
 */
BotError.UNFULFILLED_ACTION_CONTEXT = 401;




module.exports = BotError;