const schema = require('./base')();
const validate = require('mongoose-validator');
const Helper = require('./../libs/helper');
const CONSTANTS = require('./../constants/constants');

schema.add({
  name: {
    type: String, /* this is our internal reference name */
    index: true,
    trim: true,
    required: true
  },
  module: {
    type: mongoose.Schema.ObjectId,
    ref: 'Module'
  },
  actionType: {
    type: String,
    required: true
  },
  messages: {
    type: [String]
  },
  status: {
    type: String,
    required: true,
    'default': CONSTANTS.DB.STATUS.ACTIVE
  }
});

module.exports = schema;