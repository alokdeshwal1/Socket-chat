const schema = require('./base')();
const validate = require('mongoose-validator');
const Helper = require('./../libs/helper');
const CONSTANTS = require('./../constants/constants');

schema.add({
  witAiIntentName: {
    type: String,
    index: true
  },
  actionType: {
    type: String,
    required: true
  },
  messages: {
    type: [String]
  },
  status: {
    type: String,
    required: true,
    'default': CONSTANTS.DB.STATUS.ACTIVE
  }
});

module.exports = schema;