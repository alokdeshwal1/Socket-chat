const schema = require('./base')();
const validate = require('mongoose-validator');
const CONSTANTS = require('./../constants/constants');
const mongoose = require('./../libs/mongoose-connection')();

schema.add({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    index: true,
    required: true,
    ref: 'User'
  },
  advisor: {
    type: mongoose.Schema.Types.ObjectId,
    required: true,
    ref: 'User'
  },
  userGoal: {
    type: mongoose.Schema.Types.ObjectId,
    required: true,
    ref: 'UserGoal'
  },
  feedbackRating: {
    type: Number,
    required: true
  },
  feedbackComment: {
    type: String
  },
  feedbackEmoji: {
    type: String
  },
  status: {
    type: String,
    required: true,
    'default': CONSTANTS.DB.STATUS.ACTIVE
  }
});

module.exports = schema;