const schema = require('./base')();
const validate = require('mongoose-validator');
const CONSTANTS = require('./../constants/constants');

schema.add({
  name: {
    type: String,
    index: true,
    required: true,
    unique: true
  },
  status: {
    type: String,
    required: true,
    'default': CONSTANTS.DB.STATUS.ACTIVE
  }
});

module.exports = schema;