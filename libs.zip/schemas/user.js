const schema = require('./base')();
const validate = require('mongoose-validator');
const Helper = require('./../libs/helper');
const CONSTANTS = require('./../constants/constants');
const _ = require('lodash');

schema.add({
  email: {
    type: String,
    index: true,
    required: true,
    validate: validate({
      validator: 'matches',
      arguments: /^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i,
      message: 'Email is not valid'
    })
  },
  company: {
    type: mongoose.Schema.Types.ObjectId,
    index: true,
    ref: 'Company'
  },
  password: {
    type: String,
    required: true
  },
  name: {
    type: String,
    required: true,
    ltrim: true
  },
  firstName: {
    type: String,
    index: true,
    required: true,
    ltrim: true
  },
  middleName: {
    type: String,
    ltrim: true
  },
  lastName: {
    type: String,
    index: true,
    required: true,
    ltrim: true
  },
  jobTitle: {
    type: String
  },
  pictureSource: {
    type: String
  },
  pictureUrl: {
    type: String
  },
  isEmailVerified: {
    type: Boolean,
    'default': false
  },
  verifyEmailSentAt: {
    type: Date
  },
  confirmationCode: {
    type: String
  },
  isSeeded: {
    type: Boolean
  },
  isSeededAccountClaimed: {
    type: Boolean
  },
  isCreatedViaSlack: {
    type: Boolean
  },
  isSignedUpOnBot: {
    type: Boolean
  },
  manager: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  jobFunction: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Function'
  }],
  slackUserId: {
    type: String,
    ltrim: true,
    rtrim: true,
    index: true
  },
  slackUserName: {
    type: String,
    ltrim: true,
    rtrim: true
  },
  slackUserNameLower: {
    type: String,
    ltrim: true,
    rtrim: true,
    index: true
  },
  slackIntegration: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'SlackIntegration'
  },
  googleOauthToken: {
    type: Object
  },
  googleEmailAccount: {
    type: String
  },
  selfAssessment: {
    type: Object
  },
  timezone: {
    type: String,
    required: true
  },
  timezoneLabel: {
    type: String
  },
  timezoneOffset: {
    type: Number
  },
  tag: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Tag'
  }],
  role: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Role'
  }],
  status: {
    type: String,
    required: true,
    'default': CONSTANTS.DB.STATUS.ACTIVE
  }
});

schema.pre('validate', function(next) {
  this.password = this.password || Helper.generateRandomCode(10);

  // fix undefined error exception thrown by Mongoose because timezoneOffset is type Number
  var tzOffset = this.timezoneOffset;
  try {
    tzOffset = Number(tzOffset);
  }
  catch (ex) {
    this.timezoneOffset = undefined;
  }
  if (Number.isNaN(tzOffset)) {
    this.timezoneOffset = undefined;
  }

  next();
});

schema.pre('save', function(next) {
  const bcrypt = require('bcrypt');
  const salt = bcrypt.genSaltSync(10);
  this.password = bcrypt.hashSync(this.password || Helper.generateRandomCode(10), salt);

  // fix undefined error exception thrown by Mongoose because timezoneOffset is type Number
  var tzOffset = this.timezoneOffset;
  try {
    tzOffset = Number(tzOffset);
  }
  catch (ex) {
    this.timezoneOffset = undefined;
  }
  if (Number.isNaN(tzOffset)) {
    this.timezoneOffset = undefined;
  }

  if (this.slackUserName && typeof this.slackUserName === 'string' && ! this.slackUserNameLower) {
    this.slackUserNameLower = this.slackUserName.toLowerCase();
  }

  next();
});

schema.set('toJSON', {
  transform: function(doc, ret, options) {
    delete ret.password;
    return ret;
  }
});

module.exports = schema;