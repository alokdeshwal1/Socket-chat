const schema = require('./base')();
const validate = require('mongoose-validator');
const CONSTANTS = require('./../constants/constants');

schema.add({
  name: {
    type: String,
    index: true,
    required: true
  },
  emailDomain: {
    type: String,
    index: true,
    required: true
  },
  isCreatedViaSlack: {
    type: Boolean
  },
  isSeeded: {
    type: Boolean
  },
  featurePersonalGoal: {
    type: Boolean
  },
  featureOkrGoal: {
    type: Boolean
  },
  enabledModules: [{type: mongoose.Schema.ObjectId, ref: 'Module'}],
  status: {
    type: String,
    required: true,
    'default': CONSTANTS.DB.STATUS.ACTIVE
  }
});

module.exports = schema;