/**
 * This schema store the email search criteria
 */

const schema = require('./base')();
const validate = require('mongoose-validator');
const CONSTANTS = require('./../constants/constants');
const mongoose = require('./../libs/mongoose-connection')();

schema.add({
  trigger: {
    type: mongoose.Schema.Types.ObjectId,
    required: true,
    ref: 'Trigger'
  },
  userGoal: {
    type: mongoose.Schema.Types.ObjectId,
    required: true,
    ref: 'UserGoal'
  },
  user: {
    type: mongoose.Schema.Types.ObjectId,
    index: true,
    required: true,
    ref: 'User'
  },
  criteria: {
    type: Object,
    required: true
  },
  userCriteriaText: {
    type: String,
    required: true
  },
  status: {
    type: String,
    required: true,
    'default': CONSTANTS.DB.STATUS.ACTIVE
  }
});

module.exports = schema;