const schema = require('./base')();
const validate = require('mongoose-validator');
const CONSTANTS = require('./../constants/constants');
const mongoose = require('./../libs/mongoose-connection')();

schema.add({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    index: true,
    ref: 'User',
    required: true
  },
  name: {
    type: String
  },
  goal: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Goal'
  },
  advisors: [{type: mongoose.Schema.ObjectId, ref: 'User'}],
  isGeneral: {
    type: Boolean
  },
  status: {
    type: String,
    required: true,
    'default': CONSTANTS.DB.STATUS.ACTIVE
  }
});

module.exports = schema;