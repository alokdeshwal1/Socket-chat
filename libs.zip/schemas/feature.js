const schema = require('./base')();
const validate = require('mongoose-validator');
const CONSTANTS = require('./../constants/constants');

schema.add({
  module: {
    type: mongoose.Schema.ObjectId,
    ref: 'Module',
    index: true,
    required: true
  },
  name: {
    type: String,
    index: true,
    required: true
  },
  action: {
    type: String,
    required: true
  },
  status: {
    type: String,
    required: true,
    'default': CONSTANTS.DB.STATUS.ACTIVE
  }
});

module.exports = schema;