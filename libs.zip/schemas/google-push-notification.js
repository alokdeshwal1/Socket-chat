const schema = require('./base')();
const validate = require('mongoose-validator');
const CONSTANTS = require('./../constants/constants');
const mongoose = require('./../libs/mongoose-connection')();

schema.add({
  uuid: {
    type: String,
    required: true
  },
  user: {
    type: mongoose.Schema.Types.ObjectId,
    index: true,
    ref: 'User',
    required: true
  },
  watchInfo: {
    type: Object
  },
  resourceUri: {
    type: String,
    required: true
  },
  watchTriggerUri: {
    type: String,
    required: true
  },
  watchType: {
   type: String
  },
  pubSubTopic: {
    type: String
  },
  status: {
    type: String,
    required: true,
    'default': CONSTANTS.DB.STATUS.ACTIVE
  }
});

module.exports = schema;