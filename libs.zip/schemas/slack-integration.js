const schema = require('./base')();
const validate = require('mongoose-validator');
const CONSTANTS = require('./../constants/constants');
const ModelCompany = require('./../models/company');
const Validator = require('validator');
const Co = require('co');
const assert = require('http-assert');

schema.add({
  company: {
    type: mongoose.Schema.Types.ObjectId,
    index: true,
    ref: 'Company'
  },
  accessToken: {
    type: String,
    required: true
  },
  incomingWebHook: {
    type: Object
  },
  scope: {
    type: String,
    required: true
  },
  teamId: {
    type: String,
    required: true
  },
  teamName: {
    type: String,
    required: true
  },
  bot: {
    type: Object,
    required: true
  },
  installerSlackUserId: {
    type: String,
    required: true
  },
  installerSlackUserName: {
    type: String
  },
  installerSlackUserEmail: {
    type: String
  },
  rawData: {
    type: Object,
    required: true
  },
  status: {
    type: String,
    required: true,
    'default': CONSTANTS.DB.STATUS.ACTIVE
  }
});

schema.pre('save', function(next, done) {
  createCompanyIfNotExist(this).then((companyId) => {
    this.company = companyId;
    next();
  });
});

function createCompanyIfNotExist(data) {
  assert(Validator.isEmail(data.installerSlackUserEmail),
    'Cannot save integration because installerSlackUserEmail is not valid or found');
  const emailDomain = data.installerSlackUserEmail.replace(/.*@/, '');

  return new Promise((resolve, reject) => {
    Co(function*() {
      var result;
      try {
        result = yield ModelCompany.upsert({'emailDomain': emailDomain, 'name': data.teamName}, {
          'name': data.teamName,
          'emailDomain': emailDomain,
          'isCreatedViaSlack': true,
          'status': CONSTANTS.DB.STATUS.ACTIVE
        });
      }
      catch(ex) {
        return reject(ex);
      }

      return resolve(result.id);
    });
  });
}

module.exports = schema;