const moment = require('moment');
const mongoose = require('./../libs/mongoose-connection')();
const Schema = mongoose.Schema;

module.exports = function() {
  const base = new Schema({
    createdAt: { type: Date },
    updatedAt: { type: Date },
    acl: {}
  });

  base.pre('update', function(next, done) {
    this.update({}, {$set: {updatedAt: moment.utc().format()}});
    next();
  });

  base.pre('save', function(next, done) {
    var now = moment.utc().format();
    this.updatedAt = now;
    if ( ! this.createdAt) {
      this.createdAt = now;
    }
    next();
  });

  return base;
};