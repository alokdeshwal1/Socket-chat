const schema = require('./base')();
const CONSTANTS = require('./../constants/constants');

schema.add({
  name: {
    type: String,
    required: true,
    ltrim: true,
    rtrim: true
  },
  company: {
    type: mongoose.Schema.Types.ObjectId,
    index: true,
    ref: 'Company'
  },
  module: {
    type: mongoose.Schema.Types.ObjectId,
    index: true,
    ref: 'Module'
  },
  isStandard: {
    type: Boolean
  },
  status: {
    type: String,
    required: true,
    'default': CONSTANTS.DB.STATUS.ACTIVE
  }
});

module.exports = schema;