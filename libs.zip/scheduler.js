'use strict';

/**
 * Scheduler must be running on only one instance / server. Otherwise, multiple events will be queued
 */

const schedule = require('node-schedule');
const CONSTANTS = require('./constants/constants');
const Co = require('co');
const assert = require('assert');
const Util = require('util');
const Config = require('./configs/config');
const jackrabbit = require('jackrabbit');
const EventEmitter = require('events').EventEmitter;
const Helper = require('./bot/libs/helper');
const Logger = require('./libs/logger');
const CronParser = require('cron-parser');
const CronJob = require('cron').CronJob;
const uuid = require('uuid');
const RRule = require('rrule').RRule;
const RRecur = require('rrecur').Rrecur;
const moment = require('moment-timezone');
const memwatch = require('memwatch-next');
const RecurrenceDateValidation = require('./bot/validations/recurrence-date');
const _ = require('lodash');
var triggers = {};

class Scheduler extends EventEmitter {

  constructor(queueName, skipQueue) {
    super();
    assert(typeof queueName === 'string', 'queueName (String) is required');
    this.queueName = queueName;
    this.crons = {};
    this._reconnectInterval = 2000;
    this.pushNotificationCron = null;

    if ( ! skipQueue) {
      this.startQueue();
      this.on('ready', this._isInit);
      this.on('error:queue', this._reconnectQueue);
      this.on('disconnected:queue', this._reconnectQueue);
    }
  }

  _isInit() {
    this._readyCount = this._readyCount || 0;
    if (++this._readyCount === 1) {
      this.init();
    }
  }

  init() {
    Co(function *() {
      try {
        yield this.createQueue();
        this.amqb.handle(this.queueName, this.handleQueue.bind(this));

        this.scheduleTriggers();
        this.scheduleRenewPushNotification();
        this.scheduleOkrGoals();
      }
      catch(ex) {
        Logger.error({
          ex: ex,
          exStack: ex.stack
        }, 'Scheduler: Failed to init');
      }
    }.bind(this));
  }

  _reconnectQueue() {
    setTimeout(() => {
      Logger.warn('Trying to reconnect Queue');
      this.startQueue();
    }, this._reconnectInterval);
  }

  /**
   * Check if cron modifier expression criteria is fulfilled
   *
   * @param timezone
   * @param modifier
   * @param dateNow - Moment date object in UTC
   * @param triggerDate - Moment date object in UTC
   * @returns {boolean}
   * @private
   */
  _isModifierDateCriteriaFulfilled(userText, timezone, modifier, dateNow, startDate) {
    try {
      assert(typeof userText === 'string', 'userText (String) is required');
      assert(typeof timezone === 'string', 'timezone (String) is required');
      assert(typeof modifier === 'string', 'modifier (String) is required');
      assert(typeof dateNow === 'object', 'dateNow (Moment Object in UTC) is required');
      startDate && assert(typeof startDate === 'object', 'startDate must be an Moment Object in UTC');

      startDate = startDate || dateNow;
      const rdate = new RecurrenceDateValidation(timezone);
      const modifierValue = rdate.supportedModifiers[modifier];
      const outputFormat = 'YYYY/MM/DD HH:mm ZZ';
      assert(modifierValue, 'input modifier is not found in supportedModifier list');

      var dates = rdate.getDates(userText, dateNow, startDate, outputFormat).sampleDates;
      return dateNow.tz(timezone).format(outputFormat) === dates[0];
    }
    catch(ex) {
      Logger.error({
        ex: ex,
        exStack: ex.stack,
        arguments: arguments
      }, 'Failed to run _isModifierDateCriteriaFulfilled');
    }

    return false;
  }

  scheduleJob(userTrigger) {
    try {
      // cancel the previous job if there is an existing job
      if (this.crons[userTrigger.id]) {
        this.cancelJob(userTrigger.id);
      }

      if (userTrigger.frequencyCron) {
        this.crons[userTrigger.id] = new CronJob(userTrigger.frequencyCron, this.runJob(userTrigger.id),
                                                  this.doneJob(userTrigger.id), true, (userTrigger.user && userTrigger.user.timezone) || undefined);
      }
      else if(userTrigger.rrule && Array.isArray(userTrigger.rrule.rules)) {
        if ( ! userTrigger.rrule.end) {
          userTrigger.rrule.end = userTrigger.googleCalendarObject && userTrigger.googleCalendarObject.end;
        }
        this._scheduleRRuleJob(userTrigger);
      }
      else if (userTrigger.googleCalendarObject && typeof userTrigger.googleCalendarObject.end === 'object') {
        var endTime = moment(userTrigger.googleCalendarObject.end.dateTime);
        this.crons[userTrigger.id] = new CronJob(endTime.toDate(), this.runJob(userTrigger.id),
                                        this.doneJob(userTrigger.id), true, userTrigger.googleCalendarObject.end.timeZone || undefined);
      }
      else {
        throw new Error('Incorrect trigger format');
      }

      return this.crons[userTrigger.id];
    }
    catch(ex) {
      Logger.error({
        ex: ex,
        exStack: ex.stack,
        userTrigger: userTrigger
      },'Failed to schedule job');
    }
  }

  scheduleUserOkrGoal(userOkrGoal) {
    try {
      const prefix = 'OkrGoal-';
      const indexKey = prefix + userOkrGoal.id;
      var frequencyCron;
      // cancel the previous job if there is an existing job
      if (this.crons[indexKey]) {
        this.cancelJob(indexKey);
      }

      if (userOkrGoal && userOkrGoal.user && userOkrGoal.user.selfAssessment && userOkrGoal.user.selfAssessment.frequencyCron) {
        frequencyCron = userOkrGoal.user.selfAssessment.frequencyCron;
      }
      else {
        frequencyCron = Config.selfAssessment.frequencyCron;
      }

      if (frequencyCron) {
        this.crons[indexKey] = new CronJob(frequencyCron, this.runOkrJob(userOkrGoal.id),
                                            this.doneJob(userOkrGoal.id), true, (userOkrGoal.user && userOkrGoal.user.timezone) || undefined);
      }

      return this.crons[indexKey];
    }
    catch(ex) {
      Logger.error({
        ex: ex,
        exStack: ex.stack,
        userOkrGoal: userOkrGoal
      }, 'Failed to schedule userOKRGoal job');
    }
  }

  cancelJob(indexKey) {
    try {
      if (typeof this.crons[indexKey] === 'object') {
        Object.keys(this.crons[indexKey]).forEach(key => {
          if (typeof this.crons[indexKey][key].stop == 'function') {
            this.crons[indexKey][key].stop();
          }
        });

        delete this.crons[indexKey];
      }
      else {
        if (typeof this.crons[indexKey].stop === 'function') {
          this.crons[indexKey].stop();
          delete this.crons[indexKey];
        }
      }
    }
    catch(ex) {
      Logger.error({
        ex: ex,
        exStack: ex.stack,
        indexKey: indexKey
      },'Failed to cancel job');
    }
  }

  scheduleTriggers() {
    return new Promise((resolve, reject) => {
      Co(function *() {
        const ModelUserTrigger = require('./models/user-trigger');
        try {
          triggers = yield ModelUserTrigger.find({ status: CONSTANTS.DB.STATUS.ACTIVE }).populate('user');
          triggers.forEach(item => {
            this.scheduleJob(item);
          });

          resolve(true);
        }
        catch(ex) {
          Logger.error({
            ex: ex,
            exStack: ex.stack
          },'Failed to schedule triggers');

          return reject(ex);
        }
      }.bind(this));
    });
  }

  scheduleOkrGoals() {
    return new Promise((resolve, reject) => {
      Co(function *() {
        const ModelUserOkrGoal = require('./models/user-okr-goal');
        var orkGoals;
        try {
          orkGoals = yield ModelUserOkrGoal.find({ status: CONSTANTS.DB.STATUS.ACTIVE }).populate('user');
          orkGoals.forEach(item => {
            this.scheduleUserOkrGoal(item);
          });

          resolve(true);
        }
        catch(ex) {
          Logger.error({
            ex: ex,
            exStack: ex.stack,
            orkGoals: orkGoals
          }, 'Failed to schedule okr goals');

          return reject(ex);
        }
      }.bind(this));
    });
  }

  scheduleRenewPushNotification() {
    this.pushNotificationCron = new CronJob('*/10 * * * *', this.runPushNotificationCheck(), null, true);
  }

  startQueue() {
    this.amqb = jackrabbit(Config.rabbitUrl)
      .on('connected', () => {
        this.emit('ready');
      })
      .on('error', (err) => {
        this.emit('error:queue', err, {msg: err, service: 'rabbitmq'});
      })
      .on('disconnected', () => {
        this.emit('disconnected:queue', {msg: 'disconnected', service: 'rabbitmq'});
      });

      // @TODO: move this to a custom jackrabbit module
      this.amqb.queueJob = function(queueName, job) {
        return new Promise((resolve, reject) => {
          this.create(queueName, { prefetch: 5 }, (err) => {
            if (err) {
              Logger.error({
                err: err,
                queueName: queueName,
                job: job
              }, 'failed to create amqb channel');

              return reject(err);
            }

            try {
              this.publish(queueName, Object.assign({id: uuid.v1()}, job));
            }
            catch(ex) {
              return reject(ex);
            }

            return resolve(true);
          });
        });
      };
  }

  handleQueue(job, ack) {
    Co(function*() {
      try {
        Logger.debug('Scheduler receive job', job);
        assert(typeof job === 'object', 'Job (Object) is required');
        if(job.type === CONSTANTS.SCHEDULER_JOB_TYPE.ADD || job.type === CONSTANTS.SCHEDULER_JOB_TYPE.UPDATE) {
          if (job.module === CONSTANTS.MODULES.OKR) {
            const ModelUserOkrGoal = require('./models/user-okr-goal');
            let orkGoals = yield ModelUserOkrGoal.find({ status: CONSTANTS.DB.STATUS.ACTIVE, user: job.userId }).populate('user');
            orkGoals.forEach(item => {
              this.scheduleUserOkrGoal(item);
            });
          }
          else {
            const ModelUserTrigger = require('./models/user-trigger');
            const userTrigger = yield ModelUserTrigger.findOne({_id: job.triggerId, status: CONSTANTS.DB.STATUS.ACTIVE})
                                    .populate('user userGoal');
            this.scheduleJob(userTrigger);
          }
        }
        else if(job.type === CONSTANTS.SCHEDULER_JOB_TYPE.REMOVE) {
          if (job.module === CONSTANTS.MODULES.OKR) {
            const ModelUserOkrGoal = require('./models/user-okr-goal');
            let orkGoals = yield ModelUserOkrGoal.find({ status: CONSTANTS.DB.STATUS.ACTIVE, user: job.userId }).populate('user');
            orkGoals.forEach(item => {
              this.cancelJob('OkrGoal-' + item.id);
            });
          }
          else {
            this.cancelJob(job.triggerId);
          }
        }
        else {
          Logger.error({job: job}, 'Unsupported or unrecognized job type received');
        }
      }
      catch(ex) {
        Logger.error({
          ex: ex,
          exStack: ex.stack,
          job: job
        }, 'Failed to schedule a job from queue');
      }

      ack && ack();
    }.bind(this));
  }

  createQueue() {
    return new Promise((resolve, reject) => {
      this.amqb.create(this.queueName, { prefetch: 5 }, (err) => {
        Logger.info('creating amqb channel', this.queueName);
        if (err) {
          Logger.error({ queueName: this.queueName }, 'failed to create amqb channel');
          return reject(err);
        }
        return resolve(true);
      });
    });
  }

  /*
  _timeTimzone(time, zone) {
    var inputFormat = 'ddd MMM DD YYYY H:mm:ss z ZZ';
    var format = 'YYYY/MM/DD HH:mm:ss ZZ';
    return moment(time, inputFormat).tz(zone).format(format);
  }
  */

  /**
   * Convert Google RRule to Recur Object
   * @param iCalRRule
   * @param timezone
   * @param start
   * @param until - Must be in UTC
   * @returns {*}
   * @private
   */
  _convertRRule(iCalRRule, timezone, start, until) {
    assert(typeof iCalRRule === 'string', 'iCalRRUle (String) is required');
    assert(typeof timezone === 'string', 'timezone (String) is required');
    //assert(typeof start === 'string', 'start (String) is required');

    var obj = {
      dtstart: {
        utc: start,
        locale: timezone
      },
      rrule: RRecur.parse(iCalRRule)
    };

    if (until) {
      obj.until = until;
    }

    return RRecur.create(obj, new Date());
  }

  _scheduleRRuleJob(userTrigger) {
    try {
      const endTime = moment(userTrigger.rrule.end.dateTime).tz(userTrigger.rrule.end.timeZone).toDate().toISOString();
      const localeTimezone = 'GMT'+ moment().tz(userTrigger.rrule.end.timeZone).format('ZZ (z)');
      userTrigger.rrule.rules.forEach(rule => {
        var ruleInfo = {
          rule: rule,
          localeTimezone: localeTimezone,
          endTime: endTime
        };
        this._scheduleRRuleItemJob(ruleInfo, userTrigger);
      });
    }
    catch (ex) {
      Logger.error({
        ex: ex,
        exStack: ex.stack,
        userTrigger: userTrigger
      }, 'Failed to scheduleRRuleJob');

      return false;
    }

    return true;
  }

  _scheduleRRuleItemJob(ruleInfo, userTrigger) {
    try {
      if( ! (ruleInfo && typeof(ruleInfo) === 'object')) {
        Logger.warn({
          ruleInfo: ruleInfo,
          userTrigger: userTrigger
        }, 'Trying to _scheduleRRuleItemJob with invalid ruleInfo');

        return false;
      }

      var ruleObject = this._convertRRule(ruleInfo.rule, ruleInfo.localeTimezone, ruleInfo.endTime);
      var nextDate = ruleObject.next();
      var userTriggerId = userTrigger.id;
      if (nextDate) {
        this.crons[userTriggerId] = this.crons[userTriggerId] || {};
        this.crons[userTriggerId][ruleInfo.rule] = new CronJob(moment(nextDate).toDate(), this.runJob(userTriggerId, ruleInfo), this.doneJob(userTriggerId, ruleInfo), true);
        return true;
      }
      else {
        delete this.crons[userTriggerId][ruleInfo.rule];
      }
    }
    catch (ex) {
      Logger.error({
        ex: ex,
        exStack: ex.stack,
        ruleInfo: ruleInfo,
        userTrigger: userTrigger
      },'Fail to run _scheduleRRuleItemJob');
    }

    return false;
  }

  runOkrJob(okrGoalId) {
    return () => {
      this._runOkrJobCalled();
      Co(function *() {
        try {
          const ModelSlackIntegration = require('./models/slack-integration');
          const ModelGoal = require('./models/goal');
          const ModelUser = require('./models/user');
          const ModelUserOkrGoal = require('./models/user-okr-goal');
          const userOkrGoal = yield ModelUserOkrGoal.findOneActive(okrGoalId, 'user');
          if (! (userOkrGoal && userOkrGoal.advisors && Array.isArray(userOkrGoal.advisors))) {
            return false;
          }

          // check whether there is a modifier for this config
          var cronModifier;
          var cronUserText;
          var cronStartDate;
          if (userOkrGoal && userOkrGoal.user && userOkrGoal.user.selfAssessment) {
            cronModifier = userOkrGoal.user.selfAssessment.frequencyCronModifier;
            cronUserText = userOkrGoal.user.selfAssessment.frequencyUserText;
            cronStartDate = userOkrGoal.user.selfAssessment.frequencyStartDate;
          }
          else {
            cronModifier = Config.selfAssessment.frequencyModifier;
            cronUserText = Config.selfAssessment.frequencyUserText;
            cronStartDate = Config.selfAssessment.frequencyStartDate;
          }

          // check whether frequency modifier date is fulfilled
          if (cronModifier && ! this._isModifierDateCriteriaFulfilled(cronUserText, userOkrGoal.user.timezone,
              cronModifier, moment(), moment(cronStartDate))) {

            return false;
          }

          var actions = [];
          var user = yield ModelUser.findOne( { _id: userOkrGoal.user.id, status: CONSTANTS.DB.STATUS.ACTIVE }).populate('slackIntegration manager');
          userOkrGoal.advisors.forEach(advisor => {
            actions.push(ModelUser.findOne({
              _id: advisor.toString(),
              status: CONSTANTS.DB.STATUS.ACTIVE
            }).populate('slackIntegration'));
          });

          var advisors = yield Promise.all(actions);
          var theTask = _.cloneDeep(require('./bot/tasks/feedback/gather-okr-feedback'));
          theTask.priority = 3;
          if (Array.isArray(advisors)) {
            advisors.forEach(advisor => {
              GLOBAL.scheduler.amqb.queueJob(Helper.getBotQueueName(advisor.slackIntegration.teamName, advisor.slackIntegration.teamId), {
                slackUserId: advisor.slackUserId,
                context: {
                  appName: Config.appName,
                  userFirstName: advisor.firstName,
                  targetUserFirstName: (user.firstName === advisor.firstName) ? 'you' : user.firstName,
                  managerFirstName: user.manager && user.manager.firstName,
                  advisorId: advisor.id,
                  userOkrGoalId: userOkrGoal.id,
                  targetUserId: user.id,
                  slackUserId: advisor.slackUserId,
                  targetUserGoalName: userOkrGoal && userOkrGoal.okrGoal && userOkrGoal.okrGoal.name || userOkrGoal.name
                },
                task: theTask
              });
            });
          }
        }
        catch (ex) {
          Logger.error({
            ex: ex,
            exStack: ex.stack,
            okrGoalId: okrGoalId
          }, 'Failed to fire feedback request jobs');
        }
      }.bind(this));
    }
  }

  runJob(userTriggerId, ruleInfo) {
    return () => {
      this._runJobCalled();
      Co(function *() {
        try {
          const ModelSlackIntegration = require('./models/slack-integration');
          const ModelGoal = require('./models/goal');
          const ModelUser = require('./models/user');
          const ModelUserGoal = require('./models/user-goal');
          const ModelUserTrigger = require('./models/user-trigger');
          const userTrigger = yield ModelUserTrigger.findOne({
            _id: userTriggerId,
            status: CONSTANTS.DB.STATUS.ACTIVE
          }).populate('user userGoal');

          if (! (userTrigger && userTrigger.userGoal && userTrigger.userGoal.advisors && Array.isArray(userTrigger.userGoal.advisors))) {
            return false;
          }

          // schedule next available date if it is a RRule job
          if (ruleInfo) {
            this._scheduleRRuleItemJob(ruleInfo, userTrigger);
          }

          var actions = [];
          var user = yield ModelUser.findOne( { _id: userTrigger.user.id, status: CONSTANTS.DB.STATUS.ACTIVE }).populate('slackIntegration');
          var userGoal = yield ModelUserGoal.findOne( { _id: userTrigger.userGoal.id, status: CONSTANTS.DB.STATUS.ACTIVE }).populate('goal');
          if ( ! (user && userGoal)) {
            return false;
          }

          // check whether frequency modifier date is fulfilled
          if (userTrigger.frequencyCronModifier && ! this._isModifierDateCriteriaFulfilled(userTrigger.frequencyUserText, user.timezone,
              userTrigger.frequencyCronModifier, moment(), moment(userTrigger.frequencyStartDate))) {

            return false;
          }

          userTrigger.userGoal.advisors.forEach(advisor => {
            actions.push(ModelUser.findOne({
              _id: advisor.toString(),
              status: CONSTANTS.DB.STATUS.ACTIVE
            }).populate('slackIntegration'));
          });

          var advisors = yield Promise.all(actions);

          var theTask;
          if (userGoal.isGeneral === true) {
            theTask = _.cloneDeep(require('./bot/tasks/feedback/gather-general-feedback'));
          }
          else {
            theTask = _.cloneDeep(require('./bot/tasks/feedback/gather-feedback'));
          }
          theTask.priority = 3;
          if (Array.isArray(advisors)) {
            advisors.forEach(advisor => {
              GLOBAL.scheduler.amqb.queueJob(Helper.getBotQueueName(advisor.slackIntegration.teamName, advisor.slackIntegration.teamId), {
                slackUserId: advisor.slackUserId,
                context: {
                  appName: Config.appName,
                  advisor: advisor,
                  userGoal: userTrigger.userGoal,
                  trigger: userTrigger,
                  slackUserId: advisor.slackUserId,
                  userFirstName: advisor.firstName,
                  targetUser: user,
                  targetUserFirstName: user.firstName,
                  targetUserGoalName: userGoal && userGoal.goal && userGoal.goal.name || userGoal.name
                },
                task: theTask
              });
            });
          }
        }
        catch (ex) {
          Logger.error({
            ex: ex,
            exStack: ex.stack,
            userTriggerId: userTriggerId,
            ruleInfo: ruleInfo
          },'Failed to fire feedback request jobs');
        }
      }.bind(this));
    }
  }

  runPushNotificationCheck() {
    return () => {
      Co(function *() {
        const ModelGooglePushNotification = require('./models/google-push-notification');
        try {
          const pns = yield ModelGooglePushNotification.find({status: CONSTANTS.DB.STATUS.ACTIVE});
          pns.forEach(item => {
            if(item && item.watchInfo && item.watchInfo.expiration &&
              ( (item.watchInfo.expiration - (+ new Date())) < Config.google.renewPushNotificationAfter)) {

              GLOBAL.scheduler.amqb.queueJob(CONSTANTS.JOB_QUEUE.RENEW_PUSH_NOTIFICATION, {
                googlePushNotificationId: item.id
              });
            }
          });
        }
        catch(ex) {
          Logger.error({
            ex: ex,
            exStack: ex.stack
          },'Failed to schedule triggers');
        }
      }.bind(this));
    }
  }

  doneJob(userTriggerId, ruleInfo) {
    return () => {
    };
  }

  // for unit test purpose
  _runJobCalled() {}
  _runOkrJobCalled() {}
}

if (! module.parent) {
  var scheduler = GLOBAL.scheduler = new Scheduler(CONSTANTS.JOB_QUEUE.CRON_SCHEDULER);
}

memwatch.on('leak', function(info) {
  Logger.error({
    info: info
  }, 'Scheduler Memory Leak');
});

module.exports = Scheduler;