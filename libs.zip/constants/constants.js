const keys = {
  'DB': {
    'STATUS': {
      'ACTIVE': 'active',
      'INACTIVE': 'inactive',
      'PENDING': 'pending',
      'DELETE': 'delete',
      'ARCHIVED': 'archived'
    },
    'TRIGGER': {
      'MANUAL': 'Regular Time Interval',
      'GMAIL': 'Google Gmail Integration',
      'GCAL': 'Google Calendar Integration'
    }
  },
  'SOCKET_EVENT': {
    'AUTHENTICATION': 'authentication',
    'AUTHENTICATED': 'authenticated',
    'UNAUTHORIZED': 'unauthorized',
    'RECEIVE_FEEDBACK': 'receiveFeedback',
    'RECEIVE_REQUEST': 'receiveRequest',
    'RECEIVE_MESSAGE': 'receiveMessage'
  },
  'JOB_QUEUE': {
    'SEND_EMAIL': 'JobSendEmail',
    'SLACK_INSTALLATION': 'JobSlackInstallation',
    'BOT_SERVER': 'JobBotServer',
    'CRON_SCHEDULER': 'JobCronScheduler',
    'SUMMARY_REPORT': 'JobSummaryReport',
    'SUMMARY_OKR_REPORT': 'JobSummaryOkrReport',
    'RENEW_PUSH_NOTIFICATION': 'JobRenewPushNotification'
  },
  'TASK_TYPE': {
    'HELP_COMMAND': 'helpCommand',
    'CHAINED_TASK': 'chainedTask'
  },
  'BOT_EVENT': {
    'MESSAGE': 'message',
    'MESSAGE_POSTED': 'messagePosted',
    'MESSAGE_QUEUED': 'messageQueued',
    'DIRECT_MESSAGE': 'directMessage',
    'ATTACHMENT_MESSAGE': 'attachmentMessage',
    'EMOJI_REACTION': 'emojiReaction',
    'EMOJI_REACTION_POSTED': 'emojiReactionPosted',
    'EMOJI_REACTION_DELETE': 'emojiReactionDelete',
    'REMOVE_EMOJI_REACTION': 'removeEmojiReaction',
    'QUEUE_JOB': 'queueJob',
    'TASK': 'botTask',
    'END': 'botEnd',
    'END_TASK': 'botEndTask',
    'DONE': 'botEnd',
    'ERROR': 'botError'
  },
  'MODULES': {
    'OKR': 'featureOkrGoal', // @retiring
    'PERSONAL_GOAL': 'featurePersonalGoal', // @retiring
    'MEMORY_RESTORATION': 'memoryRestoration', // @retiring

    'FEEDBACK': 'Feedback',
    'ICE_BREAKERS': 'IceBreakers'
  },
  'SCHEDULER_JOB_TYPE': {
    'ADD': 'add',
    'REMOVE': 'remove',
    'UPDATE': 'update'
  },
  'BOT_JOB_TYPE': {
    'INTEGRATION_MESSAGE': 'integrationMessage'
  },
  'INTEGRATION_TYPE': {
    'INTERACTIVE_MESSAGE': 'interactiveMessage'
  }
};

module.exports = keys;
