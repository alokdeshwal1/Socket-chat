//const Chai = require('chai');
//const expect = Chai.expect;
//const app = require('../app.js');
//const request = require('supertest').agent(app.server);
//const Config = require('./test-configs/test-config');
//const CONSTANTS = require('../constants/constants');
//const Helper = require('../libs/helper.js');
//const Accounts = require('./test-configs/test-accounts');
//const Socket = require('socket.io-client');
//var connection;
//
//// start the server manually because superagent doesn't start it properly
//describe('Socket.IO tests', function() {
//  beforeEach(function() {
//    app.server.listen(process.env.PORT || 8080);
//    connection = Socket.connect('http://localhost:'+ (process.env.PORT || 8080), {
//      transports: ['websocket'],
//      'force new connection': true
//    });
//  });
//
//  it('should establish a new connection ', function(done) {
//    var c1 = Socket.connect('http://localhost:'+ (process.env.PORT || 8080), {
//      transports: ['websocket'],
//      'force new connection': true
//    });
//
//    c1.on('connect', function() {
//      done();
//    });
//  });
//
//  it('should fire authenticated event with the right token', function(done) {
//    var account = Accounts.good[1];
//    connection.emit(CONSTANTS.SOCKET_EVENT.AUTHENTICATION, account.sessionToken);
//    connection.on(CONSTANTS.SOCKET_EVENT.AUTHENTICATED, function() {
//      done();
//    });
//  });
//
//  it('should fire unauthorized event and drop connection afterwards with the wrong token', function(done) {
//    connection.emit(CONSTANTS.SOCKET_EVENT.AUTHENTICATION, 'some-bad-token');
//    connection.on(CONSTANTS.SOCKET_EVENT.UNAUTHORIZED, done);
//  });
//
//});
