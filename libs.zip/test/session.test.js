//const Helper = require('../libs/helper.js');
//const expect = require('chai').expect;
//const Session = require('./../libs/session');
//const Accounts = require('./test-configs/test-accounts');
//
//describe('Session Library', function() {
//  describe('isValid', function() {
//    it('should be true with correct sessionToken', function(done) {
//      var account = Accounts.good[1];
//      Session.isValid(account.sessionToken).then(function(status) {
//        expect(status).to.be.true;
//        done();
//      });
//    });
//
//    it('should be false with wrong sessionToken', function(done) {
//      Session.isValid('SOMESTUPIDtoken').then(function(status) {
//        expect(status).to.be.false;
//        done();
//      });
//    });
//  });
//
//  describe('getUserBySessionToken', function() {
//    it('should be return user that match the sessionToken\'s bearer', function(done) {
//      var account = Accounts.good[1];
//      Session.getUserBySessionToken(account.sessionToken).then(function(user) {
//        expect(user.firstName).to.equal(account.firstName);
//        expect(user.lastName).to.equal(account.lastName);
//        done();
//      }, function(err) {
//        expect(false, err);
//        done();
//      });
//    });
//
//    it('should be false with wrong sessionToken', function(done) {
//      Session.getUserBySessionToken('SOMESTUPIDtoken').then(function(user) {
//        expect(user).to.be.false;
//        done();
//      }, function(err) {
//        expect(false, err);
//        done();
//      });
//    });
//  });
//});