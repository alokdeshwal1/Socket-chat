'use strict';

const Chai = require('chai');
const Sinon = require('sinon');
const expect = Chai.expect;
const moment = require('moment-timezone');
const Config = require('./../configs/config');
const _ = require('lodash');
const Scheduler = require('./../scheduler');
const TestUser = require('./bot/configs/user');
const ModelUser = require('./../models/user');
const ModelTrigger = require('./../models/trigger');
const ModelJobFunction = require('./../models/function');
const ModelUserGoal = require('./../models/user-goal');
const ModelUserTrigger = require('./../models/user-trigger');
const ModelUserOkrGoal = require('./../models/user-okr-goal');
const CONSTANTS = require('./../constants/constants');
const Util = require('util');
const Co = require('co');
var instance;

describe('Scheduler', () => {
  beforeEach(() => {
    instance = new Scheduler('test', true /* do not start the queue */);
    Sinon.spy(instance, '_runJobCalled');
    Sinon.spy(instance, '_runOkrJobCalled');

    GLOBAL.scheduler = {
      amqb: {
        queueJob: Sinon.spy()
      }
    };
  });

  describe('Cron expression', () => {
    it('should schedule cron expression event', (done) => {
      var secondsApart = 1;
      var m = moment().tz('America/Los_Angeles');
      var userTrigger = {
        id: 'test',
        frequencyCron: Util.format('%s %s %s * * *', Number(m.format('s')) + secondsApart, m.format('m'), m.format('H')),
        user: {
          timezone: 'America/Los_Angeles'
        }
      };

      instance.scheduleJob(userTrigger);

      setTimeout(() => {
        expect(instance._runJobCalled.calledOnce).to.equal(true);
        done();
      }, secondsApart * 1000);
    });

    it('should schedule cron expression event in requester\'s timezone', (done) => {
      var secondsApart = 1;
      var m = moment().tz('America/New_York');
      var userTrigger = {
        id: 'test',
        frequencyCron: Util.format('%s %s %s * * *', Number(m.format('s')) + secondsApart, m.format('m'), m.format('H')),
        user: {
          timezone: 'America/New_York'
        }
      };

      instance.scheduleJob(userTrigger);

      setTimeout(() => {
        expect(instance._runJobCalled.calledOnce).to.equal(true);
        done();
      }, secondsApart * 1000);
    });

  });

  describe('Schedule one time', () => {
    it('should schedule one time Google event with NO timezone info', (done) => {
      var secondsApart = 1;
      var userTrigger = {
        googleCalendarObject: {
          end: {
            //dateTime: '2016-02-25T18:00:00Z',
            dateTime: moment().add(secondsApart, 'seconds').format().replace('+00:00', 'Z')
            //timeZone: 'America/Los_Angeles'
          }
        }
      };

      instance.scheduleJob(userTrigger);

      setTimeout(() => {
        expect(instance._runJobCalled.calledOnce).to.equal(true);
        done();
      }, secondsApart * 1000);
    });

    it('should schedule one time Google event with timezone info', (done) => {
      var secondsApart = 1;
      var userTrigger = {
        googleCalendarObject: {
          end: {
            dateTime: moment().tz('America/Chicago').add(secondsApart, 'seconds').format().replace('+00:00', 'Z'),
            timeZone: 'America/Chicago'
          }
        }
      };

      instance.scheduleJob(userTrigger);

      setTimeout(() => {
        expect(instance._runJobCalled.calledOnce).to.equal(true);
        done();
      }, secondsApart * 1000);
    });

    it('should schedule recurrence rule next date', (done) => {
      var secondsApart = 1;
      var testDateUTC = moment().add(secondsApart, 'seconds');
      var testDateLocal = moment(testDateUTC).tz('America/Phoenix');
      const ruleInfo = {
        rule: 'RRULE:FREQ=WEEKLY;BYDAY='+ testDateLocal.format('dd').toUpperCase(),
        localeTimezone: 'GMT-0700 (MST)',
        endTime: Util.format('%sT%s:%s:%s.000Z', testDateUTC.format('YYYY-MM-DD'), testDateUTC.format('HH'),
          testDateUTC.format('mm'), testDateUTC.format('ss'))
      };

      const result = instance._convertRRule(ruleInfo.rule, ruleInfo.localeTimezone, ruleInfo.endTime);
      const nextDate = result.next();
      const regExp = new RegExp(Util.format('[0-9]{4}-[0-9]{2}-[0-9]{2}T%s:%s:%s.000-0700', testDateLocal.format('HH'),
        testDateLocal.format('mm'), testDateLocal.format('ss')));

      expect(nextDate).to.match(regExp);

      instance._scheduleRRuleItemJob(ruleInfo, {
        id: 'testTrigger'
      });

      setTimeout(() => {
        expect(instance._runJobCalled.calledOnce).to.equal(true);
        done();
      }, (secondsApart + 1) * 1000);
    });
  });





  describe('Schedule recurrence date', () => {
    it('should schedule recurrence date with timezone info (fall back for old data without rrule.end)', (done) => {
      var secondsApart = 1;
      var userTrigger = {
        googleCalendarObject: {
          end: {
            dateTime: moment().tz('America/Los_Angeles').add(secondsApart, 'seconds').format().replace('+00:00', 'Z'),
            timeZone: 'America/Los_Angeles'
          }
        },
        rrule: {
          rules: ['RRULE:FREQ=WEEKLY;UNTIL=20161230T180000Z;BYDAY=MO,TU,WE,TH,FR,SA,SU'],
          start: {
            dateTime: moment().tz('America/Los_Angeles').add(secondsApart, 'seconds').format().replace('+00:00', 'Z'),
            timeZone: 'America/Los_Angeles'
          }
        }
      };

      instance.scheduleJob(userTrigger);

      setTimeout(() => {
        expect(instance._runJobCalled.calledOnce).to.equal(true);
        done();
      }, secondsApart * 1000);
    });

    it('should schedule recurrence date with timezone info', (done) => {
      var secondsApart = 1;
      var userTrigger = {
        rrule: {
          rules: ['RRULE:FREQ=WEEKLY;UNTIL=20161230T180000Z;BYDAY=MO,TU,WE,TH,FR,SA,SU'],
          end: {
            dateTime: moment().tz('America/Los_Angeles').add(secondsApart, 'seconds').format().replace('+00:00', 'Z'),
            timeZone: 'America/Los_Angeles'
          }
        }
      };

      instance.scheduleJob(userTrigger);

      setTimeout(() => {
        expect(instance._runJobCalled.calledOnce).to.equal(true);
        done();
      }, secondsApart * 1000);
    });
  });





  describe('Job handling add, update, and remove', () => {
    var userTriggerId;

    before(done => {
      Co(function *(){
        try {
          const trigger = yield ModelTrigger.findOne({ systemKey: 'Regular Time Interval'});
          const user0 = yield ModelUser.findOne({ slackUserId: TestUser[0].slackUserId });
          const user1 = yield ModelUser.findOne({ slackUserId: TestUser[1].slackUserId });
          const user2 = yield ModelUser.findOne({ slackUserId: TestUser[2].slackUserId });

          yield ModelUserGoal.remove({name: 'Unit test - Scheduler'});
          var userGoal = new ModelUserGoal();
          userGoal.name = 'Unit test - Scheduler';
          userGoal.user = user2.id;
          userGoal.status = CONSTANTS.DB.STATUS.ACTIVE;
          userGoal.advisors = [user0.id, user1.id];
          yield userGoal.save();

          var userTrigger = new ModelUserTrigger();
          userTrigger.frequencyUserText = '12pm monday';
          userTrigger.frequencyCron = '0 12 * * 1';
          userTrigger.user = user2.id;
          userTrigger.status = CONSTANTS.DB.STATUS.ACTIVE;
          userTrigger.trigger = trigger.id;
          userTrigger.userGoal = userGoal.id;
          yield userTrigger.save();

          userTriggerId = userTrigger.id;

          done();
        }
        catch (ex){
          done(ex);
        }
      }.bind(this))
    });

    after(() => {
      return ModelUserGoal.remove({name: 'Unit test - Scheduler'});
    });

    it('should NOT handle job with invalid trigger id', (done) => {
      var ack = () => {
        expect(Object.keys(instance.crons).length).to.equal(0);
        done();
      };

      expect(Object.keys(instance.crons).length).to.equal(0);
      instance.handleQueue( {
        type: CONSTANTS.SCHEDULER_JOB_TYPE.ADD,
        triggerId: 'testId'
      }, ack);
    });

    it('should handle "add" job', (done) => {
      var ack = () => {
        expect(Object.keys(instance.crons).length).to.equal(1);
        expect(Object.keys(instance.crons)[0]).to.equal(userTriggerId);
        done();
      };

      expect(Object.keys(instance.crons).length).to.equal(0);
      instance.handleQueue( {
        type: CONSTANTS.SCHEDULER_JOB_TYPE.ADD,
        triggerId: userTriggerId
      }, ack);
    });

    it('should handle "update" job', (done) => {
      var ack = () => {
        expect(Object.keys(instance.crons).length).to.equal(1);
        expect(Object.keys(instance.crons)[0]).to.equal(userTriggerId);
        done();
      };

      expect(Object.keys(instance.crons).length).to.equal(0);
      instance.handleQueue( {
        type: CONSTANTS.SCHEDULER_JOB_TYPE.UPDATE,
        triggerId: userTriggerId
      }, ack);
    });

    it('should handle "remove" job', (done) => {
      // schedule a job first
      expect(Object.keys(instance.crons).length).to.equal(0);
      instance.handleQueue( {
        type: CONSTANTS.SCHEDULER_JOB_TYPE.ADD,
        triggerId: userTriggerId
      }, () => {
        expect(Object.keys(instance.crons).length).to.equal(1);
        expect(Object.keys(instance.crons)[0]).to.equal(userTriggerId);

        // then, remove the job
        instance.handleQueue( {
          type: CONSTANTS.SCHEDULER_JOB_TYPE.REMOVE,
          triggerId: userTriggerId
        }, () => {
          expect(Object.keys(instance.crons).length).to.equal(0);
          done();
        });
      });
    });
  });

  describe('Handling job date with date modifier (example: first of every month)', () => {
    it('should run job with date "1st Tues of every month"', () => {
      var timezone = 'America/New_York';
      var userText = '1st Monday of the month';
      var tests = [
        // testing 1st monday (Monday is derived from the day 2016-5-2 falls under)
        {
          modifier: '1st',
          date: moment.tz('2016-05-02 10:00:00', timezone).utc(),
          expected: true
        },
        {
          modifier: '1st',
          date: moment.tz('2016-05-09 10:00:00', timezone).utc(),
          expected: false
        },
        {
          modifier: '1st',
          date: moment.tz('2016-05-16 10:00:00', timezone).utc(),
          expected: false
        },
        {
          modifier: '1st',
          date: moment.tz('2016-05-23 10:00:00', timezone).utc(),
          expected: false
        }
      ];

      for(let test of tests) {
        expect(instance._isModifierDateCriteriaFulfilled(userText, timezone, test.modifier, moment(test.date, 'YYYY-M-D H:mm'))).to.equal(test.expected);
      }
    });

    it('should run job with date "2nd Friday of every month"', () => {
      var timezone = 'America/New_York';
      var userText = '2nd Friday of every month';
      var tests = [
        {
          modifier: '2nd',
          date: moment.tz('2016-05-06 10:00:00', timezone).utc(),
          expected: false
        },
        {
          modifier: '2nd',
          date: moment.tz('2016-05-13 10:00:00', timezone).utc(),
          expected: true
        },
        {
          modifier: '2nd',
          date: moment.tz('2016-05-20 10:00:00', timezone).utc(),
          expected: false
        },
        {
          modifier: '2nd',
          date: moment.tz('2016-05-27 10:00:00', timezone).utc(),
          expected: false
        }
      ];

      for(let test of tests) {
        expect(instance._isModifierDateCriteriaFulfilled(userText, timezone, test.modifier, moment(test.date, 'YYYY-M-D H:mm'))).to.equal(test.expected);
      }
    });


    it('should run job with date "every other day of the month"', () => {
      var timezone = 'America/New_York';
      var userText = 'every other friday';
      var tests = [
        {
          modifier: 'every other',
          currentDate: moment.tz('2016-05-06 10:00:00', timezone).utc(),
          startDate: moment.tz('2016-05-01 00:00:00', timezone).utc(),
          expected: true
        },
        {
          modifier: 'every other',
          currentDate: moment.tz('2016-05-13 10:00:00', timezone).utc(),
          startDate: moment.tz('2016-05-01 00:00:00', timezone).utc(),
          expected: false
        },
        {
          modifier: 'every other',
          currentDate: moment.tz('2016-05-20 10:00:00', timezone).utc(),
          startDate: moment.tz('2016-05-01 00:00:00', timezone).utc(),
          expected: true
        },
        {
          modifier: 'every other',
          currentDate: moment.tz('2016-05-27 10:00:00', timezone).utc(),
          startDate: moment.tz('2016-05-01 00:00:00', timezone).utc(),
          expected: false
        },
        {
          modifier: 'every other',
          currentDate: moment.tz('2016-06-03 10:00:00', timezone).utc(),
          startDate: moment.tz('2016-05-01 00:00:00', timezone).utc(),
          expected: true
        },
        {
          modifier: 'every other',
          currentDate: moment.tz('2016-06-10 10:00:00', timezone).utc(),
          startDate: moment.tz('2016-05-01 00:00:00', timezone).utc(),
          expected: false
        },
        {
          modifier: 'every other',
          currentDate: moment.tz('2016-06-17 10:00:00', timezone).utc(),
          startDate: moment.tz('2016-05-01 00:00:00', timezone).utc(),
          expected: true
        }
      ];

      for(let test of tests) {
        expect(instance._isModifierDateCriteriaFulfilled(userText, timezone, test.modifier,
          moment(test.currentDate, 'YYYY-M-D H:mm'), moment(test.startDate, 'YYYY-M-D H:mm'))).to.equal(test.expected);
      }
    });

    it('should run job with date "every other day of the month"', () => {
      var timezone = 'America/Los_Angeles';
      var userText = 'every other tuesday at 1:55am';
      var tests = [
        {
          modifier: 'every other',
          currentDate: moment.tz('2016-05-17 01:55:59', timezone).utc(),
          startDate: moment.tz('2016-05-17 01:53:33', timezone).utc(),
          expected: true
        }
      ];

      for(let test of tests) {
        expect(instance._isModifierDateCriteriaFulfilled(userText, timezone, test.modifier,
          moment(test.currentDate, 'YYYY-M-D H:mm'), moment(test.startDate, 'YYYY-M-D H:mm'))).to.equal(test.expected);
      }
    });
  });

  describe('Job cancellation', () => {
    it('should NOT firing schedule job if job is created and then deleted through queue', done => {
      var secondsApart = 1;
      var m = moment().tz('America/Los_Angeles');
      var userTrigger = {
        id: 'test',
        frequencyCron: Util.format('%s %s %s * * *', Number(m.format('s')) + secondsApart, m.format('m'), m.format('H')),
        user: {
          timezone: 'America/Los_Angeles'
        }
      };

      instance.scheduleJob(userTrigger);
      instance.cancelJob(userTrigger.id);

      setTimeout(() => {
        expect(instance._runJobCalled.calledOnce).to.equal(false);
        expect(instance._runJobCalled.callCount).to.equal(0);
        done();
      }, secondsApart * 1000);
    });

    it('should NOT firing duplicated jobs if same triggerId is added twice or more', done => {
      var secondsApart = 1;
      var m = moment().tz('America/Los_Angeles');
      var userTrigger = {
        id: 'test',
        frequencyCron: Util.format('%s %s %s * * *', Number(m.format('s')) + secondsApart, m.format('m'), m.format('H')),
        user: {
          timezone: 'America/Los_Angeles'
        }
      };

      instance.scheduleJob(userTrigger);
      instance.scheduleJob(userTrigger);
      instance.scheduleJob(userTrigger);
      instance.scheduleJob(userTrigger);

      setTimeout(() => {
        expect(instance._runJobCalled.calledOnce).to.equal(true);
        expect(instance._runJobCalled.callCount).to.equal(1);
        done();
      }, secondsApart * 1000);
    });

  });





  describe('Schedule OKR assessment', () => {
    it('should schedule an OKR self assessment with default Config datetime', (done) => {
      Co(function *() {
        const user0 = yield ModelUser.findOne({ slackUserId: TestUser[0].slackUserId });
        var secondsApart = 2;
        yield ModelUser.update({ _id: user0.id }, { selfAssessment: undefined });
        yield ModelUserOkrGoal.remove({ name: 'Scheduler unit test - OKR'});
        var m = moment().tz('America/Los_Angeles');
        var okrGoal = new ModelUserOkrGoal();
        okrGoal.name = 'Scheduler unit test - OKR';
        okrGoal.user = user0.id;
        okrGoal.advisors = [user0.id];
        yield okrGoal.save();
        okrGoal = yield ModelUserOkrGoal.findOneActive(okrGoal.id, 'user');
        Config.selfAssessment.frequencyCron = Util.format('%s %s %s * * *', Number(m.format('s')) + secondsApart, m.format('m'), m.format('H'));
        instance.scheduleUserOkrGoal(okrGoal);

        setTimeout(() => {
          expect(instance._runOkrJobCalled.calledOnce).to.equal(true);
          expect(instance._runOkrJobCalled.callCount).to.equal(1);
          done();
        }, secondsApart * 1000);
      }.bind(this));
    });

    it('should schedule an OKR self assessment with user\'s assesstmentDateTime', (done) => {
      Co(function *() {
        const user0 = yield ModelUser.findOne({ slackUserId: TestUser[0].slackUserId });
        var secondsApart = 3;
        var m = moment().tz('America/Los_Angeles');

        yield ModelUserOkrGoal.remove({ name: 'Scheduler unit test - OKR'});
        yield ModelUser.update({ _id: user0.id }, {
          selfAssessment: {
            frequencyCron:  Util.format('%s %s %s * * *', Number(m.format('s')) + secondsApart, m.format('m'), m.format('H'))
          }
        });

        var okrGoal = new ModelUserOkrGoal();
        okrGoal.name = 'Scheduler unit test - OKR';
        okrGoal.user = user0.id;
        okrGoal.advisors = [user0.id];
        yield okrGoal.save();
        okrGoal = yield ModelUserOkrGoal.findOneActive(okrGoal.id, 'user');

        instance.scheduleUserOkrGoal(okrGoal);

        setTimeout(() => {
          expect(instance._runOkrJobCalled.calledOnce).to.equal(true);
          expect(instance._runOkrJobCalled.callCount).to.equal(1);
          done();
        }, secondsApart * 1000);
      }.bind(this));
    });
  });

  describe('Google Calendar RRule Conversion', () => {
    it('should have next date that match the time zone', () => {
      const ruleInfo = {
        rule: 'RRULE:FREQ=WEEKLY;BYDAY=FR',
        localeTimezone: 'GMT-0700 (MST)',
        endTime: '2016-03-11T20:30:00.000Z'
      };

      const result = instance._convertRRule(ruleInfo.rule, ruleInfo.localeTimezone, ruleInfo.endTime);
      expect(result.next()).to.match(/^[0-9]{4}-[0-9]{2}-[0-9]{2}T13:30:00.000-0700/);
    });

  });

});
