const Chai = require('chai');
const expect = Chai.expect;
const Mockery = require('mockery');
const Sinon = require('sinon');
const Co = require('co');
const Bluebird = require('bluebird');
const ModelSlackIntegration = require('./../../models/slack-integration');
const ModelCompany = require('./../../models/company');
const ModelUser = require('./../../models/user');
const mockTeamName = 'mock-team_name';
const mockTeamId = 'mock-team_id';
var request;
var spyQueueJob;

describe('User Schema', function() {
  beforeEach(() => {
    return ModelUser.remove({ email: 'testregistration@test.com' });
  });

  it('should not throw error if timezoneOffset is "undefined"', function() {
    var user = new ModelUser();
    user.email = 'testregistration@test.com';
    user.password = 'test123';
    user.name = 'test user test';
    user.firstName = 'Test';
    user.lastName = 'User';
    user.status = 'active';
    user.timezone = 'America/Los_Angeles';
    user.timezoneOffset = "undefined";

    return user.save();
  });

  it('should not throw error if timezoneOffset is undefined', function() {
    var user = new ModelUser();
    user.email = 'testregistration@test.com';
    user.password = 'test123';
    user.name = 'test user test';
    user.firstName = 'Test';
    user.lastName = 'User';
    user.status = 'active';
    user.timezone = 'America/Los_Angeles';
    user.timezoneOffset = undefined;

    return user.save();
  });

  it('should not throw error if timezoneOffset is not SET', function() {
    var user = new ModelUser();
    user.email = 'testregistration@test.com';
    user.password = 'test123';
    user.name = 'test user test';
    user.firstName = 'Test';
    user.lastName = 'User';
    user.status = 'active';
    user.timezone = 'America/Los_Angeles';

    return user.save();
  });
});