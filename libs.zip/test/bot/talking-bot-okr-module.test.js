const Chai = require('chai');
const Sinon = require('sinon');
const expect = Chai.expect;
const mockTalkingBot = require('./mocks/mock-talking-bot');
const TalkingBot = require('./../../bot/talking-bot');
const Co = require('co');
const CONSTANTS = require('./../../constants/constants');
const TestUser = require('./../bot/configs/user');
const IntegrationTest = require('./../bot-integration-test');
const teamName = 'eatravelive';
const teamId = 'T0G9HMJK1';
const teamKey = TalkingBot.getTeamKey(teamName, teamId);
const accessToken = 'xoxp-16323732647-16321667203-20295470704-9d49375704';
const botName = 'CareerLark';
const channelName = 'testChannel';
const slackUserId = 'testUserId';
const Config = require('../../configs/config');
const _ = require('lodash');
const sampleTask = {
  name: 'SampleTask',
  priority: 10,
  interactions: [
    {
      type: 'ActionMessage',
      message: 'Hello, this is a test'
    },
    {
      type: 'ActionQuestionAndAnswer',
      message: 'Bye Bye'
    }
  ]
};

var instance;

describe('Talking Bot: OKR Module', function() {
  describe('Help command', () => {
    var expected = {};
    var enabledModules = {};
    enabledModules[CONSTANTS.MODULES.OKR] = true;
    expected[TestUser[2].firstName +' '+ TestUser[2].lastName] = [
      {
        expect: {
          type: 'message',
          text: "Help is on the way! \n\n*General* \n`cancel`: cancels you out of the current task \n`view my profile`: see your job function, manager, direct reports, and OKR's \n`change self assessment time`: change the time at which you are prompted for your self assessment \n\n*OKR update summaries* \n`summary` : pull up update history. You can specify the following options:\n\n`for [@gabe]` : get update history for a specific person (for managers) \n`for team` : get a snapshot of the whole team (for managers) \n`for me` : get your own update history"
        }
      }
    ];

    var iTest = new IntegrationTest(enabledModules, TestUser[2], TestUser, expected, function() {
      this.instance.listen(this.slackUserId, this.primaryChannel, 'help');
    });

    before(done => {
      Co(function *() {
        try {
          // run the tests
          yield iTest.runTest();
        }
        catch (ex) {
          console.log(ex);
        }

        done();

      }.bind(this));
    });

    // generate Mocha "it" tests
    iTest.generateAllTests();
  });


});
