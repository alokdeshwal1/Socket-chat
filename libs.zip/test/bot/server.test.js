const Chai = require('chai');
const Sinon = require('sinon');
const expect = Chai.expect;
const Server = require('./../../bot/server');
const Co = require('co');
const _ = require('lodash');
var instance;

describe('Server for Bot', function() {
  describe('Reconnect AMQP connection if it is dropped', () => {
    it('should try to reconnect AMQP', (done) => {
      Server.prototype._startQueue = Sinon.spy();

      instance = new Server(1);
      instance._reconnectInterval = 1000;
      expect(instance._startQueue.callCount).to.equal(1);
      instance.emit('queue:error');
      setTimeout(() => {
        expect(instance._startQueue.callCount).to.equal(2);
        done();
      }, 1000);
    });

  });

});
