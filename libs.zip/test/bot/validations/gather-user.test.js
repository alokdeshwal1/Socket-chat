'use strict';

const Chai = require('chai');
const Sinon = require('sinon');
const expect = Chai.expect;
const assert = Chai.assert;
const Mockery = require('mockery');
const Validation = require('./../../../bot/validations/gather-user');
const BotMessages = require('./../../../configs/bot-messages');
var instance;

describe('Bot: GatherUser Validation', function() {
  before(function() {
    instance = new Validation();
  });

  it('should parse single user (<@user1>)', function() {
    var input = '<@user1>';
    var expected = ['<@user1>'];
    expect(instance._parseTextToUsersList(input)).to.deep.equal(expected);
  });

  it('should parse single user that has :(<@user1>)', function() {
    var input = '<@user1>';
    var expected = ['<@user1>'];
    expect(instance._parseTextToUsersList(input)).to.deep.equal(expected);
  });

  it('should parse user list in comma separated value ([user1], [user2], [user3])', function() {
    var input = 'user1, user2, user3';
    var expected = ['user1', 'user2', 'user3'];
    expect(instance._parseTextToUsersList(input)).to.deep.equal(expected);
  });

  it('should parse user list in space separated value ([user1] [user2] [user3])', function() {
    var input = 'user1 user2 user3';
    var expected = ['user1', 'user2', 'user3'];
    expect(instance._parseTextToUsersList(input)).to.deep.equal(expected);
  });

  it('should parse user list that has ":" ([user1]:[user2]   [user3])', function() {
    var input = 'user1:user2    user3';
    var expected = ['user1', 'user2', 'user3'];
    expect(instance._parseTextToUsersList(input)).to.deep.equal(expected);
  });

  it('should parse user list in SlackFormat that has ":" (<@user1>:<@user2>   <@user3>)', function() {
    var input = '<@user1>:<@user2>   <@user3>';
    var expected = ['<@user1>', '<@user2>', '<@user3>'];
    expect(instance._parseTextToUsersList(input)).to.deep.equal(expected);
  });

  it('should parse user list that has comma and space separated (<@user1>, <@user2> <@user3>)', function() {
    var input = '<@user1>, <@user2>   <@user3>';
    var expected = ['<@user1>', '<@user2>', '<@user3>'];
    expect(instance._parseTextToUsersList(input)).to.deep.equal(expected);
  });

  it('should parse user list that has comma, colon, and space separated (<@user1>:, <@user2> <@user3>)', function() {
    var input = '<@user1>:, <@user2>';
    var expected = ['<@user1>', '<@user2>'];
    expect(instance._parseTextToUsersList(input)).to.deep.equal(expected);

    input = '<@user1>:, <@user2>, <@user3>';
    expected = ['<@user1>', '<@user2>', '<@user3>'];
    expect(instance._parseTextToUsersList(input)).to.deep.equal(expected);
  });

});
