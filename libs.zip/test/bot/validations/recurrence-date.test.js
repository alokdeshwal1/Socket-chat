'use strict';

const Chai = require('chai');
const Sinon = require('sinon');
const expect = Chai.expect;
const assert = Chai.assert;
const Mockery = require('mockery');
const RecurrenceDateValidation = require('./../../../bot/validations/recurrence-date');
const BotMessages = require('./../../../configs/bot-messages');
var instance;

describe('Bot: Recurrence Date Validation', function() {
  before(function() {
    instance = new RecurrenceDateValidation();
  });

  it('should return the error message with incorrect input', function(done) {
    var actions = [];
    var inputs = [
      'blah blah',
      'test'
    ];

    inputs.forEach(input => {
      actions.push(instance.validate(input));
    });

    Promise.all(actions)
      .then(data => {
        inputs.forEach((item, key) => {
          expect(data[key].error).to.equal(BotMessages.Validation.recurrenceDate());
        });

        done();
      })
      .catch(err => {
        assert(false, 'Recurrence date validation failed', err);
        console.log(err);
      });
  });

  it('should return the correct recurrence info with correct string input', function(done) {
    var actions = [];
    var inputs = [
      'weekly 3:30PM Mondays',
      '10AM every Wed',
      'second Tuesday of every month at 11:25',
      'daily 10:45PM',
      '9PM on Sundays',
      'daily 3:30',
      'daily 12:14'
    ];
    var expected = [
      {
        expression: '30 15 * * 1'
      },
      {
        expression: '0 10 * * 3'
      },
      {
        expression: '25 11 * * 2',
        modifier: 'second'
      },
      {
        expression: '45 22 * * 1-5'
      },
      {
        expression: '0 21 * * 0'
      },
      {
        expression: '30 15 * * 1-5'
      },
      {
        expression: '14 12 * * 1-5'
      }
    ];

    inputs.forEach(input => {
      actions.push(instance.validate(input));
    });

    Promise.all(actions)
      .then(data => {
        expected.forEach((item, key) => {
          expect(data[key].result.expression).to.equal(item.expression);
          data[key].result.modifier && expect(data[key].result.modifier).to.equal(item.modifier);
        });

        done();
      })
      .catch(err => {
        assert(false, 'Recurrence date validation failed', err);
        console.log(err);
      });
  });

  it('should parse "every other tuesday"', () => {
    var input = 'every other tuesday';
    var expected = {
      expression: '0 10 * * 2',
      modifier: 'every other'
    };
    return instance.validate(input).then((data) => {
      expect(data.result.expression).to.deep.equal(expected.expression);
      expect(data.result.modifier).to.deep.equal(expected.modifier);
    });
  });

  it('should parse "every tuesday morning"', () => {
    var input = 'every tuesday morning';
    var expected = '0 10 * * 2';
    return instance.validate(input).then((data) => {
      expect(data.result.expression).to.deep.equal(expected);
    });
  });

  it('should parse "every friday afternoon"', () => {
    var input = 'every friday afternoon';
    var expected = '0 14 * * 5';
    return instance.validate(input).then((data) => {
      expect(data.result.expression).to.equal(expected);
    });
  });

  it('should not schedule interval that firing every second', () => {
    var input = 'tuesday afternoon ';
    var expected = '0 14 * * 2';
    return instance.validate(input).then((data) => {
      expect(data.result.expression).to.equal(expected);
    });
  });

  it('should parse 1st 2nd 3rd ... of every month"', () => {
    var input = '2nd of every month';
    var expected = '0 10 2 * *';
    return instance.validate(input).then((data) => {
      expect(data.result.expression).to.equal(expected);
    });
  });

  it('should parse time at 1st 2nd 3rd ... of the month"', () => {
    var input = '5:30 on 4th of every month';
    var expected = '30 17 4 * *';
    return instance.validate(input).then((data) => {
      expect(data.result.expression).to.equal(expected);
    });
  });

});
