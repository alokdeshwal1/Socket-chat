'use strict';

const TalkingBot = require('./../../../bot/talking-bot');
const Chai = require('chai');
const Sinon = require('sinon');
const expect = Chai.expect;
const Config = require('./../../../configs/config');
const CONSTANTS = require('./../../../constants/constants');
const EventEmitter = require('events').EventEmitter;

// we use a dummy listener to delay the firing of Talking-Bot event
// so that our tests could bind the bot events before being fired
class Dummy extends EventEmitter {
  constructor() {
    super();
  }
}

function createInstance(enabledModules, teamName, teamId, accessToken, botName, channelName) {
  mock();

  var args = Array.prototype.slice.call(arguments);
  if (args.length === 5) {
    args.unshift(null);
  }

  // by pass the Slack Websocket connection
  TalkingBot.prototype.login = Sinon.stub().returns(function() {
    this.emit('openSlackWs');
  });

  // by pass the AMQP Queue connection
  TalkingBot.prototype.startBrain = Sinon.stub().returns(function() {
    this.emit('ready:queue');
  });

  TalkingBot.prototype.connect = Sinon.stub().returns(function() {
    this.emit('openSlackWs');
  });

  TalkingBot.prototype.saveMemory = Sinon.stub().returns(function() {
    return true;
  });

  var instance = new TalkingBot(args[0], { amqb: {}, redis: {} }, args[1], args[2], args[3], args[4], null, false, false);
  instance.redis.set = Sinon.stub().returns(Promise.resolve(true));
  instance.redis.get = Sinon.stub().returns(Promise.resolve(true));

  instance.archive = {
    update: Sinon.spy(),
    send: Sinon.spy(),
    receive: Sinon.spy(),
    log: Sinon.spy()
  };

  channelName = args[5];
  if (channelName) {
    instance._getChannel = Sinon.stub();
    if (typeof channelName === 'string') {
      instance._getChannel.returns(new Promise (function(resolve, reject) {
        resolve(channelName);
      }));
    }
    else {
      for(let slackUserId of Object.keys(channelName)) {
        instance._getChannel.withArgs(slackUserId).returns(Promise.resolve(channelName[slackUserId]));
      }
    }
  }

  instance.postMessage = Sinon.stub().returns(new Promise (function(resolve, reject) {
    resolve({"ok":true,"channel":"D0PHXJYUR","ts":"1457034467.000009","message":{"text":"blah blah blah","username":"larkbot","type":"message","subtype":"bot_message","ts":"1457034467.000009"}});
  }));
  instance.postEmojiToChannel = Sinon.stub().returns(new Promise (function(resolve, reject) {
    resolve({"ok":true,"channel":"D0PHXJYUR","ts":"1457034467.000009","message":{"text":"blah blah blah","username":"larkbot","type":"message","subtype":"bot_message","ts":"1457034467.000009"}});
  }));

  instance.postEmojis = Sinon.stub().returns(new Promise (function(resolve, reject) {
    resolve({"ok":true});
  }));

  instance.deleteEmojis = Sinon.stub().returns(new Promise (function(resolve, reject) {
    resolve({"ok":true});
  }));

  instance.amqb = instance.amqb || {} ;
  instance.amqb.queueJob = function(queueName, job) {
    this._queueTask(job);
  }.bind(instance);

  Sinon.spy(instance, 'speak');
  Sinon.spy(instance, 'attachmentMessage');

  instance.dummyListener = new Dummy();

  instance.dummyListener.setMaxListeners(Infinity);

  instance.on(CONSTANTS.BOT_EVENT.MESSAGE_QUEUED, function(data) {
    setTimeout(function() {
      instance.dummyListener.emit(CONSTANTS.BOT_EVENT.MESSAGE_POSTED, data);
    }, 200);
  });

  instance.on(CONSTANTS.BOT_EVENT.END, function(data) {
    //instance.fireMessageSubscribers(data);

    setTimeout(function() {
      instance.dummyListener.emit(CONSTANTS.BOT_EVENT.END, data);
    }, 200);
  });


  /**
   * For unit / bdd tests purpose,
   * because it is hard to write test against the event emit
   */
  instance.addMessageSubscriber = function(subscriber) {
    if (typeof subscriber !== 'function') {
      return;
    }
    this._messageSubscribers = this._messageSubscribers || [];
    this._messageSubscribers.push(subscriber);
  };

  instance.fireMessageSubscribers = function (data) {
    this._messageSubscribers = this._messageSubscribers || [];
    this._messageSubscribers.forEach(subscriber => {
      subscriber(data);
    });
  };

  return instance;
}

function mock() {
  const Mockery = require('mockery');
  const Config = require('./../../../configs/config');
  Config.botEmojiPostingWaitingSec = 1;
  Mockery.registerMock('./../../configs/config', Config);
}

module.exports = createInstance;


