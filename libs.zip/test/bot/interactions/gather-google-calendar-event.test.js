const Chai = require('chai');
const Sinon = require('sinon');
const expect = Chai.expect;
const Co = require('co');
const Config = require('../../../configs/config');
const GatherGoogleCalendarEvent = require('../../../bot/interactions/gather-google-calendar-event');
const TestUser = require('./../configs/user');
const _ = require('lodash');

describe('Gather Google Calendar Events', function() {
  beforeEach(function() {
    instance = new GatherGoogleCalendarEvent("test", {
      slackUserId: TestUser[0].slackUserId,
      googleOauthToken: {
        token: 'dummyToken'
      }
    });
  });

  describe('_getSearchCriteria', () => {
    it('should return null criteria', () => {
      return instance._getSearchCriteria(TestUser[0].slackUserId, {})
              .then((data) => {
                expect(data).to.equal(null);
              });
    });

    it('should return "organizer: me" criteria', () => {
      return instance._getSearchCriteria(TestUser[0].slackUserId, {organizer: ['me']})
        .then((data) => {
          expect(data.organizerEmail).to.equal(TestUser[0].email);
        });
    });

    it('should return "organizer: <@user1>" criteria', () => {
      return instance._getSearchCriteria(TestUser[0].slackUserId, {organizer: ['<@'+ TestUser[1].slackUserId +'>']})
        .then((data) => {
          expect(data.organizerEmail).to.equal(TestUser[1].email);
        })
    });

    it('should return "attendees: me" criteria', () => {
      return instance._getSearchCriteria(TestUser[0].slackUserId, {attendees: ['me']})
        .then((data) => {
          expect(data.attendeeEmails).to.deep.equal([TestUser[0].email]);
        });
    });

    it('should return "attendees: <@user1>" criteria', () => {
      return instance._getSearchCriteria(TestUser[0].slackUserId, {attendees: ['<@'+ TestUser[1].slackUserId +'>']})
        .then((data) => {
          expect(data.attendeeEmails).to.deep.equal([TestUser[1].email]);
        })
    });

    it('should return "attendees: me, <@user1>" criteria', () => {
      return instance._getSearchCriteria(TestUser[0].slackUserId, {attendees: ['me', '<@'+ TestUser[1].slackUserId +'>']})
        .then((data) => {
          expect(data.attendeeEmails).to.deep.equal([TestUser[0].email, TestUser[1].email]);
        })
    });

    it('should return "attendees: Jared, me, <@user1>" criteria', () => {
      return instance._getSearchCriteria(TestUser[0].slackUserId, {attendees: ['Jared', 'me', '<@'+ TestUser[1].slackUserId +'>']})
        .then((data) => {
          expect(data.attendeeEmails).to.deep.equal([TestUser[2].email, TestUser[0].email, TestUser[1].email]);
        })
    });
  });
});
