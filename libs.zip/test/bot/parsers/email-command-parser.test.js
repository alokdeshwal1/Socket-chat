'use strict';

const Mockery = require('mockery');
const Chai = require('chai');
const Sinon = require('sinon');
const expect = Chai.expect;
const TalkingBot = require('./../../../bot/talking-bot');
const Task = require('./../../../bot/task');
const Config = require('./../../../configs/config');
const CONSTANTS = require('./../../../constants/constants');
const EmailCommandParser = require('./../../../bot/parsers/email-command-parser');
var instance;

describe('Bot: Email Command Parser', () => {
  before(() => {
    instance = new EmailCommandParser();
  });

  function generateTest(title, message, expected) {
    it(title, function(done) {
      instance.process(message)
        .then((result) => {
          expect(result).deep.equal(expected);
          done();
        })
        .catch(err => {
          throw err;
        });
    });
  }

  describe('Email Sender', () => {
    ['emails that I started', 'emails I started', 'emails I start', 'email I starts'].forEach(message => {
      var expected = {
        emailSender: ['I']
      };
      generateTest('should parse "'+ message +'"', message, expected);
    });

    ['emails that Richard started', 'emails Richard started', 'emails Richard start', 'email Richard starts'].forEach(message => {
      var expected = {
        emailSender: ['Richard']
      };
      generateTest('should parse "'+ message +'"', message, expected);
    });
  });

  describe('Email Recipients', () => {
    ['emails sent to Susan'].forEach(message => {
      var expected = {
        recipients: ['Susan']
      };
      generateTest('should parse "'+ message +'"', message, expected);
    });

    ['emails sent to Susan, Richard, Adam', 'emails sent to Susan Richard Adam', 'emails sent to Susan Richard and Adam'].forEach(message => {
      var expected = {
        recipients: ['Susan', 'Richard', 'Adam']
      };
      generateTest('should parse "'+ message +'"', message, expected);
    });
  });

  describe('Email Subject', () => {
    ['email has subject line 1:1 meeting with Alex', 'email subject 1:1 meeting with Alex', 'subject line 1:1 meeting with Alex'].forEach(message => {
      var expected = {
        subject: ['1:1 meeting with Alex']
      };
      generateTest('should parse "'+ message +'"', message, expected);
    });
  });

  describe('Number of Attendees', () => {
    ['sent to more than 8 people'].forEach(message => {
      var expected = {
        numberOfAttendees: {
          'total': 8,
          'modifier': '>'
        }
      };
      generateTest('should parse "'+ message +'"', message, expected);
    });
  });

  describe('Person Reply', () => {
    ['emails that I replied to'].forEach(message => {
      var expected = {
        personReply: ['I']
      };
      generateTest('should parse "'+ message +'"', message, expected);
    });
  });

  describe('Long expressions', () => {
    ['emails that I replied to and sent to more than 8 people'].forEach(message => {
      var expected = {
        personReply: ['I'],
        numberOfAttendees: {
          'total': 8,
          'modifier': '>'
        }
      };
      generateTest('should parse "'+ message +'"', message, expected);
    });

    ['emails has subject line test123 blab blah, sent to Susan, Richard, and Adam'].forEach(message => {
      var expected = {
        recipients: ['Susan', 'Richard', 'Adam'],
        subject: ['test123 blab blah']
      };
      generateTest('should parse "'+ message +'"', message, expected);
    });

    ['emails that I started, has more than 5 people, and subject has project bagel update sent to deepak'].forEach(message => {
      var expected = {
        recipients: ['deepak'],
        subject: ['has project bagel update sent to deepak'],
        emailSender: ['I']
      };
      generateTest('should parse "'+ message +'"', message, expected);
    });

  });

});
