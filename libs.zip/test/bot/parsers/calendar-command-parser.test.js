'use strict';

const Mockery = require('mockery');
const Chai = require('chai');
const Sinon = require('sinon');
const expect = Chai.expect;
const TalkingBot = require('./../../../bot/talking-bot');
const Task = require('./../../../bot/task');
const Config = require('./../../../configs/config');
const CONSTANTS = require('./../../../constants/constants');
const CalendarCommandParser = require('./../../../bot/parsers/calendar-command-parser');
var instance;

describe('Bot: Calendar Command Parser', () => {
  before(() => {
    instance = new CalendarCommandParser();
  });

  function generateTest(title, message, expected) {
    it(title, function() {
      return instance.process(message)
        .then((result) => {
          expect(result).deep.equal(expected);
        })
    });
  }

  describe('Organizer', () => {
    ['organized by Katie', 'organize by Katie'].forEach(message => {
      var expected = {
        organizer: ['Katie']
      };
      generateTest('should parse "'+ message +'"', message, expected);
    });

    ['organized by me'].forEach(message => {
      var expected = {
        organizer: ['me']
      };
      generateTest('should parse "'+ message +'"', message, expected);
    });

    ['organized by <@user>'].forEach(message => {
      var expected = {
        organizer: ['<@user>']
      };
      generateTest('should parse "'+ message +'"', message, expected);
    });
  });

  describe('Number of attendees', () => {
    ['has more than 5 people'].forEach(message => {
      var expected = {
        numberOfAttendees: {
          'total': 5,
          'modifier': '>'
        }
      };
      generateTest('should parse "'+ message +'"', message, expected);
    });
  });

  describe('Attendees', () => {
    ['attendees richard and ashley'].forEach(message => {
      var expected = {
        attendees: ['richard', 'ashley']
      };
      generateTest('should parse "'+ message +'"', message, expected);
    });

    ['attended by richard and ashley'].forEach(message => {
      var expected = {
        attendees: ['richard', 'ashley']
      };
      generateTest('should parse "'+ message +'"', message, expected);
    });
  });

  describe('Meeting Title', () => {
    ['name has product sync'].forEach(message => {
      var expected = {
        title: ['product sync']
      };
      generateTest('should parse "'+ message +'"', message, expected);
    });

    ['name has daily standup'].forEach(message => {
      var expected = {
        title: ['daily standup']
      };
      generateTest('should parse "'+ message +'"', message, expected);
    });

    ['name has mike'].forEach(message => {
      var expected = {
        title: ['mike']
      };
      generateTest('should parse "'+ message +'"', message, expected);
    });
  });

  describe('Long expressions', () => {
    ['mtgs where name has design sync, and attendees laurens and kevin'].forEach(message => {
      var expected = {
        title: ['design sync'],
        attendees: ['laurens', 'kevin']
      };
      generateTest('should parse "'+ message +'"', message, expected);
    });

    ['mtgs title is design sync, has more than eight people, has attendees laurens and kevin'].forEach(message => {
      var expected = {
        title: ['design sync'],
        attendees: ['laurens', 'kevin'],
        numberOfAttendees: {
          'total': 8,
          'modifier': '>'
        }
      };
      generateTest('should parse "'+ message +'"', message, expected);
    });

    it('should parse "name has mike and has more than 3 people"', () => {
      var input = 'name has mike and has more than 3 people';
      var expected = {
        title: ['mike'],
        numberOfAttendees: {
          'total': 3,
          'modifier': '>'
        }
      };

      return instance.process(input)
        .then((result) => {
          expect(result).deep.equal(expected);
        });
    });

  });

});
