'use strict';

const Mockery = require('mockery');
const Chai = require('chai');
const Sinon = require('sinon');
const expect = Chai.expect;
const Config = require('./../../configs/config');
const CONSTANTS = require('./../../constants/constants');
const TestUser = require('./configs/user');
const Helper = require('./../../bot/libs/helper');
const ModelUser = require('./../../models/user');
const ModelJobFunction = require('./../../models/function');
const Co = require('co');
const IntegrationTest = require('./../bot-integration-test');
const mockTalkingBot = require('./mocks/mock-talking-bot');
const _ = require('lodash');
const teamName = 'eatravelive';
const teamId = 'T0G9HMJK1';
const teamKey = Helper.getBotTeamKey(teamName, teamId);
const accessToken = 'xoxp-16323732647-16321667203-20295470704-9d49375704';
const slackUserId = 'testUserId';
const botName = 'CareerLark';
const channelName = 'testChannel';
const TaskGatherFunction = require('./../../bot/tasks/feedback/gather-function');
const TaskGatherFeedback = require('./../../bot/tasks/feedback/gather-feedback');

describe('Talking Bot: Memory Restoration', () => {
  describe('Serialize and deserialize data', () => {
    it('should able to serialize and deserialize data', () => {
      var instance = mockTalkingBot(teamName, teamId, accessToken, botName, channelName);
      return instance._queueTask({
        slackUserId: slackUserId,
        task: require('./../../bot/tasks/feedback/gather-feedback'),
        context: {
          userFirstName: TestUser[2].firstName,
          targetUserFirstName: TestUser[3].firstName,
          targetUserGoalName: 'Test Unit Test Goal'
        }
      }).then(() => {
        var jsonString = instance._serialize();
        expect(jsonString).to.be.a('string');
        var jsonObject = instance._deSerialize(jsonString);
        expect(jsonObject).to.be.an('object');
      });
    });
  });





  //describe('Save a task and restore it', () => {
  //  var expected = {};
  //  expected[TestUser[4].name] = [
  //    {
  //      overwriteTest: function(expected, result) {
  //        delete result[0].callback_id;
  //        expect(result).to.deep.equal(expected);
  //        return true;
  //      },
  //      expect: {
  //        text: [
  //          {
  //            "actions": [
  //              {
  //                "name": ":one:",
  //                "style": "primary",
  //                "text": ":one:",
  //                "type": "button",
  //                "value": ":one:"
  //              },
  //              {
  //                "name": ":two:",
  //                "style": "primary",
  //                "text": ":two:",
  //                "type": "button",
  //                "value": ":two:"
  //              },
  //              {
  //                "name": ":three:",
  //                "style": "primary",
  //                "text": ":three:",
  //                "type": "button",
  //                "value": ":three:"
  //              },
  //              {
  //                "name": ":four:",
  //                "style": "primary",
  //                "text": ":four:",
  //                "type": "button",
  //                "value": ":four:"
  //              },
  //              {
  //                "name": ":five:",
  //                "style": "primary",
  //                "text": ":five:",
  //                "type": "button",
  //                "value": ":five:"
  //              }
  //            ],
  //            "attachment_type": "default",
  //            "color": "#DA552F",
  //            "fallback": "Pick a function:",
  //            "fields": [
  //              {
  //                "title": "Job Functions:",
  //                "value": ":one: Design\n:two: Sales\n:three: People Ops\n:four: Customer Success\n:five: Other\n\nPick a reaction:"
  //              }
  //            ],
  //            "mrkdwn_in": [
  //              "fields",
  //              "pretext",
  //              "text"
  //            ],
  //            "pretext": TaskGatherFunction.interactions[1].message.pretext
  //          }
  //        ]
  //      }
  //    }
  //  ];
  //
  //  var iTest = new IntegrationTest(null, TestUser[4], TestUser, expected);
  //
  //  before(() => {
  //    return iTest.before(function *(users) {
  //      users[4].jobFunction = undefined;
  //      users[4].manager = users[2].id;
  //      yield users[4].save();
  //
  //      iTest.instance.listen(iTest.slackUserId, iTest.primaryChannel, 'add goal');
  //
  //      var jsonString = iTest.instance._serialize();
  //      iTest.instance.convos = {};
  //      iTest.instance.redis.get = function(teamKey, cb) {
  //        cb(null, jsonString);
  //      };
  //
  //      // save the current memory
  //      yield iTest.instance.restoreMemory();
  //    }.bind(this));
  //  });
  //
  //  // generate Mocha "it" tests
  //  iTest.generateAllTests();
  //});





  describe('Save a feedback task and restore it', () => {
    var expected = {};
    expected[TestUser[3].name] = [
      {
        overwriteTest: function(expected, result) {
          expect(result.length).to.equal(1);
          delete result[0].callback_id;
          expect(result).to.deep.equal(expected);
          return true;
        },
        expect: {
          type: 'attachmentMessage',
          text: [
            {
              "actions": [
                {
                  "name": ":disappointed:",
                  "style": "primary",
                  "text": ":disappointed:",
                  "type": "button",
                  "value": ":disappointed:"
                },
                {
                  "name": ":neutral_face:",
                  "style": "primary",
                  "text": ":neutral_face:",
                  "type": "button",
                  "value": ":neutral_face:"
                },
                {
                  "name": ":simple_smile:",
                  "style": "primary",
                  "text": ":simple_smile:",
                  "type": "button",
                  "value": ":simple_smile:"
                },
                {
                  "name": ":smile:",
                  "style": "primary",
                  "text": ":smile:",
                  "type": "button",
                  "value": ":smile:"
                },
                {
                  "name": ":joy:",
                  "style": "primary",
                  "text": ":joy:",
                  "type": "button",
                  "value": ":joy:"
                }
              ],
              "attachment_type": "default",
              "color": "#DA552F",
              "fallback": Helper.replaceMessagePlaceholder(TaskGatherFeedback.interactions[0].message.fallback, {targetUserFirstName: TestUser[4].firstName}),
              "mrkdwn_in": [
                "fields",
                "pretext",
                "text"
              ],
              "text": Helper.replaceMessagePlaceholder(TaskGatherFeedback.interactions[0].message.text, {
                userFirstName: TestUser[3].firstName,
                targetUserFirstName: TestUser[4].firstName,
                targetUserGoalName: 'TestGoal'
              }),
              "title": Helper.replaceMessagePlaceholder(TaskGatherFeedback.interactions[0].message.title, {targetUserFirstName: TestUser[4].firstName})
            }
          ]
        }
      }
    ];

    var iTest = new IntegrationTest(null, TestUser[3], TestUser, expected);

    before(() => {
      return iTest.before(function *(users) {
        var theTask = _.cloneDeep(require('./../../bot/tasks/feedback/gather-feedback'));
        theTask.priority = 2;
        yield (function() {
          return new Promise((resolve, reject) => {
            iTest.instance.handleQueue({
              slackUserId: TestUser[3].slackUserId,
              task: theTask,
              context: {
                userFirstName: TestUser[3].firstName,
                appName: Config.appName,
                targetUserFirstName: TestUser[4].firstName,
                targetUserGoalName: 'TestGoal',
                slackUserId: TestUser[3].slackUserId
              }
            }, () => {
              resolve(true);
            });
          });
        })();

        users[4].jobFunction = undefined;
        users[4].manager = users[2].id;
        yield users[4].save();

        var jsonString = iTest.instance._serialize();
        iTest.instance.convos = {};
        iTest.instance.redis.get = function(teamKey, cb) {
          cb(null, jsonString);
        };

        // save the current memory
        yield iTest.instance.restoreMemory();
      }.bind(this));
    });

    // generate Mocha "it" tests
    iTest.generateAllTests();
  });
});
