'use strict';

const Mockery = require('mockery');
const Chai = require('chai');
const Sinon = require('sinon');
const expect = Chai.expect;
const Config = require('./../../configs/config');
const CONSTANTS = require('./../../constants/constants');
const TestUser = require('./configs/user');
const ModelUser = require('./../../models/user');
const ModelJobFunction = require('./../../models/function');
const Co = require('co');
const IntegrationTest = require('./../bot-integration-test');
const _ = require('lodash');
const TaskGatherFunction = require('./../../bot/tasks/feedback/gather-function');

describe('Talking Bot: Back feature', () => {
  describe('Back from one task to another task', () => {
    var expected = {};
    var globalUsers;
    expected[TestUser[4].firstName +' '+ TestUser[4].lastName] = [
      {
        overwriteTest: function(expected, result) {
          expect(result.length).to.equal(1);
          delete result[0].callback_id;
          expect(result).to.deep.equal(expected);
          return true;
        },
        expect: {
          type: 'attachmentMessage',
          text: [
            {
              "actions": [
                {
                  "name": ":one:",
                  "style": "primary",
                  "text": ":one:",
                  "type": "button",
                  "value": ":one:"
                },
                {
                  "name": ":two:",
                  "style": "primary",
                  "text": ":two:",
                  "type": "button",
                  "value": ":two:"
                },
                {
                  "name": ":three:",
                  "style": "primary",
                  "text": ":three:",
                  "type": "button",
                  "value": ":three:"
                },
                {
                  "name": ":four:",
                  "style": "primary",
                  "text": ":four:",
                  "type": "button",
                  "value": ":four:"
                },
                {
                  "name": ":five:",
                  "style": "primary",
                  "text": ":five:",
                  "type": "button",
                  "value": ":five:"
                }
              ],
              "attachment_type": "default",
              "color": "#DA552F",
              "fallback": "Pick a function:",
              "fields": [
                {
                  "title": "Job Functions:",
                  "value": ":one: Engineering\n:two: Operations\n:three: Product Management\n:four: Sales\n:five: Other\n\nPick a reaction:"
                }
              ],
              "mrkdwn_in": [
                "fields",
                "pretext",
                "text"
              ],
              "pretext": TaskGatherFunction.interactions[1].message.pretext
            }
          ]
        },

        enterMessage: '2'
      },
      {
        expect: {
          type: 'message',
          text: 'Great! Which of the following goal categories look interesting to you?'
        }
      },
      {
        overwriteTest: function(expected, result) {
          expect(result.length).to.equal(1);
          delete result[0].callback_id;
          expect(result).to.deep.equal(expected);
          return true;
        },
        expect: {
          text: [
            {
              "actions": [
                {
                  "name": ":one:",
                  "style": "primary",
                  "text": ":one:",
                  "type": "button",
                  "value": ":one:"
                },
                {
                  "name": ":two:",
                  "style": "primary",
                  "text": ":two:",
                  "type": "button",
                  "value": ":two:"
                },
                {
                  "name": ":three:",
                  "style": "primary",
                  "text": ":three:",
                  "type": "button",
                  "value": ":three:"
                },
                {
                  "name": ":four:",
                  "style": "primary",
                  "text": ":four:",
                  "type": "button",
                  "value": ":four:"
                }
              ],
              "attachment_type": "default",
              "fallback": "Pick one of the following categories:",
              "color": "#DA552F",
              "fields": [
                {
                  "title": "Goal categories:",
                  "value": ":one: Communication\n:two: Productivity\n:three: Leadership and Managerial Skills\n:four: Attitude and Outlook\n\nSelect a button:"
                }
              ],
              "mrkdwn_in": [
                "fields",
                "pretext",
                "text"
              ],
              "pretext": "Pick one of the following categories:"
            }
          ]
        },

        enterMessage: 'back'
      },
      {
        overwriteTest: function(expected, result) {
          expect(result.length).to.equal(1);
          delete result[0].callback_id;
          expect(result).to.deep.equal(expected);
          return true;
        },
        expect: {
          type: 'attachmentMessage',
          text: [
            {
              "actions": [
                {
                  "name": ":one:",
                  "style": "primary",
                  "text": ":one:",
                  "type": "button",
                  "value": ":one:"
                },
                {
                  "name": ":two:",
                  "style": "primary",
                  "text": ":two:",
                  "type": "button",
                  "value": ":two:"
                },
                {
                  "name": ":three:",
                  "style": "primary",
                  "text": ":three:",
                  "type": "button",
                  "value": ":three:"
                },
                {
                  "name": ":four:",
                  "style": "primary",
                  "text": ":four:",
                  "type": "button",
                  "value": ":four:"
                },
                {
                  "name": ":five:",
                  "style": "primary",
                  "text": ":five:",
                  "type": "button",
                  "value": ":five:"
                }
              ],
              "attachment_type": "default",
              "color": "#DA552F",
              "fallback": "Pick a function:",
              "fields": [
                {
                  "title": "Job Functions:",
                  "value": ":one: Engineering\n:two: Operations\n:three: Product Management\n:four: Sales\n:five: Other\n\nPick a reaction:"
                }
              ],
              "mrkdwn_in": [
                "fields",
                "pretext",
                "text"
              ],
              "pretext": TaskGatherFunction.interactions[1].message.pretext
            }
          ]
        },

        enterMessage: 'back'
      },
      {
        expect: {
          type: 'message',
          text: 'Hmm, looks like I can\'t go back. Sorry about that! :slightly_frowning_face:'
        }
      }
    ];

    var iTest = new IntegrationTest(null, TestUser[4], TestUser, expected, function() {
      this.instance.listen(this.slackUserId, this.primaryChannel, 'add goal');

      // schedule a gather feedback, which will be only shown after add Goal is over
      // an extra test to make sure that make sure chainTask is working
      var theTask = _.cloneDeep(require('./../../bot/tasks/feedback/gather-feedback'));
      theTask.priority = 2;
      this.instance.handleQueue({
        slackUserId: this.slackUserId,
        task: theTask,
        context: {
          userFirstName: TestUser[3].firstName,
          appName: Config.appName,
          targetUserFirstName: TestUser[4].firstName,
          targetUserGoalName: 'TestGoal',
          slackUserId: this.slackUserId
        }
      });
    });

    before(() => {
      return iTest.before(function *(users) {
        globalUsers = users;

        users[4].jobFunction = undefined;
        users[4].manager = users[2].id;
        yield users[4].save();
      }.bind(this));
    });

    // generate Mocha "it" tests
    iTest.generateAllTests();

    it('should roll back user\'s job function', () => {
      return ModelUser.findOne({ _id: globalUsers[4].id })
            .then(data => {
              expect(data.jobFunction.length).to.deep.equal(0);
            });
    });

  });





  describe('Back from creating trigger', () => {
    var expected = {};
    expected[TestUser[4].firstName +' '+ TestUser[4].lastName] = [
      {
        overwriteTest: function(expected, result) {
          expect(result.length).to.equal(1);
          delete result[0].callback_id;
          expect(result).to.deep.equal(expected);
          return true;
        },
        expect: {
          text: [
            {
              "actions": [
                {
                  "name": ":one:",
                  "style": "primary",
                  "text": ":one:",
                  "type": "button",
                  "value": ":one:"
                },
                {
                  "name": ":two:",
                  "style": "primary",
                  "text": ":two:",
                  "type": "button",
                  "value": ":two:"
                },
                {
                  "name": ":three:",
                  "style": "primary",
                  "text": ":three:",
                  "type": "button",
                  "value": ":three:"
                },
                {
                  "name": ":four:",
                  "style": "primary",
                  "text": ":four:",
                  "type": "button",
                  "value": ":four:"
                },
                {
                  "name": ":five:",
                  "style": "primary",
                  "text": ":five:",
                  "type": "button",
                  "value": ":five:"
                }
              ],
              "attachment_type": "default",
              "color": "#DA552F",
              "fallback": "Pick a function:",
              "fields": [
                {
                  "title": "Job Functions:",
                  "value": ":one: Engineering\n:two: Operations\n:three: Product Management\n:four: Sales\n:five: Other\n\nPick a reaction:"
                }
              ],
              "mrkdwn_in": [
                "fields",
                "pretext",
                "text"
              ],
              "pretext": TaskGatherFunction.interactions[1].message.pretext
            }
          ]
        },

        enterMessage: '2'
      },
      {
        expect: {
          type: 'message',
          text: 'Great! Which of the following goal categories look interesting to you?'
        }
      },
      {
        overwriteTest: function(expected, result) {
          expect(result.length).to.equal(1);
          delete result[0].callback_id;
          expect(result).to.deep.equal(expected);
          return true;
        },
        expect: {
          text: [
            {
              "actions": [
                {
                  "name": ":one:",
                  "style": "primary",
                  "text": ":one:",
                  "type": "button",
                  "value": ":one:"
                },
                {
                  "name": ":two:",
                  "style": "primary",
                  "text": ":two:",
                  "type": "button",
                  "value": ":two:"
                },
                {
                  "name": ":three:",
                  "style": "primary",
                  "text": ":three:",
                  "type": "button",
                  "value": ":three:"
                },
                {
                  "name": ":four:",
                  "style": "primary",
                  "text": ":four:",
                  "type": "button",
                  "value": ":four:"
                }
              ],
              "attachment_type": "default",
              "fallback": "Pick one of the following categories:",
              "color": "#DA552F",
              "fields": [
                {
                  "title": "Goal categories:",
                  "value": ":one: Communication\n:two: Productivity\n:three: Leadership and Managerial Skills\n:four: Attitude and Outlook\n\nSelect a button:"
                }
              ],
              "mrkdwn_in": [
                "fields",
                "pretext",
                "text"
              ],
              "pretext": "Pick one of the following categories:"
            }
          ]
        },

        enterMessage: '2'
      },
      {
        overwriteTest: function(expected, result) {
          expect(result.length).to.equal(1);
          delete result[0].callback_id;
          expect(result).to.deep.equal(expected);
          return true;
        },
        expect: {
          type: 'attachmentMessage',
          text: [
            {
              "actions": [
                {
                  "name": ":one:",
                  "style": "primary",
                  "text": ":one:",
                  "type": "button",
                  "value": ":one:"
                },
                {
                  "name": ":two:",
                  "style": "primary",
                  "text": ":two:",
                  "type": "button",
                  "value": ":two:"
                },
                {
                  "name": ":three:",
                  "style": "primary",
                  "text": ":three:",
                  "type": "button",
                  "value": ":three:"
                },
                {
                  "name": ":four:",
                  "style": "primary",
                  "text": ":four:",
                  "type": "button",
                  "value": ":four:"
                },
                {
                  "name": ":five:",
                  "style": "primary",
                  "text": ":five:",
                  "type": "button",
                  "value": ":five:"
                }
              ],
              "attachment_type": "default",
              "color": "#DA552F",
              "fallback": "Great, pick one of these Productivity suggested goals or write in your own!",
              "fields": [
                {
                  "title": "Suggested goals:",
                  "value": ":one: Pay close attention to detail\n:two: Know when to use existing solutions and resources without reinventing the wheel\n:three: Take on new projects and go above and beyond when faced with challenges\n:four: Take initiative to make things better, even outside of your day to day responsibilities\n:five: Manage time efficiently and consistently deliver on commitments\n\nPick a button. Or write in your own!"
                }
              ],
              "mrkdwn_in": [
                "fields",
                "pretext",
                "text"
              ],
              "pretext": "Great, pick one of these Productivity suggested goals or write in your own!"
            }
          ]
        },

        enterMessage: 'Integration Test Goal - Add Goal'
      },
      {
        expect: {
          type: 'message',
          text: 'Cool, who would you like to get feedback from for this? \n\n:bulb:Tip: You can type @ to see a dropdown with all of your coworkers. Select as many as you want'
        },

        enterMessage: TestUser[3].firstName
      },
      {
        overwriteTest: function(expected, result) {
          expect(result.length).to.equal(1);
          delete result[0].callback_id;
          expect(result).to.deep.equal(expected);
          return true;
        },
        expect: {
          text: [
            {
              "actions": [
                {
                  "name": ":one:",
                  "style": "primary",
                  "text": ":one:",
                  "type": "button",
                  "value": ":one:"
                },
                {
                  "name": ":two:",
                  "style": "primary",
                  "text": ":two:",
                  "type": "button",
                  "value": ":two:"
                }
              ],
              "attachment_type": "default",
              "fallback": "Great! How should I ask them?",
              "color": "#DA552F",
              "fields": [
                {
                  "title": "Prompt types:",
                  "value": ":one: After meetings (GCal sign-in needed)\n:two: At regular time intervals (set manually)\n\nPick a button:",
                }
              ],
              "mrkdwn_in": [
                "fields",
                "pretext",
                "text"
              ],
              "pretext": "Great! How should I ask them?"
            }
          ]
        },

        enterMessage: '2'
      },
      {
        expect: {
          type: 'message',
          text: "OK, can you tell me at what interval? Here are the types of things that I understand (I'm working on it but I'm a bot after all :simple_smile:) \n`every Monday at 3:30pm` \n`1st Tues of every month` \n`9PM on Sundays` \n`every other Tuesday at 9am` \n\n:bulb:Tip: We recommend asking for feedback at most once a week"
        },

        enterMessage: '12pm monday'
      },

      {
        overwriteTest: function(expected, result) {
          expect(result[0].fields[0].value).to.match(expected[0].fields[0].value);
          delete result[0].fields[0].value;
          delete expected[0].fields[0].value;
          expect(result).to.deep.equal(expected);
          return true;
        },
        expect: {
          text: [
            {
              "color": "#DA552F",
              "fallback": "Cool, this is what I have. Sound good? Say `yes` or `no`",
              "fields": [
                {
                  "value": /\d+\/\d+ Monday 12:00PM\n\d+\/\d+ Monday 12:00PM\n\d+\/\d+ Monday 12:00PM/
                }
              ],
              "mrkdwn_in": [
                "fields",
                "pretext"
              ],
              "pretext": "Cool, this is what I have. Sound good? Say `yes` or `no`"
            }
          ]
        },

        enterMessage: 'yes'
      },

      {
        expect: {
          type: 'message',
          text: 'Got it!'
        },

        enterMessage: 'back'
      },

      {
        overwriteTest: function(expected, result) {
          expect(result.length).to.equal(1);
          delete result[0].callback_id;
          expect(result).to.deep.equal(expected);
          return true;
        },
        expect: {
          text: [
            {
              "actions": [
                {
                  "name": ":one:",
                  "style": "primary",
                  "text": ":one:",
                  "type": "button",
                  "value": ":one:"
                },
                {
                  "name": ":two:",
                  "style": "primary",
                  "text": ":two:",
                  "type": "button",
                  "value": ":two:"
                }
              ],
              "attachment_type": "default",
              "fallback": "Great! How should I ask them?",
              "color": "#DA552F",
              "fields": [
                {
                  "title": "Prompt types:",
                  "value": ":one: After meetings (GCal sign-in needed)\n:two: At regular time intervals (set manually)\n\nPick a button:",
                }
              ],
              "mrkdwn_in": [
                "fields",
                "pretext",
                "text"
              ],
              "pretext": "Great! How should I ask them?"
            }
          ]
        },

        enterMessage: 'back'
      },

      {
        expect: {
          type: 'message',
          text: "Cool, who would you like to get feedback from for this? \n\n:bulb:Tip: You can type @ to see a dropdown with all of your coworkers. Select as many as you want"
        },

        enterMessage: 'back'
      },

      {
        overwriteTest: function(expected, result) {
          expect(result.length).to.equal(1);
          delete result[0].callback_id;
          expect(result).to.deep.equal(expected);
          return true;
        },
        expect: {
          text: [
            {
              "actions": [
                {
                  "name": ":one:",
                  "style": "primary",
                  "text": ":one:",
                  "type": "button",
                  "value": ":one:"
                },
                {
                  "name": ":two:",
                  "style": "primary",
                  "text": ":two:",
                  "type": "button",
                  "value": ":two:"
                },
                {
                  "name": ":three:",
                  "style": "primary",
                  "text": ":three:",
                  "type": "button",
                  "value": ":three:"
                },
                {
                  "name": ":four:",
                  "style": "primary",
                  "text": ":four:",
                  "type": "button",
                  "value": ":four:"
                },
                {
                  "name": ":five:",
                  "style": "primary",
                  "text": ":five:",
                  "type": "button",
                  "value": ":five:"
                }
              ],
              "attachment_type": "default",
              "color": "#DA552F",
              "fallback": "Great, pick one of these Productivity suggested goals or write in your own!",
              "fields": [
                {
                  "title": "Suggested goals:",
                  "value": ":one: Pay close attention to detail\n:two: Know when to use existing solutions and resources without reinventing the wheel\n:three: Take on new projects and go above and beyond when faced with challenges\n:four: Take initiative to make things better, even outside of your day to day responsibilities\n:five: Manage time efficiently and consistently deliver on commitments\n\nPick a button. Or write in your own!"
                }
              ],
              "mrkdwn_in": [
                "fields",
                "pretext",
                "text"
              ],
              "pretext": "Great, pick one of these Productivity suggested goals or write in your own!"
            }
          ]
        },

        enterMessage: 'back'
      },

      {
        overwriteTest: function(expected, result) {
          expect(result.length).to.equal(1);
          delete result[0].callback_id;
          expect(result).to.deep.equal(expected);
          return true;
        },
        expect: {
          text: [
            {
              "actions": [
                {
                  "name": ":one:",
                  "style": "primary",
                  "text": ":one:",
                  "type": "button",
                  "value": ":one:"
                },
                {
                  "name": ":two:",
                  "style": "primary",
                  "text": ":two:",
                  "type": "button",
                  "value": ":two:"
                },
                {
                  "name": ":three:",
                  "style": "primary",
                  "text": ":three:",
                  "type": "button",
                  "value": ":three:"
                },
                {
                  "name": ":four:",
                  "style": "primary",
                  "text": ":four:",
                  "type": "button",
                  "value": ":four:"
                }
              ],
              "attachment_type": "default",
              "fallback": "Pick one of the following categories:",
              "color": "#DA552F",
              "fields": [
                {
                  "title": "Goal categories:",
                  "value": ":one: Communication\n:two: Productivity\n:three: Leadership and Managerial Skills\n:four: Attitude and Outlook\n\nSelect a button:"
                }
              ],
              "mrkdwn_in": [
                "fields",
                "pretext",
                "text"
              ],
              "pretext": "Pick one of the following categories:"
            }
          ]
        },

        enterMessage: 'back'
      },

      {
        overwriteTest: function(expected, result) {
          expect(result.length).to.equal(1);
          delete result[0].callback_id;
          expect(result).to.deep.equal(expected);
          return true;
        },
        expect: {
          text: [
            {
              "actions": [
                {
                  "name": ":one:",
                  "style": "primary",
                  "text": ":one:",
                  "type": "button",
                  "value": ":one:"
                },
                {
                  "name": ":two:",
                  "style": "primary",
                  "text": ":two:",
                  "type": "button",
                  "value": ":two:"
                },
                {
                  "name": ":three:",
                  "style": "primary",
                  "text": ":three:",
                  "type": "button",
                  "value": ":three:"
                },
                {
                  "name": ":four:",
                  "style": "primary",
                  "text": ":four:",
                  "type": "button",
                  "value": ":four:"
                },
                {
                  "name": ":five:",
                  "style": "primary",
                  "text": ":five:",
                  "type": "button",
                  "value": ":five:"
                }
              ],
              "attachment_type": "default",
              "color": "#DA552F",
              "fallback": "Pick a function:",
              "fields": [
                {
                  "title": "Job Functions:",
                  "value": ":one: Engineering\n:two: Operations\n:three: Product Management\n:four: Sales\n:five: Other\n\nPick a reaction:"
                }
              ],
              "mrkdwn_in": [
                "fields",
                "pretext",
                "text"
              ],
              "pretext": TaskGatherFunction.interactions[1].message.pretext
            }
          ]
        },

        enterMessage: 'back'
      },

      {
        expect: {
          type: 'message',
          text: 'Hmm, looks like I can\'t go back. Sorry about that! :slightly_frowning_face:'
        }
      }
    ];

    var iTest = new IntegrationTest(null, TestUser[4], TestUser, expected, function() {
      this.instance.listen(this.slackUserId, this.primaryChannel, 'add goal');

      // schedule a gather feedback, which will be only shown after add Goal is over
      // an extra test to make sure that make sure chainTask is working
      var theTask = _.cloneDeep(require('./../../bot/tasks/feedback/gather-feedback'));
      theTask.priority = 2;
      this.instance.handleQueue({
        slackUserId: this.slackUserId,
        task: theTask,
        context: {
          userFirstName: TestUser[3].firstName,
          appName: Config.appName,
          targetUserFirstName: TestUser[4].firstName,
          targetUserGoalName: 'TestGoal',
          slackUserId: this.slackUserId
        }
      });
    });

    before(() => {
      return iTest.before(function *(users) {
        users[4].jobFunction = undefined;
        users[4].manager = users[2].id;
        yield users[4].save();
      }.bind(this));
    });

    // generate Mocha "it" tests
    iTest.generateAllTests();
  });
});
