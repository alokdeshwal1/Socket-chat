//'use strict';
//
//const Chai = require('chai');
//const Sinon = require('sinon');
//const expect = Chai.expect;
//const Mockery = require('mockery');
//const EventEmitter = require('events').EventEmitter;
//const mockTalkingBot = require('./../mocks/mock-talking-bot');
//const TalkingBot = require('./../../../bot/talking-bot');
//const Task = require('./../../../bot/task');
//const theTask = require('./../../../bot/tasks/gather-goal');
//const Config = require('./../../../configs/config');
//const CONSTANTS = require('./../../../constants/constants');
//const teamName = 'eatravelive';
//const teamId = 'T0G9HMJK1';
//const teamKey = TalkingBot.getTeamKey(teamName, teamId);
//const accessToken = 'xoxb-23605291715-V9st3mnB44JfpJW1ZvsqIm41';
//const botName = 'LarkBot';
//const channelName = 'testChannel';
//const slackUserId = 'testUserId';
//const context = {
//  appName: Config.appName,
//  userFirstName: 'Elaine',
//  managerFirstName: 'Adrian',
//  companyName: 'Test Company',
//  companyId: '56d69dbaed275b88160d9878',
//  slackUserId: 'testUserId',
//  slackIntegrationId: 'testSlackIntegrationId'
//};
//var instance;
//
//// we use a dummy listener to delay the firing of Talking-Bot event
//// so that our tests could bind the bot events before being fired
//class Dummy extends EventEmitter {
//  constructor() {
//    super();
//  }
//}
//var dummyListener = new Dummy();
//
//describe('Bot: Task Gather Goal', function() {
//  before(function(done) {
//    try {
//      instance = mockTalkingBot(teamName, teamId, accessToken, botName, channelName);
//    }
//    catch (ex) {
//      console.og(ex);
//    }
//
//    instance.handleQueue({
//      slackUserId: slackUserId,
//      task: theTask,
//      context: context
//    }, done);
//  });
//
//  it('should fire greeting message', function(done) {
//    instance.dummyListener.once(CONSTANTS.BOT_EVENT.MESSAGE_POSTED, function() {
//      expect(instance.speak.lastCall.args[0]).to.equal(channelName);
//      expect(instance.speak.lastCall.args[1]).to.equal(Task.replaceMessagePlaceholder(
//        theTask.interactions[0].message, context));
//      done();
//    });
//  });
//
//  it('should ask for goal category', (done) => {
//    instance.dummyListener.once(CONSTANTS.BOT_EVENT.MESSAGE_POSTED, () => {
//      expect(instance.attachmentMessage.lastCall.args[1].message).to.deep.equal([
//        {
//          "color": "#DA552F",
//          "fallback": "Pick a category:",
//          "fields": [
//            {
//              "title": "Goal categories:",
//              "value": "\n:one: Productivity\n:two: Core Values\n:three: Technical Skills\n:four: Communication\n:five: Leadership\n\nPick a reaction:"
//            }
//          ],
//          "pretext": ""
//        }
//      ]);
//      done();
//    });
//  });
//
//  it('should ask for selecting goal competencies after picking one', (done) => {
//    // select a job category
//    instance.listen(slackUserId, channelName, '4');
//
//    instance.dummyListener.once(CONSTANTS.BOT_EVENT.MESSAGE_POSTED, () => {
//      expect(instance.attachmentMessage.lastCall.args[1].message).to.deep.equal([
//          {
//            "color": "#DA552F",
//            "fallback": "Pick a goal:",
//            "fields": [
//              {
//                "title": "Suggested goals:",
//                "value": "\n:one: Follow through reliably\n:two: Confidently make decisions & present\n:three: Approach with a positive attitude\n:four: Be result-oriented\n:five: Take initiative above and beyond\n:six: Work collaboratively in teams\n:seven: Communicate clearly & appropriately\n:eight: Think strategically and big-picture\n:nine: Develop designs with usability focus\n:keycap_ten: Other\n\nPick a reaction. Or write in your own!"
//              }
//            ],
//            "pretext": "Great, pick one of these Communication suggested goals or write in your own!"
//          }
//        ]);
//      done();
//    });
//  });
//
//  it('should able to go to next page with input 10', function(done) {
//    // go to next page
//    instance.listen(slackUserId, channelName, 'ten');
//
//    instance.dummyListener.once(CONSTANTS.BOT_EVENT.MESSAGE_POSTED, function() {
//      expect(instance.attachmentMessage.lastCall.args).to.deep.equal([
//        "testChannel",
//        [
//          {
//            "fallback": "OK, is it one of these?",
//            "color": "#DA552F",
//            "pretext": "OK, is it one of these?",
//            "fields": [
//              {
//                "value": "10.  Translate business goals to product\n\nPick any function from 1-10. Or write in your own!"
//              }
//            ],
//            "mrkdwn_in": [
//              "fields",
//              "pretext"
//            ]
//          }
//        ]
//      ]);
//
//      done()
//    });
//  });
//
//  it('should proceed to asking for advisors when a goal is entered', function(done) {
//    // go to next page
//    instance.listen(slackUserId, channelName, 'Be more diligent on my follow-throughs');
//
//    instance.dummyListener.once(CONSTANTS.BOT_EVENT.MESSAGE_POSTED, function() {
//      expect(instance.speak.lastCall.args[1]).to.deep.equal("Cool, who would you like to get feedback from for this? (Slack names please)");
//      done()
//    });
//  });
//
//  it('should proceed to asking for trigger options with correct input of users', function(done) {
//    // go to next page
//    instance.listen(slackUserId, channelName, 'testUser2');
//
//    instance.dummyListener.once(CONSTANTS.BOT_EVENT.MESSAGE_POSTED, function() {
//      expect( instance.attachmentMessage.lastCall.args[1].message).to.deep.equal([
//        {
//          "color": "#DA552F",
//          "fallback": "Pick a prompt",
//          "fields": [
//            {
//              "title": "Prompt types:",
//              "value": "\n:one: After meetings (GCal sign-in needed)\n:two: At regular time intervals (set manually)\n\nPick a reaction:"
//            }
//          ],
//          "pretext": "Great! How should I ask them?"
//        }
//      ]);
//      done()
//    });
//  });
//});