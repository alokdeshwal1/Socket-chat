//'use strict';
//
//mock(); // this has to run at the top
//const Mockery = require('mockery');
//const Chai = require('chai');
//const Sinon = require('sinon');
//const expect = Chai.expect;
//const EventEmitter = require('events').EventEmitter;
//const mockTalkingBot = require('./../mocks/mock-talking-bot');
//const TalkingBot = require('./../../../bot/talking-bot');
//const Task = require('./../../../bot/task');
//const taskGatherFunction = require('./../../../bot/tasks/gather-function');
//const taskGatherGoal = require('./../../../bot/tasks/gather-goal');
//const taskGatherManualTrigger = require('./../../../bot/tasks/gather-manual-trigger');
//const taskGatherGoalRepeat = require('./../../../bot/tasks/gather-goal-repeat');
//const BotMessages = require('./../../../configs/bot-messages');
//const Config = require('./../../../configs/config');
//const CONSTANTS = require('./../../../constants/constants');
//const teamName = 'eatravelive';
//const teamId = 'T0G9HMJK1';
//const teamKey = TalkingBot.getTeamKey(teamName, teamId);
//const accessToken = 'xoxb-23605291715-V9st3mnB44JfpJW1ZvsqIm41';
//const botName = 'LarkBot';
//const channelName = 'testChannel';
//const slackUserId = 'testUserId';
//const context = {
//  appName: Config.appName,
//  userFirstName: 'Elaine',
//  managerFirstName: 'Adrian',
//  companyName: 'Test Company',
//  companyId: '56d69dbaed275b88160d9878',
//  slackUserId: 'testUserId'
//};
//var instance;
//
//describe('Bot: FTUE Flow End-to-End', function() {
//  before(function() {
//    try {
//      instance = mockTalkingBot(teamName, teamId, accessToken, botName, channelName);
//    }
//    catch (ex) {
//      console.log(ex);
//    }
//  });
//
//  after(function() {
//    Mockery.deregisterAll();
//  });
//
//  it('FTUE flow with one trigger and goal', function(done) {
//    //expect(instance.speak.lastCall.args[0]).to.equal(channelName);
//    //expect(instance.speak.lastCall.args[1]).to.equal(Task.replaceMessagePlaceholder(
//    //  taskGatherFunction.interactions[0].message, context));
//
//    var expected = [
//      {
//        expect: {
//          type: 'message',
//          text: "Great, can you tell me what kind of meetings? Here are types of things that I understand " +
//          "(I\'m working on it but I\'m a bot after all :):\n" +
//          "`organized by katies`\n" +
//          "`has more than 5 people`\n" +
//          "`has richer erlich and ashley`\n" +
//          "`name has product sync`"
//        },
//
//        enterMessage: 'mtgs where name has design sync and attendees laurens and kevin'
//      },
//      {
//        expect: {
//          type: 'attachmentMessage',
//          text: '[{\"fallback\":\"Pick one of Test Company\'s functions:\",\"color\":\"#DA552F\",\"pretext\":\"First, what is your job function? Here are Test Company\' functions:\",\"fields\":[{\"title\":\"Job Functions: \",\"value\":\":one: Design\\n:two: Sales\\n:three: People Ops\\n:four: Customer Success\\n:five: Marketing\\n:six: Product Management\\n:seven: Engineering\\n:eight: Recruiting\\n:nine: People Ops\\n:keycap_ten: Other\\n\\nPick one by tapping on a reaction:\"}]}]'
//        },
//
//        enterMessage: 'yes'
//      },
//      {
//        expect: {
//          type: 'message',
//          text: 'Great! Now tell me - what\'s skill or goal you\'re currently working on and would like to get guidance from your coworkers on?'
//        }
//      },
//      {
//        expect: {
//          type: 'attachmentMessage',
//          text: "[{\"fallback\":\"Pick one of Test Company's goal categories:\",\"color\":\"#DA552F\",\"pretext\":\"Pick one of the following categories:\",\"fields\":[{\"title\":\"Categories: \",\"value\":\":one: Productivity\\n:two: Core Values\\n:three: Technical Skills\\n:four: Communication\\n:five: Leadership\\n\\nPick one by tapping on a reaction:\"}]}]"
//        }
//      }
//    ];
//
//    var result = [];
//    var counter = 0;
//    instance.dummyListener.on(CONSTANTS.BOT_EVENT.MESSAGE_POSTED, () => {
//      if (expected[counter].expect.type === 'message') {
//        result.push(instance.speak.lastCall.args);
//      }
//      else if(expected[counter].expect.type === 'attachmentMessage') {
//        result.push(instance.attachmentMessage.lastCall.args);
//      }
//      else {
//        throw new Error('expect.type is required');
//      }
//
//      if(expected[counter] && expected[counter].enterMessage) {
//        instance.listen(slackUserId, channelName, expected[counter].enterMessage);
//      }
//
//      counter++;
//      if (counter >= expected.length) {
//        result.forEach((item, key)=> {
//          var value = item[1];
//          if (Array.isArray(value)) {
//            value = JSON.stringify(value);
//          }
//          expect(value).to.equal(expected[key].expect.text);
//        });
//
//        done();
//      }
//    });
//
//
//    instance.handleQueue({
//      slackUserId: slackUserId,
//      task: taskGatherFunction,
//      context: context
//    });
//
//  });
//
//});
//
//function mock() {
//  const Mockery = require('mockery');
//  const Sinon = require('sinon');
//  const path = require('path');
//  const fs = require('fs');
//
//  fs.readdirSync(path.join(__dirname, './../../../bot/persist')).forEach(function(file) {
//    var klass = require('./../../../bot/persist/'+ file);
//    if (klass.saveToDb && ! klass.saveToDb.isSinonProxy) {
//      if (klass.name === 'PersistGatherGoal') {
//        Sinon.stub(klass, 'saveToDb', function(context) {
//          context.goal = {
//            _id: 'testGoalId'
//          };
//          return Promise.resolve(true);
//        });
//      }
//      else {
//        Sinon.stub(klass, 'saveToDb', function(context) {
//          return Promise.resolve(true);
//        });
//      }
//    }
//
//    Mockery.registerMock('./persist/'+ file.replace('.js', ''), klass);
//  });
//}