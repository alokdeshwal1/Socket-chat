'use strict';


const Chai = require('chai');
const Sinon = require('sinon');
const expect = Chai.expect;
const Mockery = require('mockery');
const EventEmitter = require('events').EventEmitter;
const mockTalkingBot = require('./../mocks/mock-talking-bot');
const TalkingBot = require('./../../../bot/talking-bot');
const Task = require('./../../../bot/task');
const Helper = require('./../../../bot/libs/helper');
const theTask = require('./../../../bot/tasks/feedback/gather-manual-trigger');
const Config = require('./../../../configs/config');
const CONSTANTS = require('./../../../constants/constants');
const BotMessages = require('./../../../configs/bot-messages');
const teamName = 'eatravelive';
const teamId = 'T0G9HMJK1';
const teamKey = TalkingBot.getTeamKey(teamName, teamId);
const accessToken = 'xoxb-23605291715-V9st3mnB44JfpJW1ZvsqIm41';
const botName = 'LarkBot';
const channelName = 'testChannel';
const slackUserId = 'testUserId';
const TestUser = require('./../configs/user');

const context = {
  appName: Config.appName,
  slackUserId: TestUser[0].slackUserId,
  slackIntegrationId: TestUser[0].slackIntegration,
  goal: {
    _id: 'testGoalId'
  }
};

var instance;

// we use a dummy listener to delay the firing of Talking-Bot event
// so that our tests could bind the bot events before being fired
class Dummy extends EventEmitter {
  constructor() {
    super();
  }
}
var dummyListener = new Dummy();

describe('Bot: Task Gather Manual Trigger', function() {
  before(function(done) {
    mock();

    try {
      instance = mockTalkingBot(teamName, teamId, accessToken, botName, channelName);
    }
    catch (ex) {
      console.og(ex);
    }

    instance.handleQueue({
      slackUserId: slackUserId,
      task: theTask,
      context: context
    }, done);
  });

  after(function() {
    Mockery.deregisterAll();
  });

  it('should fire the instruction message', function(done) {
    instance.dummyListener.once(CONSTANTS.BOT_EVENT.MESSAGE_POSTED, function() {
      expect(instance.speak.lastCall.args[0]).to.equal(channelName);
      expect(instance.speak.lastCall.args[1]).to.equal(Helper.replaceMessagePlaceholder(
        theTask.interactions[0].message, context));
      done();
    });
  });

  it('should show incorrect input message', (done) => {
    // go to next page
    instance.listen(slackUserId, channelName, 'blah blah blah');

    instance.dummyListener.once(CONSTANTS.BOT_EVENT.MESSAGE_POSTED, () => {
      expect(instance.speak.lastCall.args[0]).to.equal(channelName);
      expect(instance.speak.lastCall.args[1]).to.equal(BotMessages.Validation.recurrenceDate());

      done();
    });
  });

  it('should show confirmation for sample dates', (done) => {
    // go to next page
    instance.listen(slackUserId, channelName, 'every monday at 11:50AM');

    instance.dummyListener.once(CONSTANTS.BOT_EVENT.MESSAGE_POSTED, () => {
      expect(instance.attachmentMessage.lastCall.args[0]).to.equal(channelName);
      expect(instance.attachmentMessage.lastCall.args[1][0].pretext).to.equal('Cool, this is what I have. Sound good? Say `yes` or `no`');
      expect(instance.attachmentMessage.lastCall.args[1][0].fields.length).to.be.above(0);

      done();
    });
  });

  it('should end interaction when a yes is entered', (done) => {
    instance.listen(slackUserId, channelName, 'yes');

    instance.dummyListener.once(CONSTANTS.BOT_EVENT.MESSAGE_POSTED, () => {
      expect(instance.speak.lastCall.args[0]).to.equal(channelName);
      expect(instance.speak.lastCall.args[1]).to.equal('Got it!');

      done()
    });

    // @TODO - need to stub persist hook in order to get the DONE function fired

    //instance.dummyListener.once(CONSTANTS.BOT_EVENT.END, function(taskName) {
    //  expect(taskName).to.equal(theTask.name);
    //  done()
    //});
  });


});

function mock() {
  const Sinon = require('sinon');
  const Mockery = require('mockery');
  const ValidationGatherUser = require('./../../../bot/validations/gather-user');
  if ( ! ValidationGatherUser.prototype.validate.isSinonProxy) {
    Sinon.stub(ValidationGatherUser.prototype, 'validate').returns(new Promise((resolve, reject) => {
      return resolve({
        status: 'success',
        result: {
          _id: 'testUserId2'
        }
      })
    }));

    Mockery.registerMock('./../validations/gather-user', ValidationGatherUser);
  }

  //const ModelUser = require('./../../../models/user');
  //if ( ! ModelUser.prototype.validate.isSinonProxy) {
  //  Sinon.stub(ModelUser, 'findBySlackId').returns(new Promise((resolve, reject) => {
  //    return resolve({
  //      slackUserId: 'testUserId',
  //      firstName: 'test',
  //      lastName: 'test',
  //      timezone: 'America/Los_Angeles'
  //    })
  //  }));
  //
  //  Mockery.registerMock('./../validations/gather-user', ValidationGatherUser);
  //}
}