const Chai = require('chai');
const Sinon = require('sinon');
const expect = Chai.expect;
const Task = require('./../../bot/task');

describe('Task', function() {
  describe('back', () => {
    it('should go back to previous interaction', () => {
      var taskConfig = {
        name: 'AddGoal',
        priority: 2,
        step: 2,
        interactions: [
          {
            type: 'ActionMessage',
            message: "Sure! First, let's select a category to see a list of suggested goals. If you'd like to add your own custom goal, go ahead and select a category, and you can write in your goal in the next step."
          },
          {
            type: 'ActionGatherGoalCategory',
            message: 'Pick one of the following categories:'
          },
          {
            type: 'ActionGatherGoalCompetency',
            message: '[[companyName]]\'s [[goalCategoryName]] competencies:'
          }
        ]
      };

      var instance = new Task(taskConfig, { companyId: 'testCompanyId', 'companyName': 'testCompanyName' });
      expect(instance.step).to.equal(2);
      expect(instance.back()).to.equal(true);
      expect(instance.step).to.equal(1);
    });

    it('should go back to interaction that requires action', () => {
      var taskConfig = {
        name: 'AddGoal',
        priority: 2,
        step: 2,
        interactions: [
          {
            type: 'ActionGatherGoalCategory',
            message: 'Pick one of the following categories:'
          },
          {
            type: 'ActionMessage',
            message: "Sure! First, let's select a category to see a list of suggested goals. If you'd like to add your own custom goal, go ahead and select a category, and you can write in your goal in the next step."
          },
          {
            type: 'ActionGatherGoalCompetency',
            message: '[[companyName]]\'s [[goalCategoryName]] competencies:'
          }
        ]
      };

      var instance = new Task(taskConfig, { companyId: 'testCompanyId', 'companyName': 'testCompanyName' });
      expect(instance.step).to.equal(2);
      expect(instance.back()).to.equal(true);
      expect(instance.step).to.equal(0);
    });

    it('should return false if cannot go back anymore', () => {
      var taskConfig = {
        name: 'AddGoal',
        priority: 2,
        step: 0,
        interactions: [
          {
            type: 'ActionGatherGoalCategory',
            message: 'Pick one of the following categories:'
          },
          {
            type: 'ActionMessage',
            message: "Sure! First, let's select a category to see a list of suggested goals. If you'd like to add your own custom goal, go ahead and select a category, and you can write in your goal in the next step."
          },
          {
            type: 'ActionGatherGoalCompetency',
            message: '[[companyName]]\'s [[goalCategoryName]] competencies:'
          }
        ]
      };

      var instance = new Task(taskConfig, { companyId: 'testCompanyId', 'companyName': 'testCompanyName' });
      expect(instance.step).to.equal(0);
      expect(instance.back()).to.equal(false);
    });
  });

});
