'use strict';

const Mockery = require('mockery');
const Chai = require('chai');
const Sinon = require('sinon');
const expect = Chai.expect;
const command = require('./../../../bot/commands/summary');
const moment = require('moment-timezone');
var instance;

const tests = [
  function(timezone) {
    it('should parse "summary weekly/weekly summary for team"', function() {
      ['summary weekly for team', 'weekly summary for team '].forEach(message => {
        var intent = new command(timezone).parse(message);
        expect(intent.context).to.be.an('object');
        expect(intent.context.summary.isTeamSummary).to.equal(true);
        expect(intent.context.summary.startDate).to.equal(moment().utc().subtract(7, 'days').format());
        expect(intent.context.summary.endDate).to.equal(moment().utc().format());
      });
    });
  },

  function(timezone) {
    it('should parse "summary weekly/weekly summary for [user]"', function() {
      ['summary weekly for elaine', 'summary weekly for @elaine', 'weekly summary for elaine', 'weekly summary for @elaine'].forEach(message => {
        var intent = new command(timezone).parse(message);
        expect(intent.context).to.be.an('object');
        expect(intent.context.summary.isTeamSummary).to.equal(undefined);
        expect(intent.context.summary.startDate).to.equal(moment().utc().subtract(7, 'days').format());
        expect(intent.context.summary.endDate).to.equal(moment().utc().format());
        expect(intent.context.summary.user).to.equal('elaine');
      });
    });
  },

  function(timezone) {
    it('should parse "summary monthly/monthly summary for [user]"', function() {
      ['summary monthly for elaine', 'summary monthly for @elaine', 'monthly summary for elaine', 'monthly summary for @elaine'].forEach(message => {
        var intent = new command(timezone).parse(message);
        expect(intent.context).to.be.an('object');
        expect(intent.context.summary.isTeamSummary).to.equal(undefined);
        expect(intent.context.summary.startDate).to.equal(moment().utc().subtract(1, 'months').format());
        expect(intent.context.summary.endDate).to.equal(moment().utc().format());
        expect(intent.context.summary.user).to.equal('elaine');
      });
    });
  },

  function(timezone) {
    it('should parse "summary monthly/monthly summary for [user]"', function() {
      ['summary monthly for <@elaine>', 'summary monthly for <@elaine>', 'monthly summary for <@elaine>', 'monthly summary for <@elaine>'].forEach(message => {
        var intent = new command(timezone).parse(message);
        expect(intent.context).to.be.an('object');
        expect(intent.context.summary.isTeamSummary).to.equal(undefined);
        expect(intent.context.summary.startDate).to.equal(moment().utc().subtract(1, 'months').format());
        expect(intent.context.summary.endDate).to.equal(moment().utc().format());
        expect(intent.context.summary.user).to.equal('<@elaine>');
      });
    });
  },

  function(timezone) {
    it('should parse "summary for [user]"', function() {
      ['summary for elaine', 'summary for @elaine'].forEach(message => {
        var intent = new command(timezone).parse(message);
        expect(intent.context).to.be.an('object');
        expect(intent.context.summary.isTeamSummary).to.equal(undefined);
        expect(intent.context.summary.startDate).to.equal(moment().utc().subtract(7, 'days').format());
        expect(intent.context.summary.endDate).to.equal(moment().utc().format());
        expect(intent.context.summary.user).to.equal('elaine');
      });
    });
  },

  function(timezone) {
    it('should parse "summary weekly for <@user>"', function() {
      ['summary weekly for <@elaine>'].forEach(message => {
        var intent = new command(timezone).parse(message);
        expect(intent.context).to.be.an('object');
        expect(intent.context.summary.isTeamSummary).to.equal(undefined);
        expect(intent.context.summary.startDate).to.equal(moment().utc().subtract(7, 'days').format());
        expect(intent.context.summary.endDate).to.equal(moment().utc().format());
        expect(intent.context.summary.user).to.equal('<@elaine>');
      });
    });
  },

  function(timezone) {
    it('should parse "summary"', function() {
      ['summary'].forEach(message => {
        var intent = new command(timezone).parse(message);
        expect(intent.context).to.be.an('object');
        expect(intent.context.summary.isTeamSummary).to.equal(undefined);
        expect(intent.context.summary.user).to.equal(undefined);
        expect(intent.context.summary.startDate).to.equal(moment().utc().subtract(7, 'days').format());
        expect(intent.context.summary.endDate).to.equal(moment().utc().format());
      });
    });
  },

  function(timezone) {
    it('should parse "my summary" "my feedback"', function() {
      ['my summary', 'my feedback'].forEach(message => {
        var intent = new command(timezone).parse(message);
        expect(intent.context).to.be.an('object');
        expect(intent.context.summary.isTeamSummary).to.equal(undefined);
        expect(intent.context.summary.user).to.equal('I');
        expect(intent.context.summary.startDate).to.equal(moment().utc().subtract(7, 'days').format());
        expect(intent.context.summary.endDate).to.equal(moment().utc().format());
      });
    });
  },

  function(timezone) {
    it('should parse "weekly summary"', function() {
      ['weekly summary'].forEach(message => {
        var intent = new command(timezone).parse(message);
        expect(intent.context).to.be.an('object');
        expect(intent.context.summary.isTeamSummary).to.equal(undefined);
        expect(intent.context.summary.user).to.equal(undefined);
        expect(intent.context.summary.startDate).to.equal(moment().utc().subtract(7, 'days').format());
        expect(intent.context.summary.endDate).to.equal(moment().utc().format());
      });
    });
  },

  function(timezone) {
    it('should parse "monthly summary"', function() {
      ['monthly summary'].forEach(message => {
        var intent = new command(timezone).parse(message);
        expect(intent.context).to.be.an('object');
        expect(intent.context.summary.isTeamSummary).to.equal(undefined);
        expect(intent.context.summary.user).to.equal(undefined);
        expect(intent.context.summary.startDate).to.equal(moment().utc().subtract(1, 'months').format());
        expect(intent.context.summary.endDate).to.equal(moment().utc().format());
      });
    });
  },

  function(timezone) {
    it('should parse "summary today"', function() {
      ['summary today'].forEach(message => {
        var intent = new command(timezone).parse(message);
        expect(intent.context).to.be.an('object');
        expect(intent.context.summary.isTeamSummary).to.equal(undefined);
        expect(intent.context.summary.user).to.equal(undefined);
        expect(intent.context.summary.startDate).to.equal(moment().utc().hours(0).minutes(0).seconds(0).format());
        expect(intent.context.summary.endDate).to.equal(moment().utc().hours(23).minutes(59).seconds(59).format());
      });
    });
  },

  function(timezone) {
    it('should parse "summary active"', function() {
      ['summary active'].forEach(message => {
        var intent = new command(timezone).parse(message);
        expect(intent.context).to.be.an('object');
        expect(intent.context.summary.isTeamSummary).to.equal(undefined);
        expect(intent.context.summary.user).to.equal(undefined);
        expect(intent.context.summary.status).to.equal('active');
        expect(intent.context.summary.startDate).to.equal(moment().utc().subtract(7, 'days').format());
        expect(intent.context.summary.endDate).to.equal(moment().utc().format());
      });
    });
  },

  function(timezone) {
    it('should parse "summary archived"', function() {
      ['summary archived'].forEach(message => {
        var intent = new command(timezone).parse(message);
        expect(intent.context).to.be.an('object');
        expect(intent.context.summary.isTeamSummary).to.equal(undefined);
        expect(intent.context.summary.user).to.equal(undefined);
        expect(intent.context.summary.status).to.equal('archived');
        expect(intent.context.summary.startDate).to.equal(moment().utc().subtract(7, 'days').format());
        expect(intent.context.summary.endDate).to.equal(moment().utc().format());
      });
    });
  },

  function(timezone) {
    it('should parse "summary weekly/weekly summary for [user] from [fromUser]"', function() {
      ['summary weekly for elaine from adrian', 'summary weekly for @elaine from @adrian',
        'weekly summary for elaine from adrian', 'weekly summary for @elaine from @adrian'].forEach(message => {
        var intent = new command(timezone).parse(message);
        expect(intent.context).to.be.an('object');
        expect(intent.context.summary.isTeamSummary).to.equal(undefined);
        expect(intent.context.summary.startDate).to.equal(moment().utc().subtract(7, 'days').format());
        expect(intent.context.summary.endDate).to.equal(moment().utc().format());
        expect(intent.context.summary.user).to.equal('elaine');
        expect(intent.context.summary.fromUser).to.equal('adrian');
      });
    });
  },

  function(timezone) {
    it('should parse "summary weekly for [user] from [fromUser] active"', function() {
      ['summary weekly for elaine from adrian active', 'summary weekly for @elaine from @adrian active'].forEach(message => {
        var intent = new command(timezone).parse(message);
        expect(intent.context).to.be.an('object');
        expect(intent.context.summary.isTeamSummary).to.equal(undefined);
        expect(intent.context.summary.startDate).to.equal(moment().utc().subtract(7, 'days').format());
        expect(intent.context.summary.endDate).to.equal(moment().utc().format());
        expect(intent.context.summary.user).to.equal('elaine');
        expect(intent.context.summary.fromUser).to.equal('adrian');
        expect(intent.context.summary.status).to.equal('active');
      });
    });

    it('should parse "summary weekly for [user] from [fromUser] archived"', function() {
      ['summary weekly for elaine from adrian archived', 'summary weekly for @elaine from @adrian archived'].forEach(message => {
        var intent = new command(timezone).parse(message);
        expect(intent.context).to.be.an('object');
        expect(intent.context.summary.isTeamSummary).to.equal(undefined);
        expect(intent.context.summary.startDate).to.equal(moment().utc().subtract(7, 'days').format());
        expect(intent.context.summary.endDate).to.equal(moment().utc().format());
        expect(intent.context.summary.user).to.equal('elaine');
        expect(intent.context.summary.fromUser).to.equal('adrian');
        expect(intent.context.summary.status).to.equal('archived');
      });
    });
  },

  function(timezone) {
    it('should parse "summary monthly for [user] from [fromUser]"', function() {
      ['summary monthly for elaine from adrian', 'summary monthly for @elaine from @adrian'].forEach(message => {
        var intent = new command(timezone).parse(message);
        expect(intent.context).to.be.an('object');
        expect(intent.context.summary.isTeamSummary).to.equal(undefined);
        expect(intent.context.summary.startDate).to.equal(moment().utc().subtract(1, 'months').format());
        expect(intent.context.summary.endDate).to.equal(moment().utc().format());
        expect(intent.context.summary.user).to.equal('elaine');
        expect(intent.context.summary.fromUser).to.equal('adrian');
      });
    });
  },

  function(timezone) {
    it('should parse "summary archived"', function() {
      ['summary archived'].forEach(message => {
        var intent = new command(timezone).parse(message);
        expect(intent.context.summary.startDate).to.equal(moment().utc().subtract(7, 'days').format());
        expect(intent.context.summary.endDate).to.equal(moment().utc().format());
        expect(intent.context.summary.user).to.equal(undefined);
        expect(intent.context.summary.fromUser).to.equal(undefined);
        expect(intent.context.summary.status).to.equal('archived');
      });
    });
  },

  function(timezone) {
    it('should parse "summary for me archived"', function() {
      ['summary for me archived'].forEach(message => {
        var intent = new command(timezone).parse(message);
        expect(intent.context.summary.startDate).to.equal(moment().utc().subtract(7, 'days').format());
        expect(intent.context.summary.endDate).to.equal(moment().utc().format());
        expect(intent.context.summary.user).to.equal("I");
        expect(intent.context.summary.fromUser).to.equal(undefined);
        expect(intent.context.summary.status).to.equal('archived');
      });
    });
  },

  function(timezone) {
    it('should parse "summary for ellen from me"', function() {
      ['summary for ellen from me'].forEach(message => {
        var intent = new command(timezone).parse(message);
        expect(intent.context.summary.startDate).to.equal(moment().utc().subtract(7, 'days').format());
        expect(intent.context.summary.endDate).to.equal(moment().utc().format());
        expect(intent.context.summary.user).to.equal("ellen");
        expect(intent.context.summary.fromUser).to.equal("I");
        expect(intent.context.summary.status).to.equal(undefined);
      });
    });
  },


  function(timezone) {
    it('should NOT parse "summary whatever"', function() {
      ['summary whatever'].forEach(message => {
        var intent = new command(timezone).parse(message);
        expect(intent).to.equal(null);
      });
    });
  }
];

describe('Bot: Command Summary', () => {
  describe('No timezone specified', () => {
    tests.forEach(test => {
      test.call(this);
    });
  });

  describe('Timezone: "America/Los_Angeles"', () => {
    var timezone = 'America/Los_Angeles';
    tests.forEach(test => {
      test.call(this, timezone);
    });
  });

  describe('Timezone: "US/Eastern"', () => {
    var timezone = 'US/Eastern';
    tests.forEach(test => {
      test.call(this, timezone);
    });
  });

});
