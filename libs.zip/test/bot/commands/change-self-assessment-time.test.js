'use strict';

const Mockery = require('mockery');
const Chai = require('chai');
const Sinon = require('sinon');
const expect = Chai.expect;
const command = require('./../../../bot/commands/change-self-assessment-time');
const moment = require('moment');
var instance;

describe('Bot: Change Self Assessment Time', function() {
  beforeEach(function() {
    instance = new command();
  });

  it('should parse "change self assessment time"', function() {
    ['change self assessment time', 'update self assessment time', 'change assessment time'].forEach(message => {
      var intent = new command().parse(message);
      expect(intent.task.name).to.equal('ChangeSelfAssessmentTime');
    });
  });

});
