'use strict';

const Mockery = require('mockery');
const Chai = require('chai');
const Sinon = require('sinon');
const expect = Chai.expect;
const command = require('./../../../bot/commands/goal-crud');
const moment = require('moment');
var instance;

describe('Bot: Goal Edit, Archive, Delete', function() {
  beforeEach(function() {
    instance = new command();
  });

  it('should parse "archive goal"', function() {
    ['archive goal', 'archive goal ', 'archive goals', 'archive a goal', 'complete goal', 'finish goal', 'end goal'].forEach(message => {
      var intent = new command().parse(message);
      expect(intent.task.name).to.equal('ArchiveGoal');
    });
  });

  it('should parse "delete goal"', function() {
    ['delete goal', 'delete goal ', 'delete a goal', 'delete goals'].forEach(message => {
      var intent = new command().parse(message);
      expect(intent.task.name).to.equal('DeleteGoal');
    });
  });

  //it('should parse "edit goal"', function() {
  //  ['edit goal', 'edit goal ', 'edit a goal', 'change goal', 'change a goal', 'change goals', 'edit goals'].forEach(message => {
  //    var intent = new command().parse(message);
  //    expect(intent.task.name).to.equal('EditGoal');
  //  });
  //});

  it('should parse "add goal"', function() {
    ['add goal', 'add goal ', 'add a goal', 'add new goal', 'add goals', 'add new goals', 'new goal', 'new goals', 'create new goals', 'create a new goal'].forEach(message => {
      var intent = new command().parse(message);
      expect(intent.task.name).to.equal('AddGoal');
    });
  });

});
