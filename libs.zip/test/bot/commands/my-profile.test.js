'use strict';

const Mockery = require('mockery');
const Chai = require('chai');
const Sinon = require('sinon');
const expect = Chai.expect;
const command = require('./../../../bot/commands/my-profile');
const moment = require('moment');
var instance;

describe('Bot: My Profile', function() {
  beforeEach(function() {
    instance = new command();
  });

  it('should parse "my profile"', function() {
    ['my profile', 'my profiles'].forEach(message => {
      var intent = new command().parse(message);
      expect(intent.task.name).to.equal('MyProfile');
    });
  });

  it('should parse "view my profile"', function() {
    ['view my profile', 'view my profiles'].forEach(message => {
      var intent = new command().parse(message);
      expect(intent.task.name).to.equal('MyProfile');
    });
  });
});
