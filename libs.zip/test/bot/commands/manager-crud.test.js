'use strict';

const Mockery = require('mockery');
const Chai = require('chai');
const Sinon = require('sinon');
const expect = Chai.expect;
const command = require('./../../../bot/commands/manager-crud');
const moment = require('moment');
var instance;

describe('Bot: Manager Add Remove', function() {
  beforeEach(function() {
    instance = new command();
  });

  it('should parse "change manager [managerName]"', function() {
    ['change manager ericl'].forEach(message => {
      var intent = new command().parse(message);
      expect(intent.task.name).to.equal('ChangeManager');
      expect(intent.context.changeManagerSlackUserName).to.equal('ericl');
    });
  });

  it('should parse "change manager @[managerName]"', function() {
    ['change manager @jamesd'].forEach(message => {
      var intent = new command().parse(message);
      expect(intent.task.name).to.equal('ChangeManager');
      expect(intent.context.changeManagerSlackUserName).to.equal('jamesd');
    });
  });

  it('should parse "change manager <@[managerUserId]>"', function() {
    ['change manager <@managerUserId>'].forEach(message => {
      var intent = new command().parse(message);
      expect(intent.task.name).to.equal('ChangeManager');
      expect(intent.context.changeManagerSlackUserId).to.equal('managerUserId');
    });
  });

  it('should parse "change manager <@[managerUserId]>:"', function() {
    ['change manager <@managerUserId>'].forEach(message => {
      var intent = new command().parse(message);
      expect(intent.task.name).to.equal('ChangeManager');
      expect(intent.context.changeManagerSlackUserId).to.equal('managerUserId');
    });
  });

  it('should parse "add manager [managerName]"', function() {
    ['add manager peter'].forEach(message => {
      var intent = new command().parse(message);
      expect(intent.task.name).to.equal('AddManager');
      expect(intent.context.addManagerSlackUserName).to.equal('peter');
    });
  });

  it('should parse "add manager @[managerName]"', function() {
    ['add manager @alexm'].forEach(message => {
      var intent = new command().parse(message);
      expect(intent.task.name).to.equal('AddManager');
      expect(intent.context.addManagerSlackUserName).to.equal('alexm');
    });
  });

  it('should parse "add manager <@[managerUserId]>"', function() {
    ['add manager <@managerUserId>'].forEach(message => {
      var intent = new command().parse(message);
      expect(intent.task.name).to.equal('AddManager');
      expect(intent.context.addManagerSlackUserId).to.equal('managerUserId');
    });
  });

  it('should parse "add manager <@[managerUserId]>:"', function() {
    ['add manager <@managerUserId>:'].forEach(message => {
      var intent = new command().parse(message);
      expect(intent.task.name).to.equal('AddManager');
      expect(intent.context.addManagerSlackUserId).to.equal('managerUserId');
    });
  });
});
