'use strict';

const Mockery = require('mockery');
const Chai = require('chai');
const Sinon = require('sinon');
const expect = Chai.expect;
const command = require('./../../../bot/commands/advisor-crud');
const moment = require('moment');
var instance;

describe('Bot: Advisor Remove', function() {
  beforeEach(function() {
    instance = new command();
  });

  it('should parse "take me off as reviewer"', function() {
    ['take me off as reviewer', 'take me off as a reviewer'].forEach(message => {
      var intent = new command().parse(message);
      expect(intent.task.name).to.equal('RemoveAdvisor');
      expect(intent.context.removeAdvisor).to.equal(undefined);
    });
  });

  it('should parse "take me off as reviewer @peter"', function() {
    ['take me off as reviewer @peter', 'I no longer want to review @peter'].forEach(message => {
      var intent = new command().parse(message);
      expect(intent.task.name).to.equal('RemoveAdvisor');
      expect(intent.context.removeAdvisorSlackUserName).to.equal('peter');
    });
  });

  it('should parse "take me off as reviewer <@peter>"', function() {
    ['take me off as reviewer <@utest.3_->', 'I no longer want to review <@utest.3_->'].forEach(message => {
      var intent = new command().parse(message);
      expect(intent.task.name).to.equal('RemoveAdvisor');
      expect(intent.context.removeAdvisorSlackUserId).to.equal('utest.3_-');
    });
  });

});