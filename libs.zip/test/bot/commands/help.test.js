'use strict';

const Mockery = require('mockery');
const Chai = require('chai');
const Sinon = require('sinon');
const expect = Chai.expect;
const command = require('./../../../bot/commands/help');

describe('Bot: Command Help', function() {
  it('should return the Help intent with correct input', function() {
    var expected = require('./../../../bot/tasks/feedback/help');

    ['help', 'help ', ' help', 'help me', 'please help', 'can you help me',
      'can you please help', 'help me please', 'please help me', 'i need help', 'i\'m confused'].forEach(message => {
      expect(new command().parse(message).task).to.deep.equal(expected);
    });
  });

  it('should return null with wrong input', function() {
    ['help la', 'no this is not help'].forEach(message => {
      expect(new command().parse(message)).to.equal(null);
    });
  });

});
