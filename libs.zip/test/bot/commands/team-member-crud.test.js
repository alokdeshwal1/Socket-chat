'use strict';

const Mockery = require('mockery');
const Chai = require('chai');
const Sinon = require('sinon');
const expect = Chai.expect;
const command = require('./../../../bot/commands/team-member-crud');
const moment = require('moment');
var instance;

describe('Bot: Team Member Add Remove', function() {
  beforeEach(function() {
    instance = new command();
  });

  it('should parse "add team member/direct report"', function() {
    ['add team member', 'add team members', 'add direct report', 'add direct reports'].forEach(message => {
      var intent = new command().parse(message);
      expect(intent.task.name).to.equal('AddTeamMember');
      expect(intent.context.addTeamMemberSlackUserName).to.equal(undefined);
    });
  });


  it('should parse "add team member/direct report [userName]"', function() {
    ['add team member @peterl', 'add direct report @peterl', 'add direct reports @peterl', 'add @peterl to my team', 'add team members @peterl'].forEach(message => {
      var intent = new command().parse(message);
      expect(intent.task.name).to.equal('AddTeamMember');
      expect(intent.context.addTeamMemberSlackUserName).to.equal('peterl');

    });
  });

  it('should parse "add team member/direct report <@[userName]>"', function() {
    ['add team member <@peterl>', 'add direct report <@peterl>', 'add direct reports <@peterl>', 'add <@peterl> to my team', 'add team members <@peterl>'].forEach(message => {
      var intent = new command().parse(message);
      expect(intent.task.name).to.equal('AddTeamMember');
      expect(intent.context.addTeamMemberSlackUserName).to.equal(undefined);
      expect(intent.context.addTeamMemberSlackUserId).to.equal('peterl');
    });
  });

  it('should parse "add direct report(s) [userName]"', function() {
    ['add direct report @peterl', 'add direct reports @peterl'].forEach(message => {
      var intent = new command().parse(message);
      expect(intent.task.name).to.equal('AddTeamMember');
      expect(intent.context.addTeamMemberSlackUserName).to.equal('peterl');
    });
  });

  it('should parse "phase out/remove team member"', function() {
    ['phase out team member', 'phase out team members', 'phase out direct report', 'phase out direct reports',
      'remove team member', 'remove team members', 'remove direct report', 'remove direct reports'].forEach(message => {
      var intent = new command().parse(message);
      expect(intent.task.name).to.equal('RemoveTeamMember');
      expect(intent.context.removeTeamMemberSlackUserName).to.equal(undefined);
    });
  });

  it('should parse "phase out team member [userName]"', function() {
    ['phase out team member @jamesd', 'remove @jamesd from my team', 'phase out team members @jamesd'].forEach(message => {
      var intent = new command().parse(message);
      expect(intent.task.name).to.equal('RemoveTeamMember');
      expect(intent.context.removeTeamMemberSlackUserName).to.equal('jamesd');
    });
  });

  it('should parse "phase out team member [userName]"', function() {
    ['phase out team member <@jamesd>', 'remove <@jamesd> from my team', 'phase out team members <@jamesd>'].forEach(message => {
      var intent = new command().parse(message);
      expect(intent.task.name).to.equal('RemoveTeamMember');
      expect(intent.context.removeTeamMemberSlackUserName).to.equal(undefined);
      expect(intent.context.removeTeamMemberSlackUserId).to.equal('jamesd');
    });
  });

});
