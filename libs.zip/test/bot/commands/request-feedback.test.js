'use strict';

const Mockery = require('mockery');
const Chai = require('chai');
const Sinon = require('sinon');
const expect = Chai.expect;
const command = require('./../../../bot/commands/request-feedback');
const moment = require('moment');
var instance;

describe('Bot: Request Feedback', function() {
  beforeEach(function() {
    instance = new command();
  });

  it('should parse "request feedback"', function() {
    ['request feedback'].forEach(message => {
      var intent = new command().parse(message);
      expect(intent.task.name).to.equal('RequestFeedback');
      expect(intent.context).to.deep.equal({});
    });
  });

  it('should parse "request feedback from <@[userId]>"', function() {
    ['request feedback from <@userId1>'].forEach(message => {
      var intent = new command().parse(message);
      expect(intent.task.name).to.equal('RequestFeedback');
      expect(intent.context.requestFeedbackFromUser).to.equal('userId1');
    });
  });

  it('should parse "request feedback from @peter"', function() {
    ['request feedback from @peter'].forEach(message => {
      var intent = new command().parse(message);
      expect(intent.task.name).to.equal('RequestFeedback');
      expect(intent.context.requestFeedbackFromUser).to.equal('peter');
    });
  });

});