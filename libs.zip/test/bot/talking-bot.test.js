const Chai = require('chai');
const Sinon = require('sinon');
const expect = Chai.expect;
const mockTalkingBot = require('./mocks/mock-talking-bot');
const TalkingBot = require('./../../bot/talking-bot');
const Co = require('co');
const TestUser = require('./../bot/configs/user');
const IntegrationTest = require('./../bot-integration-test');
const teamName = 'eatravelive';
const teamId = 'T0G9HMJK1';
const teamKey = TalkingBot.getTeamKey(teamName, teamId);
const accessToken = 'xoxp-16323732647-16321667203-20295470704-9d49375704';
const botName = 'CareerLark';
const channelName = 'testChannel';
const slackUserId = 'testUserId';
const Config = require('../../configs/config');
const TaskGatherFeedback = require('./../../bot/tasks/feedback/gather-feedback');
const Helper = require('./../../bot/libs/helper');
const _ = require('lodash');
const sampleTask = {
  name: 'SampleTask',
  priority: 10,
  interactions: [
    {
      type: 'ActionMessage',
      message: 'Hello, this is a test'
    },
    {
      type: 'ActionQuestionAndAnswer',
      message: 'Bye Bye'
    }
  ]
};

var instance;

describe('Talking Bot', function() {
  beforeEach(function() {
    instance = mockTalkingBot(teamName, teamId, accessToken, botName, channelName);
  });

  it('should able to pickup job from her boss, Queue', function(done) {
    expect(Object.keys(instance.convos)).to.have.lengthOf(0);

    instance.handleQueue({
      slackUserId: slackUserId,
      task: sampleTask,
      params: {
      }
    }, ack);

    function ack() {
      expect(instance.convos[teamKey][channelName].tasks).to.have.lengthOf(1);
      done();
    }
  });

  it('should update channel last updated information when there is a new message', function() {
    var before = + (new Date());
    instance.listen('testUser', 'testChannel', 'test test test');
    expect(instance.convos[teamKey][channelName].updatedAt).to.be.at.least(before);
  });

  it('should only parse message if it is directed to the boot or direct message, no otherwise', function() {
    expect(instance._shouldParseMessage('test 1 2 3', channelName, 'testUserId')).to.equal(false);
    expect(instance._shouldParseMessage('@'+ Config.slack.botName + ' hello', channelName, 'testUserId')).to.equal(true);
  });

  it('should have createdAt timestamp when creating a new task', function(done) {
    // current task is ended, then insert a new higher priority task
    instance.handleQueue({
      slackUserId: slackUserId,
      task: sampleTask
    }, ack);

    function ack() {
      expect(instance.convos[teamKey][channelName].currentTask.createdAt).to.be.at.most(+ new Date());
      expect(instance.convos[teamKey][channelName].currentTask.name).to.equal('SampleTask');
      expect(instance.convos[teamKey][channelName].currentTask.isStarted).to.equal(true);

      done();
    }
  });

  it('should set enable default module to personal_goal', () => {
    var i = new TalkingBot(null, { amqb: {}, redis: {} }, teamName, teamId, accessToken, botName);
    expect(i.modules).to.deep.equal({
      featurePersonalGoal: true
    });

    i = new TalkingBot({
      featureOkrGoal: true
    }, { amqb: {}, redis: {} }, teamName, teamId, accessToken, botName);
    expect(i.modules).to.deep.equal({
      featureOkrGoal: true
    });

    i = new TalkingBot({
      featurePersonalGoal: false,
      featureOkrGoal: true
    }, { amqb: {}, redis: {} }, teamName, teamId, accessToken, botName);
    expect(i.modules).to.deep.equal({
      featurePersonalGoal: false,
      featureOkrGoal: true
    });

    i = new TalkingBot({
      featurePersonalGoal: false,
      featureOkrGoal: false
    }, { amqb: {}, redis: {} }, teamName, teamId, accessToken, botName);
    expect(i.modules).to.deep.equal({
      featurePersonalGoal: true
    });
  });

  describe('Queue handling', () => {
    it('task prioritization: current task (NOT ended), insert a new task (Higher priority)', function() {
      instance._addTask(channelName, slackUserId, _.clone(sampleTask));
      instance._addTask(channelName, slackUserId, _.clone(sampleTask));
      instance._addTask(channelName, slackUserId, _.clone(sampleTask));

      var sampleTask2 = _.clone(sampleTask);
      sampleTask2.name = 'SampleTask2';
      sampleTask2.priority = 5;
      instance._addTask(channelName, slackUserId, sampleTask2);

      var currentTask = instance.convos[teamKey][channelName].currentTask;
      expect(currentTask.name).to.equal(sampleTask2.name);
      expect(currentTask.isStarted).to.equal(true);
    });

    it('task prioritization: current task (NOT ended), insert a new task(Equal priority)', function() {
      instance._addTask(channelName, slackUserId, _.clone(sampleTask));
      instance._addTask(channelName, slackUserId, _.clone(sampleTask));
      instance._addTask(channelName, slackUserId, _.clone(sampleTask));

      var sampleTask2 = _.clone(sampleTask);
      sampleTask2.name = 'SampleTask2';
      sampleTask2.priority = 10;
      instance._addTask(channelName, slackUserId, sampleTask2);

      var currentTask = instance.convos[teamKey][channelName].currentTask;
      expect(currentTask.name).to.equal(sampleTask.name);
      expect(currentTask.isStarted).to.equal(true);

      var tasks = instance.convos[teamKey][channelName].tasks;
      expect(tasks[tasks.length - 1].name).to.equal(sampleTask2.name);
    });

    it('task prioritization: current task (ended), insert a new task (Higher priority)', function() {
      var task1 = _.clone(sampleTask);
      var task2 = _.clone(sampleTask);
      var task3 = _.clone(sampleTask);
      task1.name = 'Test Task 1';
      task2.name = 'Test Task 2';
      task3.name = 'Test Task 3';

      instance._addTask(channelName, slackUserId, task1);
      instance.convos[teamKey][channelName].tasks[0].isStarted = true;
      instance.convos[teamKey][channelName].tasks[0].isEnded = true;

      instance._addTask(channelName, slackUserId, task2);
      instance._addTask(channelName, slackUserId, task3);

      var sampleTask2 = _.clone(sampleTask);
      sampleTask2.name = 'SampleTask2';
      sampleTask2.priority = 2;
      instance._addTask(channelName, slackUserId, sampleTask2);

      var channelInfo = instance.convos[teamKey][channelName];
      var currentTask = instance.convos[teamKey][channelName].currentTask;
      expect(currentTask.name).to.equal(sampleTask2.name);
      expect(currentTask.isStarted).to.equal(true);
      expect(channelInfo.step).to.equal(1);
    });

    it('task prioritization: current task (ended), insert a new task (equal priority)', function() {
      var task1 = _.clone(sampleTask);
      var task2 = _.clone(sampleTask);
      var task3 = _.clone(sampleTask);
      task1.name = 'Test Task 1';
      task2.name = 'Test Task 2';
      task3.name = 'Test Task 3';

      instance._addTask(channelName, slackUserId, task1);
      instance.convos[teamKey][channelName].tasks[0].isStarted = true;
      instance.convos[teamKey][channelName].tasks[0].isEnded = true;

      instance._addTask(channelName, slackUserId, task2);
      instance._addTask(channelName, slackUserId, task3);

      var sampleTask2 = _.clone(sampleTask);
      sampleTask2.name = 'SampleTask2';
      sampleTask2.priority = 10;
      instance._addTask(channelName, slackUserId, sampleTask2);

      var channelInfo = instance.convos[teamKey][channelName];
      var currentTask = instance.convos[teamKey][channelName].currentTask;
      expect(currentTask.name).to.equal(task2.name);
      expect(currentTask.isStarted).to.equal(true);
      expect(channelInfo.step).to.equal(1);
    });
  });

  describe('Help command tasks firing order', () => {
    it('cancel current help command if new help command is fired', () => {
      instance.listen('testUser', 'testChannel', 'add team member');
      var conversation = instance.convos[teamKey][channelName];
      expect(conversation.currentTask.isStarted).to.equal(true);

      instance.listen('testUser', 'testChannel', 'add manager');
      expect(conversation.currentTask.name).to.equal('AddManager');
      expect(conversation.currentTask.isStarted).to.equal(true);
    });

    it('should cancel previous help task even it is fired in the middle of another task', () => {
      var task1 = _.clone(sampleTask);
      instance._addTask(channelName, slackUserId, task1);
      var conversation = instance.convos[teamKey][channelName];
      expect(conversation.currentTask.isStarted).to.equal(true);
      expect(conversation.currentTask.name).to.equal('SampleTask');

      instance.listen('testUser', 'testChannel', 'add team member');
      expect(conversation.currentTask.isStarted).to.equal(true);
      expect(conversation.currentTask.name).to.equal('AddTeamMember');

      instance.listen('testUser', 'testChannel', 'add manager');
      expect(conversation.currentTask.isStarted).to.equal(true);
      expect(conversation.currentTask.name).to.equal('AddManager');
    });
  });

  describe('Suspend a task and coming back to the task', () => {
    var expected = {};
    expected[TestUser[2].firstName +' '+ TestUser[2].lastName] = [
      {
        overwriteTest: function(expected, result) {
          expect(result.length).to.equal(1);
          delete result[0].callback_id;
          expect(result).to.deep.equal(expected);
          return true;
        },
        expect: {
          text: [
            {
              "actions": [
                {
                  "name": ":disappointed:",
                  "style": "primary",
                  "text": ":disappointed:",
                  "type": "button",
                  "value": ":disappointed:"
                },
                {
                  "name": ":neutral_face:",
                  "style": "primary",
                  "text": ":neutral_face:",
                  "type": "button",
                  "value": ":neutral_face:"
                },
                {
                  "name": ":simple_smile:",
                  "style": "primary",
                  "text": ":simple_smile:",
                  "type": "button",
                  "value": ":simple_smile:"
                },
                {
                  "name": ":smile:",
                  "style": "primary",
                  "text": ":smile:",
                  "type": "button",
                  "value": ":smile:"
                },
                {
                  "name": ":joy:",
                  "style": "primary",
                  "text": ":joy:",
                  "type": "button",
                  "value": ":joy:"
                }
              ],
              "attachment_type": "default",
              "color": "#DA552F",
              "fallback": Helper.replaceMessagePlaceholder(TaskGatherFeedback.interactions[0].message.fallback, {targetUserFirstName: TestUser[3].firstName}),
              "mrkdwn_in": [
                "fields",
                "pretext",
                "text"
              ],
              "text": Helper.replaceMessagePlaceholder(TaskGatherFeedback.interactions[0].message.text, {
                userFirstName: TestUser[2].firstName,
                targetUserFirstName: TestUser[3].firstName,
                targetUserGoalName: 'Test Unit Test Goal'
              }),
              "title": Helper.replaceMessagePlaceholder(TaskGatherFeedback.interactions[0].message.title, {targetUserFirstName: TestUser[3].firstName})
            }
          ]
        },

        enterMessage: 'add goal'
      },
      {
        expect: {
          type: 'message',
          text: "Sure! First, let's select a category to see a list of suggested goals. If you'd like to add your own custom goal, go ahead and select a category, and you can write in your goal in the next step."
        },

        enterMessage: 'cancel'
      },
      {
        expect: {
          type: 'message',
          text: 'Ok'
        }
      }
    ];

    var iTest = new IntegrationTest(null,TestUser[2], TestUser, expected, function() {
      this.instance.handleQueue({
        slackUserId: this.slackUserId,
        task: require('./../../bot/tasks/feedback/gather-feedback'),
        context: {
          slackUserId: this.slackUserId,
          userFirstName: TestUser[2].firstName,
          targetUserFirstName: TestUser[3].firstName,
          targetUserGoalName: 'Test Unit Test Goal'
        }
      });
    });

    before(done => {
      Co(function *() {
        try {
          // run the tests
          yield iTest.runTest();
        }
        catch (ex) {
          console.log(ex);
        }

        done();

      }.bind(this));
    });

    // generate Mocha "it" tests
    iTest.generateAllTests();
  });

});
