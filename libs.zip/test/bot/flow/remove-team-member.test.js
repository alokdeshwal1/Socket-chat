'use strict';

const Mockery = require('mockery');
const Chai = require('chai');
const Sinon = require('sinon');
const expect = Chai.expect;
const Config = require('./../../../configs/config');
const CONSTANTS = require('./../../../constants/constants');
const TestUser = require('./../configs/user');
const ModelUser = require('./../../../models/user');
const ModelJobFunction = require('./../../../models/function');
const ModelUserGoal = require('./../../../models/user-goal');
const Co = require('co');
const IntegrationTest = require('./../../bot-integration-test');
const _ = require('lodash');

describe('Bot: Remove Team member', () => {
  describe('remove team member (in the team)', () => {
    var expected = {};
    expected[TestUser[0].name] = [
      {
        expect: {
          text: "OK, who would you like to remove? \n\n:bulb:Tip: You can type @ to see a dropdown with all of your coworkers. Select as many as you want"
        },

        // job function
        enterMessage: 'richard'
      },
      {
        expect: {
          text: 'Great! Done.'
        }
      }
    ];

    var iTest = new IntegrationTest(null, TestUser[0], TestUser, expected, function() {
      this.instance.listen(this.slackUserId, this.primaryChannel, 'phase out team member');
    });

    before(() => {
      return iTest.before(function *(users) {
        users[1].manager = users[0].id;
        yield users[1].save();
      }.bind(this));
    });

    // generate Mocha "it" tests
    iTest.generateAllTests();
  });




  describe('remove team member (NOT in the team)', () => {
    var expected = {};
    expected[TestUser[1].name] = [
      {
        expect: {
          type: 'message',
          text: "OK, who would you like to remove? \n\n:bulb:Tip: You can type @ to see a dropdown with all of your coworkers. Select as many as you want"
        },

        // job function
        enterMessage: 'richard'
      },
      {
        expect: {
          type: 'message',
          text: 'Doesn\'t look like Richard is on your team'
        }
      }
    ];

    var iTest = new IntegrationTest(null, TestUser[1], TestUser, expected, function() {
      this.instance.listen(this.slackUserId, this.primaryChannel, 'phase out team member');
    });

    before(() => {
      return iTest.before(function *(users) {
        users[1].manager = users[2].id;
        yield users[1].save();
      }.bind(this));
    });

    // generate Mocha "it" tests
    iTest.generateAllTests();
  });
});
