'use strict';

const Mockery = require('mockery');
const Chai = require('chai');
const Sinon = require('sinon');
const expect = Chai.expect;
const Config = require('./../../../configs/config');
const CONSTANTS = require('./../../../constants/constants');
const TestUser = require('./../configs/user');
const ModelUser = require('./../../../models/user');
const ModelJobFunction = require('./../../../models/function');
const Co = require('co');
const IntegrationTest = require('./../../bot-integration-test');
const TaskGatherFunction = require('./../../../bot/tasks/feedback/gather-function');
const _ = require('lodash');

describe('Bot: Add Goal', () => {
  describe('Add Goal (User does NOT have job function)', () => {
    var expected = {};
    expected[TestUser[4].name] = [
      {
        overwriteTest: function(expected, result) {
          expect(result.length).to.equal(1);
          delete result[0].callback_id;
          expect(result).to.deep.equal(expected);
          return true;
        },
        expect: {
          text: [
            {
              "actions": [
                {
                  "name": ":one:",
                  "style": "primary",
                  "text": ":one:",
                  "type": "button",
                  "value": ":one:"
                },
                {
                  "name": ":two:",
                  "style": "primary",
                  "text": ":two:",
                  "type": "button",
                  "value": ":two:"
                },
                {
                  "name": ":three:",
                  "style": "primary",
                  "text": ":three:",
                  "type": "button",
                  "value": ":three:"
                },
                {
                  "name": ":four:",
                  "style": "primary",
                  "text": ":four:",
                  "type": "button",
                  "value": ":four:"
                },
                {
                  "name": ":five:",
                  "style": "primary",
                  "text": ":five:",
                  "type": "button",
                  "value": ":five:"
                }
              ],
              "attachment_type": "default",
              "color": "#DA552F",
              "fallback": "Pick a function:",
              "fields": [
                {
                  "title": "Job Functions:",
                  "value": ":one: Engineering\n:two: Operations\n:three: Product Management\n:four: Sales\n:five: Other\n\nPick a reaction:"
                }
              ],
              "mrkdwn_in": [
                "fields",
                "pretext",
                "text"
              ],
              "pretext": TaskGatherFunction.interactions[1].message.pretext
            }
          ]
        },

        enterMessage: '2'
      },
      {
        expect: {
          text: 'Great! Which of the following goal categories look interesting to you?'
        }
      },
      {
        overwriteTest: function(expected, result) {
          expect(result.length).to.equal(1);
          delete result[0].callback_id;
          expect(result).to.deep.equal(expected);
          return true;
        },
        expect: {
          text: [
            {
              "actions": [
                {
                  "name": ":one:",
                  "style": "primary",
                  "text": ":one:",
                  "type": "button",
                  "value": ":one:"
                },
                {
                  "name": ":two:",
                  "style": "primary",
                  "text": ":two:",
                  "type": "button",
                  "value": ":two:"
                },
                {
                  "name": ":three:",
                  "style": "primary",
                  "text": ":three:",
                  "type": "button",
                  "value": ":three:"
                },
                {
                  "name": ":four:",
                  "style": "primary",
                  "text": ":four:",
                  "type": "button",
                  "value": ":four:"
                }
              ],
              "attachment_type": "default",
              "fallback": "Pick one of the following categories:",
              "color": "#DA552F",
              "fields": [
                {
                  "title": "Goal categories:",
                  "value": ":one: Communication\n:two: Productivity\n:three: Leadership and Managerial Skills\n:four: Attitude and Outlook\n\nSelect a button:"
                }
              ],
              "mrkdwn_in": [
                "fields",
                "pretext",
                "text"
              ],
              "pretext": "Pick one of the following categories:"
            }
          ]
        },

        enterMessage: '1'
      },
      {
        overwriteTest: function(expected, result) {
          expect(result.length).to.equal(1);
          delete result[0].callback_id;
          expect(result).to.deep.equal(expected);
          return true;
        },
        expect: {
          text: [
            {
              "actions": [
                {
                  "name": ":one:",
                  "style": "primary",
                  "text": ":one:",
                  "type": "button",
                  "value": ":one:"
                },
                {
                  "name": ":two:",
                  "style": "primary",
                  "text": ":two:",
                  "type": "button",
                  "value": ":two:"
                },
                {
                  "name": ":three:",
                  "style": "primary",
                  "text": ":three:",
                  "type": "button",
                  "value": ":three:"
                },
                {
                  "name": ":four:",
                  "style": "primary",
                  "text": ":four:",
                  "type": "button",
                  "value": ":four:"
                },
                {
                  "name": ":five:",
                  "style": "primary",
                  "text": ":five:",
                  "type": "button",
                  "value": ":five:"
                }
              ],
              "attachment_type": "default",
              "color": "#DA552F",
              "fallback": "Great, pick one of these Communication suggested goals or write in your own!",
              "fields": [
                {
                  "title": "Suggested goals:",
                  "value": ":one: Listen actively. Seek first to understand, then to be understood.\n:two: Communicate in a clear and logical manner with the appropriate level of detail\n:three: Express yourself clearly and concisely in written communications\n:four: Always have prepared agendas for meetings and ensure everything stays on track\n:five: Keep all relevant stakeholders informed as appropriate\n\nPick a button. Or write in your own!"
                }
              ],
              "mrkdwn_in": [
                "fields",
                "pretext",
                "text"
              ],
              "pretext": "Great, pick one of these Communication suggested goals or write in your own!"
            }
          ]
        },

        enterMessage: 'Integration Test Goal - Add Goal'
      },
      {
        expect: {
          text: "Cool, who would you like to get feedback from for this? \n\n:bulb:Tip: You can type @ to see a dropdown with all of your coworkers. Select as many as you want"
        },

        enterMessage: TestUser[3].slackUserName
      },
      {
        overwriteTest: function(expected, result) {
          delete result[0].callback_id;
          expect(result).to.deep.equal(expected);
          return true;
        },
        expect: {
          text: [
            {
              "actions": [
                {
                  "name": ":one:",
                  "style": "primary",
                  "text": ":one:",
                  "type": "button",
                  "value": ":one:"
                },
                {
                  "name": ":two:",
                  "style": "primary",
                  "text": ":two:",
                  "type": "button",
                  "value": ":two:"
                }
              ],
              "attachment_type": "default",
              "fallback": "Great! How should I ask them?",
              "color": "#DA552F",
              "fields": [
                {
                  "title": "Prompt types:",
                  "value": ":one: After meetings (GCal sign-in needed)\n:two: At regular time intervals (set manually)\n\nPick a button:",
                }
              ],
              "mrkdwn_in": [
                "fields",
                "pretext",
                "text"
              ],
              "pretext": "Great! How should I ask them?"
            }
          ]
        },

        enterMessage: '2'
      },
      {
        expect: {
          text: "OK, can you tell me at what interval? Here are the types of things that I understand (I'm working on it but I'm a bot after all :simple_smile:) \n`every Monday at 3:30pm` \n`1st Tues of every month` \n`9PM on Sundays` \n`every other Tuesday at 9am` \n\n:bulb:Tip: We recommend asking for feedback at most once a week"
        },

        enterMessage: '12pm monday'
      },
      {
        overwriteTest: function(expected, result) {
          expect(result[0].fields[0].value).to.match(expected[0].fields[0].value);
          delete result[0].fields[0].value;
          delete expected[0].fields[0].value;
          expect(result).to.deep.equal(expected);
          return true;
        },
        expect: {
          text: [
            {
              "color": "#DA552F",
              "fallback": "Cool, this is what I have. Sound good? Say `yes` or `no`",
              "fields": [
                {
                  "value": /\d+\/\d+ Monday 12:00PM\n\d+\/\d+ Monday 12:00PM\n\d+\/\d+ Monday 12:00PM/
                }
              ],
              "mrkdwn_in": [
                "fields",
                "pretext"
              ],
              "pretext": "Cool, this is what I have. Sound good? Say `yes` or `no`"
            }
          ]
        },

        enterMessage: 'yes'
      },
      {
        expect: {
          type: 'message',
          text: 'Got it!'
        }
      },
      {
        overwriteTest: function(expected, result) {
          expect(result.length).to.equal(1);
          delete result[0].callback_id;
          expect(result).to.deep.equal(expected);
          return true;
        },
        expect: {
          type: 'message',
          text: [
            {
              "actions": [
                {
                  "name": ":one:",
                  "style": "primary",
                  "text": ":one:",
                  "type": "button",
                  "value": ":one:"
                },
                {
                  "name": ":two:",
                  "style": "primary",
                  "text": ":two:",
                  "type": "button",
                  "value": ":two:"
                }
              ],
              "fallback": "Cool, want to add another prompt? If not, tell me `no`.",
              "attachment_type": "default",
              "color": "#DA552F",
              "fields": [
                {
                  "title": "Prompt types:",
                  "value": ":one: After meetings (GCal sign-in needed)\n:two: At regular time intervals (set manually)\n\nPick a button:"
                }
              ],
              "mrkdwn_in": [
                "fields",
                "pretext",
                "text"
              ],
              "pretext": "Cool, want to add another prompt? If not, tell me `no`."
            }
          ]
        },

        enterMessage: 'no'
      },

      {
        overwriteTest: function(expected, result) {
          expect(result.length).to.equal(1);
          delete result[0].callback_id;
          expect(result).to.deep.equal(expected);
          return true;
        },
        expect: {
          text: [
            {
              "actions": [
                {
                  "name": ":one:",
                  "style": "primary",
                  "text": ":one:",
                  "type": "button",
                  "value": ":one:"
                },
                {
                  "name": ":two:",
                  "style": "primary",
                  "text": ":two:",
                  "type": "button",
                  "value": ":two:"
                },
                {
                  "name": ":three:",
                  "style": "primary",
                  "text": ":three:",
                  "type": "button",
                  "value": ":three:"
                },
                {
                  "name": ":four:",
                  "style": "primary",
                  "text": ":four:",
                  "type": "button",
                  "value": ":four:"
                }
              ],
              "attachment_type": "default",
              "fallback": "OK! want to add another goal? If so, pick one of the following categories. If not, tell me `no`. You can always go back and add more later.",
              "color": "#DA552F",
              "fields": [
                {
                  "title": "Goal categories:",
                  "value": ":one: Communication\n:two: Productivity\n:three: Leadership and Managerial Skills\n:four: Attitude and Outlook\n\nSelect a button:"
                }
              ],
              "mrkdwn_in": [
                "fields",
                "pretext",
                "text"
              ],
              "pretext": "OK! want to add another goal? If so, pick one of the following categories. If not, tell me `no`. You can always go back and add more later."
            }
          ]
        },

        enterMessage: 'no'
      },

      {
        expect: {
          type: 'message',
          text: 'Great, you\'re all set. If you need me, say `help`...otherwise bye for now! :wave:'
        }
      }
    ];

    // manager
    expected[TestUser[2].name] = [
      {
        expect: {
          type: 'message',
          text: 'Hey Jared, gilfoyle (gilfoyle) updated goals.'
        }
      },

      {
        expect: {
          type: 'message',
          text: [
            {
              "color": "#3F2D4F",
              "fallback": "Goal #1. Integration Test Goal - Add Goal",
              "fields": [
                {
                  "title": "Goal #1",
                  "value": "Integration Test Goal - Add Goal"
                },
                {
                  "title": "Prompt",
                  "value": "12pm monday"
                },
                {
                  "title": "Feedback Givers",
                  "value": "Monica"
                }
              ],
              "mrkdwn_in": [
                "fields",
                "pretext"
              ]
            }
          ]
        }
      }
    ];

    // advisor
    expected[TestUser[3].name] = [
      {
        expect: {
          type: 'message',
          text: 'Hi Monica! I\'m CareerLark, your friendly bot that helps everyone share more feedback. Your coworker gilfoyle has selected you as a feedback giver. Here is more detail'
        }
      },

      {
        expect: {
          type: 'message',
          text: [
            {
              "color": "#3F2D4F",
              "fallback": "Goal #1. Integration Test Goal - Add Goal",
              "fields": [
                {
                  "title": "Goal #1",
                  "value": "Integration Test Goal - Add Goal"
                },
                {
                  "title": "Prompt",
                  "value": "12pm monday"
                }
              ],
              "mrkdwn_in": ["fields", "pretext"]
            }
          ]
        }
      }
    ];

    var iTest = new IntegrationTest(null, TestUser[4], TestUser, expected, function() {
      this.instance.listen(this.slackUserId, this.primaryChannel, 'add goal');

      // schedule a gather feedback, which will be only shown after add Goal is over
      // an extra test to make sure that make sure chainTask is working
      var theTask = _.cloneDeep(require('./../../../bot/tasks/feedback/gather-feedback'));
      theTask.priority = 2;
      this.instance.handleQueue({
        slackUserId: this.slackUserId,
        task: theTask,
        context: {
          userFirstName: TestUser[3].firstName,
          appName: Config.appName,
          targetUserFirstName: TestUser[4].firstName,
          targetUserGoalName: 'TestGoal',
          slackUserId: this.slackUserId
        }
      });
    });

    before(() => {
      return iTest.before(function *(users) {
        users[4].jobFunction = undefined;
        users[4].manager = users[2].id;

        yield users[4].save();
      }.bind(this));
    });

    // generate Mocha "it" tests
    iTest.generateAllTests();
  });








  describe('Add Goal (User has job function)', () => {
    var expected = {};
    expected[TestUser[4].name] = [
      {
        expect: {
          type: 'message',
          text: "Sure! First, let's select a category to see a list of suggested goals. If you'd like to add your own custom goal, go ahead and select a category, and you can write in your goal in the next step."
        }
      },
      {
        overwriteTest: function(expected, result) {
          expect(result.length).to.equal(1);
          delete result[0].callback_id;
          expect(result).to.deep.equal(expected);
          return true;
        },
        expect: {
          text: [
            {
              "actions": [
                {
                  "name": ":one:",
                  "style": "primary",
                  "text": ":one:",
                  "type": "button",
                  "value": ":one:"
                },
                {
                  "name": ":two:",
                  "style": "primary",
                  "text": ":two:",
                  "type": "button",
                  "value": ":two:"
                },
                {
                  "name": ":three:",
                  "style": "primary",
                  "text": ":three:",
                  "type": "button",
                  "value": ":three:"
                },
                {
                  "name": ":four:",
                  "style": "primary",
                  "text": ":four:",
                  "type": "button",
                  "value": ":four:"
                },
                {
                  "name": ":five:",
                  "style": "primary",
                  "text": ":five:",
                  "type": "button",
                  "value": ":five:"
                }
              ],
              "attachment_type": "default",
              "color": "#DA552F",
              "fallback": "Pick one of the following categories:",
              "fields": [
                {
                  "title": "Goal categories:",
                  "value": ":one: Communication\n:two: Productivity\n:three: Leadership and Managerial Skills\n:four: Attitude and Outlook\n:five: Technical Skills\n\nSelect a button:"
                }
              ],
              "mrkdwn_in": [
                "fields",
                "pretext",
                "text"
              ],
              "pretext": "Pick one of the following categories:"
            }
          ]
        },

        enterMessage: '5'
      },
      {
        overwriteTest: function(expected, result) {
          expect(result.length).to.equal(1);
          delete result[0].callback_id;
          expect(result).to.deep.equal(expected);
          return true;
        },
        expect: {
          text: [
            {
              "actions": [
                {
                  "name": ":one:",
                  "style": "primary",
                  "text": ":one:",
                  "type": "button",
                  "value": ":one:"
                },
                {
                  "name": ":two:",
                  "style": "primary",
                  "text": ":two:",
                  "type": "button",
                  "value": ":two:"
                },
                {
                  "name": ":three:",
                  "style": "primary",
                  "text": ":three:",
                  "type": "button",
                  "value": ":three:"
                }
              ],
              "attachment_type": "default",
              "color": "#DA552F",
              "fallback": "Great, pick one of these Technical Skills suggested goals or write in your own!",
              "fields": [
                {
                  "title": "Suggested goals:",
                  "value": ":one: Consistently produce high-quality, bug free output\n:two: Thoroughly test all code prior to pushing to production\n:three: Use appropriate languages and technologies to solve the problem at hand\n\nPick a button. Or write in your own!"
                }
              ],
              "mrkdwn_in": [
                "fields",
                "pretext",
                "text"
              ],
              "pretext": "Great, pick one of these Technical Skills suggested goals or write in your own!"
            }
          ]
        },

        enterMessage: 'Unit test custom goal'
      },
      {
        expect: {
          text: "Cool, who would you like to get feedback from for this? \n\n:bulb:Tip: You can type @ to see a dropdown with all of your coworkers. Select as many as you want"
        },

        enterMessage: TestUser[3].slackUserName
      },
      {
        overwriteTest: function(expected, result) {
          expect(result.length).to.equal(1);
          delete result[0].callback_id;
          expect(result).to.deep.equal(expected);
          return true;
        },
        expect: {
          text: [
            {
              "actions": [
                {
                  "name": ":one:",
                  "style": "primary",
                  "text": ":one:",
                  "type": "button",
                  "value": ":one:"
                },
                {
                  "name": ":two:",
                  "style": "primary",
                  "text": ":two:",
                  "type": "button",
                  "value": ":two:"
                }
              ],
              "attachment_type": "default",
              "fallback": "Great! How should I ask them?",
              "color": "#DA552F",
              "fields": [
                {
                  "title": "Prompt types:",
                  "value": ":one: After meetings (GCal sign-in needed)\n:two: At regular time intervals (set manually)\n\nPick a button:",
                }
              ],
              "mrkdwn_in": [
                "fields",
                "pretext",
                "text"
              ],
              "pretext": "Great! How should I ask them?"
            }
          ]
        },

        enterMessage: '2'
      }
    ];

    var iTest = new IntegrationTest(null, TestUser[4], TestUser, expected, function() {
      this.instance.listen(this.slackUserId, this.primaryChannel, 'add goal');
    });

    before(() => {
      return iTest.before(function *(users) {
        var jobFunction = yield ModelJobFunction.findOne({ name: 'Engineering' });
        users[4].jobFunction = [jobFunction.id];

        yield users[4].save();
      }.bind(this));
    });

    // generate Mocha "it" tests
    iTest.generateAllTests();
  });

});
