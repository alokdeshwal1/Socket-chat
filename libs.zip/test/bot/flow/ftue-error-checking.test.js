'use strict';

const Mockery = require('mockery');
const Chai = require('chai');
const Sinon = require('sinon');
const expect = Chai.expect;
const Config = require('./../../../configs/config');
const CONSTANTS = require('./../../../constants/constants');
const BotMessages = require('./../../../configs/bot-messages');
const TestUser = require('./../configs/user');
const ModelUser = require('./../../../models/user');
const ModelJobFunction = require('./../../../models/function');
const Co = require('co');
const IntegrationTest = require('./../../bot-integration-test');
const TaskGatherFeedback = require('./../../../bot/tasks/feedback/gather-feedback');
const Helper = require('./../../../bot/libs/helper');

describe('Bot: FTUE Error Checking', () => {
  describe('Should not schedule duplicated FTUE', () => {
    var expected = {};
    expected[TestUser[3].name] = [
      {
        expect: {
          type: 'message',
          text: "Hi Monica :wave:! I'm CareerLark, your friendly :robot_face:. I’m going to help you give and get micro-feedback to take your career to the next level. Let's get you set up. This will only take a few moments.\nIf you’re a manager looking to get your team set up to give and receive feedback type `manager`. Otherwise, type `individual feedback` to start getting micro-feedback from your coworkers.\n\nYou can also type `help` at any point if you get stuck."
        },

        enterMessage: 'manager'
      },
      {
        expect: {
          type: 'message',
          text: "Great! Who are your direct reports? I'll send them invites to get started.\n\n:bulb: Tip: type @ to see a dropdown with all of your coworkers. Select as many as you want."
        },

        enterMessage: TestUser[4].firstName
      },
      {
        expect: {
          type: 'message',
          text: 'Great, thanks! :+1: I\'m going to now ping them and get them set up with their goals. Once they\'re done I\'ll let you know and we\'ll start pinging you for quick feedback.'
        }
      },
      {
        expect: {
          type: 'message',
          text: 'Now try typing `help`!'
        }
      },

      // Feedback gather message should be shown only after FTUE is over
      {
        overwriteTest: function(expected, result) {
          expect(result.length).to.equal(1);
          delete result[0].callback_id;
          expect(result).to.deep.equal(expected);
          return true;
        },
        expect: {
          type: 'message',
          text: [
            {
              "actions": [
                {
                  "name": ":disappointed:",
                  "style": "primary",
                  "text": ":disappointed:",
                  "type": "button",
                  "value": ":disappointed:"
                },
                {
                  "name": ":neutral_face:",
                  "style": "primary",
                  "text": ":neutral_face:",
                  "type": "button",
                  "value": ":neutral_face:"
                },
                {
                  "name": ":simple_smile:",
                  "style": "primary",
                  "text": ":simple_smile:",
                  "type": "button",
                  "value": ":simple_smile:"
                },
                {
                  "name": ":smile:",
                  "style": "primary",
                  "text": ":smile:",
                  "type": "button",
                  "value": ":smile:"
                },
                {
                  "name": ":joy:",
                  "style": "primary",
                  "text": ":joy:",
                  "type": "button",
                  "value": ":joy:"
                }
              ],
              "attachment_type": "default",
              "color": "#DA552F",
              "fallback": Helper.replaceMessagePlaceholder(TaskGatherFeedback.interactions[0].message.fallback, {targetUserFirstName: TestUser[4].firstName}),
              "mrkdwn_in": [
                "fields",
                "pretext",
                "text"
              ],
              "text": Helper.replaceMessagePlaceholder(TaskGatherFeedback.interactions[0].message.text, {
                userFirstName: TestUser[3].firstName,
                targetUserFirstName: TestUser[4].firstName,
                targetUserGoalName: 'TestGoal'
              }),
              "title": Helper.replaceMessagePlaceholder(TaskGatherFeedback.interactions[0].message.title, {targetUserFirstName: TestUser[4].firstName})
            }
          ]
        }
      }
    ];

    // manager
    expected[TestUser[4].name] = [
      {
        expect: {
          type: 'message',
          text: 'Hi gilfoyle! :wave: Your manager Monica just signed you up for CareerLark, a friendly :robot_face: that is going to help you give and receive lightweight feedback. Let’s get your goals set up so you can take your career to the next level! This will only take a few minutes.\n\n(pro tip: type `back` to re-enter, `cancel` to end the current task, or `help` for other commands)'
        }
      },
      {
        expect: {
          type: 'message',
          text: "Great! Let’s get you set up! Who would you like to get feedback from?\n\nWe recommend choosing folks that you work closely with, who can provide you with meaningful guidance. We'll let them know that you value their input and are adding them as reviewers. \n\n:bulb:Tip: You can type @ to see a dropdown with all of your coworkers. Select as many as you want"
        }
      }
    ];

    var iTest = new IntegrationTest(null, TestUser[3], TestUser, expected, function() {
      this.instance.handleQueue({
        slackUserId: this.slackUserId,
        task: require('./../../../bot/tasks/feedback/ftue'),
        context: {
          userFirstName: TestUser[3].firstName,
          appName: Config.appName,
          slackUserId: this.slackUserId
        }
      });

      // schedule another FTUE task, which should be discarded
      this.instance.handleQueue({
        slackUserId: this.slackUserId,
        task: require('./../../../bot/tasks/feedback/ftue'),
        context: {
          userFirstName: TestUser[3].firstName,
          appName: Config.appName,
          slackUserId: this.slackUserId
        }
      });

      // schedule a gather feedback, which will be only shown after FTUE is over
      this.instance.handleQueue({
        slackUserId: this.slackUserId,
        task: require('./../../../bot/tasks/feedback/gather-feedback'),
        context: {
          userFirstName: TestUser[3].firstName,
          appName: Config.appName,
          targetUserFirstName: TestUser[4].firstName,
          targetUserGoalName: 'TestGoal',
          slackUserId: this.slackUserId
        }
      });

    });

    before(() => {
      return iTest.before(function *(users) {
        users[4].jobFunction = undefined;
        users[4].isSignedUpOnBot = undefined;
        users[4].manager = undefined;
        yield users[4].save();

        users[3].isSignedUpOnBot = undefined;
        yield users[3].save();
      }.bind(this));
    });

    // generate Mocha "it" tests
    iTest.generateAllTests();
  });





  describe('Firing help command in FTUE', () => {
    var expected = {};
    expected[TestUser[3].name] = [
      {
        expect: {
          type: 'message',
          text: "Hi Monica :wave:! I'm CareerLark, your friendly :robot_face:. I’m going to help you give and get micro-feedback to take your career to the next level. Let's get you set up. This will only take a few moments.\nIf you’re a manager looking to get your team set up to give and receive feedback type `manager`. Otherwise, type `individual feedback` to start getting micro-feedback from your coworkers.\n\nYou can also type `help` at any point if you get stuck."
        },

        enterMessage: 'employee'
      },
      {
        expect: {
          type: 'message',
          text: "Great! Let’s get you set up! Who would you like to get feedback from?\n\nWe recommend choosing folks that you work closely with, who can provide you with meaningful guidance. We'll let them know that you value their input and are adding them as reviewers. \n\n:bulb:Tip: You can type @ to see a dropdown with all of your coworkers. Select as many as you want"
        },

        enterMessage: 'help'
      },
      {
        expect: {
          type: 'message',
          text: BotMessages.Help
        }
      },
      {
        expect: {
          type: 'message',
          text: "Great! Let’s get you set up! Who would you like to get feedback from?\n\nWe recommend choosing folks that you work closely with, who can provide you with meaningful guidance. We'll let them know that you value their input and are adding them as reviewers. \n\n:bulb:Tip: You can type @ to see a dropdown with all of your coworkers. Select as many as you want"
        }
      }
    ];

    var iTest = new IntegrationTest(null, TestUser[3], TestUser, expected, function() {
      this.instance.handleQueue({
        slackUserId: this.slackUserId,
        task: require('./../../../bot/tasks/feedback/ftue'),
        context: {
          userFirstName: TestUser[3].firstName,
          appName: Config.appName,
          slackUserId: this.slackUserId
        }
      });
    });

    before(() => {
      return iTest.before(function *(users) {
        users[4].jobFunction = undefined;
        yield users[4].save();

        users[3].isSignedUpOnBot = undefined;
        yield users[3].save();
      }.bind(this));
    });

    // generate Mocha "it" tests
    iTest.generateAllTests();

  });

});
