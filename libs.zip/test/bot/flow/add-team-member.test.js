'use strict';

const Mockery = require('mockery');
const Chai = require('chai');
const Sinon = require('sinon');
const expect = Chai.expect;
const Config = require('./../../../configs/config');
const CONSTANTS = require('./../../../constants/constants');
const TestUser = require('./../configs/user');
const ModelUser = require('./../../../models/user');
const ModelJobFunction = require('./../../../models/function');
const Co = require('co');
const IntegrationTest = require('./../../bot-integration-test');

describe('Bot: Add Team Member', () => {
  describe('add one team member (Already in the team)', () => {
    var expected = {};
    expected[TestUser[0].name] = [
      {
        expect: {
          type: 'message',
          text: "OK, who would you like to add? \n\n:bulb:Tip: You can type @ to see a dropdown with all of your coworkers. Select as many as you want"
        },

        // job function
        enterMessage: 'richard'
      },
      {
        expect: {
          type: 'message',
          text: 'I\'ve already got Richard listed as one of your direct reports. If you want to add another direct report, type `add direct report`'
        }
      }
    ];

    var iTest = new IntegrationTest(null, TestUser[0], TestUser, expected, function() {
      this.instance.listen(this.slackUserId, this.primaryChannel, 'add team member');
    });

    before(() => {
      return iTest.before(function *(users) {
        users[1].manager = users[0].id;
        yield users[1].save();
      }.bind(this));
    });

    // generate Mocha "it" tests
    iTest.generateAllTests();
  });

  describe('add one team member (does NOT have manager)', () => {
    var expected = {};
    expected[TestUser[0].name] = [
      {
        expect: {
          type: 'message',
          text: "OK, who would you like to add? \n\n:bulb:Tip: You can type @ to see a dropdown with all of your coworkers. Select as many as you want"
        },

        // job function
        enterMessage: 'jared'
      },
      {
        expect: {
          type: 'message',
          text: 'great, done!'
        }
      }
    ];

    expected[TestUser[2].name] = [
      {
        expect: {
          type: 'message',
          text: "Hi Jared! :wave: Your manager Susan just signed you up for CareerLark, a friendly :robot_face: that is going to help you give and receive lightweight feedback. Let’s get your goals set up so you can take your career to the next level! This will only take a few minutes.\n\n(pro tip: type `back` to re-enter, `cancel` to end the current task, or `help` for other commands)"
        }
      }
    ];

    var iTest = new IntegrationTest(null, TestUser[0], TestUser, expected, function() {
      this.instance.listen(this.slackUserId, this.primaryChannel, 'add team member');
    });

    before(() => {
      return iTest.before(function *(users) {
        users[2].manager = undefined;
        users[2].isSignedUpOnBot = undefined;
        yield users[2].save();
      }.bind(this));
    });

    // generate Mocha "it" tests
    iTest.generateAllTests();
  });

  describe('add one team member (already have other manager)', () => {
    var expected = {};
    expected[TestUser[0].name] = [
      {
        expect: {
          type: 'message',
          text: "OK, who would you like to add? \n\n:bulb:Tip: You can type @ to see a dropdown with all of your coworkers. Select as many as you want"
        },

        // job function
        enterMessage: 'jared'
      },
      {
        expect: {
          type: 'message',
          text: 'Ok! Just sent Jared a quick message to confirm'
        }
      },
      {
        expect: {
          type: 'message',
          text: 'Great! Jared is now on your team!'
        }
      }
    ];

    expected[TestUser[2].name] = [
      {
        expect: {
          type: 'message',
          text: 'Susan wants to add you to their team. Can you confirm that Susan is in fact your manager? If so, your info will be updated.'
        },

        enterMessage: 'yes'
      },

      {
        expect: {
          type: 'message',
          text: 'Great! Susan is now your manager'
        }
      }
    ];

    // replaced manager
    expected[TestUser[1].name] = [
      {
        expect: {
          type: 'message',
          text: 'Jared has changed their manager to Susan. If you think this is an error, talk to Jared directly. Thanks!'
        }
      }
    ];

    var iTest = new IntegrationTest(null, TestUser[0], TestUser, expected, function() {
      this.instance.listen(this.slackUserId, this.primaryChannel, 'add team member');
    });

    before(() => {
      return iTest.before(function *(users) {
        users[2].manager = users[1].id;
        yield users[2].save();
      }.bind(this));
    });

    // generate Mocha "it" tests
    iTest.generateAllTests();
  });
});
