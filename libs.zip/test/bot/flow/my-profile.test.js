'use strict';

const Mockery = require('mockery');
const Chai = require('chai');
const Sinon = require('sinon');
const expect = Chai.expect;
const Config = require('./../../../configs/config');
const CONSTANTS = require('./../../../constants/constants');
const TestUser = require('./../configs/user');
const ModelUser = require('./../../../models/user');
const ModelJobFunction = require('./../../../models/function');
const ModelUserGoal = require('./../../../models/user-goal');
const ModelUserTrigger = require('./../../../models/user-trigger');
const ModelTrigger = require('./../../../models/trigger');
const ModelUserOkrGoal = require('./../../../models/user-okr-goal');
const Co = require('co');
const IntegrationTest = require('./../../bot-integration-test');

describe('Bot: My Profile Command', () => {
  describe('Module Personal Goal: My profile (NO job function, NO manager, NO goals, NO Trigger)', () => {
    var expected = {};
    expected[TestUser[2].name] = [
      {
        expect: {
          text: [
            {
              "fallback": "Jared's Profile",
              "color": "#3F2D4F",
              "title": "Jared's Profile",
              "mrkdwn_in": [
                "fields",
                "pretext"
              ],
              "fields": [
                {
                  "title": "Manager",
                  "value": "_not set yet_"
                },
                {
                  "title": "Direct Reports",
                  "value": "_not set yet_"
                },
                {
                  "title": "Giving Feedback To",
                  "value": "_not set yet_"
                },
                {
                  "title": "Goals",
                  "value": "_not set yet_"
                }
              ]
            }
          ]
        }
      }
    ];

    var iTest = new IntegrationTest(null, TestUser[2], TestUser, expected, function() {
      this.instance.listen(this.slackUserId, this.primaryChannel, 'my profile');
    });

    before(() => {
      return iTest.before(function *(users) {
        users[2].jobFunction = undefined;
        users[2].manager = undefined;
        yield users[2].save();

        yield ModelUser.update({ manager: users[2].id }, { manager: undefined }, { multi: true });
        yield ModelUserGoal.remove({ user: users[2].id});
        yield ModelUserTrigger.remove({ user: users[2].id });
        yield ModelUserGoal.remove({ advisors: users[2].id });

      }.bind(this));
    });

    // generate Mocha "it" tests
    iTest.generateAllTests();
  });





  describe('Module Personal Goal: My profile (HAS goals, triggers, manager, and jobFunction)', () => {
    var expected = {};
    expected[TestUser[2].name] = [
      {
        expect: {
          type: 'attachmentMessage',
          text: [
            {
              "fallback": "Jared's Profile",
              "color": "#3F2D4F",
              "title": "Jared's Profile",
              "mrkdwn_in": [
                "fields",
                "pretext"
              ],
              "fields": [
                {
                  "title": "Job Function",
                  "value": "Product Management"
                },
                {
                  "title": "Manager",
                  "value": "Monica Stabler"
                },
                {
                  "title": "Direct Reports",
                  "value": "gilfoyle"
                },
                {
                  "title": "Giving Feedback To",
                  "value": "Monica"
                }
              ]
            },
            {
              "fallback": "Goal #1. Unit test - My Profile Goal #1",
              "color": "#3F2D4F",
              "mrkdwn_in": [
                "fields",
                "pretext"
              ],
              "fields": [
                {
                  "title": "Goal #1",
                  "value": "Unit test - My Profile Goal #1"
                },
                {
                  "title": "Prompt",
                  "value": "_not set yet_"
                },
                {
                  "title": "Feedback Givers",
                  "value": "Susan and Richard"
                }
              ]
            },
            {
              "fallback": "Goal #2. Unit test - My Profile Goal #2",
              "color": "#3F2D4F",
              "mrkdwn_in": [
                "fields",
                "pretext"
              ],
              "fields": [
                {
                  "title": "Goal #2",
                  "value": "Unit test - My Profile Goal #2 *(Archived)*"
                },
                {
                  "title": "Prompt",
                  "value": "12pm monday"
                },
                {
                  "title": "Feedback Givers",
                  "value": "Susan and Richard"
                }
              ]
            }
          ]
        }
      }
    ];

    var iTest = new IntegrationTest(null, TestUser[2], TestUser, expected, function() {
      this.instance.listen(this.slackUserId, this.primaryChannel, 'my profile');
    });

    before(() => {
      return iTest.before(function *(users) {
        var jobFunction = yield ModelJobFunction.findOne({ name: 'Product Management'});
        var trigger = yield ModelTrigger.findOne({ systemKey: 'Regular Time Interval'});

        users[2].jobFunction = jobFunction.id;
        users[2].manager = users[3].id;
        yield users[2].save();

        users[4].manager = users[2].id;
        yield users[4].save();

        yield ModelUserGoal.remove({user: users[2].id});
        yield ModelUserTrigger.remove({user: users[2].id});
        yield ModelUserGoal.remove({advisors: users[2].id});

        var userGoal = new ModelUserGoal();
        userGoal.name = 'Unit test - My Profile Goal #1';
        userGoal.user = users[2].id;
        userGoal.status = CONSTANTS.DB.STATUS.ACTIVE;
        userGoal.advisors = [users[0].id, users[1].id];
        yield userGoal.save();

        userGoal = new ModelUserGoal();
        userGoal.name = 'Unit test - My Profile Goal #2';
        userGoal.user = users[2].id;
        userGoal.status = CONSTANTS.DB.STATUS.ARCHIVED;
        userGoal.advisors = [users[0].id, users[1].id];
        yield userGoal.save();

        var userTrigger = new ModelUserTrigger();
        userTrigger.frequencyUserText = '12pm monday';
        userTrigger.frequencyCron = '0 12 * * 1';
        userTrigger.user = users[2].id;
        userTrigger.status = CONSTANTS.DB.STATUS.ACTIVE;
        userTrigger.trigger = trigger.id;
        userTrigger.userGoal = userGoal.id;
        yield userTrigger.save();

        // make user a reviewer for someone's goal
        userGoal = new ModelUserGoal();
        userGoal.name = 'Unit test - My Profile Goal #3';
        userGoal.user = users[3].id;
        userGoal.status = CONSTANTS.DB.STATUS.ACTIVE;
        userGoal.advisors = [users[2].id, users[1].id];
        yield userGoal.save();

      }.bind(this));
    });

    after(() => {
      return ModelUserGoal.remove({ name: 'Unit test - My Profile Goal #1' });
    });

    // generate Mocha "it" tests
    iTest.generateAllTests();
  });




  describe('Module OKR: My profile (NO job function, NO manager, NO goals, NO Trigger)', () => {
    var expected = {};
    expected[TestUser[2].name] = [
      {
        expect: {
          type: 'attachmentMessage',
          text: [
            {
              "fallback": "Jared's Profile",
              "color": "#3F2D4F",
              "title": "Jared's Profile",
              "mrkdwn_in": [
                "fields",
                "pretext"
              ],
              "fields": [
                {
                  "title": "Manager",
                  "value": "_not set yet_"
                },
                {
                  "title": "Direct Reports",
                  "value": "_not set yet_"
                },
                {
                  "title": "Self-assessment time",
                  "value": "every other Friday at 10AM"
                },
                {
                  "title": "OKR",
                  "value": "_none_"
                }
              ]
            }
          ]
        }
      }
    ];

    var enabledModules = {};
    enabledModules[CONSTANTS.MODULES.OKR] = true;
    var iTest = new IntegrationTest(enabledModules, TestUser[2], TestUser, expected, function() {
      this.instance.listen(this.slackUserId, this.primaryChannel, 'my profile');
    });

    before(() => {
      return iTest.before(function *(users) {
        users[2].jobFunction = undefined;
        users[2].manager = undefined;
        users[2].selfAssessment = undefined;
        yield users[2].save();

        yield ModelUser.update({ manager: users[2].id }, { manager: undefined }, { multi: true });
        yield ModelUserOkrGoal.remove({ user: users[2].id });

      }.bind(this));
    });

    // generate Mocha "it" tests
    iTest.generateAllTests();
  });




  describe('Module OKR: My profile (HAS goals, triggers, manager, and jobFunction)', () => {
    var expected = {};
    expected[TestUser[2].name] = [
      {
        expect: {
          type: 'attachmentMessage',
          text: [
            {
              "fallback": "Jared's Profile",
              "color": "#3F2D4F",
              "title": "Jared's Profile",
              "mrkdwn_in": [
                "fields",
                "pretext"
              ],
              "fields": [
                {
                  "title": "Job Function",
                  "value": "Product Management"
                },
                {
                  "title": "Manager",
                  "value": "Monica Stabler"
                },
                {
                  "title": "Direct Reports",
                  "value": "gilfoyle"
                },
                {
                  "title": "Self-assessment time",
                  "value": "every other Friday at 10AM"
                }
              ]
            },
            {
              "color": "#3F2D4F",
              "fallback": "ORK #1. Unit test - My OKR #1",
              "fields": [
                {
                  "title": "OKR #1",
                  "value": "Unit test - My OKR #1"
                }
              ],
              "mrkdwn_in": [
                "fields",
                "pretext"
              ]
            },
            {
              "color": "#3F2D4F",
              "fallback": "ORK #2. Unit test - My OKR #2",
              "fields": [
                {
                  "title": "OKR #2",
                  "value": "Unit test - My OKR #2 *(Archived)*"
                }
              ],
              "mrkdwn_in": [
                "fields",
                "pretext"
              ]
            }
          ]
        }
      }
    ];

    var enabledModules = {};
    enabledModules[CONSTANTS.MODULES.OKR] = true;
    var iTest = new IntegrationTest(enabledModules, TestUser[2], TestUser, expected, function() {
      this.instance.listen(this.slackUserId, this.primaryChannel, 'my profile');
    });

    before(() => {
      return iTest.before(function *(users) {
        var jobFunction = yield ModelJobFunction.findOne({ name: 'Product Management'});
        var trigger = yield ModelTrigger.findOne({ systemKey: 'Regular Time Interval'});

        users[2].jobFunction = jobFunction.id;
        users[2].manager = users[3].id;
        users[2].selfAssessment = undefined;
        yield users[2].save();

        users[4].manager = users[2].id;
        yield users[4].save();

        yield ModelUserOkrGoal.remove({ user: users[2].id});

        var okr = new ModelUserOkrGoal();
        okr.name = 'Unit test - My OKR #1';
        okr.user = users[2].id;
        okr.status = CONSTANTS.DB.STATUS.ACTIVE;
        okr.advisors = [users[2].id];
        yield okr.save();

        okr = new ModelUserOkrGoal();
        okr.name = 'Unit test - My OKR #2';
        okr.user = users[2].id;
        okr.status = CONSTANTS.DB.STATUS.ARCHIVED;
        okr.advisors = [users[2].id];
        yield okr.save();

      }.bind(this));
    });

    after(() => {
      return ModelUserGoal.remove({ name: 'Unit test - My Profile Goal #1' });
    });

    // generate Mocha "it" tests
    iTest.generateAllTests();
  });

});
