'use strict';

const Mockery = require('mockery');
const Chai = require('chai');
const Sinon = require('sinon');
const expect = Chai.expect;
const Config = require('./../../../configs/config');
const CONSTANTS = require('./../../../constants/constants');
const TestUser = require('./../configs/user');
const ModelUser = require('./../../../models/user');
const ModelJobFunction = require('./../../../models/function');
const ModelUserGoal = require('./../../../models/user-goal');
const ModelUserTrigger = require('./../../../models/user-trigger');
const Co = require('co');
const IntegrationTest = require('./../../bot-integration-test');
const _ = require('lodash');

describe('Bot: Main FTUE', () => {
 describe('Set up as employee', () => {
   var expected = {};
   expected[TestUser[3].name] = [
      {
        expect: {
          text: "Hi Monica :wave:! I'm CareerLark, your friendly :robot_face:. I’m going to help you give and get micro-feedback to take your career to the next level. Let's get you set up. This will only take a few moments.\nIf you’re a manager looking to get your team set up to give and receive feedback type `manager`. Otherwise, type `individual feedback` to start getting micro-feedback from your coworkers.\n\nYou can also type `help` at any point if you get stuck."
        },

        enterMessage: 'employee'
      },
      {
        expect: {
          text: "Great! Let’s get you set up! Who would you like to get feedback from?\n\nWe recommend choosing folks that you work closely with, who can provide you with meaningful guidance. We'll let them know that you value their input and are adding them as reviewers. \n\n:bulb:Tip: You can type @ to see a dropdown with all of your coworkers. Select as many as you want"
        },

        enterMessage: TestUser[4].slackUserName
      },
      {
         expect: {
           text: "Sweet! I'll be pinging them for feedback for you every 2 weeks."
         }
      }
   ];

   expected[TestUser[4].name] = [
     {
       expect: {
         text: /^Hi gilfoyle! I'm CareerLark, your friendly bot that helps everyone share more feedback\. Your coworker Monica has selected you as a feedback giver\. I'll prompt you to give Monica feedback every other (Monday|Tuesday|Wednesday|Thursday|Friday) at 10AM/ig
       }
     }
   ];

   var iTest = new IntegrationTest(null, TestUser[3], TestUser, expected, function() {
     this.instance.handleQueue({
       slackUserId: this.slackUserId,
       task: require('./../../../bot/tasks/feedback/ftue'),
       context: {
         userFirstName: TestUser[3].firstName,
         appName: Config.appName,
         slackUserId: this.slackUserId
       }
     });
   });

   before(() => {
     return iTest.before(function *(users) {
       users[4].jobFunction = undefined;
       yield users[4].save();

       users[3].isSignedUpOnBot = undefined;
       yield users[3].save();

       yield ModelUserGoal.remove( { user: users[3].id });
       yield ModelUserTrigger.remove( { user: users[3].id });
     }.bind(this));
   });

   // generate Mocha "it" tests
   iTest.generateAllTests();

   it('should save data', done => {
     Co(function *() {
       try {
         var user3 = yield ModelUser.findOne({ slackUserId: TestUser[3].slackUserId });
         var goal = yield ModelUserGoal.findOne({ user: user3.id, isGeneral: true });
         var trigger = yield ModelUserTrigger.findOne({ user: user3.id });

         expect(goal).to.be.an('object');
         expect(trigger).to.be.an('object');

         done();
       }
       catch (ex) {
         done(ex);
       }
     }.bind(this));
   });

  });
});

