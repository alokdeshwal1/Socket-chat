'use strict';

const Mockery = require('mockery');
const Chai = require('chai');
const Sinon = require('sinon');
const expect = Chai.expect;
const Config = require('./../../../configs/config');
const CONSTANTS = require('./../../../constants/constants');
const TestUser = require('./../configs/user');
const ModelUser = require('./../../../models/user');
const ModelUserGoal = require('./../../../models/user-goal');
const ModelJobFunction = require('./../../../models/function');
const ModelFeedback = require('./../../../models/feedback');
const Co = require('co');
const IntegrationTest = require('./../../bot-integration-test');
const _ = require('lodash');

describe('Bot: Delete Goal', () => {
  describe('delete goal that has NO feedback', () => {
    var expected = {};
    expected[TestUser[2].name] = [
      {
        overwriteTest: function(expected, result) {
          expect(result.length).to.equal(1);
          delete result[0].callback_id;
          expect(result).to.deep.equal(expected);
          return true;
        },
        expect: {
          text: [
            {
              "actions": [
                {
                  "name": ":one:",
                  "style": "primary",
                  "text": ":one:",
                  "type": "button",
                  "value": ":one:"
                }
              ],
              "attachment_type": "default",
              "color": "#DA552F",
              "fallback": "Select a goal",
              "fields": [
                {
                  "title": "Goals",
                  "value": ":one: Unit test user goal\n\nPick a button:"
                }
              ],
              "mrkdwn_in": [
                "fields",
                "pretext",
                "text"
              ],
              "pretext": "Alrighty, which goal?"
            }
          ]
        },

        enterMessage: '1'
      },
      {
        expect: {
          type: 'message',
          text: 'OK, done! :tada:'
        }
      }
    ];

    var iTest = new IntegrationTest(null, TestUser[2], TestUser, expected, function() {
      this.instance.listen(this.slackUserId, this.primaryChannel, 'delete goal');
    });

    before(() => {
      return iTest.before(function *(users) {
        yield ModelUserGoal.remove({ user: users[2].id });

        var userGoal = new ModelUserGoal();
        userGoal.name = 'Unit test user goal';
        userGoal.user = users[2].id;
        userGoal.status = CONSTANTS.DB.STATUS.ACTIVE;
        userGoal.advisors = [users[0].id, users[1].id];

        yield userGoal.save();
      }.bind(this));
    });

    // generate Mocha "it" tests
    iTest.generateAllTests();
  });

  describe('delete goal that has One or more feedback (prompt for Archive confirmation - enter YES)', () => {
    var expected = {};
    expected[TestUser[2].name] = [
      {
        overwriteTest: function(expected, result) {
          expect(result.length).to.equal(1);
          delete result[0].callback_id;
          expect(result).to.deep.equal(expected);
          return true;
        },
        expect: {
          text: [
            {
              "actions": [
                {
                  "name": ":one:",
                  "style": "primary",
                  "text": ":one:",
                  "type": "button",
                  "value": ":one:"
                }
              ],
              "attachment_type": "default",
              "color": "#DA552F",
              "fallback": "Select a goal",
              "fields": [
                {
                  "title": "Goals",
                  "value": ":one: Unit test user goal\n\nPick a button:"
                }
              ],
              "mrkdwn_in": [
                "fields",
                "pretext",
                "text"
              ],
              "pretext": "Alrighty, which goal?"
            }
          ]
        },

        enterMessage: '1'
      },
      {
        expect: {
          type: 'message',
          text: 'You’ve already gotten some feedback on this goal, so we can’t delete it. Would you like to archive it instead?'
        },

        enterMessage: 'yes'
      },
      {
        expect: {
          type: 'message',
          text: 'OK, done! :tada:'
        },

        enterMessage: 'delete goal'
      },
      {
        expect: {
          type: 'message',
          text: 'It looks you haven\'t don\'t have any goals set up yet. Do that first and then you can delete them if you really want :wink:'
        }
      }
    ];

    var iTest = new IntegrationTest(null, TestUser[2], TestUser, expected, function() {
      this.instance.listen(this.slackUserId, this.primaryChannel, 'delete goal');
    });

    before(() => {
      return iTest.before(function *(users) {
        yield ModelUserGoal.remove({ user: users[2].id });

        var userGoal = new ModelUserGoal();
        userGoal.name = 'Unit test user goal';
        userGoal.user = users[2].id;
        userGoal.status = CONSTANTS.DB.STATUS.ACTIVE;
        userGoal.advisors = [users[0].id, users[1].id];
        yield userGoal.save();

        var feedback = new ModelFeedback();
        feedback.feedbackEmoji = ':joy:';
        feedback.feedbackComment = 'Unit test feedback';
        feedback.feedbackRating = '5';
        feedback.feedbackRating = '5';
        feedback.userGoal = userGoal.id;
        feedback.user = users[2].id;
        feedback.advisor = users[0].id;
        yield feedback.save();
      }.bind(this));
    });

    // generate Mocha "it" tests
    iTest.generateAllTests();
  });

  describe('delete goal that has One or more feedback (prompt for Archive confirmation - enter delete goal again)', () => {
    var expected = {};
    expected[TestUser[2].name] = [
      {
        overwriteTest: function(expected, result) {
          expect(result.length).to.equal(1);
          delete result[0].callback_id;
          expect(result).to.deep.equal(expected);
          return true;
        },
        expect: {
          text: [
            {
              "actions": [
                {
                  "name": ":one:",
                  "style": "primary",
                  "text": ":one:",
                  "type": "button",
                  "value": ":one:"
                }
              ],
              "attachment_type": "default",
              "color": "#DA552F",
              "fallback": "Select a goal",
              "fields": [
                {
                  "title": "Goals",
                  "value": ":one: Unit test user goal\n\nPick a button:"
                }
              ],
              "mrkdwn_in": [
                "fields",
                "pretext",
                "text"
              ],
              "pretext": "Alrighty, which goal?"
            }
          ]
        },

        enterMessage: '1'
      },
      {
        expect: {
          type: 'message',
          text: 'You’ve already gotten some feedback on this goal, so we can’t delete it. Would you like to archive it instead?'
        },

        enterMessage: 'delete goal'
      },
      {
        overwriteTest: function(expected, result) {
          expect(result.length).to.equal(1);
          delete result[0].callback_id;
          expect(result).to.deep.equal(expected);
          return true;
        },
        expect: {
          text: [
            {
              "actions": [
                {
                  "name": ":one:",
                  "style": "primary",
                  "text": ":one:",
                  "type": "button",
                  "value": ":one:"
                }
              ],
              "attachment_type": "default",
              "color": "#DA552F",
              "fallback": "Select a goal",
              "fields": [
                {
                  "title": "Goals",
                  "value": ":one: Unit test user goal\n\nPick a button:"
                }
              ],
              "mrkdwn_in": [
                "fields",
                "pretext",
                "text"
              ],
              "pretext": "Alrighty, which goal?"
            }
          ]
        }
      }
    ];

    var iTest = new IntegrationTest(null, TestUser[2], TestUser, expected, function() {
      this.instance.listen(this.slackUserId, this.primaryChannel, 'delete goal');
    });

    before(() => {
      return iTest.before(function *(users) {
        yield ModelUserGoal.remove({ user: users[2].id });

        var userGoal = new ModelUserGoal();
        userGoal.name = 'Unit test user goal';
        userGoal.user = users[2].id;
        userGoal.status = CONSTANTS.DB.STATUS.ACTIVE;
        userGoal.advisors = [users[0].id, users[1].id];
        yield userGoal.save();

        var feedback = new ModelFeedback();
        feedback.feedbackEmoji = ':joy:';
        feedback.feedbackComment = 'Unit test feedback';
        feedback.feedbackRating = '5';
        feedback.feedbackRating = '5';
        feedback.userGoal = userGoal.id;
        feedback.user = users[2].id;
        feedback.advisor = users[0].id;
        yield feedback.save();
      }.bind(this));
    });

    // generate Mocha "it" tests
    iTest.generateAllTests();
  });
});
