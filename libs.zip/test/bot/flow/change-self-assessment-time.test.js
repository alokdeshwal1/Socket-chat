'use strict';

const Mockery = require('mockery');
const Chai = require('chai');
const Sinon = require('sinon');
const expect = Chai.expect;
const Config = require('./../../../configs/config');
const CONSTANTS = require('./../../../constants/constants');
const TestUser = require('./../configs/user');
const ModelUser = require('./../../../models/user');
const ModelJobFunction = require('./../../../models/function');
const Co = require('co');
const IntegrationTest = require('./../../bot-integration-test');
const _ = require('lodash');

describe('Bot: Change Self Assessment Time', () => {
  describe('Change Self Assessment Time', () => {
    var expected = {};
    expected[TestUser[4].name] = [
      {
        expect: {
          type: 'attachmentMessage',
          text: "OK, can you tell me at what interval? Here are the types of things that I understand (I'm working on it but I'm a bot after all :simple_smile:) \n`every Monday at 3:30pm` \n`daily 10:30AM` \n`1st Tues of every month` \n`9PM on Sundays`"
        },

        enterMessage: 'every Monday at 4:30pm'
      },
      {
        overwriteTest: function(expected, result) {
          expect(result[0].fields[0].value).to.match(expected[0].fields[0].value);
          delete result[0].fields[0].value;
          delete expected[0].fields[0].value;
          expect(result).to.deep.equal(expected);
          return true;
        },
        expect: {
          type: 'message',
          text: [
            {
              "color": "#DA552F",
              "fallback": "Cool, this is what I have. Sound good? Say `yes` or `no`",
              "fields": [
                {
                  "value": /\d+\/\d+ Monday 4:30PM\n\d+\/\d+ Monday 4:30PM\n\d+\/\d+ Monday 4:30PM/
                }
              ],
              "mrkdwn_in": [
                "fields",
                "pretext"
              ],
              "pretext": "Cool, this is what I have. Sound good? Say `yes` or `no`"
            }
          ]
        },

        enterMessage: 'yes'
      },
      {
        expect: {
          type: 'message',
          text: "Got it!"
        }
      },
      {
        expect: {
          type: 'message',
          text: "Done"
        }
      }
    ];

    var iTest = new IntegrationTest(null, TestUser[4], TestUser, expected, function() {
      this.instance.listen(this.slackUserId, this.primaryChannel, 'change self assessment time');
    });

    before(() => {
      return iTest.before();
    });

    // generate Mocha "it" tests
    iTest.generateAllTests();
  });
});
