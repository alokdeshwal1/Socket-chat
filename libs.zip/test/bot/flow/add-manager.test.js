'use strict';

const Mockery = require('mockery');
const Chai = require('chai');
const Sinon = require('sinon');
const expect = Chai.expect;
const Config = require('./../../../configs/config');
const CONSTANTS = require('./../../../constants/constants');
const TestUser = require('./../configs/user');
const ModelUser = require('./../../../models/user');
const ModelJobFunction = require('./../../../models/function');
const Co = require('co');
const IntegrationTest = require('./../../bot-integration-test');
const TaskGatherFunction = require('./../../../bot/tasks/feedback/gather-function');
const _ = require('lodash');

describe('Bot: Add Manager', () => {
  describe('add manager (user has NO manager, manager already signup) - Susan adds Richard as Manager', () => {
    var expected = {};
    expected[TestUser[0].name] = [
      {
        expect: {
          type: 'message',
          text: "OK, who would you like to add? \n\n:bulb:Tip: You can type @ to see a dropdown with all of your coworkers. Select as many as you want"
        },

        // job function
        enterMessage: 'richard'
      },
      {
        expect: {
          type: 'message',
          text: 'Awesome. I just added Richard as your manager.'
        }
      }
    ];

    // manager
    expected[TestUser[1].name] = [
      {
        expect: {
          type: 'message',
          text: 'Hi! Susan just added you as a manager on CareerLark. We\'ll be prompting you periodically for some lightweight feedback once Susan has set up some goals.'
        }
      },

      {
        expect: {
          type: 'message',
          text: '\nI can help you give lightweight feedback to your other team member as well on areas that they want to grow in. Let’s get the rest of your reports set up. Can you tell me their slack names?'
        }
      }
    ];

    var iTest = new IntegrationTest(null, TestUser[0], TestUser, expected, function() {
      this.instance.listen(this.slackUserId, this.primaryChannel, 'add manager');
    });

    before(() => {
      return iTest.before(function *(users) {
        users[0].manager = undefined;
        yield users[0].save();

        users[1].jobFunction = undefined;
        yield users[1].save();
      }.bind(this));
    });

    // generate Mocha "it" tests
    iTest.generateAllTests();
  });
});
