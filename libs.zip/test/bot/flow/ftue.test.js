'use strict';

const Mockery = require('mockery');
const Chai = require('chai');
const Sinon = require('sinon');
const expect = Chai.expect;
const Config = require('./../../../configs/config');
const CONSTANTS = require('./../../../constants/constants');
const TestUser = require('./../configs/user');
const ModelUser = require('./../../../models/user');
const ModelJobFunction = require('./../../../models/function');
const ModelUserGoal = require('./../../../models/user-goal');
const ModelUserTrigger = require('./../../../models/user-trigger');
const Co = require('co');
const IntegrationTest = require('./../../bot-integration-test');
const _ = require('lodash');

describe('Bot: FTUE', () => {
  describe('Type Help command multiple times in FTUE should behave correctly', () => {
    var expected = {};
    expected[TestUser[3].name] = [
      {
        expect: {
          text: "Hi Monica :wave:! I'm CareerLark, your friendly :robot_face:. I’m going to help you give and get micro-feedback to take your career to the next level. Let's get you set up. This will only take a few moments.\nIf you’re a manager looking to get your team set up to give and receive feedback type `manager`. Otherwise, type `individual feedback` to start getting micro-feedback from your coworkers.\n\nYou can also type `help` at any point if you get stuck."
        },

        enterMessage: 'help'
      },
      {
        expect: {
          text: "Help is on the way! \n\n*General* \n`cancel`: cancels you out of the current task \n`view my profile`: see your job function, manager, direct reports, and goals \n`request feedback`: request feedback from someone on a particular goal \n\n*Update goals* \n`add goal`: set up new goals with associated reviewers and feedback prompts \n`delete goal`: delete a goal from your records. Note: If a goal has already received feedback, it can no longer be deleted\n`archive goal` : stop prompting for feedback for a particular goal. You will still be able to see prior feedback \n\n*Update your manager* \n`change manager` `to [@lauriel]` \n`add manager` `[@richard]` \n\n*Update your team (for managers)*  \n`add direct report` `[@erlich]` : add to the group of people that you manage and give feedback to. You are able to see all feedback given to your direct reports \n`phase out direct report` `[@erlich]` : take this person out of the group of people you manage and give feedback to \n\n*Update your feedback receivers* \n`take me off as reviewer` `[@dinsh]` : stop giving feedback for this person \n\n*Feedback summaries* \n`summary` : pull up feedback history. You can specify the following options: \n\n`weekly` `monthly` \n\n`for [@gabe]` : get feedback history for a specific person \n`for team` : get a feedback snapshot of the whole team (for managers) \n`for me` : get your own feedback history \n\n`from [@peter]` : get feedback history from a person \n\n`archived` `active` : pull feedback history for specific types of goals"
        }
      },
      {
        expect: {
          text: "Hi Monica :wave:! I'm CareerLark, your friendly :robot_face:. I’m going to help you give and get micro-feedback to take your career to the next level. Let's get you set up. This will only take a few moments.\nIf you’re a manager looking to get your team set up to give and receive feedback type `manager`. Otherwise, type `individual feedback` to start getting micro-feedback from your coworkers.\n\nYou can also type `help` at any point if you get stuck."
        },

        enterMessage: 'delete goal'
      },
      {
        overwriteTest: function(expected, result) {
          expect(result.length).to.equal(1);
          delete result[0].callback_id;
          expect(result).to.deep.equal(expected);
          return true;
        },
        expect: {
          text: [
            {
              "actions": [
                {
                  "name": ":one:",
                  "style": "primary",
                  "text": ":one:",
                  "type": "button",
                  "value": ":one:"
                }
              ],
              "attachment_type": "default",
              "color": "#DA552F",
              "fallback": "Select a goal",
              "fields": [
                {
                  "title": "Goals",
                  "value": ":one: Unit test user goal\n\nPick a button:"
                }
              ],
              "mrkdwn_in": [
                "fields",
                "pretext",
                "text"
              ],
              "pretext": "Alrighty, which goal?"
            }
          ]
        }
      }
    ];

    var iTest = new IntegrationTest(null, TestUser[3], TestUser, expected, function() {
      this.instance.handleQueue({
        slackUserId: this.slackUserId,
        task: require('./../../../bot/tasks/feedback/ftue'),
        context: {
          userFirstName: TestUser[3].firstName,
          appName: Config.appName,
          slackUserId: this.slackUserId
        }
      });
    });

    before(() => {
      return iTest.before(function *(users) {
        users[4].jobFunction = undefined;
        users[4].manager = undefined;
        yield users[4].save();

        users[3].isSignedUpOnBot = undefined;
        yield users[3].save();

        yield ModelUserGoal.remove({ user: users[3].id });
        var userGoal = new ModelUserGoal();
        userGoal.name = 'Unit test user goal';
        userGoal.user = users[3].id;
        userGoal.status = CONSTANTS.DB.STATUS.ACTIVE;
        userGoal.advisors = [users[0].id, users[1].id];
        yield userGoal.save();
      }.bind(this));
    });

    // generate Mocha "it" tests
    iTest.generateAllTests();
  });





  describe('Set up as manager, employee does NOT have manager yet', () => {
    var expected = {};
    expected[TestUser[3].name] = [
      {
        expect: {
          type: 'message',
          text: "Hi Monica :wave:! I'm CareerLark, your friendly :robot_face:. I’m going to help you give and get micro-feedback to take your career to the next level. Let's get you set up. This will only take a few moments.\nIf you’re a manager looking to get your team set up to give and receive feedback type `manager`. Otherwise, type `individual feedback` to start getting micro-feedback from your coworkers.\n\nYou can also type `help` at any point if you get stuck."
        },

        enterMessage: 'manager'
      },
      {
        expect: {
          type: 'message',
          text: "Great! Who are your direct reports? I'll send them invites to get started.\n\n:bulb: Tip: type @ to see a dropdown with all of your coworkers. Select as many as you want."
        },

        enterMessage: TestUser[4].slackUserName
      },
      {
        expect: {
          type: 'message',
          text: 'Great, thanks! :+1: I\'m going to now ping them and get them set up with their goals. Once they\'re done I\'ll let you know and we\'ll start pinging you for quick feedback.'
        }
      },
      {
        expect: {
          type: 'message',
          text: 'Now try typing `help`!'
        }
      }
    ];

    expected[TestUser[4].name] = [
      {
        expect: {
          type: 'message',
          text: 'Hi gilfoyle! :wave: Your manager Monica just signed you up for CareerLark, a friendly :robot_face: that is going to help you give and receive lightweight feedback. Let’s get your goals set up so you can take your career to the next level! This will only take a few minutes.\n\n(pro tip: type `back` to re-enter, `cancel` to end the current task, or `help` for other commands)'
        }
      },
      {
        expect: {
          type: 'attachmentMessage',
          text: "Great! Let’s get you set up! Who would you like to get feedback from?\n\nWe recommend choosing folks that you work closely with, who can provide you with meaningful guidance. We'll let them know that you value their input and are adding them as reviewers. \n\n:bulb:Tip: You can type @ to see a dropdown with all of your coworkers. Select as many as you want"
        }
      }
    ];

    var iTest = new IntegrationTest(null, TestUser[3], TestUser, expected, function() {
      this.instance.handleQueue({
        slackUserId: this.slackUserId,
        task: require('./../../../bot/tasks/feedback/ftue'),
        context: {
          userFirstName: TestUser[3].firstName,
          appName: Config.appName,
          slackUserId: this.slackUserId
        }
      });
    });

    before(() => {
      return iTest.before(function *(users) {
        yield ModelUser.update({ _id: users[4].id }, {
          jobFunction: undefined,
          manager: undefined,
          isSignedUpOnBot: undefined
        }, { multi: true });

        users[3].isSignedUpOnBot = undefined;
        yield users[3].save();
      }.bind(this));
    });

    // generate Mocha "it" tests
    iTest.generateAllTests();
  });





  describe('Set up as manager, employee does have manager', () => {
    var expected = {};
    expected[TestUser[3].name] = [
      {
        expect: {
          type: 'message',
          text: "Hi Monica :wave:! I'm CareerLark, your friendly :robot_face:. I’m going to help you give and get micro-feedback to take your career to the next level. Let's get you set up. This will only take a few moments.\nIf you’re a manager looking to get your team set up to give and receive feedback type `manager`. Otherwise, type `individual feedback` to start getting micro-feedback from your coworkers.\n\nYou can also type `help` at any point if you get stuck."
        },

        enterMessage: 'manager'
      },
      {
        expect: {
          type: 'message',
          text: "Great! Who are your direct reports? I'll send them invites to get started.\n\n:bulb: Tip: type @ to see a dropdown with all of your coworkers. Select as many as you want."
        },

        enterMessage: TestUser[4].firstName
      },

      {
        expect: {
          type: 'message',
          text: 'Ok! Just sent gilfoyle a quick message to confirm'
        }
      },

      {
        expect: {
          type: 'message',
          text: 'Now try typing `help`!'
        }
      }
    ];

    expected[TestUser[4].name] = [
      {
        expect: {
          type: 'message',
          text: 'Monica wants to add you to their team. Can you confirm that Monica is in fact your manager? If so, your info will be updated.'
        }
      }
    ];

    var iTest = new IntegrationTest(null, TestUser[3], TestUser, expected, function() {
      this.instance.handleQueue({
        slackUserId: this.slackUserId,
        task: require('./../../../bot/tasks/feedback/ftue'),
        context: {
          userFirstName: TestUser[3].firstName,
          appName: Config.appName,
          slackUserId: this.slackUserId
        }
      });
    });

    before(() => {
      return iTest.before(function *(users) {
        users[4].jobFunction = undefined;
        users[4].manager = users[2].id;
        yield users[4].save();

        users[3].isSignedUpOnBot = undefined;
        yield users[3].save();
      }.bind(this));
    });

    // generate Mocha "it" tests
    iTest.generateAllTests();
  });





  describe('Set up as manager, employee already in the team', () => {
    var expected = {};
    expected[TestUser[3].name] = [
      {
        expect: {
          type: 'message',
          text: "Hi Monica :wave:! I'm CareerLark, your friendly :robot_face:. I’m going to help you give and get micro-feedback to take your career to the next level. Let's get you set up. This will only take a few moments.\nIf you’re a manager looking to get your team set up to give and receive feedback type `manager`. Otherwise, type `individual feedback` to start getting micro-feedback from your coworkers.\n\nYou can also type `help` at any point if you get stuck."
        },

        enterMessage: 'manager'
      },
      {
        expect: {
          type: 'message',
          text: "Great! Who are your direct reports? I'll send them invites to get started.\n\n:bulb: Tip: type @ to see a dropdown with all of your coworkers. Select as many as you want."
        },

        enterMessage: TestUser[4].slackUserName
      },

      {
        expect: {
          type: 'message',
          text: 'Looks like gilfoyle has already signed up. Type `summary for gilfoyle` to see a summary.'
        }
      },

      {
        expect: {
          type: 'message',
          text: 'Now try typing `help`!'
        }
      }
    ];

    var iTest = new IntegrationTest(null, TestUser[3], TestUser, expected, function() {
      this.instance.handleQueue({
        slackUserId: this.slackUserId,
        task: require('./../../../bot/tasks/feedback/ftue'),
        context: {
          userFirstName: TestUser[3].firstName,
          appName: Config.appName,
          slackUserId: this.slackUserId
        }
      });
    });

    before(() => {
      return iTest.before(function *(users) {
        users[4].jobFunction = undefined;
        users[4].manager = users[3].id;
        yield users[4].save();

        users[3].isSignedUpOnBot = undefined;
        yield users[3].save();
      }.bind(this));
    });

    // generate Mocha "it" tests
    iTest.generateAllTests();
  });





  describe('When set up as employee', () => {
    var expected = {};
    expected[TestUser[3].name] = [
      {
        expect: {
          type: 'message',
          text: "Hi Monica :wave:! I'm CareerLark, your friendly :robot_face:. I’m going to help you give and get micro-feedback to take your career to the next level. Let's get you set up. This will only take a few moments.\nIf you’re a manager looking to get your team set up to give and receive feedback type `manager`. Otherwise, type `individual feedback` to start getting micro-feedback from your coworkers.\n\nYou can also type `help` at any point if you get stuck."
        },

        enterMessage: 'employee'
      },
      {
        expect: {
          type: 'attachmentMessage',
          text: "Great! Let’s get you set up! Who would you like to get feedback from?\n\nWe recommend choosing folks that you work closely with, who can provide you with meaningful guidance. We'll let them know that you value their input and are adding them as reviewers. \n\n:bulb:Tip: You can type @ to see a dropdown with all of your coworkers. Select as many as you want"
        }
      }
    ];

    var iTest = new IntegrationTest(null, TestUser[3], TestUser, expected, function() {
      this.instance.handleQueue({
        slackUserId: this.slackUserId,
        task: require('./../../../bot/tasks/feedback/ftue'),
        context: {
          userFirstName: TestUser[3].firstName,
          appName: Config.appName,
          slackUserId: this.slackUserId
        }
      });
    });

    before(() => {
      return iTest.before(function *(users) {
        users[4].jobFunction = undefined;
        yield users[4].save();

        users[3].isSignedUpOnBot = undefined;
        yield users[3].save();
      }.bind(this));
    });

    // generate Mocha "it" tests
    iTest.generateAllTests();
  });
});

