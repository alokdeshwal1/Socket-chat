'use strict';

const Mockery = require('mockery');
const Chai = require('chai');
const Sinon = require('sinon');
const expect = Chai.expect;
const Config = require('./../../../configs/config');
const CONSTANTS = require('./../../../constants/constants');
const TestUser = require('./../configs/user');
const ModelUser = require('./../../../models/user');
const ModelJobFunction = require('./../../../models/function');
const ModelUserGoal = require('./../../../models/user-goal');
const Co = require('co');
const IntegrationTest = require('./../../bot-integration-test');
const _ = require('lodash');
const TaskGatherFeedback = require('./../../../bot/tasks/feedback/gather-feedback');
const Helper = require('./../../../bot/libs/helper');

describe('Bot: Button Gather Feedback', () => {
  describe('Scenario: Click on emoji button', () => {
    var expected = {};
    var testUserGoal;
    var globalUsers;
    expected[TestUser[4].name] = [
      {
        overwriteTest: function(expected, result) {
          expect(result.length).to.equal(1);
          delete result[0].callback_id;
          expect(result).to.deep.equal(expected);
          return true;
        },
        expect: {
          text: [
            {
              "actions": [
                {
                  "name": ":disappointed:",
                  "style": "primary",
                  "text": ":disappointed:",
                  "type": "button",
                  "value": ":disappointed:"
                },
                {
                  "name": ":neutral_face:",
                  "style": "primary",
                  "text": ":neutral_face:",
                  "type": "button",
                  "value": ":neutral_face:"
                },
                {
                  "name": ":simple_smile:",
                  "style": "primary",
                  "text": ":simple_smile:",
                  "type": "button",
                  "value": ":simple_smile:"
                },
                {
                  "name": ":smile:",
                  "style": "primary",
                  "text": ":smile:",
                  "type": "button",
                  "value": ":smile:"
                },
                {
                  "name": ":joy:",
                  "style": "primary",
                  "text": ":joy:",
                  "type": "button",
                  "value": ":joy:"
                }
              ],
              "attachment_type": "default",
              "color": "#DA552F",
              "fallback": Helper.replaceMessagePlaceholder(TaskGatherFeedback.interactions[0].message.fallback, {targetUserFirstName: TestUser[3].firstName}),
              "mrkdwn_in": [
                "fields",
                "pretext",
                "text"
              ],
              "text": Helper.replaceMessagePlaceholder(TaskGatherFeedback.interactions[0].message.text, {
                userFirstName: TestUser[4].firstName,
                targetUserFirstName: TestUser[3].firstName,
                targetUserGoalName: 'TestGoal'
              }),
              "title": Helper.replaceMessagePlaceholder(TaskGatherFeedback.interactions[0].message.title, {targetUserFirstName: TestUser[3].firstName})
            }
          ]
        },

        enterButtonAction: ':smile:'
      },
      {
        expect: {
          text: "Great, thanks! What in particular do you want see *Monica* do next time?"
        },

        enterMessage: 'She is progressing well.'
      },
      {
        expect: {
          text: "Awesome! :+1: I'll make sure to give Monica the message. Bye for now. :wave:"
        }
      }
    ];

    // receiver
    expected[TestUser[3].name] = [
      {
        expect: {
          text: "Hey Monica! *gilfoyle* has some feedback for you."
        }
      },
      {
        expect: {
          type: 'attachmentMessage',
          text: [
            {
              "color": "#36A64F",
              "fallback": "She is progressing well.",
              "fields": [
                {
                  "title": "Goal",
                  "value": "Unit test user goal for Feedback"
                },
                {
                  "title": "Reaction",
                  "value": ":smile:"
                },
                {
                  "title": "Comment",
                  "value": "She is progressing well."
                }
              ]
            }
          ]
        }
      }
    ];

    var iTest = new IntegrationTest(null, TestUser[4], TestUser, expected, function() {
      this.instance.handleQueue({
        slackUserId: this.slackUserId,
        task: require('./../../../bot/tasks/feedback/gather-feedback'),
        context: {
          userFirstName: TestUser[4].firstName,
          appName: Config.appName,
          targetUserFirstName: TestUser[3].firstName,
          advisor: {
            _id: globalUsers[4].id,
            firstName: TestUser[4].firstName
          },
          userGoal: testUserGoal,
          targetUser: globalUsers[3],
          targetUserGoalName: 'TestGoal',
          slackUserId: this.slackUserId
        }
      });
    });

    before(() => {
      return iTest.before(function *(users) {
        globalUsers = users;

        users[3].manager = users[2].id;
        yield users[3].save();

        yield ModelUserGoal.remove({ name : 'Unit test user goal for Feedback'});
        var userGoal = new ModelUserGoal();
        userGoal.name = 'Unit test user goal for Feedback';
        userGoal.user = users[3].id;
        userGoal.status = CONSTANTS.DB.STATUS.ACTIVE;
        userGoal.advisors = [users[4].id];
        testUserGoal = yield userGoal.save();

      }.bind(this));
    });

    // generate Mocha "it" tests
    iTest.generateAllTests();
  });

  describe('Scenario: Enter emoji as message', () => {
    var expected = {};
    var testUserGoal;
    var globalUsers;
    expected[TestUser[4].name] = [
      {
        overwriteTest: function(expected, result) {
          expect(result.length).to.equal(1);
          delete result[0].callback_id;
          expect(result).to.deep.equal(expected);
          return true;
        },
        expect: {
          text: [
            {
              "actions": [
                {
                  "name": ":disappointed:",
                  "style": "primary",
                  "text": ":disappointed:",
                  "type": "button",
                  "value": ":disappointed:"
                },
                {
                  "name": ":neutral_face:",
                  "style": "primary",
                  "text": ":neutral_face:",
                  "type": "button",
                  "value": ":neutral_face:"
                },
                {
                  "name": ":simple_smile:",
                  "style": "primary",
                  "text": ":simple_smile:",
                  "type": "button",
                  "value": ":simple_smile:"
                },
                {
                  "name": ":smile:",
                  "style": "primary",
                  "text": ":smile:",
                  "type": "button",
                  "value": ":smile:"
                },
                {
                  "name": ":joy:",
                  "style": "primary",
                  "text": ":joy:",
                  "type": "button",
                  "value": ":joy:"
                }
              ],
              "attachment_type": "default",
              "color": "#DA552F",
              "fallback": Helper.replaceMessagePlaceholder(TaskGatherFeedback.interactions[0].message.fallback, {targetUserFirstName: TestUser[3].firstName}),
              "mrkdwn_in": [
                "fields",
                "pretext",
                "text"
              ],
              "text": Helper.replaceMessagePlaceholder(TaskGatherFeedback.interactions[0].message.text, {
                userFirstName: TestUser[4].firstName,
                targetUserFirstName: TestUser[3].firstName,
                targetUserGoalName: 'TestGoal'
              }),
              "title": Helper.replaceMessagePlaceholder(TaskGatherFeedback.interactions[0].message.title, {targetUserFirstName: TestUser[3].firstName})
            }
          ]
        },

        enterMessage: ':smile:'
      },
      {
        expect: {
          text: "Great, to confirm this is for *Monica*'s goal of *TestGoal*?"
        },

        enterMessage: 'no'
      },
      {
        overwriteTest: function(expected, result) {
          expect(result.length).to.equal(1);
          delete result[0].callback_id;
          expect(result).to.deep.equal(expected);
          return true;
        },
        expect: {
          text: [
            {
              "actions": [
                {
                  "name": ":disappointed:",
                  "style": "primary",
                  "text": ":disappointed:",
                  "type": "button",
                  "value": ":disappointed:"
                },
                {
                  "name": ":neutral_face:",
                  "style": "primary",
                  "text": ":neutral_face:",
                  "type": "button",
                  "value": ":neutral_face:"
                },
                {
                  "name": ":simple_smile:",
                  "style": "primary",
                  "text": ":simple_smile:",
                  "type": "button",
                  "value": ":simple_smile:"
                },
                {
                  "name": ":smile:",
                  "style": "primary",
                  "text": ":smile:",
                  "type": "button",
                  "value": ":smile:"
                },
                {
                  "name": ":joy:",
                  "style": "primary",
                  "text": ":joy:",
                  "type": "button",
                  "value": ":joy:"
                }
              ],
              "attachment_type": "default",
              "color": "#DA552F",
              "fallback": Helper.replaceMessagePlaceholder(TaskGatherFeedback.interactions[0].message.fallback, {targetUserFirstName: TestUser[3].firstName}),
              "mrkdwn_in": [
                "fields",
                "pretext",
                "text"
              ],
              "text": Helper.replaceMessagePlaceholder(TaskGatherFeedback.interactions[0].message.alternativeMessage, {
                userFirstName: TestUser[4].firstName,
                targetUserFirstName: TestUser[3].firstName,
                targetUserGoalName: 'TestGoal'
              }),
              "title": Helper.replaceMessagePlaceholder(TaskGatherFeedback.interactions[0].message.title, {targetUserFirstName: TestUser[3].firstName})
            }
          ]
        },

        enterMessage: ':neutral_face:'
      },
      {
        expect: {
          text: "Great, to confirm this is for *Monica*'s goal of *TestGoal*?"
        },

        enterMessage: 'yes'
      },
      {
        expect: {
          text: "Ok. What would you like to see *Monica* do next time?"
        },

        enterMessage: 'Work harder!'
      },
      {
        expect: {
          text: "Awesome! :+1: I'll make sure to give Monica the message. Bye for now. :wave:"
        }
      }
    ];

    // manager
    expected[TestUser[2].name] = [
      {
        expect: {
          text: "Hey Jared, thought you'd like to know that Monica got this feedback from gilfoyle"
        }
      },
      {
        expect: {
          text: [
            {
              "color": "#36A64F",
              "fallback": "Work harder!",
              "fields": [
                {
                  "title": "Goal",
                  "value": "Unit test user goal for Feedback"
                },
                {
                  "title": "Reaction",
                  "value": ":neutral_face:"
                },
                {
                  "title": "Comment",
                  "value": "Work harder!"
                }
              ]
            }
          ]
        }
      }
    ];

    // receiver
    expected[TestUser[3].name] = [
      {
        expect: {
          text: "Hey Monica! *gilfoyle* has some feedback for you."
        }
      },
      {
        expect: {
          text: [
            {
              "color": "#36A64F",
              "fallback": "Work harder!",
              "fields": [
                {
                  "title": "Goal",
                  "value": "Unit test user goal for Feedback"
                },
                {
                  "title": "Reaction",
                  "value": ":neutral_face:"
                },
                {
                  "title": "Comment",
                  "value": "Work harder!"
                }
              ]
            }
          ]
        }
      }
    ];

    var iTest = new IntegrationTest(null, TestUser[4], TestUser, expected, function() {
      this.instance.handleQueue({
        slackUserId: this.slackUserId,
        task: require('./../../../bot/tasks/feedback/gather-feedback'),
        context: {
          userFirstName: TestUser[4].firstName,
          appName: Config.appName,
          targetUserFirstName: globalUsers[3].firstName,
          advisor: {
            _id: globalUsers[4].id,
            firstName: TestUser[4].firstName
          },
          userGoal: testUserGoal,
          targetUser: globalUsers[3],
          targetUserGoalName: 'TestGoal',
          slackUserId: this.slackUserId
        }
      });
    });

    before(() => {
      return iTest.before(function *(users) {
        globalUsers = users;

        users[3].manager = users[2].id;
        yield users[3].save();

        yield ModelUserGoal.remove({ name : 'Unit test user goal for Feedback'});
        var userGoal = new ModelUserGoal();
        userGoal.name = 'Unit test user goal for Feedback';
        userGoal.user = users[3].id;
        userGoal.status = CONSTANTS.DB.STATUS.ACTIVE;
        userGoal.advisors = [users[4].id];
        testUserGoal = yield userGoal.save();

      }.bind(this));
    });

    // generate Mocha "it" tests
    iTest.generateAllTests();
  });

});
