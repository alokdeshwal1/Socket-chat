'use strict';

const Mockery = require('mockery');
const Chai = require('chai');
const Sinon = require('sinon');
const expect = Chai.expect;
const Config = require('./../../../configs/config');
const CONSTANTS = require('./../../../constants/constants');
const TestUser = require('./../configs/user');
const ModelUser = require('./../../../models/user');
const ModelJobFunction = require('./../../../models/function');
const ModelUserGoal = require('./../../../models/user-goal');
const Co = require('co');
const IntegrationTest = require('./../../bot-integration-test');
const _ = require('lodash');

describe('Bot: Remove Advisor (Take me off as reviewer)', () => {
  describe('remove from ONE user (has userGoal) that is NOT listed you as advisor', () => {
    var expected = {};
    expected[TestUser[2].name] = [
      {
        expect: {
          type: 'message',
          text: "OK, from whom? \n\n:bulb:Tip: You can type @ to see a dropdown with all of your coworkers"
        },

        enterMessage: '<@'+ TestUser[3].slackUserId +'>'
      },
      {
        expect: {
          type: 'message',
          text: 'It doesn\'t look like you’re currently a reviewer for Monica'
        }
      }
    ];

    var iTest = new IntegrationTest(null, TestUser[2], TestUser, expected, function() {
      this.instance.listen(this.slackUserId, this.primaryChannel, 'take me off as reviewer');
    });

    before(() => {
      return iTest.before(function *(users) {
        yield ModelUserGoal.remove({ user: users[3].id });

        var userGoal = new ModelUserGoal();
        userGoal.name = 'Unit Test - Remove Advisor';
        userGoal.user = users[3].id;
        userGoal.status = CONSTANTS.DB.STATUS.ACTIVE;
        userGoal.advisors = [users[0].id];

        yield userGoal.save();
      }.bind(this));
    });

    // generate Mocha "it" tests
    iTest.generateAllTests();
  });




  describe('remove from ONE user (NO userGoal) that is NOT listed you as advisor', () => {
    var expected = {};
    expected[TestUser[2].name] = [
      {
        expect: {
          type: 'message',
          text: "OK, from whom? \n\n:bulb:Tip: You can type @ to see a dropdown with all of your coworkers"
        },

        enterMessage: '<@'+ TestUser[3].slackUserId +'>'
      },
      {
        expect: {
          type: 'message',
          text: 'It doesn\'t look like you’re currently a reviewer for Monica'
        }
      }
    ];

    var iTest = new IntegrationTest(null, TestUser[2], TestUser, expected, function() {
      this.instance.listen(this.slackUserId, this.primaryChannel, 'take me off as reviewer');
    });

    before(() => {
      return iTest.before(function *(users) {
        yield ModelUserGoal.remove({ user: users[3].id });
      }.bind(this));
    });

    // generate Mocha "it" tests
    iTest.generateAllTests();
  });




  describe('remove from ONE user (has userGoal) that is listed you as advisor - Yes for confirmation', () => {
    var expected = {};
    expected[TestUser[2].name] = [
      {
        expect: {
          type: 'message',
          text: "OK, from whom? \n\n:bulb:Tip: You can type @ to see a dropdown with all of your coworkers"
        },

        enterMessage: '<@'+ TestUser[3].slackUserId +'>'
      },
      {
        expect: {
          type: 'attachmentMessage',
          text: [
            {
              "color": "#DA552F",
              "fallback": "Confirm delete goals",
              "fields": [
                {
                  "title": "Goal #1",
                  "value": "Unit Test - Remove Advisor"
                }
              ],
              "mrkdwn_in": [
                "fields",
                "pretext"
              ],
              "pretext": "Ok. You’re currently giving *Monica* on the following goals."
            }
          ]
        }
      },
      {
        expect: {
          type: 'message',
          text: 'Are you sure you want to stop giving *Monica* feedback?'
        },

        enterMessage: 'Yes'
      },
      {
        expect: {
          type: 'message',
          text: "OK, done! :tada:"
        }
      }
    ];

    expected[TestUser[3].name] = [
      {
        expect: {
          type: 'message',
          text: 'Jared is no longer able to provide you with feedback on Unit Test - Remove Advisor.'
        }
      }
    ];

    var iTest = new IntegrationTest(null, TestUser[2], TestUser, expected, function() {
      this.instance.listen(this.slackUserId, this.primaryChannel, 'take me off as reviewer');
    });

    before(() => {
      return iTest.before(function *(users) {
        yield ModelUserGoal.remove({ user: users[3].id });

        var userGoal = new ModelUserGoal();
        userGoal.name = 'Unit Test - Remove Advisor';
        userGoal.user = users[3].id;
        userGoal.status = CONSTANTS.DB.STATUS.ACTIVE;
        userGoal.advisors = [users[2].id, users[0].id];

        var targetUserGoal = yield userGoal.save();
        targetUserGoal = yield ModelUserGoal.findOne({ _id: targetUserGoal.id }).populate('advisors');

        expect(_.pluck(targetUserGoal.advisors, 'id').indexOf(users[2].id) >= 0).to.equal(true);
      }.bind(this));
    });

    // generate Mocha "it" tests
    iTest.generateAllTests();
  });




  describe('remove from ONE user (has userGoal) that is listed you as advisor - No for confirmation', () => {
    var expected = {};
    expected[TestUser[2].name] = [
      {
        expect: {
          type: 'message',
          text: "OK, from whom? \n\n:bulb:Tip: You can type @ to see a dropdown with all of your coworkers"
        },

        enterMessage: '<@'+ TestUser[3].slackUserId +'>'
      },
      {
        expect: {
          type: 'attachmentMessage',
          text: [
            {
              "color": "#DA552F",
              "fallback": "Confirm delete goals",
              "fields": [
                {
                  "title": "Goal #1",
                  "value": "Unit Test - Remove Advisor"
                }
              ],
              "mrkdwn_in": [
                "fields",
                "pretext"
              ],
              "pretext": "Ok. You’re currently giving *Monica* on the following goals."
            }
          ]
        }
      },
      {
        expect: {
          type: 'message',
          text: 'Are you sure you want to stop giving *Monica* feedback?'
        },

        enterMessage: 'No'
      },
      {
        expect: {
          type: 'message',
          text: 'OK, I didn\'t change anything.'
        }
      }
    ];

    var iTest = new IntegrationTest(null, TestUser[2], TestUser, expected, function() {
      this.instance.listen(this.slackUserId, this.primaryChannel, 'take me off as reviewer');
    });

    before(() => {
      return iTest.before(function *(users) {
        yield ModelUserGoal.remove({ user: users[3].id });

        var userGoal = new ModelUserGoal();
        userGoal.name = 'Unit Test - Remove Advisor';
        userGoal.user = users[3].id;
        userGoal.status = CONSTANTS.DB.STATUS.ACTIVE;
        userGoal.advisors = [users[2].id, users[0].id];

        var targetUserGoal = yield userGoal.save();
        targetUserGoal = yield ModelUserGoal.findOne({ _id: targetUserGoal.id }).populate('advisors');

        expect(_.pluck(targetUserGoal.advisors, 'id').indexOf(users[2].id) >= 0).to.equal(true);
      }.bind(this));
    });

    // generate Mocha "it" tests
    iTest.generateAllTests();
  });
});
