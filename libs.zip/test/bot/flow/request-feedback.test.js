'use strict';

const Mockery = require('mockery');
const Chai = require('chai');
const Sinon = require('sinon');
const expect = Chai.expect;
const Config = require('./../../../configs/config');
const CONSTANTS = require('./../../../constants/constants');
const TestUser = require('./../configs/user');
const ModelUser = require('./../../../models/user');
const ModelUserGoal = require('./../../../models/user-goal');
const ModelJobFunction = require('./../../../models/function');
const Co = require('co');
const IntegrationTest = require('./../../bot-integration-test');
const _ = require('lodash');
const TaskGatherFeedback = require('./../../../bot/tasks/feedback/gather-feedback');
const Helper = require('./../../../bot/libs/helper');

describe('Bot: Request Feedback', () => {
  describe('Request feedback', () => {
    var expected = {};
    expected[TestUser[4].name] = [
      {
        expect: {
          type: 'message',
          text: "OK, who would you like request feedback from?\n\n:bulb:Tip: You can type @ to see a dropdown with all of your coworkers. Select as many as you want"
        },

        enterMessage: TestUser[3].firstName
      },
      {
        overwriteTest: function(expected, result) {
          expect(result.length).to.equal(1);
          delete result[0].callback_id;
          expect(result).to.deep.equal(expected);
          return true;
        },
        expect: {
          text: [
            {
              "actions": [
                {
                  "name": ":one:",
                  "style": "primary",
                  "text": ":one:",
                  "type": "button",
                  "value": ":one:"
                }
              ],
              "attachment_type": "default",
              "color": "#DA552F",
              "fallback": "Select a goal",
              "fields": [
                {
                  "title": "Goals",
                  "value": ":one: Unit test user goal\n\nPick a button:"
                }
              ],
              "mrkdwn_in": [
                "fields",
                "pretext",
                "text"
              ],
              "pretext": "Alrighty, which goal?"
            }
          ]
        },

        enterMessage: '1'
      },
      {
        expect: {
          type: 'message',
          text: 'OK, done! :tada:'
        }
      }
    ];

    // advisor
    expected[TestUser[3].name] = [
      {
        overwriteTest: function(expected, result) {
          expect(result.length).to.equal(1);
          delete result[0].callback_id;
          expect(result).to.deep.equal(expected);
          return true;
        },
        expect: {
          type: 'message',
          text: [
            {
              "actions": [
                {
                  "name": ":disappointed:",
                  "style": "primary",
                  "text": ":disappointed:",
                  "type": "button",
                  "value": ":disappointed:"
                },
                {
                  "name": ":neutral_face:",
                  "style": "primary",
                  "text": ":neutral_face:",
                  "type": "button",
                  "value": ":neutral_face:"
                },
                {
                  "name": ":simple_smile:",
                  "style": "primary",
                  "text": ":simple_smile:",
                  "type": "button",
                  "value": ":simple_smile:"
                },
                {
                  "name": ":smile:",
                  "style": "primary",
                  "text": ":smile:",
                  "type": "button",
                  "value": ":smile:"
                },
                {
                  "name": ":joy:",
                  "style": "primary",
                  "text": ":joy:",
                  "type": "button",
                  "value": ":joy:"
                }
              ],
              "attachment_type": "default",
              "color": "#DA552F",
              "fallback": Helper.replaceMessagePlaceholder(TaskGatherFeedback.interactions[0].message.fallback, {targetUserFirstName: TestUser[4].firstName}),
              "mrkdwn_in": [
                "fields",
                "pretext",
                "text"
              ],
              "text": Helper.replaceMessagePlaceholder(TaskGatherFeedback.interactions[0].message.text, {
                userFirstName: TestUser[3].firstName,
                targetUserFirstName: TestUser[4].firstName,
                targetUserGoalName: 'Unit test user goal'
              }),
              "title": Helper.replaceMessagePlaceholder(TaskGatherFeedback.interactions[0].message.title, {targetUserFirstName: TestUser[4].firstName})
            }
          ]
        }
      }
    ];

    var iTest = new IntegrationTest(null, TestUser[4], TestUser, expected, function() {
      this.instance.listen(this.slackUserId, this.primaryChannel, 'request feedback');
    });

    before(() => {
      return iTest.before(function *(users) {
        users[4].jobFunction = undefined;
        users[4].manager = users[2].id;

        yield users[4].save();

        yield ModelUserGoal.remove({ user: users[4].id });
        var userGoal = new ModelUserGoal();
        userGoal.name = 'Unit test user goal';
        userGoal.user = users[4].id;
        userGoal.status = CONSTANTS.DB.STATUS.ACTIVE;
        userGoal.advisors = [users[0].id, users[1].id];

        yield userGoal.save();
      }.bind(this));
    });

    // generate Mocha "it" tests
    iTest.generateAllTests();
  });

});
