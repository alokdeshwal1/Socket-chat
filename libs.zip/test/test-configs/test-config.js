var Config = {};
Config.PARSE_APPLICATION_ID = 'KHAHifDMLWpcGa1Lvg7LLBLraOODIJEr062gTLDM';
Config.PARSE_WEBHOOK_KEY = 'eqhloumHdFW4p9mXHn7xdYpqlRNzjncwBvZvVh2N';

module.exports = Config;