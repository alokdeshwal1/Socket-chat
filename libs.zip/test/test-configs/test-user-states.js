/**
 * IMPORTANT:
 *
 * This file must sync with asteri-backend test-accounts.js
 * the content of this file should be identical to asteri-backend project test-accounts.js
 */

var UserStates = {
  good: {}
};

/**
 * Good working login Accounts
 */
UserStates.good[1] = {
  user: '0b5lw0e1tD',
  status: 'active',
  numberOfInvites: 1
};

module.exports = UserStates;