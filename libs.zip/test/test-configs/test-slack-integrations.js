var SlackIntegration = {
 good: {}
};

SlackIntegration.good[1] = {
  "accessToken" : "xoxp-4449571030-4508952739-14558306641-8a4b4a309d",
  "createdAt" : "2015-11-16T01:26:54.319Z",
  "incomingWebHook" : {
    "channel" : "@slackbot",
    "configuration_url" : "https://careerlark.slack.com/services/B0EJA414J",
    "url" : "https://hooks.slack.com/services/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"
  },
  "objectId" : "z5mAJ6mPXE",
  "scope" : "identify,incoming-webhook,commands",
  "teamId" : "T04D7GT0W",
  "teamName" : "CareerLark",
  "updatedAt" : "2015-11-16T01:26:54.319Z"
};

module.exports = SlackIntegration;