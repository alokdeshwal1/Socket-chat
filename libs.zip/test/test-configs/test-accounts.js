/**
 * IMPORTANT:
 *
 * This file must sync with asteri-backend test-accounts.js
 * the content of this file should be identical to asteri-backend project test-accounts.js
 */

var Accounts = {
  good: {},
  bad: {},
  seeded: {},
  facebook: {},
  confirmation: {},
  create: {},
  hasVotes: {}
};

/**
 * Good working login Accounts
 */

Accounts.good[1] = {
  firstName: 'Test',
  lastName: 'User 1',
  email: 'user1@testdummycompany.com',
  password: 'test123',
  company: {
    name: 'TEST COMPANY',
    objectId: 'b2KzLaPzK6'
  },
  id: '0b5lw0e1tD',
  objectId: '0b5lw0e1tD',
  status: 'active',
  sessionToken: 'r:qVSJw8JmIWh0ss5OIBZkfRnlI'
};

Accounts.good[2] = {
  firstName: 'Test',
  lastName: 'User 4',
  email: 'user4@testdummycompany.com',
  password: 'test123',
  company: {
    name: 'TEST COMPANY',
    objectId: 'b2KzLaPzK6'
  },
  id: 'rEDFszx5ZI',
  objectId: 'rEDFszx5ZI',
  status: 'active',
  sessionToken: 'r:Q0RPMlT6r6h0oLLWrrHfATNC4'
};

/**
 * Good working Facebook login Accounts
 */

Accounts.facebook[1] = {
  firstName: 'Facebook',
  lastName: 'User 5',
  email: 'user5@testdummycompany.com',
  password: 'test123',
  company: {
    name: 'TEST COMPANY',
    objectId: 'b2KzLaPzK6'
  },
  id: 'T2uSzNQS3v',
  objectId: 'T2uSzNQS3v',
  status: 'active',
  facebookId: 'test-facebook-id',
  facebookEmail: 'facebookuser5@facebook-test.com',
  sessionToken: 'r:Q0RPMlT6r6h0oLLWrrHfATNC4'
};

/**
 * Login accounts to be created by tests
 */
Accounts.create[1] = {
  firstName: 'New',
  lastName: 'Account 1',
  email: 'new-account-1@testdummycompany.com',
  password: 'test123',
  company: {
    name: 'TEST COMPANY',
    objectId: 'b2KzLaPzK6'
  }
};

/**
 * Seeded accounts
 */
Accounts.seeded[1] = {
  firstName: 'Test',
  lastName: 'User 2',
  email: 'user2@testdummycompany.com',
  password: 'test123',
  company: {
    name: 'TEST COMPANY',
    objectId: 'b2KzLaPzK6'
  },
  id: '0d23Y42bg3',
  objectId: '0d23Y42bg3',
  status: 'active',
  sessionToken: 'r:iGZhniryPHcR4vVXWlRJI8kB2'
};

/**
 * For confirmation testing
 */
Accounts.confirmation[1] = {
  firstName: 'Test',
  lastName: 'User 3',
  email: 'user3@testdummycompany.com',
  password: 'test123',
  company: {
    name: 'TEST COMPANY',
    objectId: 'b2KzLaPzK6'
  },
  id: 'XkQrvcAlTi',
  objectId: 'XkQrvcAlTi',
  status: 'active',
  confirmationCode: 'Pdd17PwjjlZo(q6',
  sessionToken: 'r:22bpZ4zn94OmqJNwbJFwkNo1g'
};

/**
 * Bad non-working login Accounts
 */
Accounts.bad[1] = {
  firstName: 'Blabh Blah',
  lastName: 'Lala',
  email: 'whocare@lalaa.com',
  password: 'blah blah blah',
  company: {
    name: 'TEST COMPANY',
    objectId: 'b2KzLaPzK6'
  },
  objectId: '94skNDkdk'
};

Accounts.hasVotes[1] = {
  firstName: 'Test',
  lastName: 'User 6',
  email: 'user6@testdummycompany.com',
  password: 'test123',
  company: {
    name: 'TEST COMPANY',
    objectId: 'b2KzLaPzK6'
  },
  objectId: 'sirR2EVrNW',
  status: 'active',
  sessionToken: 'r:0xAmSzuLO74lpE4KyCloeAnuJ'
};


module.exports = Accounts;
