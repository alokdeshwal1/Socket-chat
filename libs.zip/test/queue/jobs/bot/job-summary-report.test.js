'use strict';

const Mockery = require('mockery');
const Chai = require('chai');
const Sinon = require('sinon');
const expect = Chai.expect;
const JobSummaryReport = require('./../../../../queue/jobs/bot/job-summary-report.js');
const moment = require('moment');
const TestUser = require('./../../../bot/configs/user');
const ModelUser = require('./../../../../models/user');
const ModelUserGoal = require('./../../../../models/user-goal');
const ModelFeedback = require('./../../../../models/feedback');
const TalkingBot = require('./../../../../bot/talking-bot');
const Co = require('co');
const _ = require('lodash');
const Util = require('util');
const teamName = 'eatravelive';
const teamId = 'T0G9HMJK1';
const teamKey = TalkingBot.getTeamKey(teamName, teamId);
const queueName = 'Bot-' + teamKey;
const botName = 'LarkBot';
const channelName = 'testChannel';
const primaryChannel = channelName;
const CONSTANTS = require('./../../../../constants/constants');

describe('Job: Bot Summary Report (NOT Manager)', () => {
  // Mocha runs the following code way before executing the "it" and "before" statements
  // so, we are adding 1 hour endDate to make sure we are getting the newly inserted feedback
  var startDate = moment().subtract('7', 'days');
  var endDate = moment().add('1', 'hours');
  var mockConnections;
  var results = [];
  var instance;

  before(() => {
    mockConnections = {
      amqb: {
        queueJob: Sinon.stub().returns(Promise.resolve(true))
      }
    };
    instance = new JobSummaryReport(mockConnections);

    return resetData().then(() => {
      return runTests();
    });
  });

  var tests = [
    // Test: Summary from certain date range
    {
      'title': 'should show weekly summary report',
      input: {
        slackUserId: TestUser[4].slackUserId,
        summary: {
          startDate: startDate.format(),
          endDate: endDate.format()
        }
      },
      expected: expected1()
    },

    // Test: passing isTeamSummary = true
    {
      'title': 'should NOT see team summary report',
      input: {
        slackUserId: TestUser[4].slackUserId,
        summary: {
          startDate: startDate.format(),
          endDate: endDate.format(),
          isTeamSummary: true
        }
      },
      expected: [
        "Bot-eatravelive-T0G9HMJK1",
        {
          "slackUserId": "U0TSWM0TH",
          "task": {
            "name": "SummaryReport",
            "priority": 3,
            "interactions": [
              {
                "type": "ActionMessage",
                "message": "The team summary is a snapshot of feedback provided to your direct reports. It looks like you don’t have any direct reports set up yet. If you’d like to add some, type `add direct reports` now"
              }
            ]
          }
        }
      ]
    },

    // Test: user shouldn't see other's summary report
    {
      'title': 'should NOT see others\'s reports' ,
      input: {
        slackUserId: TestUser[4].slackUserId,
        summary: {
          startDate: startDate.format(),
          endDate: endDate.format(),
          user: TestUser[0].slackUserId
        }
      },
      expected: [
        "Bot-eatravelive-T0G9HMJK1",
        {
          "slackUserId": "U0TSWM0TH",
          "task": {
            "name": "SummaryReport",
            "priority": 3,
            "interactions": [
              {
                "type": "ActionMessage",
                "message": "Sorry, only Susan’s manager can see that feedback summary"
              }
            ]
          }
        }
      ]
    },

    {
      'title': 'should able to get report that is from one particular user' ,
      input: {
        slackUserId: TestUser[4].slackUserId,
        summary: {
          startDate: startDate.format(),
          endDate: endDate.format(),
          fromUser: TestUser[0].slackUserId
        }
      },
      expected: expected2()
    },

    {
      'title': 'should able to get archived feedback report' ,
      input: {
        slackUserId: TestUser[4].slackUserId,
        summary: {
          startDate: startDate.format(),
          endDate: endDate.format(),
          status: CONSTANTS.DB.STATUS.ARCHIVED
        }
      },
      expected: expected3()
    },

    {
      'title': 'should able to get "summary for me"' ,
      input: {
        slackUserId: TestUser[4].slackUserId,
        summary: {
          startDate: startDate.format(),
          endDate: endDate.format(),
          user: 'me'
        }
      },
      expected: expected1()
    },

    {
      'title': 'should able to get "summary for <@slackUserId>"' ,
      input: {
        slackUserId: TestUser[4].slackUserId,
        summary: {
          startDate: startDate.format(),
          endDate: endDate.format(),
          user: '<@'+ TestUser[4].slackUserId +'>'
        }
      },
      expected: expected1()
    },

    {
      'title': 'should show error message if user is not found' ,
      input: {
        slackUserId: TestUser[4].slackUserId,
        summary: {
          startDate: startDate.format(),
          endDate: endDate.format(),
          user: 'not-exisiting-id'
        }
      },
      expected: [
        "Bot-eatravelive-T0G9HMJK1",
        {
          "slackUserId": "U0TSWM0TH",
          "task": {
            "interactions": [
              {
                "message": 'looks like "not-exisiting-id" has not joined our service. Feel free to pull up another summary.',
                "type": "ActionMessage"
              }
            ],
            "name": "SummaryReport",
            "priority": 3
          }
        }
      ]
    }
  ];


  for(var i = 0; i < tests.length; i++) {
    (function(i) {
      it(tests[i].title, () => {
        expect(results[i]).to.deep.equal(tests[i].expected);
      });
    })(i)
  }

  function runTests() {
    return new Promise((resolve, reject) => {
      Co(function *() {
        try {
          for(var i = 0; i < tests.length; i++) {
            yield instance.handle(tests[i].input);
            results.push(mockConnections.amqb.queueJob.lastCall.args);
          }

          return resolve(true);
        }
        catch(ex) {
          return reject(ex);
        }
      }.bind(this));
    });
  }

  function resetData() {
    return new Promise((resolve, reject) => {
      Co(function *() {
        try {
          var users = yield ModelUser.find({slackUserId: {'$in': _.pluck(TestUser, 'slackUserId')}});
          users = _.sortBy(users, (item) => {
            return _.findIndex(TestUser, {slackUserId: item.slackUserId});
          });

          yield ModelUser.update({manager: users[4].id}, {manager: undefined}, {multi: true});

          // remove user's goals
          yield ModelUserGoal.remove({user: users[4].id});
          // remove user's feedback
          yield ModelFeedback.remove({ user: users[4].id });

          // user4 has goals
          var userGoal1 = new ModelUserGoal();
          userGoal1.name = 'Unit Test - Bot Summary Report Non Manager #1';
          userGoal1.user = users[4].id;
          userGoal1.status = CONSTANTS.DB.STATUS.ACTIVE;
          userGoal1.advisors = [users[0].id, users[1].id];
          userGoal1.createdAt = moment.utc().format();
          userGoal1 = yield userGoal1.save();

          var userGoal2 = new ModelUserGoal();
          userGoal2.name = 'Unit Test - Bot Summary Report Non Manager #2';
          userGoal2.user = users[4].id;
          userGoal2.status = CONSTANTS.DB.STATUS.ACTIVE;
          userGoal2.advisors = [users[1].id];
          userGoal2.createdAt = moment().add('1', 'minutes').utc().format();
          userGoal2 = yield userGoal2.save();

          var userGoal3 = new ModelUserGoal();
          userGoal3.user = users[4].id;
          userGoal3.status = CONSTANTS.DB.STATUS.ACTIVE;
          userGoal3.advisors = [users[1].id];
          userGoal3.isGeneral = true;
          userGoal3 = yield userGoal3.save();

          var userFeedback1 = new ModelFeedback();
          userFeedback1.feedbackEmoji = ':joy:';
          userFeedback1.feedbackComment = 'Summary Report - Unit Test Feedback #1';
          userFeedback1.feedbackRating = 5;
          userFeedback1.userGoal = userGoal1.id;
          userFeedback1.user = users[4].id;
          userFeedback1.advisor = users[0].id;
          yield userFeedback1.save();

          var userFeedback2 = new ModelFeedback();
          userFeedback2.feedbackEmoji = ':simple_smile:';
          userFeedback2.feedbackComment = 'Summary Report - Unit Test Feedback #2';
          userFeedback2.feedbackRating = 3;
          userFeedback2.userGoal = userGoal2.id;
          userFeedback2.user = users[4].id;
          userFeedback2.advisor = users[1].id;
          yield userFeedback2.save();

          var userFeedback3 = new ModelFeedback();
          userFeedback3.feedbackEmoji = ':smile:';
          userFeedback3.feedbackComment = 'Summary Report - Unit Test Feedback #3';
          userFeedback3.feedbackRating = 4;
          userFeedback3.userGoal = userGoal1.id;
          userFeedback3.user = users[4].id;
          userFeedback3.advisor = users[0].id;
          userFeedback3.status = CONSTANTS.DB.STATUS.ARCHIVED;
          yield userFeedback3.save();

          return resolve(true);
        }
        catch(ex) {
          return reject(ex);
        }
      }.bind(this));
    });
  }


  function expected1() {
    return [
      "Bot-eatravelive-T0G9HMJK1",
      {
        "slackUserId": "U0TSWM0TH",
        "task": {
          "name": "SummaryReport",
          "priority": 3,
          "interactions": [
            {
              "type": "ActionMessage",
              "message": Util.format("*Feedback for gilfoyle (%s/%s-%s/%s)*\n*2* responses from *2* givers",
                startDate.format('M'), startDate.format('D'), endDate.format('M'), endDate.format('D'))
            },
            {
              "type": "ActionAttachmentMessage",
              "message": [
                {
                  "color": "#36A64F",
                  "fallback": "General Feedback",
                  "fields": [
                    {
                      "title": "Goal",
                      "value": "General"
                    },
                    {
                      "value": "_No feedback received yet_"
                    }
                  ],
                  "mrkdwn_in": [
                    "fields",
                    "pretext"
                  ]
                },
                {
                  "color": "#36A64F",
                  "fallback": "Feedback for Unit Test - Bot Summary Report Non Manager #1",
                  "fields": [
                    {
                      "title": "Goal",
                      "value": "Unit Test - Bot Summary Report Non Manager #1"
                    },
                    {
                      "title": "Reaction",
                      "value": ":joy:"
                    },
                    {
                      "title": "Feedback",
                      "value": Util.format("%s/%s , from Susan\n:joy: Summary Report - Unit Test Feedback #1",
                        moment().format('M'), moment().format('D'))
                    }
                  ],
                  "mrkdwn_in": [
                    "fields",
                    "pretext"
                  ]
                },
                {
                  "fallback": "Feedback for Unit Test - Bot Summary Report Non Manager #2",
                  "color": "#36A64F",
                  "mrkdwn_in": [
                    "fields",
                    "pretext"
                  ],
                  "fields": [
                    {
                      "title": "Goal",
                      "value": "Unit Test - Bot Summary Report Non Manager #2"
                    },
                    {
                      "title": "Reaction",
                      "value": ":simple_smile:"
                    },
                    {
                      "title": "Feedback",
                      "value": Util.format("%s/%s , from Richard\n:simple_smile: Summary Report - Unit Test Feedback #2", endDate.format('M'), endDate.format('D'))
                    }
                  ]
                }
              ]
            }
          ]
        }
      }
    ];
  }

  function expected2() {
    return [
      "Bot-eatravelive-T0G9HMJK1",
      {
        "slackUserId": "U0TSWM0TH",
        "task": {
          "name": "SummaryReport",
          "priority": 3,
          "interactions": [
            {
              "type": "ActionMessage",
              "message": Util.format("*Feedback for gilfoyle (%s/%s-%s/%s)*\n*1* response from *Susan*",
              startDate.format('M'), startDate.format('D'), endDate.format('M'), endDate.format('D'))
            },
            {
              "type": "ActionAttachmentMessage",
              "message": [
                {
                  "color": "#36A64F",
                  "fallback": "General Feedback",
                  "fields": [
                    {
                      "title": "Goal",
                      "value": "General"
                    },
                    {
                      "value": "_No feedback received yet_"
                    }
                  ],
                  "mrkdwn_in": [
                    "fields",
                    "pretext"
                  ]
                },
                {
                  "color": "#36A64F",
                  "fallback": "Feedback for Unit Test - Bot Summary Report Non Manager #1",
                  "fields": [
                    {
                      "title": "Goal",
                      "value": "Unit Test - Bot Summary Report Non Manager #1"
                    },
                    {
                      "title": "Reaction",
                      "value": ":joy:"
                    },
                    {
                      "title": "Feedback",
                      "value": Util.format("%s/%s , from Susan\n:joy: Summary Report - Unit Test Feedback #1",
                        moment().format('M'), moment().format('D'))
                    }
                  ],
                  "mrkdwn_in": [
                    "fields",
                    "pretext"
                  ]
                },
                {
                  "fallback": "Feedback for Unit Test - Bot Summary Report Non Manager #2",
                  "color": "#36A64F",
                  "mrkdwn_in": [
                    "fields",
                    "pretext"
                  ],
                  "fields": [
                    {
                      "title": "Goal",
                      "value": "Unit Test - Bot Summary Report Non Manager #2"
                    },
                    {
                      "value": "_No feedback received yet_"
                    }
                  ]
                }
              ]
            }
          ]
        }
      }
    ];
  }

  function expected3() {
    return [
      "Bot-eatravelive-T0G9HMJK1",
      {
        "slackUserId": "U0TSWM0TH",
        "task": {
          "interactions": [
            {
              "message": "It looks like you haven't created a goal yet.",
              "type": "ActionMessage"
            }
          ],
          "name": "SummaryReport",
          "priority": 3
        }
      }
    ]
  }

});