module.exports = function() {
  if ( ! GLOBAL.request) {
    const app = require('./../app.js');
    GLOBAL.request = require('supertest').agent(app.server);
    if ( ! GLOBAL.app) {
      GLOBAL.app = app;
    }
  }

  return GLOBAL.request;
};