//const Sinon = require('sinon');
//const Chai = require('chai');
//const expect = Chai.expect;
//const request = require('./../../../load-server')();
//const Config = require('./../../../../configs/config');
//const Accounts = require('./../../../test-configs/test-accounts');
//const Queue = require('./../../../../queue');
//
//describe('API: Google Watch Calendar', () => {
//  describe('Calendar Update', () => {
//    before((done) => {
//      GLOBAL.app.queue = new Queue(Config);
//      GLOBAL.app.queue.on('ready', function() {
//        GLOBAL.app.queue.queueJob = Sinon.stub().returns(new Promise(function(resolve, reject) {
//          resolve(true);
//        }));
//
//        done();
//      });
//    });
//
//    it('should update calendar when update push notification is sent', (done) => {
//      request
//        .post('/v1/google/watch/calendar')
//        .set('user-agent', 'APIs-Google; (+https://developers.google.com/webmasters/APIs-Google.html)')
//        .set('Content-Type', 'application/json; utf-8')
//        .set('Content-Length', '0')
//        .set('X-Goog-Channel-ID', '583bb9e0-f531-11e5-af34-c346181ebe2d')
//        .set('X-Goog-Channel-Token', 'userId=56f4d47351d57e5f08df3895')
//        .set('X-Goog-Channel-Expiration', 'Tue, 19 Nov 2013 01:13:52 GMT')
//        .set('X-Goog-Resource-ID', 'Csehl97v3SVbHbrQKP_u_hOG5yM')
//        .set('X-Goog-Resource-URI', 'https://www.googleapis.com/calendar/v3/calendars/primary/events?alt=json')
//        .set('X-Goog-Resource-State', 'exists')
//        .set('X-Goog-Message-Number', '238324458')
//        .send()
//        .end(function(err, res) {
//          expect(err).to.equal(null);
//          expect(res.status).to.equal(200);
//          expect(res.body.status).to.equal('success');
//          done();
//        });
//
//    });
//  });
//});
