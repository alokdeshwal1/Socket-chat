//const Chai = require('chai');
//const expect = Chai.expect;
//const request = require('./../load-server')();
//const Config = require('./../../configs/config');
//const Accounts = require('./../test-configs/test-accounts');
//
//describe.only('Bunch of API generator tests', function() {
//  var recordId;
//  var testAccount = {
//    'name': 'Test test',
//    'firstName': 'Test',
//    'lastName': 'Test',
//    'email': 'test@test.com',
//    'password': 'test123',
//    timezone: 'America/Los_Angeles',
//    timezoneLabel: 'Pacific Standard Time',
//    timezoneOffset: '-28800',
//    status: 'active'
//  };
//
//  it('should save some records', function(done) {
//    request
//      .post('/v1/user')
//      .send(testAccount)
//      .end(function(err, res) {
//        expect(err).to.equal(null);
//        expect(res.body.status).to.equal('success');
//        recordId = res.body.result._id;
//        done();
//      });
//  });
//
//  it('should get some records', function(done) {
//    request
//      .get('/v1/user')
//      .end(function(err, res) {
//
//        expect(err).to.equal(null);
//        expect(res.body.status).to.equal('success');
//        expect(res.body.result).to.be.an('array');
//
//        done();
//      });
//  });
//
//  it('should able to update (PUT) a record', function(done) {
//    var newAccount = Object.assign(testAccount);
//    newAccount.firstName = 'Test 2';
//
//    request
//      .put('/v1/user/'+ recordId)
//      .send(newAccount)
//      .end(function(err, res) {
//
//        expect(err).to.equal(null);
//        expect(res.body.status).to.equal('success');
//        expect(res.body.result.firstName).to.equal(newAccount.firstName);
//        expect(res.body.result._id).to.equal(recordId);
//
//        done();
//      });
//
//  });
//
//  it('should able to update (PATCH) a record', function(done) {
//    request
//      .patch('/v1/user/'+ recordId)
//      .send({
//        lastName: 'Test 2'
//      })
//      .end(function(err, res) {
//
//        expect(err).to.equal(null);
//        expect(res.body.status).to.equal('success');
//        expect(res.body.result.lastName).to.equal('Test 2');
//        expect(res.body.result._id).to.equal(recordId);
//
//        done();
//      });
//
//  });
//
//  it('should delete a record', function(done) {
//    request
//      .delete('/v1/user/'+ recordId)
//      .end(function(err, res) {
//
//        expect(err).to.equal(null);
//        expect(res.body.status).to.equal('success');
//        expect(res.body.result.lastName).to.equal('Test 2');
//        expect(res.body.result._id).to.equal(recordId);
//
//        done();
//      });
//  });
//
//});