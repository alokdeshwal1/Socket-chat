const Chai = require('chai');
const expect = Chai.expect;
const Config = require('./../../../configs/config');
const Mockery = require('mockery');
const Sinon = require('sinon');
const Co = require('co');
const Bluebird = require('bluebird');
const ModelSlackIntegration = require('./../../../models/slack-integration');
const ModelCompany = require('./../../../models/company');
const ModelUser = require('./../../../models/user');
const mockTeamName = 'mock-team_name';
const mockTeamId = 'mock-team_id';
var request;
var spyQueueJob;

describe('Slack Redirect Test', function() {
  beforeEach(() => {
    request = require('./../../load-server')();
    GLOBAL.app.queue = GLOBAL.app.queue || {};
    spyQueueJob = Sinon.stub().returns(Promise.resolve(true));
    GLOBAL.app.queue.queueJob = spyQueueJob;
  });

  afterEach(() => {
    unMock();
    var actions = [];
    actions.push(ModelUser.remove({ email: 'mock-email_1@mock-email.com' }).exec());
    actions.push(ModelUser.remove({ email: 'mock-email_2@mock-email.com' }).exec());
    actions.push(ModelUser.remove({ email: 'mock-email_3@mock-email.com' }).exec());
    return Promise.all(actions);
  });

  it('should throw error message when session token is NOT valid', function(done) {
    request
      .post('/v1/slack/redirect')
      .set('session-token', 'invalid token')
      .send()
      .end(function(err, res) {
        expect(err).to.equal(null);
        expect(res.body.status).to.equal('error');
        expect(res.body.error).to.equal('Session token is invalid.');
        done();
      });
  });

  it('should throw error message when code is NOT passed in', function(done) {
    request
      .post('/v1/slack/redirect')
      .set('session-token', Config.sessionSecret)
      .send()
      .end(function(err, res) {
        expect(err).to.equal(null);
        expect(res.body.status).to.equal('error');
        expect(res.body.error).to.equal('Code (String) is required');
        done();
      });
  });

  it('should throw error message when code is NOT valid', function(done) {
    request
      .post('/v1/slack/redirect')
      .set('session-token', Config.sessionSecret)
      .send({
        code: 'not-valid-code'
      })
      .end(function(err, res) {
        expect(err).to.equal(null);
        expect(res.body.status).to.equal('error');
        expect(res.body.error).to.equal('Slack Access token is invalid');
        done();
      });
  });

  it('should register users and create installation job (new installation)', (done) => {
    Co(function *() {
      mock();

      yield ModelCompany.remove( { name: mockTeamName });
      yield ModelSlackIntegration.remove( { teamId: mockTeamId });

      request
        .post('/v1/slack/redirect')
        .set('session-token', Config.sessionSecret)
        .send({
          code: 'some-random-code'
        })
        .end(function(err, res) {

          expect(err).to.equal(null);
          expect(res.body.status).to.equal('success');
          expect(spyQueueJob.callCount).to.equal(1);

          var newSlackIntegrationId = spyQueueJob.args[0][1]['newInstallation']['job']['context']['slackIntegrationId'];
          var newCompanyId = spyQueueJob.args[0][1]['newInstallation']['job']['context']['companyId'];
          expect(typeof newSlackIntegrationId).to.equal('string');
          expect(typeof newCompanyId).to.equal('string');
          delete spyQueueJob.args[0][1]['newInstallation']['job']['context']['slackIntegrationId'];
          delete spyQueueJob.args[0][1]['newInstallation']['job']['context']['companyId'];

          expect(spyQueueJob.args[0]).to.deep.equal([
            "JobBotServer",
            {
              "accessToken": "mock-access_token",
              "scope": "mock-scope",
              "teamId": "mock-team_id",
              "teamName": "mock-team_name",
              "bot": {
                "bot_access_token": "mock-bot_access_token",
                "bot_user_id": "mock-bot_user_id"
              },
              "enabledModules": {
                "featureOkrGoal": undefined,
                "featurePersonalGoal": undefined
              },
              "rawData": {
                "access_token": "mock-access_token",
                "bot": {
                  "bot_access_token": "mock-bot_access_token",
                  "bot_user_id": "mock-bot_user_id"
                },
                "team_id": "mock-team_id",
                "team_name": "mock-team_name",
                "scope": "mock-scope"
              },
              "installerSlackUserId": "mock-user_id",
              "installerSlackUserName": "mock-user",
              "status": "active",
              "incomingWebHook": undefined,
              "installerSlackUserEmail": "mock-email_1@mock-email.com",
              "newInstallation": {
                "queueName": "Bot-mock-team_name-mock-team_id",
                "job": {
                  "slackUserId": "mock-user_id",
                  "context": {
                    "userFirstName": "mock-name_1",
                    "slackUserId": "mock-user_id",
                    "appName": "CareerLark",
                    "isNewBotInstallation": true
                    //"slackIntegrationId": "57057c9ab75b147232be1bd3",
                    //"companyId": "57057c9ab75b147232be1bd4"
                  },
                  "task": {
                    "name": "Ftue",
                    "priority": 2,
                    "module": "Feedback",
                    "before": [
                      "HookCheckBeforeFtue"
                    ],
                    "interactions": [
                      {
                        "type": "ActionManagerOrEmployee",
                        "message": "Hi [[userFirstName]] :wave:! I'm [[appName]], your friendly :robot_face:. I’m going to help you give and get micro-feedback to take your career to the next level. Let's get you set up. This will only take a few moments.\nIf you’re a manager looking to get your team set up to give and receive feedback type `manager`. Otherwise, type `individual feedback` to start getting micro-feedback from your coworkers.\n\nYou can also type `help` at any point if you get stuck."
                      }
                    ],
                    "after": [
                      "HookToManagerOrEmployee"
                    ]
                  }
                }
              }
            }
          ]);

          var actions = [];
          actions.push(ModelCompany.findOne({ name: mockTeamName }));
          actions.push(ModelSlackIntegration.findOne({ teamId: mockTeamId }));
          Promise.all(actions)
            .then((data) => {
              expect(data[0].id).to.equal(newCompanyId);
              expect(data[1].id).to.equal(newSlackIntegrationId);
              done();
            });
        });
    }.bind(this));
  });

  it('should register users and create installation job (duplicate installation). Old tokens should be replaced', (done) => {
    Co(function *() {
      mock();

      var firstSlackIntegrationId;
      var firstCompanyId;
      firstInstallation();

      function firstInstallation() {
        request
          .post('/v1/slack/redirect')
          .set('session-token', Config.sessionSecret)
          .send({
            code: 'some-random-code'
          })
          .end(function(err, res) {
            firstSlackIntegrationId = spyQueueJob.args[0][1]['newInstallation']['job']['context']['slackIntegrationId'];
            firstCompanyId= spyQueueJob.args[0][1]['newInstallation']['job']['context']['companyId'];

            secondInstallation();
          });
      }

      function secondInstallation() {
        request
          .post('/v1/slack/redirect')
          .set('session-token', Config.sessionSecret)
          .send({
            code: 'some-random-code'
          })
          .end(function(err, res) {

            expect(err).to.equal(null);
            expect(res.body.status).to.equal('success');
            expect(spyQueueJob.callCount).to.equal(2);

            var newSlackIntegrationId = spyQueueJob.args[1][1]['newInstallation']['job']['context']['slackIntegrationId'];
            var newCompanyId = spyQueueJob.args[1][1]['newInstallation']['job']['context']['companyId'];
            expect(newSlackIntegrationId).to.equal(firstSlackIntegrationId);
            expect(newCompanyId).to.equal(firstCompanyId);

            expect(spyQueueJob.args[0]).to.deep.equal([
              "JobBotServer",
              {
                "accessToken": "mock-access_token",
                "scope": "mock-scope",
                "teamId": "mock-team_id",
                "teamName": "mock-team_name",
                "bot": {
                  "bot_access_token": "mock-bot_access_token",
                  "bot_user_id": "mock-bot_user_id"
                },
                "enabledModules": {
                  "featureOkrGoal": undefined,
                  "featurePersonalGoal": undefined
                },
                "rawData": {
                  "access_token": "mock-access_token",
                  "bot": {
                    "bot_access_token": "mock-bot_access_token",
                    "bot_user_id": "mock-bot_user_id"
                  },
                  "team_id": "mock-team_id",
                  "team_name": "mock-team_name",
                  "scope": "mock-scope"
                },
                "installerSlackUserId": "mock-user_id",
                "installerSlackUserName": "mock-user",
                "status": "active",
                "incomingWebHook": undefined,
                "installerSlackUserEmail": "mock-email_1@mock-email.com",
                "newInstallation": {
                  "queueName": "Bot-mock-team_name-mock-team_id",
                  "job": {
                    "slackUserId": "mock-user_id",
                    "context": {
                      "userFirstName": "mock-name_1",
                      "slackUserId": "mock-user_id",
                      "appName": "CareerLark",
                      "isNewBotInstallation": true,
                      "slackIntegrationId": firstSlackIntegrationId,
                      "companyId": firstCompanyId
                    },
                    "task": {
                      "name": "Ftue",
                      "priority": 2,
                      "module": "Feedback",
                      "before": [
                        "HookCheckBeforeFtue"
                      ],
                      "interactions": [
                        {
                          "type": "ActionManagerOrEmployee",
                          "message": "Hi [[userFirstName]] :wave:! I'm [[appName]], your friendly :robot_face:. I’m going to help you give and get micro-feedback to take your career to the next level. Let's get you set up. This will only take a few moments.\nIf you’re a manager looking to get your team set up to give and receive feedback type `manager`. Otherwise, type `individual feedback` to start getting micro-feedback from your coworkers.\n\nYou can also type `help` at any point if you get stuck."
                        }
                      ],
                      "after": [
                        "HookToManagerOrEmployee"
                      ]
                    }
                  }
                }
              }
            ]);

            var actions = [];
            actions.push(ModelCompany.findOne({ name: mockTeamName }));
            actions.push(ModelSlackIntegration.findOne({ teamId: mockTeamId }));
            Promise.all(actions)
              .then((data) => {
                expect(data[0].id).to.equal(firstCompanyId);
                expect(data[1].id).to.equal(firstSlackIntegrationId);
                done();
              });
          });
      }

    }.bind(this));
  });

  it('should NOT create a FTUE task if the company only enable OKR goal feature', (done) => {
    Co(function *() {
      mock();

      // delete the old users
      var oldCompany = yield ModelCompany.findOne({ name: mockTeamName });
      if (oldCompany && oldCompany.id) {
        yield ModelUser.remove({ company: oldCompany.id });
      }

      yield ModelCompany.remove( { name: mockTeamName });
      yield ModelSlackIntegration.remove( { teamId: mockTeamId });

      var mockCompany = new ModelCompany();
      mockCompany.name = mockTeamName;
      mockCompany.emailDomain = 'mock-email.com';
      mockCompany.isCreatedViaSlack = true;
      mockCompany.featureOkrGoal = true;
      mockCompany = yield mockCompany.save();

      var mockSlackIntegration = new ModelSlackIntegration();
      mockSlackIntegration.company = mockCompany.id;
      mockSlackIntegration.accessToken = 'mock-access_token';
      mockSlackIntegration.scope = 'mock-scope';
      mockSlackIntegration.teamId = mockTeamId;
      mockSlackIntegration.teamName = mockTeamName;
      mockSlackIntegration.bot = {
        bot_access_token: 'mock-bot_access_token-OLD',
        bot_user_id: 'mock-bot_user_id'
      };
      mockSlackIntegration.rawData = {
        "access_token": "mock-access_token-OLD",
        "bot": {
          "bot_access_token": "mock-bot_access_token-OLD",
          "bot_user_id": "mock-bot_user_id"
        },
        "team_id": "mock-team_id",
        "team_name": "mock-team_name",
        "scope": "mock-scope"
      };
      mockSlackIntegration.installerSlackUserId = 'mock-user_id';
      mockSlackIntegration.installerSlackUserName = "mock-user";
      mockSlackIntegration.status = "active";
      mockSlackIntegration.installerSlackUserEmail = "mock-email_1@mock-email.com";
      mockSlackIntegration = yield mockSlackIntegration.save();

      request
        .post('/v1/slack/redirect')
        .set('session-token', Config.sessionSecret)
        .send({
          code: 'some-random-code'
        })
        .end(function(err, res) {

          expect(err).to.equal(null);
          expect(res.body.status).to.equal('success');
          expect(spyQueueJob.callCount).to.equal(1);

          var newSlackIntegrationId = spyQueueJob.args[0][1]['newInstallation']['job']['context']['slackIntegrationId'];
          var newCompanyId = spyQueueJob.args[0][1]['newInstallation']['job']['context']['companyId'];
          expect(newSlackIntegrationId).to.equal(mockSlackIntegration.id);
          expect(newCompanyId).to.equal(mockCompany.id);
          expect(spyQueueJob.args[0][1].newInstallation).to.be.an('object');
          expect(spyQueueJob.args[0][1].newInstallation.task).to.equal(undefined);

          var actions = [];
          actions.push(ModelCompany.findOne({ name: mockTeamName }));
          actions.push(ModelSlackIntegration.findOne({ teamId: mockTeamId }));
          Promise.all(actions)
            .then((data) => {
              expect(data[0].id).to.equal(mockCompany.id);
              expect(data[1].id).to.equal(mockSlackIntegration.id);
              done();
            });
        });
    }.bind(this));
  });

});


function mock() {
  const Slack = require('./../../../libs/slack');
  const Bot = require('./../../../bot/bot');

  // stub the users list
  Bot.prototype.users = [{
    id: 'mock-user_id',
    first_name: 'mock-first_name',
    name: 'mock-name_1',
    tz: 'America/Los_Angeles',
    profile: {
      email: 'mock-email_1@mock-email.com'
    }
  },{
    id: 'mock-user_id_2',
    first_name: 'mock-first_name_2',
    name: 'mock-name_2',
    //tz: 'America/Los_Angeles', /* purpose took this out */
    profile: {
      email: 'mock-email_2@mock-email.com'
    }
  }, {
    id: 'mock-user_id_3',
    first_name: 'mock-first_name_3',
    name: 'mock-name_3',
    tz_label: undefined,
    tz_offset: "undefined", /* purposely make it a string */
    profile: {
      email: 'mock-email_3@mock-email.com'
    }
  }];

  if ( ! Slack.exchangeCodeForAccessToken.isSinonProxy) {
    Sinon.stub(Slack, 'exchangeCodeForAccessToken').returns(new Promise((resolve, reject) => {
      return resolve(JSON.stringify({
        access_token: 'mock-access_token',
        bot: {
          bot_access_token: 'mock-bot_access_token',
          bot_user_id: 'mock-bot_user_id'
        },
        team_id: mockTeamId,
        team_name: mockTeamName,
        scope: 'mock-scope'
      }))
    }));
  }

  if ( ! Slack.getUserId.isSinonProxy) {
    Sinon.stub(Slack, 'getUserId').returns(new Promise((resolve, reject) => {
      return resolve(JSON.stringify({
        user_id: 'mock-user_id',
        user: 'mock-user'
      }))
    }));
  }

  Mockery.registerMock('./../../bot/bot', Bot);
  Mockery.registerMock('./../../libs/slack', Slack);
}

function unMock() {
  Mockery.deregisterAll();
}