const Chai = require('chai');
const expect = Chai.expect;
const Config = require('./../../../configs/config');
const Mockery = require('mockery');
const Sinon = require('sinon');
const Co = require('co');
const Bluebird = require('bluebird');
const ModelSlackIntegration = require('./../../../models/slack-integration');
const ModelCompany = require('./../../../models/company');
const ModelUser = require('./../../../models/user');
const mockTeamName = 'mock-team_name';
const mockTeamId = 'mock-team_id';
var request;
var spyQueueJob;

describe('Slack Interactive Message', () => {
  beforeEach(() => {
    request = require('./../../load-server')();
    GLOBAL.app.queue = GLOBAL.app.queue || {};
    spyQueueJob = Sinon.stub().returns(Promise.resolve(true));
    GLOBAL.app.queue.queueJob = spyQueueJob;
  });

  afterEach(() => {
    Mockery.deregisterAll();
  });

  it('should work', function(done) {
    request
      .post('/v1/slack/interactive-message')
      .set({"user-agent":"Slackbot 1.0 (+https://api.slack.com/robots)"})
      .send({
        "payload": "{\"actions\":[{\"name\":\":joy:\",\"value\":\":joy:\"}],\"callback_id\":\"feedback-b44ca2f0-2ed2-11e6-98b9-5bcb7af9e062\",\"team\":{\"id\":\"T0G9HMJK1\",\"domain\":\"careerlark\"},\"channel\":{\"id\":\"D1F9WRCP4\",\"name\":\"directmessage\"},\"user\":{\"id\":\"U1F9BF29L\",\"name\":\"testuser1\"},\"action_ts\":\"1465539415.45047\",\"message_ts\":\"1465539317.000008\",\"attachment_id\":\"1\",\"token\":\"V997LkBssTf446EeLxfCpSRd\",\"original_message\":{\"text\":\"\",\"username\":\"careerlark\",\"bot_id\":\"B0PHWBBT9\",\"attachments\":[{\"callback_id\":\"feedback-b44ca2f0-2ed2-11e6-98b9-5bcb7af9e062\",\"fallback\":\"Feedback for Test\",\"text\":\"Hey Test, How did *Kenson* do on: *test test*\\n\\nPick one or type in the emoji:\",\"title\":\"Feedback for Test\",\"id\":1,\"color\":\"DA552F\",\"actions\":[{\"id\":\"1\",\"name\":\":disappointed:\",\"text\":\":disappointed:\",\"type\":\"button\",\"value\":\":disappointed:\",\"style\":\"primary\"},{\"id\":\"2\",\"name\":\":neutral_face:\",\"text\":\":neutral_face:\",\"type\":\"button\",\"value\":\":neutral_face:\",\"style\":\"primary\"},{\"id\":\"3\",\"name\":\":simple_smile:\",\"text\":\":simple_smile:\",\"type\":\"button\",\"value\":\":simple_smile:\",\"style\":\"primary\"},{\"id\":\"4\",\"name\":\":smile:\",\"text\":\":smile:\",\"type\":\"button\",\"value\":\":smile:\",\"style\":\"primary\"},{\"id\":\"5\",\"name\":\":joy:\",\"text\":\":joy:\",\"type\":\"button\",\"value\":\":joy:\",\"style\":\"primary\"}]}],\"type\":\"message\",\"subtype\":\"bot_message\",\"ts\":\"1465539317.000008\"},\"response_url\":\"test\"}"
      })
      .end(function(err, res) {
        expect(err).to.equal(null);
        expect(res.body).to.deep.equal({
          "attachments": [
            {
              "actions": [
                {
                  "id": "5",
                  "name": ":joy:",
                  "style": "primary",
                  "text": ":joy:",
                  "type": "button",
                  "value": ":joy:"
                }
              ],
              "callback_id": "feedback-b44ca2f0-2ed2-11e6-98b9-5bcb7af9e062",
              "color": "DA552F",
              "fallback": "Feedback for Test",
              "id": 1,
              "text": "Hey Test, How did *Kenson* do on: *test test*\n\nPick one or type in the emoji:",
              "title": "Feedback for Test"
            }
          ]
        });
        expect(JSON.stringify(GLOBAL.app.queue.queueJob.args[0])).to.equal('[\"Bot-eatravelive-T0G9HMJK1\",{\"type\":\"integrationMessage\",\"slackUserId\":\"U1F9BF29L\",\"integrationType\":\"interactiveMessage\",\"payload\":{\"actions\":[{\"name\":\":joy:\",\"value\":\":joy:\"}],\"callback_id\":\"feedback-b44ca2f0-2ed2-11e6-98b9-5bcb7af9e062\",\"team\":{\"id\":\"T0G9HMJK1\",\"domain\":\"careerlark\"},\"channel\":{\"id\":\"D1F9WRCP4\",\"name\":\"directmessage\"},\"user\":{\"id\":\"U1F9BF29L\",\"name\":\"testuser1\"},\"action_ts\":\"1465539415.45047\",\"message_ts\":\"1465539317.000008\",\"attachment_id\":\"1\",\"original_message\":{\"text\":\"\",\"username\":\"careerlark\",\"bot_id\":\"B0PHWBBT9\",\"attachments\":[{\"callback_id\":\"feedback-b44ca2f0-2ed2-11e6-98b9-5bcb7af9e062\",\"fallback\":\"Feedback for Test\",\"text\":\"Hey Test, How did *Kenson* do on: *test test*\\n\\nPick one or type in the emoji:\",\"title\":\"Feedback for Test\",\"id\":1,\"color\":\"DA552F\",\"actions\":[{\"id\":\"1\",\"name\":\":disappointed:\",\"text\":\":disappointed:\",\"type\":\"button\",\"value\":\":disappointed:\",\"style\":\"primary\"},{\"id\":\"2\",\"name\":\":neutral_face:\",\"text\":\":neutral_face:\",\"type\":\"button\",\"value\":\":neutral_face:\",\"style\":\"primary\"},{\"id\":\"3\",\"name\":\":simple_smile:\",\"text\":\":simple_smile:\",\"type\":\"button\",\"value\":\":simple_smile:\",\"style\":\"primary\"},{\"id\":\"4\",\"name\":\":smile:\",\"text\":\":smile:\",\"type\":\"button\",\"value\":\":smile:\",\"style\":\"primary\"},{\"id\":\"5\",\"name\":\":joy:\",\"text\":\":joy:\",\"type\":\"button\",\"value\":\":joy:\",\"style\":\"primary\"}]}],\"type\":\"message\",\"subtype\":\"bot_message\",\"ts\":\"1465539317.000008\"},\"response_url\":\"test\"},\"context\":{\"slackUserId\":\"U1F9BF29L\"}}]');
        done();
      });
  });

  it('should throw error if user-agent is not matched', done => {
    request
      .post('/v1/slack/interactive-message')
      .set({"user-agent": "Not a slack bot"})
      .send({
        "payload": "{\"actions\":[{\"name\":\":joy:\",\"value\":\":joy:\"}],\"callback_id\":\"feedback-b44ca2f0-2ed2-11e6-98b9-5bcb7af9e062\",\"team\":{\"id\":\"T04D7GT0W\",\"domain\":\"careerlark\"},\"channel\":{\"id\":\"D1F9WRCP4\",\"name\":\"directmessage\"},\"user\":{\"id\":\"U1F9BF29L\",\"name\":\"testuser1\"},\"action_ts\":\"1465539415.45047\",\"message_ts\":\"1465539317.000008\",\"attachment_id\":\"1\",\"token\":\"V997LkBssTf446EeLxfCpSRd\",\"original_message\":{\"text\":\"\",\"username\":\"careerlark\",\"bot_id\":\"B0PHWBBT9\",\"attachments\":[{\"callback_id\":\"feedback-b44ca2f0-2ed2-11e6-98b9-5bcb7af9e062\",\"fallback\":\"Feedback for Test\",\"text\":\"Hey Test, How did *Kenson* do on: *test test*\\n\\nPick one or type in the emoji:\",\"title\":\"Feedback for Test\",\"id\":1,\"color\":\"DA552F\",\"actions\":[{\"id\":\"1\",\"name\":\":disappointed:\",\"text\":\":disappointed:\",\"type\":\"button\",\"value\":\":disappointed:\",\"style\":\"primary\"},{\"id\":\"2\",\"name\":\":neutral_face:\",\"text\":\":neutral_face:\",\"type\":\"button\",\"value\":\":neutral_face:\",\"style\":\"primary\"},{\"id\":\"3\",\"name\":\":simple_smile:\",\"text\":\":simple_smile:\",\"type\":\"button\",\"value\":\":simple_smile:\",\"style\":\"primary\"},{\"id\":\"4\",\"name\":\":smile:\",\"text\":\":smile:\",\"type\":\"button\",\"value\":\":smile:\",\"style\":\"primary\"},{\"id\":\"5\",\"name\":\":joy:\",\"text\":\":joy:\",\"type\":\"button\",\"value\":\":joy:\",\"style\":\"primary\"}]}],\"type\":\"message\",\"subtype\":\"bot_message\",\"ts\":\"1465539317.000008\"},\"response_url\":\"test\"}"
      })
      .end(function(err, res) {
        expect(err).to.equal(null);
        expect(res.body.status).to.equal('error');
        expect(res.body.error).to.equal('Invalid user agent');
        done();
      });
  });

  it('should throw error if token is not matched', done => {
    request
      .post('/v1/slack/interactive-message')
      .set({"user-agent":"Slackbot 1.0 (+https://api.slack.com/robots)"})
      .send({
        "payload": "{\"actions\":[{\"name\":\":joy:\",\"value\":\":joy:\"}],\"callback_id\":\"feedback-b44ca2f0-2ed2-11e6-98b9-5bcb7af9e062\",\"team\":{\"id\":\"T04D7GT0W\",\"domain\":\"careerlark\"},\"channel\":{\"id\":\"D1F9WRCP4\",\"name\":\"directmessage\"},\"user\":{\"id\":\"U1F9BF29L\",\"name\":\"testuser1\"},\"action_ts\":\"1465539415.45047\",\"message_ts\":\"1465539317.000008\",\"attachment_id\":\"1\",\"token\":\"WRONG TOKEN\",\"original_message\":{\"text\":\"\",\"username\":\"careerlark\",\"bot_id\":\"B0PHWBBT9\",\"attachments\":[{\"callback_id\":\"feedback-b44ca2f0-2ed2-11e6-98b9-5bcb7af9e062\",\"fallback\":\"Feedback for Test\",\"text\":\"Hey Test, How did *Kenson* do on: *test test*\\n\\nPick one or type in the emoji:\",\"title\":\"Feedback for Test\",\"id\":1,\"color\":\"DA552F\",\"actions\":[{\"id\":\"1\",\"name\":\":disappointed:\",\"text\":\":disappointed:\",\"type\":\"button\",\"value\":\":disappointed:\",\"style\":\"primary\"},{\"id\":\"2\",\"name\":\":neutral_face:\",\"text\":\":neutral_face:\",\"type\":\"button\",\"value\":\":neutral_face:\",\"style\":\"primary\"},{\"id\":\"3\",\"name\":\":simple_smile:\",\"text\":\":simple_smile:\",\"type\":\"button\",\"value\":\":simple_smile:\",\"style\":\"primary\"},{\"id\":\"4\",\"name\":\":smile:\",\"text\":\":smile:\",\"type\":\"button\",\"value\":\":smile:\",\"style\":\"primary\"},{\"id\":\"5\",\"name\":\":joy:\",\"text\":\":joy:\",\"type\":\"button\",\"value\":\":joy:\",\"style\":\"primary\"}]}],\"type\":\"message\",\"subtype\":\"bot_message\",\"ts\":\"1465539317.000008\"},\"response_url\":\"test\"}"
      })
      .end(function(err, res) {
        expect(err).to.equal(null);
        expect(res.body.status).to.equal('error');
        expect(res.body.error).to.equal('Slack Token is mismatched');
        done();
      });
  });

});
