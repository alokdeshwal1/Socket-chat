//// we use pass by reference to dynamically update the mock fb user output in each test
//const mockGoogleUser = {};
//const Sinon = require('sinon');
////const Mockery = mock(require('mockery'), mockGoogleUser);
//const Chai = require('chai');
//const expect = Chai.expect;
//const request = require('./../../load-server')();
//const Config = require('./../../../configs/config');
//const Accounts = require('./../../test-configs/test-accounts');
//const Queue = require('./../../../queue');
//
//describe('API: register Google user', function() {
//  before(function(done) {
//    Mockery.enable({
//      warnOnReplace: false,
//      warnOnUnregistered: false,
//      useCleanCache: true
//    });
//
//    GLOBAL.queue = new Queue(Config);
//    GLOBAL.queue.on('ready', function() {
//      Mockery.spy = Mockery.spy || {};
//      GLOBAL.queue.jobs.JobSendEmail.queue = Mockery.spy.spySendEmail = Sinon.stub().returns(new Promise(function(resolve, reject) {
//        resolve(true);
//      }));
//
//      done();
//    });
//  });
//
//  after(function(done) {
//    Mockery.deregisterAll();
//
//    request
//      .post('/v1/integration-tests/cleanup')
//      .end(function(err, res) {
//        done();
//      });
//  });
//
//  /*
//  describe('Seeded Facebook user', function() {
//    it('should login an existing facebook user on Asteri', function(done) {
//      var account = Accounts.facebook[1];
//      account.companyId = account.company.objectId;
//
//      mockGoogleUser.first_name = account.firstName;
//      mockGoogleUser.last_name = account.lastName;
//      mockGoogleUser.email = account.email;
//      mockGoogleUser.company_name = account.company.name;
//      mockGoogleUser.id = account.facebookId;
//
//      request
//        .post('/v1/user/register/facebook')
//        .send({
//          params: {
//            accessToken: 'some-random-token'
//          }
//        })
//        .end(function(err, res) {
//
//          expect(err).to.equal(null);
//          expect(res.status).to.equal(200);
//          expect(res.body.status).to.equal('success');
//          expect(res.body.fbUser).to.be.an('object');
//          expect(res.body.user).to.be.an('object');
//
//          expect(Mockery.spy.spySendEmail.called).to.be.false;
//
//          done();
//        });
//
//    });
//
//
//    it('should register a seeded Facebook user with user\'s isSeeded=true ', function(done) {
//
//      var account = Accounts.seeded[1];
//      account.companyId = account.company.objectId;
//
//      mockGoogleUser.first_name = account.firstName;
//      mockGoogleUser.last_name = account.lastName;
//      mockGoogleUser.email = account.email;
//      mockGoogleUser.company_name = account.company.name;
//      mockGoogleUser.id = 'some-random-userid';
//
//      request
//        .post('/v1/user/register/facebook')
//        .send({
//          params: {
//            accessToken: 'some-random-token'
//          }
//        })
//        .end(function(err, res) {
//
//          expect(err).to.equal(null);
//          expect(res.status).to.equal(200);
//          expect(res.body.status).to.equal('success');
//          expect(res.body.fbUser).to.be.an('object');
//          expect(res.body.user).to.be.an('object');
//          expect(res.body.user.firstName).to.equal(account.firstName);
//          expect(res.body.user.lastName).to.equal(account.lastName);
//
//          expect(Mockery.spy.spySendEmail.called).to.be.true;
//
//          done();
//        });
//    });
//
//    it('should return MULTIPLE MATCHES when more than one user is matched', function(done) {
//
//      var account = Accounts.seeded[1];
//      account.companyId = account.company.objectId;
//
//      mockGoogleUser.first_name = account.firstName;
//      mockGoogleUser.last_name = 'User';
//      mockGoogleUser.email = account.email;
//      mockGoogleUser.company_name = account.company.name;
//      mockGoogleUser.id = 'blah blah id';
//
//      request
//        .post('/v1/user/register/facebook')
//        .send({
//          params: {
//            accessToken: 'some-random-token'
//          }
//        })
//        .end(function(err, res) {
//
//          expect(err).to.equal(null);
//          expect(res.status).to.equal(200);
//          expect(res.body.status).to.equal('success');
//          expect(res.body.action).to.equal('MULTIPLE_MATCHES');
//          expect(res.body.fbUser).to.be.an('object');
//
//          done();
//        });
//    });
//  });
//  */
//
//  describe('Unseeded user', function() {
//    it('should redirect user to MANUAL registration', function(done) {
//
//      var account = Accounts.create[1];
//      account.companyId = account.company.objectId;
//
//      mockGoogleUser.first_name = account.firstName;
//      mockGoogleUser.last_name = account.lastName;
//      mockGoogleUser.email = account.email;
//      mockGoogleUser.company_name = account.company.name;
//      mockGoogleUser.id = 'blah blah id';
//
//      request
//        .post('/v1/user/register/google')
//        .send({
//          accessToken: 'some-random-token'
//        })
//        .end(function(err, res) {
//
//          expect(err).to.equal(null);
//          expect(res.status).to.equal(200);
//          expect(res.body.status).to.equal('success');
//          expect(res.body.action).to.equal('NEED_COMPANY_INFO');
//          expect(res.body.fbUser).to.be.an('object');
//
//          done();
//        });
//    });
//  });
//
//});
//
//
//function mock(Mockery, mockGoogleUser) {
//  var Fb = require('fb');
//
//  Mockery.spy = Mockery.spy || {};
//
//  Fb.api = Mockery.spy.spyFbApi = Sinon.stub().returns(new Promise(function(resolve, reject) {
//    resolve(mockGoogleUser);
//  }));
//
//  Mockery.registerMock('fb', Fb);
//
//  Mockery.enable({
//    warnOnReplace: false,
//    warnOnUnregistered: false,
//    useCleanCache: true
//  });
//
//  return Mockery;
//}
//
