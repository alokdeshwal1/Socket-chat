before(require('mongodb-runner/mocha/before'));
before(done => {
  // override the test environment url to mongo-runner instance
  process.env.MONGOLAB_URI = 'mongodb://localhost:27017/careerlark';
  done();
});
after(require('mongodb-runner/mocha/after'));