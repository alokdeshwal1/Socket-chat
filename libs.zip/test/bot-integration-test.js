'use strict';

const Chai = require('chai');
const Sinon = require('sinon');
const expect = Chai.expect;
const mockTalkingBot = require('./bot/mocks/mock-talking-bot');
const TalkingBot = require('./../bot/talking-bot');
const Config = require('./../configs/config');
const CONSTANTS = require('./../constants/constants');
const ModelUser = require('./../models/user');
const TestUser = require('./bot/configs/user');
const _ = require('lodash');
const Co = require('co');
Chai.config.truncateThreshold = 0;


class BotIntegrationTest {
  constructor(enabledModules, primaryUser, users, expected, init, teamName, teamId, accessToken) {
    this.primaryUser = primaryUser;
    this.teamName = teamName || 'eatravelive';
    this.teamId = teamId || 'T0G9HMJK1';
    this.teamKey = TalkingBot.getTeamKey(this.teamName, this.teamId);
    this.accessToken = accessToken || 'xoxb-23605291715-V9st3mnB44JfpJW1ZvsqIm41';
    this.botName = 'LarkBot';
    this.init = init;
    this.channelNames = {};
    this.users = users;
    if (Array.isArray(users)) {
      users.forEach(user => {
        this.channelNames[user.slackUserId] = user.firstName +' '+ user.lastName;
      });
    }
    else {
      // support old code
      Object.keys(users).forEach(key=> {
        var user = users[key];
        this.channelNames[user.slackUserId] = user.firstName +' '+ user.lastName;
      });
    }
    this.primaryChannel = this.channelNames[primaryUser.slackUserId];
    this.slackUserId = primaryUser.slackUserId;
    this.context = {
      'slackUserId': this.slackUserId
    };

    this.result = [];
    this.instance = mockTalkingBot(enabledModules, this.teamName, this.teamId, this.accessToken, this.botName, this.channelNames);
    this.expected = expected;
    this.isStarted = false;
  }

  generateAllTests() {
    if (typeof this.expected === 'object') {
      Object.keys(this.expected).forEach(channelId => {
        var row = this.expected[channelId];
        row.forEach((item, counter) => {
          var title;

          if (typeof item.expect.text === 'string') {
            title = item.expect.text;
          }
          else if (item.expect.text instanceof RegExp) {
            title = item.expect.text.toString();
          }
          else if (Array.isArray(item.expect.text)) {
            title = item.expect.text[0].fallback
          }
          else if (_.isObject(item.expect.text)) {
            if (typeof item.expect.text.message === 'string') {
              title = item.expect.text.message;
            }
            else {
              title = item.expect.text.message[0].fallback
            }
          }
          this.generateTest(channelId, counter, channelId +' should get: '+ title, item.expect, item.overwriteTest);
        });
      });
    }
  }

  generateTest(channelId, counter, title, expected, test) {
    it(title, () => {
      if (test) {
        expect(test(expected.text, this.result[channelId][counter])).to.equal(true);
      }
      else if (expected.text instanceof RegExp) {
        expect(this.result[channelId][counter]).to.match(expected.text);
      }
      else {
        expect(this.result[channelId][counter]).to.deep.equal(expected.text);
      }
    });
  }

  onEnd(cb) {
    this.instance.on(CONSTANTS.BOT_EVENT.END, cb);
  }

  runTest() {
    var totalExpected = [];
    var counters = {};
    var channelToSlackId = _.invert(this.channelNames);
    if (typeof this.expected === 'object') {
      Object.keys(this.expected).forEach(key => {
        totalExpected = totalExpected.concat(this.expected[key]);
        counters[key] = counters[key] || 0;
      });
    }
    else {
      totalExpected = this.expected;
    }

    return new Promise((resolve, reject) => {
      this.instance.on(CONSTANTS.BOT_EVENT.MESSAGE_QUEUED, (data) => {
        try {
          var channel = data.channel;
          var channelCounter = counters[channel];
          // there might be some other unexpected channel messages
          this.expected[channel] = this.expected[channel] || {};
          var expected = this.expected[channel][channelCounter];
          counters[data.channel]++;
          this.result[channel] = this.result[channel] || [];

          var messageOutput = data.message || data.attachments;
          if (data.emojiReaction) {
            messageOutput = {
              message: messageOutput,
              emojiReaction: _.cloneDeep(data.emojiReaction)
            };
          }
          this.result[channel].push(messageOutput);
          if(expected) {
            if (expected.enterMessage) {
              this.instance.listen(channelToSlackId[channel], channel, expected.enterMessage);
            }
            else if (expected.enterEmojiMessage) {
              this.instance.addEmojiMessage(expected.enterEmojiMessage, channel);
            }
            else if (expected.enterButtonAction) {
              this.instance.addButtonAction(expected.enterButtonAction, channel);
            }
          }

          if (_.sum(counters) >= totalExpected.length) {
            return resolve(this.result);
          }
        }
        catch (ex) {
          return reject(ex);
        }
      });

      if (! this.isStarted && (typeof this.init === 'function')) {
        try {
           this.init.apply(this);
        }
        catch (ex) {
          return reject(ex);
        }

        this.isStarted = true;
      }
    });
  }

  before(func) {
    return new Promise((resolve, reject) => {
      Co(function*() {
        try {
          var users = yield ModelUser.find({ slackUserId: { '$in': _.pluck(TestUser, 'slackUserId') }});
          users = _.sortBy(users, (item) => {
            return _.findIndex(TestUser, { slackUserId: item.slackUserId });
          });

          if (func) {
            yield func(users);
          }
          yield this.runTest();
          return resolve(true);
        }
        catch (ex) {
          return reject(ex);
        }
      }.bind(this));
    });
  }
}

module.exports = BotIntegrationTest;