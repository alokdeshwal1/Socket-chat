const ModelSlackIntegration = require('./../../../models/slack-integration');
const lists = [
  {
    "accessToken" : "xoxp-16323732647-16321667203-30527058817-19feb93181",
    "incomingWebHook" : {
      "url" : "https://hooks.slack.com/services/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",
      "configuration_url" : "https://eatravelive.slack.com/services/B1EBG8EQJ",
      "channel_id" : "D0G9JH4H5",
      "channel" : "@slackbot"
    },
    "scope" : "identify,bot,incoming-webhook,users:read,chat:write:bot,im:write",
    "teamId" : "T0G9HMJK1",
    "teamName" : "eatravelive",
    "bot" : {
      "bot_access_token" : "xoxb-25731692099-ldehqsgpPurQOcZHM5Hn8gAj",
      "bot_user_id" : "U0RMHLC2X"
    },
    "rawData" : {
      "bot" : {
        "bot_access_token" : "xoxb-25731692099-ldehqsgpPurQOcZHM5Hn8gAj",
        "bot_user_id" : "U0RMHLC2X"
      },
      "incoming_webhook" : {
        "url" : "https://hooks.slack.com/services/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",
        "configuration_url" : "https://eatravelive.slack.com/services/B1EBG8EQJ",
        "channel_id" : "D0G9JH4H5",
        "channel" : "@slackbot"
      },
      "team_id" : "T0G9HMJK1",
      "team_name" : "eatravelive",
      "user_id" : "U0G9FKM5Z",
      "scope" : "identify,bot,incoming-webhook,users:read,chat:write:bot,im:write",
      "access_token" : "xoxp-16323732647-16321667203-30527058817-19feb93181",
      "ok" : true
    },
    "installerSlackUserId" : "U0G9FKM5Z",
    "installerSlackUserName" : "susan",
    "installerSlackUserEmail" : "susan.miller@bezelle.com",
    "status" : "active"
  }
];
const CONSTANTS = require('./../../../constants/constants');

exports.lists = lists;
exports.up = function(db, next) {
  var actions = [];
  lists.forEach(item => {
    actions.push(ModelSlackIntegration.upsert({
      name: item.name
    }, Object.assign(item, {status: CONSTANTS.DB.STATUS.ACTIVE})));
  });

  Promise.all(actions).then(() => {
    next();
  }).catch(err => {
    next(err);
  });
};

exports.down = function(db, next) {
  var actions = [];
  lists.forEach(item => {
    actions.push(ModelSlackIntegration.remove({
      name: item.name
    }));
  });

  Promise.all(actions).then(() => {
    next();
  }).catch(err => {
    next(err);
  });
};
