const ModelUser = require('./../../../models/user');
const ModelCompany = require('./../../../models/company');
const ModelSlackIntegration = require('./../../../models/slack-integration');
const lists = [
  {
    'firstName': 'Susan',
    'lastName': 'Miller',
    'name': 'Susan Miller',
    'slackUserId': 'U0G9FKM5Z',
    'email': 'susan.miller@bezelle.com',
    'timezone': 'America/Los_Angeles',
    'slackUserName': 'miller'
  },
  {
    'firstName': 'Richard',
    'lastName': 'Caine',
    'name': 'Richard Caine',
    'slackUserId': 'U0G9HS4K0',
    'email': 'test1@eatravelive.com',
    'timezone': 'America/Los_Angeles',
    'slackUserName': 'richard'
  },
  {
    'firstName': 'Jared',
    'lastName': 'Gomez',
    'name': 'Jared Gomez',
    'slackUserId': 'U0TT6SKNW',
    'email': 'test3@eatravelive.com',
    'timezone': 'America/Los_Angeles',
    'slackUserName': 'jared'
  },
  {
    'firstName': 'Monica',
    'lastName': 'Stabler',
    'name': 'Monica Stabler',
    'slackUserId': 'U0TSP1QQ6',
    'email': 'test4@eatravelive.com',
    'timezone': 'America/Los_Angeles',
    'slackUserName': 'monica'
  },
  {
    'firstName': 'gilfoyle',
    'lastName': 'gilfoyle',
    'name': 'gilfoyle gilfoyle',
    'slackUserId': 'U0TSWM0TH',
    'email': 'test5@eatravelive.com',
    'timezone': 'America/Los_Angeles',
    'slackUserName': 'gilfoyle'
  },
  {
    'firstName': 'Dave',
    'lastName': 'Lee',
    'name': 'Dave Lee',
    'slackUserId': 'U0UE20H8Q',
    'email': 'test6@eatravelive.com',
    'timezone': 'America/Los_Angeles',
    'slackUserName': 'dave'
  }
];
const CONSTANTS = require('./../../../constants/constants');

exports.up = function(db, next) {
  var actions = [];

  Promise.all([
    ModelCompany.findOne({ name: require('./99005-add-company.js').lists[0].name }),
    ModelSlackIntegration.findOne({ teamId: require('./99007-add-slack-integration.js').lists[0].teamId })
  ]).then(data => {
    lists.forEach(item => {
      actions.push(ModelUser.upsert({
        name: item.email
      }, Object.assign(item, {company: data[0].id, slackIntegration: data[1].id, status: CONSTANTS.DB.STATUS.ACTIVE})));
    });

    return Promise.all(actions);
  }).then(() => {
    next();
  }).catch(err => {
    next(err);
  });
};

exports.down = function(db, next) {
  var actions = [];
  lists.forEach(item => {
    actions.push(ModelUser.remove({
      name: item.email
    }));
  });

  Promise.all(actions).then(() => {
    next();
  }).catch(err => {
    next(err);
  });
};

exports.lists = lists;