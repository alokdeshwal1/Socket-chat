const ModelCompany = require('./../../../models/company');
const lists = [
  {
    'name': 'eatravelive',
    'emailDomain': 'eatravelive.com'
  }
];
const CONSTANTS = require('./../../../constants/constants');

exports.lists = lists;
exports.up = function(db, next) {
  var actions = [];
  lists.forEach(item => {
    actions.push(ModelCompany.upsert({
      name: item.name
    }, Object.assign(item, {status: CONSTANTS.DB.STATUS.ACTIVE})));
  });

  Promise.all(actions).then(() => {
    next();
  }).catch(err => {
    next(err);
  });
};

exports.down = function(db, next) {
  var actions = [];
  lists.forEach(item => {
    actions.push(ModelCompany.remove({
      name: item.name
    }));
  });

  Promise.all(actions).then(() => {
    next();
  }).catch(err => {
    next(err);
  });
};

exports.lists = lists;