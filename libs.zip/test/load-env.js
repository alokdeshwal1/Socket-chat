// try to load local .env file
try {
  const LoadEnvs = require('./../node_modules/foreman/lib/envs').loadEnvs;
  var envs = [];
  try {
    envs = LoadEnvs('.env');
  }
  catch(ex) {}
  for(var key in envs) {
    if(key !== 'NODE_ENV') {
      process.env[key] = envs[key];
    }
  }

  // overload the debug option
  process.env['DEBUG'] = 'none';
  process.env['IS_RUNNING_TEST'] = true;
  process.env.MONGOLAB_URI = 'mongodb://localhost:27017/careerlark';
}
catch(ex) {
  throw('failed to load local environment variables', ex);
}
