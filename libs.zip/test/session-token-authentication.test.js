//const Chai = require('chai');
//const expect = Chai.expect;
//const Config = require('./test-configs/test-config');
//const Helper = require('../libs/helper.js');
//const Accounts = require('./test-configs/test-accounts');
//
//describe('Session Token Authentication', function() {
//  const request = require('./load-server')();
//
//  it('should be 200 with correct sessionToken and userId', function(done) {
//    const account = Accounts.good[2];
//    const userId = account.objectId;
//    const companyId  = account.company.objectId;
//
//    request
//      .get('/v1/kudos-feed/company/'+ userId +'/'+ companyId)
//      .set('x-parse-application-id', Config.PARSE_APPLICATION_ID)
//      .set('x-parse-session-token', account.sessionToken)
//      .set('x-parse-user-id', account.objectId)
//      .end(function(err, res) {
//
//        expect(err).to.equal(null);
//        expect(res.status).to.equal(200);
//        expect(res.body.status).to.equal('success');
//
//        done();
//      });
//  });
//
//  it('should be 405 with wrong sessionToken', function(done) {
//    const account = Accounts.good[1];
//    const userId = account.objectId;
//    const companyId  = account.company.objectId;
//
//    request
//      .get('/v1/kudos-feed/company/'+ userId +'/'+ companyId)
//      .set('x-parse-application-id', Config.PARSE_APPLICATION_ID)
//      .set('x-parse-session-token', 'blabblahblah')
//      .set('x-parse-user-id', account.objectId)
//      .end(function(err, res) {
//
//        expect(err).to.equal(null);
//        expect(res.status).to.equal(405);
//
//        done();
//      });
//  });
//
//  it('should be 405 with wrong userId', function(done) {
//    const account = Accounts.good[1];
//    const userId = account.objectId;
//    const companyId  = account.company.objectId;
//
//    request
//      .get('/v1/kudos-feed/company/'+ userId +'/'+ companyId)
//      .set('x-parse-application-id', Config.PARSE_APPLICATION_ID)
//      .set('x-parse-session-token', account.sessionToken)
//      .set('x-parse-user-id', 'SomeWrongId')
//      .end(function(err, res) {
//
//        expect(err).to.equal(null);
//        expect(res.status).to.equal(405);
//
//        done();
//      });
//  });
//
//});