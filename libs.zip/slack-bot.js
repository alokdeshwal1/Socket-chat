const Config = require('./configs/config');
const Logger = require('./libs/logger');
const throng = require('throng');
const http = require('http');
const TalkingBot = require('./bot/talking-bot');
const CONSTANTS = require('./constants/constants');
const Server = require('./bot/server');
const models = require('./models'); // preload all models so that there is no dependencies issues
const memwatch = require('memwatch-next');

http.globalAgent.maxSockets = Infinity;
throng(startBotServer, {workers: Config.botConcurrency});

function startBotServer(id) {
  Logger.info('booting %s id #%d on port: %s', 'Bot', id, process.env.PORT || 9000);

  new Server(id);

  process.on('SIGTERM', function() {
    console.log(`Worker ${id} exiting`);
    process.exit();
  });
}

memwatch.on('leak', function(info) {
  Logger.error('SlackBot Memory Leak', info);
});