const ModelGoal = require('./../models/goal');
const ModelGoalCategory = require('./../models/goal-category');
const ModelFunction = require('./../models/function');
const lists = [
  {
    "priority": 1,
    "isStandard": true,
    "goalCategory": "Communication",
    "name": "Listen actively. Seek first to understand, then to be understood.",
    "status": "active"
  },
  {
    "priority": 2,
    "isStandard": true,
    "goalCategory": "Communication",
    "name": "Be respectful and considerate of others",
    "status": "active"
  },
  {
    "priority": 3,
    "isStandard": true,
    "goalCategory": "Communication",
    "name": "Communicate in a clear and logical manner with the appropriate level of detail",
    "status": "active"
  },
  {
    "priority": 4,
    "isStandard": true,
    "goalCategory": "Communication",
    "name": "Express yourself clearly and concisely in written communications",
    "status": "active"
  },
  {
    "priority": 5,
    "isStandard": true,
    "goalCategory": "Communication",
    "name": "Always have prepared agendas for meetings and ensure everything stays on track",
    "status": "active",

  },
  {
    "priority": 6,
    "isStandard": true,
    "goalCategory": "Communication",
    "name": "Keep all relevant stakeholders informed as appropriate",
    "status": "active",
  },
  {
    "priority": 1,
    "isStandard": true,
    "goalCategory": "Productivity",
    "name": "Pay close attention to detail",
    "status": "active",
  },
  {
    "priority": 2,
    "isStandard": true,
    "goalCategory": "Productivity",
    "name": "Know when to use existing solutions and resources without reinventing the wheel",
    "status": "active",
  },
  {
    "priority": 3,
    "isStandard": true,
    "goalCategory": "Productivity",
    "name": "Take on new projects and go above and beyond when faced with challenges",
    "status": "active",
  },
  {
    "priority": 4,
    "isStandard": true,
    "goalCategory": "Productivity",
    "name": "Take initiative to make things better, even outside of your day to day responsibilities",
    "status": "active",
  },
  {
    "priority": 5,
    "isStandard": true,
    "goalCategory": "Productivity",
    "name": "Manage time efficiently and consistently deliver on commitments",
    "status": "active",
  },
  {
    "priority": 1,
    "isStandard": true,
    "goalCategory": "Leadership and Managerial Skills",
    "name": "Inspire and motivate your team to succeed",
    "status": "active",
  },
  {
    "priority": 2,
    "isStandard": true,
    "goalCategory": "Leadership and Managerial Skills",
    "name": "Mentor new/more junior employees",
    "status": "active",
  },
  {
    "priority": 3,
    "isStandard": true,
    "goalCategory": "Leadership and Managerial Skills",
    "name": "Coach team members through difficult situations",
    "status": "active",
  },
  {
    "priority": 1,
    "isStandard": true,
    "goalCategory": "Technical Skills",
    "name": "Consistently produce high-quality, bug free output",
    "status": "active",
  },
  {
    "priority": 2,
    "isStandard": true,
    "goalCategory": "Technical Skills",
    "name": "Thoroughly test all code prior to pushing to production",
    "status": "active",
  },
  {
    "priority": 3,
    "isStandard": true,
    "goalCategory": "Technical Skills",
    "name": "Use appropriate languages and technologies to solve the problem at hand",
    "status": "active",
  },
  {
    "priority": 1,
    "isStandard": true,
    "goalCategory": "Product Management Skills",
    "name": "Produce clear and complete specifications",
    "status": "active",
  },
  {
    "priority": 2,
    "isStandard": true,
    "goalCategory": "Product Management Skills",
    "name": "Drive consensus cross functionally when disagreements arise",
    "status": "active",
  },
  {
    "priority": 4,
    "isStandard": true,
    "goalCategory": "Product Management Skills",
    "name": "Always have a clear and compelling 12-18 month feature roadmap",
    "status": "active",
  },
  {
    "priority": 5,
    "isStandard": true,
    "goalCategory": "Product Management Skills",
    "name": "Demonstrate thought leadership in your industry/area of expertise",
    "status": "active",
  },
  {
    "priority": 1,
    "isStandard": true,
    "goalCategory": "Sales Skills",
    "name": "Always go the extra mile for the customer",
    "status": "active",
  },
  {
    "priority": 2,
    "isStandard": true,
    "goalCategory": "Sales Skills",
    "name": "Identify creative solutions to solve customer problems",
    "status": "active",
  },
  {
    "priority": 3,
    "isStandard": true,
    "goalCategory": "Sales Skills",
    "name": "Drive consensus cross functionally when internal disagreements arise",
    "status": "active",
  },
  {
    "priority": 4,
    "isStandard": true,
    "goalCategory": "Sales Skills",
    "name": "Forge and maintain close professional relationships with customers",
    "status": "active",
  },
  {
    "priority": 1,
    "isStandard": true,
    "goalCategory": "Marketing Skills",
    "name": "Produce clear and compelling marketing materials for new product/feature launches",
    "status": "active",
  },
  {
    "priority": 2,
    "isStandard": true,
    "goalCategory": "Marketing Skills",
    "name": "Ensure that sales is adequately trained on the most salient value propositions for all new features",
    "status": "active",
  },
  {
    "priority": 3,
    "isStandard": true,
    "goalCategory": "Marketing Skills",
    "name": "Drive consensus cross functionally when disagreements arise",
    "status": "active",
  },
  {
    "priority": 4,
    "isStandard": true,
    "goalCategory": "Marketing Skills",
    "name": "Maintain an active voice on the company blog/social media accounts",
    "status": "active",
  },
  {
    "priority": 5,
    "isStandard": true,
    "goalCategory": "Marketing Skills",
    "name": "Demonstrate thought leadership in your industry/area of expertise",
    "status": "active",
  },
  {
    "priority": 1,
    "isStandard": true,
    "goalCategory": "Attitude and Outlook",
    "name": "Always maintain a positive, can-do attitude",
    "status": "active",
  },
  {
    "priority": 2,
    "isStandard": true,
    "goalCategory": "Attitude and Outlook",
    "name": "Take pride in your work",
    "status": "active",

  },
  {
    "priority": 3,
    "isStandard": true,
    "goalCategory": "Attitude and Outlook",
    "name": "Empower others to succeed",
    "status": "active",
  },
  {
    "priority": 4,
    "isStandard": true,
    "goalCategory": "Attitude and Outlook",
    "name": "Take initiative to make things better, even outside of your day to day responsibilities",
    "status": "active"
  },
  {
    "priority": 3,
    "isStandard": true,
    "goalCategory": "Product Management Skills",
    "name": "Maintain a fully fleshed out backlog of features, to ensure engineering resources are always optimally utilized",
    "status": "active"
  }
];
const CONSTANTS = require('./../constants/constants');

exports.up = function(db, next) {
  ModelGoalCategory.find({status: 'active'}).then(data => {
    var goalCategories = {};
    var actions = [];
    data.map(item => {
      goalCategories[item.name] = item.id;
    });

    lists.forEach(item => {
      if (item.goalCategory) {
        item = Object.assign(item, {goalCategory: goalCategories[item.goalCategory]});
      }
      actions.push(ModelGoal.upsert({
        name: item.name
      }, Object.assign(item, {status: CONSTANTS.DB.STATUS.ACTIVE})));
    });

    return Promise.all(actions);
  })
  .then(() => {
    next();
  }).catch(err => {
    next(err);
  });
};

exports.down = function(db, next) {
  var actions = [];
  lists.forEach(item => {
    actions.push(ModelGoal.remove({
      name: item.name
    }));
  });

  Promise.all(actions).then(() => {
    next();
  }).catch(err => {
    next(err);
  });
};
