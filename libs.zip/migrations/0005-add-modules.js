const ModelModule = require('./../models/module');
exports.up = function(db, next) {
  var newObject1 = new ModelModule();
  var newObject2 = new ModelModule();
  newObject1.name = 'Feedback';
  newObject2.name = 'OKR';

  Promise.all([
    newObject1.save(),
    newObject2.save()
  ]).then(() => {
    next();
  }).catch(err => {
    next(err);
  });
};

exports.down = function(db, next) {
  Promise.all([
    ModelModule.remove({name: 'Feedback'}),
    ModelModule.remove({name: 'OKR'})
  ]).then(() => {
    next();
  }).catch(err => {
    next(err);
  });
};
