const ModelTrigger = require('./../models/trigger');
const CONSTANTS = require('./../constants/constants');
const lists = [
  {
    "category": "Google Calendar",
    "priority": 1,
    "isStandard": true,
    "name": "After meetings (GCal sign-in needed)",
    "systemKey": "Google Calendar Integration",
    "status": CONSTANTS.DB.STATUS.ACTIVE
  },
  {
    "category": "Manual",
    "priority": 3,
    "isStandard": true,
    "name": "At regular time intervals (set manually)",
    "systemKey": "Regular Time Interval",
    "status": CONSTANTS.DB.STATUS.ACTIVE
  },
  {
    "category": "Gmail",
    "priority": 2,
    "isStandard": true,
    "name": "Specific emails (Gmail sign-in needed)",
    "systemKey": "Google Gmail Integration",
    "status": CONSTANTS.DB.STATUS.INACTIVE
  }
];

exports.up = function(db, next) {
  var actions = [];
  lists.forEach(item => {
    actions.push(ModelTrigger.upsert({
      name: item.systemKey
    }, item));
  });

  Promise.all(actions)
    .then(() => {
      next();
    }).catch(err => {
      next(err);
    });
};

exports.down = function(db, next) {
  var actions = [];
  lists.forEach(item => {
    actions.push(ModelTrigger.upsert({
      name: item.systemKey
    }));
  });

  Promise.all(actions).then(() => {
    next();
  }).catch(err => {
    next(err);
  });
};
