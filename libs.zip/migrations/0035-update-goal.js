const ModelGoal = require('./../models/goal');
const ModelGoalCategory = require('./../models/goal-category');
const ModelFunction = require('./../models/function');
const CONSTANTS = require('./../constants/constants');
const lists = [
  {
    "priority": 2,
    "isStandard": true,
    "goalCategory": "Communication",
    "name": "Be respectful and considerate of others",
    "status": CONSTANTS.DB.STATUS.INACTIVE
  }
];

exports.up = function(db, next) {
  var actions = [];
  lists.forEach(item => {
    actions.push(ModelGoal.update({
      name: item.name
    }, {status: CONSTANTS.DB.STATUS.INACTIVE}));
  });

  Promise.all(actions).then(() => {
    next();
  }).catch(err => {
    next(err);
  });
};

exports.down = function(db, next) {
  var actions = [];
  lists.forEach(item => {
    actions.push(ModelGoal.update({
      name: item.name
    }, {status: CONSTANTS.DB.STATUS.ACTIVE}));
  });

  Promise.all(actions).then(() => {
    next();
  }).catch(err => {
    next(err);
  });
};
