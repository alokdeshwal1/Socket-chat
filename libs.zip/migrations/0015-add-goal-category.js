const ModelGoalCategory = require('./../models/goal-category');
const ModelFunction = require('./../models/function');
const lists = [
  {
    "priority" : 4,
    "isStandard" : true,
    "isSeeded" : true,
    "name" : "Attitude and Outlook",
    "status" : "active"
  },
  {
    "priority" : 1,
    "isStandard" : true,
    "isSeeded" : true,
    "name" : "Communication",
    "status" : "active"
  },
  {
    "priority" : 2,
    "isStandard" : true,
    "isSeeded" : true,
    "name" : "Productivity",
    "status" : "active"
  },
  {
    "priority" : 3,
    "isStandard" : true,
    "isSeeded" : true,
    "name" : "Leadership and Managerial Skills",
    "status" : "active"
  },
  {
    "priority" : 5,
    "isStandard" : true,
    "isSeeded" : true,
    "name" : "Technical Skills",
    "status" : "active",
    "jobFunction" : "Engineering"
  },
  {
    "priority" : 5,
    "isStandard" : true,
    "isSeeded" : true,
    "name" : "Product Management Skills",
    "jobFunction" : "Product Management",
    "status" : "active"
  },
  {
    "priority" : 5,
    "isStandard" : true,
    "isSeeded" : true,
    "name" : "Sales Skills",
    "jobFunction" : "Sales",
    "status" : "active"
  },
  {
    "priority" : 5,
    "isStandard" : true,
    "isSeeded" : true,
    "name" : "Marketing Skills",
    "jobFunction" : "Marketing",
    "status" : "active"
  }
];
const CONSTANTS = require('./../constants/constants');

exports.up = function(db, next) {
  ModelFunction.find({status: 'active'}).then(data => {
    var functions = {};
    var actions = [];
    data.map(item => {
      functions[item.name] = item.id;
    });

    lists.forEach(item => {
      if (item.jobFunction) {
        item = Object.assign(item, {jobFunction: functions[item.jobFunction]});
      }
      actions.push(ModelGoalCategory.upsert({
        name: item.name
      }, Object.assign(item, {status: CONSTANTS.DB.STATUS.ACTIVE})));
    });

    return Promise.all(actions);
  })
  .then(() => {
    next();
  }).catch(err => {
    next(err);
  });
};

exports.down = function(db, next) {
  var actions = [];
  lists.forEach(item => {
    actions.push(ModelGoalCategory.remove({
      name: item.name
    }));
  });

  Promise.all(actions).then(() => {
    next();
  }).catch(err => {
    next(err);
  });
};
