const ModelFunction = require('./../models/function');
const CONSTANTS = require('./../constants/constants');
const lists = [
  {
    name: 'Human Resources',
    status: CONSTANTS.DB.STATUS.INACTIVE
  },
  {
    name: 'Customer Success',
    status: CONSTANTS.DB.STATUS.INACTIVE
  },
  {
    name: 'Marketing',
    status: CONSTANTS.DB.STATUS.INACTIVE
  },
  {
    name: 'Finance',
    status: CONSTANTS.DB.STATUS.INACTIVE
  }
];


exports.up = function(db, next) {
  var actions = [];
  lists.forEach(item => {
    actions.push(ModelFunction.update({
      name: item.name
    }, item));
  });

  Promise.all(actions).then(() => {
    next();
  }).catch(err => {
    next(err);
  });
};

exports.down = function(db, next) {
  var actions = [];
  lists.forEach(item => {
    actions.push(ModelFunction.update({
      name: item.name
    }, { status: CONSTANTS.DB.STATUS.ACTIVE }));
  });

  Promise.all(actions).then(() => {
    next();
  }).catch(err => {
    next(err);
  });
};
