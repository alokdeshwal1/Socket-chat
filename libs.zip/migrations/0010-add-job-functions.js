const ModelFunction = require('./../models/function');
const lists = [
  {
    name: 'Product Management',
    priority: 1
  },
  {
    name: 'Human Resources',
    priority: 1
  },
  {
    name: 'Customer Success',
    priority: 1
  },
  {
    name: 'Engineering',
    priority: 1
  },
  {
    name: 'Marketing',
    priority: 1
  },
  {
    name: 'Sales',
    priority: 1
  },
  {
    name: 'Finance',
    priority: 1
  },
  {
    name: 'Operations',
    priority: 1
  },
  {
    name: 'Other',
    priority: 9999
  }
];
const CONSTANTS = require('./../constants/constants');

exports.up = function(db, next) {
  var actions = [];
  lists.forEach(item => {
    actions.push(ModelFunction.upsert({
      name: item.name
    }, Object.assign(item, {status: CONSTANTS.DB.STATUS.ACTIVE})));
  });

  Promise.all(actions).then(() => {
    next();
  }).catch(err => {
    next(err);
  });
};

exports.down = function(db, next) {
  var actions = [];
  lists.forEach(item => {
    actions.push(ModelFunction.remove({
      name: item.name
    }));
  });

  Promise.all(actions).then(() => {
    next();
  }).catch(err => {
    next(err);
  });
};
