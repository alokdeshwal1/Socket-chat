'use strict';

const Wit = require('node-wit');
const Config = require('./../../configs/config');
const _ = require('lodash');
const trim = require('trim');
const WordsToNumber = require('words-to-num');

class CalendarCommandParser {
  constructor() {}

  process(message) {
    message = message.replace(/ and /ig, ',');

    var result = {};
    var organizer = this._extractOrganizer(message);
    var numberOfAttendees = this._extractNumberOfAttendees(message);
    var attendees = this._extractAttendees(message);
    var title = this._extractTitle(message);

    if (organizer) {
      result.organizer = organizer;
    }
    if (numberOfAttendees) {
      result.numberOfAttendees = numberOfAttendees;
    }
    if (attendees) {
      result.attendees = attendees;
    }
    if(title) {
      result.title = title;
    }

    return Promise.resolve(result);
  }

  _extractOrganizer(message) {
    var regExps = [
      /\s*organized?(?:by| )* ([<>@a-zA-Z0-9]*)\s*/ig
    ];

    var result = this._runRegExec(regExps, message);
    if (result && Array.isArray(result) && result[0]) {
      return this._parseTextToUsersList(result[0]);
    }
    return result;
  }

  _extractTitle(message) {
    var regExps = [
      /\s*(?:name|title|subject) ?(?:is|are)* ?(?:has|have)* ?([a-zA-Z0-9 ]*)\s*/ig
    ];

    return this._runRegExec(regExps, message);
  }

  _extractAttendees(message) {
    var regExps = [
      /\s*(?:attendees?|attended by) ([a-zA-Z0-9, ]*)\s?/ig
    ];

    var result = this._runRegExec(regExps, message);
    if (result && Array.isArray(result) && result[0]) {
      // for time being, let's do this hackish way.
      // extract recipient regExp also extract expression, such as "send to more than 5 people"
      var dirtyMatch = result[0].match(/(people|person)/ig);
      if (dirtyMatch && dirtyMatch.length > 0) {
        return;
      }
      return this._parseTextToUsersList(result[0]);
    }
    return result;
  }

  _extractNumberOfAttendees(message) {
    var regExps = [
      /(?:[a-zA-Z])*\s*ha(?:s|ve)? ([a-zA-Z0-9:\-_ ]*) (?:people|person|persons)\s*/ig
    ];

    var result = this._runRegExec(regExps, message);
    if (result && Array.isArray(result) && result[0]) {
      var output = this._parseNumberExpression(result[0]);
      output.total = WordsToNumber.convert(output.total);
      if ( ! output.total) {
        return;
      }
      return output;
    }
    return result;
  }

  _runRegExec(regExps, message) {
    var matches = [];
    regExps.forEach(reg => {
      matches.push(reg.exec(message));
    });

    if (_.compact(matches).length < 1) {
      return null;
    }

    for(var i = 0; i < matches.length; i++) {
      var match = matches[i];
      if (match && match[1]) {
        return [trim(match[1])];
      }
    }

    return null;
  }

  _parseNumberExpression(message) {
    if ( ! (message && message.length > 0)) {
      return;
    }

    var result = {};
    var modifiers = [
      {
        key: 'more than or equal',
        modifier: '>='
      },
      {
        key: 'less than or equal',
        modifier: '<='
      },
      {
        key: 'more than',
        modifier: '>'
      },
      {
        key: 'greater than',
        modifier: '>'
      },
      {
        key: 'less than',
        modifier: '<'
      },
      {
        key: 'equal',
        modifier: '=='
      },
      {
        key: 'equal to',
        modifier: '=='
      }
    ];

    for(var i = 0; i < modifiers.length; i++) {
      var item = modifiers[i];
      if (message.indexOf(item.key) !== -1) {
        message = trim(message.replace(item.key, ''));
        result.modifier = item.modifier;
        result.total = message;

        return result;
      }
    }

    return {
      total: trim(message),
      modifier: '='
    };
  }

  _parseTextToUsersList(message) {
    if ( ! (message && message.length > 0)) {
      return;
    }

    message = message.replace('and', '');
    message = message.replace('or', '');

    var commaSeparated = [];
    message.split(',').map((user) => {
      if (user.indexOf(':') !== -1) {
        user = user.split(':');
      }
      commaSeparated = commaSeparated.concat(user);
    });
    commaSeparated = _.compact(commaSeparated.map((user) => {
      return user.replace(/ /g, '')
    })).filter(user => {
      return user !== ','
    });

    var spaceSeparated = [];
    message.split(' ').map((user) => {
      if (user.indexOf(':') !== -1) {
        user = user.split(':');
      }
      spaceSeparated = spaceSeparated.concat(user);
    });
    spaceSeparated = _.compact(spaceSeparated.map((user) => {
      return user.replace(/ /g, '')
    })).filter(user => {
      return user !== ','
    });

    return commaSeparated.length >= spaceSeparated.length ? commaSeparated : spaceSeparated;
  }

}

module.exports = CalendarCommandParser;