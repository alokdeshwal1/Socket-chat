'use strict';

const Wit = require('node-wit');
const Config = require('./../../configs/config');

class WitAi {
  constructor() {}

  static intentActionKey() {
    return 'witAiIntentName';
  }

  static process(message) {
    return new Promise((resolve, reject) => {
      Wit.captureTextIntent(Config.witAiApiKey, message, function(err, res) {
        if (err) return reject(err);
        if (res && res.outcomes && res.outcomes.length > 0 && res.outcomes[0].intent && res.outcomes[0].confidence) {
          return resolve(res.outcomes[0]);
        }
        else {
          Logger.warn(__filename, 'Wit.Ai intent service\'s return is not recognizable', res);
          return resolve(null);
        }
      });
    });
  }
}

module.exports = WitAi;