'use strict';

const Wit = require('node-wit');
const Config = require('./../../configs/config');
const _ = require('lodash');
const trim = require('trim');
const WordsToNumber = require('words-to-num');

class EmailCommandParser {
  constructor() {}

  process(message) {
    var result = {};
    var emailSender = this._extractSender(message);
    var personReply = this._extractPersonReply(message);
    var recipients = this._extractRecipients(message);
    var subject = this._extractSubjectLine(message);
    var numberOfAttendees = this._extractNumberOfAttendees(message);

    if (emailSender) {
      result.emailSender = emailSender;
    }
    if (recipients) {
      result.recipients = recipients;
    }
    if (personReply) {
      result.personReply = personReply;
    }
    if (subject) {
      result.subject = subject;
    }
    if (numberOfAttendees) {
      result.numberOfAttendees = numberOfAttendees;
    }


    return Promise.resolve(result);
  }

  _extractSender(message) {
    var regExps = [
      /\s*emails?(?:that| )* @?([a-zA-Z0-9.\-_]*) (?:started|start|starts)\s*/ig,
      /\s*threads?(?:that| )* @?([a-zA-Z0-9.\-_]*) (?:started|start|starts)\s*/ig
    ];

    var result = this._runRegExec(regExps, message);
    if (result && Array.isArray(result) && result[0]) {
      return this._parseTextToUsersList(result[0]);
    }
    return result;
  }

  _extractPersonReply(message) {
    var regExps = [
      /\s*emails?(?:that| )* @?([a-zA-Z0-9.\-_]*) (?:reply|replied)\s*/ig,
      /\s*threads?(?:that| )* @?([a-zA-Z0-9.\-_]*) (?:reply|replied)\s*/ig
    ];

    var result = this._runRegExec(regExps, message);
    if (result && Array.isArray(result) && result[0]) {
      return this._parseTextToUsersList(result[0]);
    }
    return result;
  }

  _extractRecipients(message) {
    var regExps = [
      /* /\s*sen(?:d|t)(?:to| )* @?([a-zA-Z0-9.\-_, ]*)\s?^(?:person|people|persons)\s?/ig */
      /\s*sen(?:d|t)(?:to| )* @?([a-zA-Z0-9.\-_, ]*)\s?/ig
    ];

    var result = this._runRegExec(regExps, message);
    if (result && Array.isArray(result) && result[0]) {
      // for time being, let's do this hackish way.
      // extract recipient regExp also extract expression, such as "send to more than 5 people"
      var dirtyMatch = result[0].match(/(people|person)/ig);
      if (dirtyMatch && dirtyMatch.length > 0) {
        return;
      }
      return this._parseTextToUsersList(result[0]);
    }
    return result;
  }

  _extractSubjectLine(message) {
    var regExps = [
      /\s*subject?(?:line| )* ([a-zA-Z0-9:\-_ ]*)\s*/ig
    ];

    return this._runRegExec(regExps, message);
  }

  _extractNumberOfAttendees(message) {
    var regExps = [
      /\s*sen(?:d|t)?(?:to| )* ([a-zA-Z0-9:\-_ ]*) (?:people|person|persons)\s*/ig
    ];

    var result = this._runRegExec(regExps, message);
    if (result && Array.isArray(result) && result[0]) {
      var output = this._parseNumberExpression(result[0]);
      output.total = WordsToNumber.convert(output.total);
      if ( ! output.total) {
        return;
      }
      return output;
    }
    return result;
  }

  _runRegExec(regExps, message) {
    var matches = [];
    regExps.forEach(reg => {
      matches.push(reg.exec(message));
    });

    if (_.compact(matches).length < 1) {
      return null;
    }

    for(var i = 0; i < matches.length; i++) {
      var match = matches[i];
      if (match && match[1]) {
        return [match[1]];
      }
    }

    return null;
  }

  _parseNumberExpression(message) {
    if ( ! (message && message.length > 0)) {
      return;
    }

    var result = {};
    var modifiers = [
      {
        key: 'more than or equal',
        modifier: '>='
      },
      {
        key: 'less than or equal',
        modifier: '<='
      },
      {
        key: 'more than',
        modifier: '>'
      },
      {
        key: 'greater than',
        modifier: '>'
      },
      {
        key: 'less than',
        modifier: '<'
      },
      {
        key: 'equal',
        modifier: '='
      },
      {
        key: 'equal to',
        modifier: '='
      }
    ];

    for(var i = 0; i < modifiers.length; i++) {
      var item = modifiers[i];
      if (message.indexOf(item.key) !== -1) {
        message = trim(message.replace(item.key, ''));
        result.modifier = item.modifier;
        result.total = message;

        return result;
      }
    }

    return {
      total: trim(message),
      modifier: '='
    };
  }

  _parseTextToUsersList(message) {
    if ( ! (message && message.length > 0)) {
      return;
    }

    message = message.replace('and', '');
    message = message.replace('or', '');

    var commaSeparated = [];
    message.split(',').map((user) => {
      if (user.indexOf(':') !== -1) {
        user = user.split(':');
      }
      commaSeparated = commaSeparated.concat(user);
    });
    commaSeparated = _.compact(commaSeparated.map((user) => {
      return user.replace(/ /g, '')
    }));

    var spaceSeparated = [];
    message.split(' ').map((user) => {
      if (user.indexOf(':') !== -1) {
        user = user.split(':');
      }
      spaceSeparated = spaceSeparated.concat(user);
    });
    spaceSeparated = _.compact(spaceSeparated.map((user) => {
      return user.replace(/ /g, '')
    }));

    return commaSeparated.length >= spaceSeparated.length ? commaSeparated : spaceSeparated;
  }

}

module.exports = EmailCommandParser;