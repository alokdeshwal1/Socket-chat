'use strict';

const assert = require('assert');
const ModelUser = require('./../../models/user');
const ModelFunction = require('./../../models/function');
const ModelUserGoal = require('./../../models/user-goal');
const Co = require('co');
const Logger = require('./../../libs/logger');
const jackrabbit = require('jackrabbit');
const CONSTANTS = require('./../../constants/constants');
const Config = require('./../../configs/config');

class PersistGatherGoal {

  constructor() {
    this.modelChanges = [];
  }

  run(context, task) {
    return new Promise((resolve, reject) => {
      Co(function *() {
        try {
          yield this.saveToDb(context);
          yield this.afterSave(context, task);

          return resolve(true);
        }
        catch(ex) {
          Logger.error({ex, exStack: ex.stack, task, context}, 'Failed to persist data for PersistGatherGoal');
          return reject(ex);
        }
      }.bind(this));
    });
  }

  rollback() {
    return new Promise((resolve, reject) => {
      Co(function *() {
        try {
          for(let item of this.modelChanges) {
            yield ModelUserGoal.remove({ _id: item.id });
          }
          return resolve(true);
        }
        catch (ex) {
          Logger.error('Failed to rollback', ex, ex.stack);
          return resolve(false);
        }
      }.bind(this));
    });
  }

  saveToDb(context) {
    assert(typeof context.slackUserId === 'string', 'Context slackUserId (String) is required');
    assert(typeof context.goalCompetency === 'object' || typeof context.goalCompetency === 'string',
      'Context goalCompetency (Object|String) is required');
    assert(Array.isArray(context.advisors), 'Context advisors (Array) is required');

    return new Promise((resolve, reject) => {
      Co(function *() {
        try {
          if(! (context.user && context.user instanceof ModelUser)) {
            context.user = yield ModelUser.findBySlackId(context.slackUserId);
          }

          if(! context.user) {
            return reject('User is not found with slackUserId: ' + context.slackUserId);
          }

          var userGoal = new ModelUserGoal();
          userGoal.user = context.user.id;
          if(typeof context.goalCompetency === 'object') {
            userGoal.goal = context.goalCompetency._id;
          }
          else {
            userGoal.name = context.goalCompetency;
          }
          if(context.advisors && Array.isArray(context.advisors)) {
            userGoal.advisors = context.advisors;
          }
          userGoal.status = CONSTANTS.DB.STATUS.ACTIVE;

          context.userGoal = yield userGoal.save();
          context.userGoals = context.userGoals || [];
          context.userGoals.push(context.userGoal);

          this.modelChanges.push({
            id: context.userGoal.id,
            model: 'UserGoal',
            type: 'delete'
          });

          return resolve(true);
        }
        catch(ex) {
          Logger.error({ex, exStack: ex.stack, context}, 'Failed to persist data for PersistGatherGoal');
          return reject(ex);
        }
      }.bind(this));
    });
  }

  afterSave(context, task) {
    var theTask;
    switch(context.trigger.systemKey) {
      case 'Google Calendar Integration':
        theTask = require('./../tasks/feedback/gather-google-calendar-authentication');
        break;

      case 'Google Gmail Integration':
        theTask = require('./../tasks/feedback/gather-gmail-authentication');
        break;

      case 'Regular Time Interval':
        theTask = require('./../tasks/feedback/gather-manual-trigger');
        break;
    }

    task.chainTask(theTask, context);
    return Promise.resolve(true);
  }
}

module.exports = PersistGatherGoal;