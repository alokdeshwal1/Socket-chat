const fs = require('fs');
const path = require('path');
const Persist = {};

fs.readdirSync(path.join(__dirname)).forEach(function(file) {
  var klass = require('./'+ file);
  Persist[klass.name] = klass;
});

module.exports = Persist;