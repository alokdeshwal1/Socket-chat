'use strict';

const assert = require('assert');
const ModelUser = require('./../../models/user');
const ModelFunction = require('./../../models/function');
const ModelUserGoal = require('./../../models/user-goal');
const ModelTrigger = require('./../../models/trigger');
const ModelUserTrigger = require('./../../models/user-trigger');
const RecurrenceValidation = require('./../validations/recurrence-date');
const Co = require('co');
const Logger = require('./../../libs/logger');
const jackrabbit = require('jackrabbit');
const CONSTANTS = require('./../../constants/constants');
const Config = require('./../../configs/config');
const moment = require('moment');
const Helper = require('./../libs/helper');
const Join = require('join-component');
const _ = require('lodash');

class PersistGatherGeneralGoal {

  constructor() {
    this.modelChanges = [];
  }

  run(context, task) {
    return new Promise((resolve, reject) => {
      Co(function *() {
        try {
          yield this.saveToDb(context, task);
          yield this.afterSave(context, task);

          return resolve(true);
        }
        catch(ex) {
          Logger.error({ex, exStack: ex.stack, context, task}, 'Failed to persist data for PersistGatherGeneralGoal');
          return reject(ex);
        }
      }.bind(this));
    });
  }

  rollback() {
    return new Promise((resolve) => {
      Co(function *() {
        try {
          for(let item of this.modelChanges) {
            switch (item.model) {
              case 'UserGoal' :
                yield ModelUserGoal.remove({ _id: item.id });
                break;

              case 'UserTrigger':
                yield ModelUserTrigger.remove({ _id: item.id });
                break;
            }
          }
          return resolve(true);
        }
        catch (ex) {
          Logger.error('Failed to rollback', ex, ex.stack);
          return resolve(false);
        }
      }.bind(this));
    });
  }

  saveToDb(context, task) {
    assert(typeof context.slackUserId === 'string', 'Context slackUserId (String) is required');
    assert(Array.isArray(context.advisors), 'Context advisors (Array) is required');

    return new Promise((resolve, reject) => {
      Co(function *() {
        try {
          if(! (context.user && context.user instanceof ModelUser)) {
            context.user = yield ModelUser.findBySlackId(context.slackUserId);
          }

          if(! context.user) {
            return reject('User is not found with slackUserId: ' + context.slackUserId);
          }

          var existingGeneralGoal;
          var existingUserTrigger;
          if (context.isFtueFlow === true) {
            existingGeneralGoal = yield ModelUserGoal.findOne({
              user: context.user.id,
              status: CONSTANTS.DB.STATUS.ACTIVE,
              isGeneral: true
            });

            if (existingGeneralGoal) {
              existingUserTrigger = yield ModelUserTrigger.findOne({
                userGoal: existingGeneralGoal.id,
                status: CONSTANTS.DB.STATUS.ACTIVE
              });
            }
          }

          var userGoal =  existingGeneralGoal || new ModelUserGoal();
          userGoal.isGeneral = true;
          userGoal.user = context.user.id;
          if(context.advisors && Array.isArray(context.advisors)) {
            var currentAdvisors = _.map(userGoal.advisors , (item) => { return item.toString() }) || [];
            var newAdvisors = _.filter(context.advisors, (item) => { return currentAdvisors.indexOf(item.id) === -1 });
            newAdvisors.forEach((item) => {
              userGoal.advisors = userGoal.advisors || [];
              userGoal.advisors.push(item);
            });
            context.newAdvisors = newAdvisors;
          }
          userGoal.status = CONSTANTS.DB.STATUS.ACTIVE;
          context.userGoal = yield userGoal.save();

          // create the trigger for general goal
          var userTrigger = existingUserTrigger || new ModelUserTrigger();
          var validation = new RecurrenceValidation(context.user.timezone);
          var triggerWeekday = moment().tz(context.user.timezone).add(1, 'day').format('dddd');
          if (triggerWeekday === 'Saturday' || triggerWeekday === 'Sunday') {
            triggerWeekday = 'Monday';
          }
          var frequencyString = 'Every other '+ triggerWeekday +' at 10AM';
          var validationOutput = yield validation.validate(frequencyString);
          context.frequencyString = frequencyString;

          const trigger = yield ModelTrigger.findOne({ systemKey: CONSTANTS.DB.TRIGGER.MANUAL });
          userTrigger.trigger = trigger.id;
          userTrigger.userGoal = context.userGoal.id;
          userTrigger.user = context.user.id;
          userTrigger.frequencyCron = validationOutput.result.expression;
          if (validationOutput.result.modifier) {
            userTrigger.frequencyCronModifier = validationOutput.result.modifier;
          }
          if (validationOutput.result.startDate) {
            userTrigger.frequencyStartDate = validationOutput.result.startDate;
          }
          userTrigger.frequencyUserText = validationOutput.result.userText;
          userTrigger.status = CONSTANTS.DB.STATUS.ACTIVE;
          context.userTrigger = yield userTrigger.save();

          this.modelChanges.push({
            id: context.userGoal.id,
            model: 'UserGoal',
            type: 'delete'
          });
          this.modelChanges.push({
            id: context.userTrigger.id,
            model: 'UserTrigger',
            type: 'delete'
          });

          return resolve(true);
        }
        catch(ex) {
          Logger.error({ ex, exStack: ex.stack, context }, 'Failed to persist data for PersistGatherGeneralGoal');
          return reject(ex);
        }
      }.bind(this));
    });
  }

  afterSave(context, task) {
    // add job to scheduler
    task.emit(CONSTANTS.BOT_EVENT.QUEUE_JOB, {
      queueName: CONSTANTS.JOB_QUEUE.CRON_SCHEDULER,
      job: {
        type: CONSTANTS.SCHEDULER_JOB_TYPE.ADD,
        triggerId: context.userTrigger.id
      }
    });

    // alert advisors
    for(let advisor of context.newAdvisors) {
      // do not fire notification to manager
      if (context.user.manager && context.user.manager.id === advisor.id) {
        continue;
      }

      task.emit(CONSTANTS.BOT_EVENT.TASK, {
        slackUserId: advisor.slackUserId,
        context: {
          userFirstName: advisor.firstName,
          employeeFirstName: context.user.firstName,
          frequencyString: context.frequencyString.charAt(0).toLowerCase() + context.frequencyString.substring(1)
        },
        task: require('./../tasks/feedback/notify-advisor-employee-general-goal')
      });
    }

    return Promise.resolve(true);
  }
}

module.exports = PersistGatherGeneralGoal;