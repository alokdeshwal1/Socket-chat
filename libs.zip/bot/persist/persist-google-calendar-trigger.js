'use strict';

const assert = require('assert');
const ModelUser = require('./../../models/user');
const ModelFunction = require('./../../models/function');
const ModelUserTrigger = require('./../../models/user-trigger');
const ModelUserTriggerGoogleCalendar = require('./../../models/user-trigger-google-calendar');
const ModelGooglePushNotification = require('./../../models/google-push-notification');
const Co = require('co');
const Logger = require('./../../libs/logger');
const jackrabbit = require('jackrabbit');
const CONSTANTS = require('./../../constants/constants');
const Config = require('./../../configs/config');
const GCalParser = require('./../../libs/google-calendar-parser');
const uuid = require('node-uuid');

class PersistGoogleCalendarTrigger {

  static run(context, task) {
    return new Promise((resolve, reject) => {
      Co(function *() {
        try {
          var modelChanges = yield saveToDb(context);
          yield afterSave(context, task);

          return resolve(modelChanges);
        }
        catch(ex) {
          Logger.error(__filename, 'Failed to persist data for PersistGoogleCalendarTrigger', ex, ex.stack);
          return reject(ex);
        }
      }.bind(this));
    });
  }
}

function saveToDb(context) {
  assert(typeof context.slackUserId === 'string', 'Context slackUserId (String) is required');
  assert(typeof context.userGoal === 'object', 'Context userGoal (Object) is required');
  assert(typeof context.trigger === 'object', 'Context trigger (Object) is required');
  assert(typeof context.googleCalendarTrigger === 'object', 'Context googleCalendarTrigger (Object) is required');
  assert(typeof context.googleCalendarTrigger.criteria === 'object', 'Context googleCalendarTrigger.criteria (Object) is required');
  assert(typeof context.googleCalendarTrigger.text === 'string', 'Context googleCalendarTrigger.text (String) is required');
  context.googleCalendarTrigger.events && assert(Array.isArray(context.googleCalendarTrigger.events), 'Context googleCalendarTrigger.events must be an array');

  return new Promise((resolve, reject) => {
    Co(function *() {
      try {
        if ( ! (context.user && context.user instanceof ModelUser)) {
          context.user = yield ModelUser.findBySlackId(context.slackUserId.toString());
        }
        if ( ! context.user) {
          return reject('User is not found with slackUserId: '+ context.slackUserId);
        }

        const modelChanges = [];
        var userTriggerGCal = new ModelUserTriggerGoogleCalendar();
        userTriggerGCal.trigger = context.trigger._id;
        userTriggerGCal.userGoal = context.userGoal._id;
        userTriggerGCal.user = context.user.id;
        userTriggerGCal.criteria = context.googleCalendarTrigger.criteria;
        userTriggerGCal.userCriteriaText = context.googleCalendarTrigger.text;
        userTriggerGCal.status = CONSTANTS.DB.STATUS.ACTIVE;

        context.userTriggerGCal = yield userTriggerGCal.save();
        context.userTriggerGCals = context.userTriggerGCals || [];
        context.userTriggerGCals.push(context.userTriggerGCal);
        modelChanges.push(context.userTriggerGCal);

        // save Google Watch push notification
        var currentRecord = yield ModelGooglePushNotification.findOne({
          user: context.user.id,
          resourceUri: Config.google.calendar.resourceUrl
        });
        if ( ! currentRecord) {
          var parser = new GCalParser(context.googleOauthToken);
          var uniqueId = uuid.v1();
          var watchResult = yield parser.saveWatch(uniqueId, context.user.id);
          if (watchResult && watchResult.resourceUri) {
            yield ModelGooglePushNotification.upsert({
              user: context.user.id,
              resourceUri: Config.google.calendar.resourceUrl
            }, {
              uuid: uniqueId,
              user: context.user.id,
              watchInfo: watchResult,
              resourceUri: Config.google.calendar.resourceUrl,
              watchTriggerUri: Config.google.calendar.watchUrl,
              status: CONSTANTS.DB.STATUS.ACTIVE
            });
          }
        }

        // save the current event matches
        if (context.googleCalendarTrigger.events && Array.isArray(context.googleCalendarTrigger.events)) {
          for(var i = 0; i < context.googleCalendarTrigger.events.length; i++) {
            var event = context.googleCalendarTrigger.events[i];
            var userTrigger = new ModelUserTrigger();
            userTrigger.trigger = context.trigger._id;
            userTrigger.userGoal = context.userGoal._id;
            userTrigger.user = context.user.id;
            if (event.recurrence) {
              userTrigger.rrule = {
                start: event.start,
                rules: event.recurrence,
                end: event.end
              };
            }
            userTrigger.userTriggerGoogleCalendar = context.userTriggerGCal.id;
            userTrigger.googleCalendarObject = event;
            userTrigger.status = CONSTANTS.DB.STATUS.ACTIVE;

            var trigger = yield userTrigger.save();
            context.userTriggers = context.userTriggers || [];
            context.userTriggers.push(trigger);
            modelChanges.push(trigger);

          }
        }

        return resolve(modelChanges);
      }
      catch(ex) {
        Logger.error(__filename, 'Failed to persist data for PersistGoogleCalendarTrigger', ex, ex.stack);
        return reject(ex);
      }
    }.bind(this));
  });
}

function afterSave(context, task) {
  // add job to scheduler
  if (context.userTriggers && Array.isArray(context.userTriggers)) {
    context.userTriggers.forEach(item => {
      task.emit(CONSTANTS.BOT_EVENT.QUEUE_JOB, {
        queueName: CONSTANTS.JOB_QUEUE.CRON_SCHEDULER,
        job: {
          type: CONSTANTS.SCHEDULER_JOB_TYPE.ADD,
          triggerId: item.id
        }
      });
    });
  }

  //delete context.userTriggers;
  //delete context.trigger;
  //delete context.userTriggerGCal;

  // append task to ask for another trigger
  task.chainTask(require('./../tasks/feedback/gather-trigger-type-repeat'), context);
  return Promise.resolve(true);
}

module.exports = PersistGoogleCalendarTrigger;