'use strict';

const assert = require('assert');
const ModelUser = require('./../../models/user');
const ModelFunction = require('./../../models/function');
const ModelUserGoal = require('./../../models/user-goal');
const Co = require('co');
const Logger = require('./../../libs/logger');
const jackrabbit = require('jackrabbit');
const CONSTANTS = require('./../../constants/constants');
const Config = require('./../../configs/config');
const CommandSummary = require('./../../bot/commands/summary');

class PersistSummaryReport {

  static run(context, task) {
    assert(context.slackUserId, 'slackUserId (String) is required');
    assert(context.userCommandText, 'userCommandText (String) is required');

    return new Promise((resolve, reject) => {
      Co(function *() {
        try {
          // reparse user's text so that startDate and endDate are in the right timezone context
          // the reason why we do this here is because we dont have user's info in the command scope
          const user = yield ModelUser.findBySlackId(context.slackUserId);
          if (user.timezone && user.timezone.length > 0) {
            var intent = (new CommandSummary(user.timezone)).parse(context.userCommandText);
            context = Object.assign(context, intent.context, {
              modules: task.bot.modules
            });
          }
          else {
            Logger.error('User has not timezone information. We cannot accurately generating a summary report', user);
          }

          if (task.bot.modules[CONSTANTS.MODULES.OKR]) {
            task.emit(CONSTANTS.BOT_EVENT.QUEUE_JOB, {
              queueName: CONSTANTS.JOB_QUEUE.SUMMARY_OKR_REPORT,
              job: context
            });
          }
          else {
            task.emit(CONSTANTS.BOT_EVENT.QUEUE_JOB, {
              queueName: CONSTANTS.JOB_QUEUE.SUMMARY_REPORT,
              job: context
            });
          }

          return resolve(true);
        }
        catch(ex) {
          Logger.error(__filename, 'Failed to persist data for PersistSummaryReport', ex, ex.stack);
          return reject(ex);
        }
      }.bind(this));
    });
  }
}

module.exports = PersistSummaryReport;