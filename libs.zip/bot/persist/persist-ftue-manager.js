'use strict';

const assert = require('assert');
const ModelUser = require('./../../models/user');
const ModelSlackIntegration = require('./../../models/slack-integration');
const Co = require('co');
const Logger = require('./../../libs/logger');
const jackrabbit = require('jackrabbit');
const CONSTANTS = require('./../../constants/constants');
const Config = require('./../../configs/config');
const Helper = require('./../libs/helper');
const Join = require('join-component');

class PersistFtueManager {

  static run(context, task) {
    assert(typeof context.slackUserId === 'string', 'Context slackUserId (String) is required');
    assert(Array.isArray(context.directs), 'Context directs (Array) is required');

    return new Promise((resolve, reject) => {
      Co(function *() {
        try {
          if (! (context.user && context.user instanceof ModelUser)) {
            context.user = yield ModelUser.findBySlackId(context.slackUserId);
          }

          const manager = context.user;
          const modelChanges = [];

          if ( ! manager) {
            return reject('Manager is not found with slackUserId: '+ context.slackUserId);
          }

          // update manager's signed up status
          manager.isSignedUpOnBot = true;
          modelChanges.push(yield manager.save());

          const directNeedConfirmation = [];
          const directAdded = [];
          for(let direct of context.directs) {

            // direct already in your team;
            if (direct.manager && direct.manager.id === manager.id) {
              task.emit(CONSTANTS.BOT_EVENT.MESSAGE, Helper.replaceMessagePlaceholder(
                'Looks like [[employeeFirstName]] has already signed up. Type `summary for [[employeeSlackUserName]]` to see a summary.', {
                  employeeFirstName: direct.firstName,
                  employeeSlackUserName: direct.slackUserName
                }));

              continue;
            }

            // direct already has manager
            if (direct.manager && direct.manager.id.length > 0) {
              // direct already has manager, trigger confirmation task
              task.emit(CONSTANTS.BOT_EVENT.TASK, {
                slackUserId: direct.slackUserId,
                context: {
                  slackUserId: direct.slackUserId,
                  userFirstName: direct.firstName,
                  employeeFirstName: direct.firstName,
                  managerFirstName: manager.firstName,
                  managerSlackUserId: manager.slackUserId,
                  managerUserId: manager.id,
                  currentManagerFirstName: direct.manager.firstName,
                  appName: Config.appName,
                  companyName: manager.company.name, // it is safe to assume that
                  companyId: manager.company.id
                },
                task: require('./../tasks/feedback/confirm-manager')
              });

              directNeedConfirmation.push(direct.firstName);
            }
            else {
              direct.manager = manager.id;
              modelChanges.push(yield direct.save());
              directAdded.push(direct.firstName);

              var slackIntegrationId =  (direct.slackIntegration instanceof ModelSlackIntegration) ?
                direct.slackIntegration.id :
                direct.slackIntegration.toString();

              try {
                // schedule jobs for the directs to set up goals
                task.emit(CONSTANTS.BOT_EVENT.TASK, {
                  slackUserId: direct.slackUserId,
                  context: {
                    userFirstName: direct.firstName,
                    managerFirstName: manager.firstName,
                    slackUserId: direct.slackUserId,
                    appName: Config.appName,
                    companyName: manager.company.name, // it is safe to assume that
                    companyId: manager.company.id,
                    slackIntegrationId: slackIntegrationId
                  },
                  task: require('./../tasks/feedback/ftue-employee')
                });
              }
              catch (ex) {
                Logger.error({
                  ex: ex,
                  exStack: ex.stack
                }, 'Failed to schedue task for new direct to set up goal');
              }
            }
          }

          if (directNeedConfirmation.length > 0) {
            task.emit(CONSTANTS.BOT_EVENT.MESSAGE, Helper.replaceMessagePlaceholder(
              'Ok! Just sent [[employeeFirstName]] a quick message to confirm', {
                employeeFirstName: Join(directNeedConfirmation, ', and')
              }));
          }

          if (directAdded.length > 0) {
            task.emit(CONSTANTS.BOT_EVENT.MESSAGE, 'Great, thanks! :+1: I\'m going to now ping them and get them set up with their goals. Once they\'re done ' +
              'I\'ll let you know and we\'ll start pinging you for quick feedback.');

          }
          task.emit(CONSTANTS.BOT_EVENT.MESSAGE, 'Now try typing `help`!');

          return resolve(modelChanges);
        }
        catch (ex) {
          Logger.error('Failed to persist data for PersistFtueManager', ex, ex.stack);
          return reject(ex);
        }
      }.bind(this));
    });
  }
}

module.exports = PersistFtueManager;