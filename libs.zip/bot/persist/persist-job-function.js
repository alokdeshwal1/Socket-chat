'use strict';

const assert = require('assert');
const ModelUser = require('./../../models/user');
const ModelFunction = require('./../../models/function');
const Co = require('co');
const Logger = require('./../../libs/logger');
const jackrabbit = require('jackrabbit');
const CONSTANTS = require('./../../constants/constants');
const Config = require('./../../configs/config');
const _ = require('lodash');

class PersistJobFunction {

  constructor() {
    this.modelChanges = [];
  }

  run(context, task) {
    assert(typeof context.slackUserId === 'string', 'Context slackUserId (String) is required');
    assert(typeof context['function'] === 'object' || typeof context['function'] === 'string', 'Context function (Object|String:"Other") is required');

    return new Promise((resolve, reject) => {
      Co(function *() {
        try {
          yield this.saveToDb.bind(this)(context);
          yield this.afterSave.bind(this)(context, task);

          return resolve(true);
        }
        catch(ex) {
          Logger.error(__filename, 'Failed to persist data for PersistJobFunction', ex, ex.stack);
          return reject(ex);
        }
      }.bind(this));
    });
  }

  rollback() {
    return new Promise((resolve, reject) => {
      Co(function *() {
        try {
          for(let item of this.modelChanges) {
            yield ModelUser.update({ _id: item.id }, item.changes);
          }
          return resolve(true);
        }
        catch (ex) {
          Logger.error('Failed to rollback', ex, ex.stack);
          return resolve(false);
        }
      }.bind(this));
    });
  }

  saveToDb(context) {
    assert(typeof context.slackUserId === 'string', 'Context slackUserId (String) is required');
    assert(typeof context['function'] === 'object' || typeof context['function'] === 'string', 'Context function (Object|String:"Other") is required');

    return new Promise((resolve, reject) => {
      Co(function *() {
        try {
          const user = yield ModelUser.findOne({ slackUserId: context.slackUserId.toString() }).populate('company, jobFunction');
          if ( ! user) {
            return reject('User is not found with slackUserId: '+ context.slackUserId);
          }

          if(context['function'] === 'Other') {
            context['function'] = yield ModelFunction.findOne({ name: 'Other', company: null });
          }

          var existingJobFunctions = user.jobFunction.map(item => {
            return item.name;
          });

          this.modelChanges.push({
            'id': user.id,
            'model': 'ModelUser',
            'changes': {
              'jobFunction': _.cloneDeep(user.jobFunction)
            }
          });
          if (existingJobFunctions.indexOf(context['function'].name) === -1) {
            user.jobFunction.push(context['function']._id);
          }

          yield user.save();
          return resolve(true);
        }
        catch(ex) {
          Logger.error(__filename, 'Failed to persist data for PersistFtueManager', ex, ex.stack);
          return reject(ex);
        }
      }.bind(this));
    });
  }

  afterSave(context, task) {
    task.chainTask(require('./../tasks/feedback/gather-goal'), context);
    return Promise.resolve(true);
  }
}


module.exports = PersistJobFunction;