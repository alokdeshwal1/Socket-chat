'use strict';

const assert = require('assert');
const ModelUser = require('./../../models/user');
const ModelFunction = require('./../../models/function');
const ModelUserTrigger = require('./../../models/user-trigger');
const ModelFeedback = require('./../../models/feedback');
const ModelUserGoal = require('./../../models/user-goal');
const ModelGoal = require('./../../models/goal');
const Co = require('co');
const Logger = require('./../../libs/logger');
const jackrabbit = require('jackrabbit');
const CONSTANTS = require('./../../constants/constants');
const Config = require('./../../configs/config');
const Helper = require('./../libs/helper');

class PersistGatherGeneralFeedback {

  static run(context, task) {
    return new Promise((resolve, reject) => {
      Co(function *() {
        try {
          var result = yield saveToDb(context);
          if (result === true) {
            yield afterSave(context, task);
          }
          return resolve(true);
        }
        catch(ex) {
          Logger.error(__filename, 'Failed to persist data for PersistGatherGeneralFeedback', ex, ex.stack);
          return reject(ex);
        }
      }.bind(this));
    });
  }
}

function saveToDb(context) {
  assert(typeof context.slackUserId === 'string', 'Context slackUserId (String) is required');
  assert(typeof context.advisor === 'object', 'Context advisor (Object) is required');
  assert(typeof context.userGoal === 'object', 'Context userGoal (Object) is required');
  assert(typeof context.feedbackRating === 'number', 'Context feedbackRating (Number) is required');
  assert(typeof context.targetUser === 'object', 'Context targetUser (Object) is required');
  context.feedbackComment && assert(typeof context.feedbackComment === 'string', 'Context feedbackComment (String) is required');
  context.feedbackEmoji && assert(typeof context.feedbackEmoji === 'string', 'Context feedbackEmoji (String) is required');

  return new Promise((resolve, reject) => {
    Co(function *() {
      try {
        var feedback = new ModelFeedback();
        feedback.advisor = context.advisor.id || context.advisor._id;
        feedback.user = context.targetUser.id || context.targetUser._id;
        feedback.userGoal = context.userGoal.id || context.userGoal._id;
        feedback.feedbackRating = context.feedbackRating;
        if (context.feedbackComment) {
          feedback.feedbackComment = context.feedbackComment;
        }
        if (context.feedbackEmoji) {
          feedback.feedbackEmoji = context.feedbackEmoji;
        }
        feedback.status = CONSTANTS.DB.STATUS.ACTIVE;

        context.feedback = yield feedback.save();
        context.userManager = yield ModelUser.findOne({ _id: context.targetUser.manager });
        if (context.userGoal && context.userGoal.goal && typeof context.userGoal.goal === 'string') {
          context.userGoal.goal = yield ModelGoal.findOne({ _id: context.userGoal.goal });
        }
        return resolve(true);
      }
      catch(ex) {
        Logger.error('Failed to persist data for PersistGatherGeneralFeedback', ex, ex.stack);
        return resolve(false);
      }
    }.bind(this));
  });
}

function afterSave(context, task) {
  assert(typeof context.targetUser === 'object', 'Context user (Object) is required');
  assert(typeof context.advisor === 'object', 'Context advisor (Object) is required');
  context.userManager && assert(typeof context.userManager === 'object', 'Context userManager (Object) is not valid');

  context.targetUserGoalName = context.userGoal.goal && context.userGoal.goal.name || context.userGoal.name;

  // Notify manager
  // if feedback rating is advisor is not manager
  // and feedback Rating is 1, 2 or 5
  var advisorId = context.advisor.id || context.advisor._id;
  if (context.userManager && (context.userManager.id !== advisorId) &&
    (Number(context.feedbackRating) <= 2 || context.feedbackRating == 5)) {

    task.emit(CONSTANTS.BOT_EVENT.TASK, {
      slackUserId: context.userManager.slackUserId,
      context: {
        managerFirstName: context.userManager.firstName,
        employeeFirstName: context.targetUser.firstName,
        advisorFirstName: context.advisor.firstName,
        targetUserGoalName: context.targetUserGoalName,
        userFeedback: JSON.stringify(Helper.buildGeneralFeedbackMessage(context.feedbackEmoji, context.feedbackComment))
      },
      task: require('./../tasks/feedback/notify-manager-employee-feedback.js')
    });
  }

  // Notify employee
  task.emit(CONSTANTS.BOT_EVENT.TASK, {
    slackUserId: context.targetUser.slackUserId,
    context: {
      userFirstName: context.targetUser.firstName,
      advisorFirstName: context.advisor.firstName,
      targetUserGoalName: context.targetUserGoalName,
      userFeedback: JSON.stringify(Helper.buildGeneralFeedbackMessage(context.feedbackEmoji, context.feedbackComment))
    },
    task: require('./../tasks/feedback/notify-user-feedback.js')
  });

  return Promise.resolve(true);
}

module.exports = PersistGatherGeneralFeedback;