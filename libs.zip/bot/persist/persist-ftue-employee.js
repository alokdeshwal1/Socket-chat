'use strict';

const assert = require('assert');
const ModelUser = require('./../../models/user');
const ModelFunction = require('./../../models/function');
const Co = require('co');
const Logger = require('./../../libs/logger');
const jackrabbit = require('jackrabbit');
const CONSTANTS = require('./../../constants/constants');
const Config = require('./../../configs/config');

class PersistFtueEmployee {

  static run(context, task) {
    assert(typeof context.slackUserId === 'string', 'Context slackUserId (String) is required');

    return new Promise((resolve, reject) => {
      Co(function *() {
        try {
          var modelChanges = yield saveToDb(context);
          yield afterSave(context, task);
          return resolve(modelChanges);
        }
        catch(ex) {
          Logger.error({
            ex: ex,
            exStack: ex.stack,
            context: context,
            task: task
          }, 'Failed to persist data for PersistFtueEmployee');

          return reject(ex);
        }
      }.bind(this));
    });
  }
}

function saveToDb(context) {
  assert(typeof context.slackUserId === 'string', 'Context slackUserId (String) is required');

  return new Promise((resolve, reject) => {
    Co(function *() {
      try {
        if ( ! (context.user && context.user instanceof ModelUser)) {
          context.user = yield ModelUser.findBySlackId(context.slackUserId);
        }

        if ( ! context.user) {
          return reject('User is not found with slackUserId: '+ context.slackUserId);
        }
        
        context.user.isSignedUpOnBot = true;
        var userModel = yield context.user.save();

        return resolve(userModel);
      }
      catch(ex) {
        Logger.error({
          ex: ex,
          exStack: ex.stack,
          context: context
        }, 'Failed to persist data for PersistFtueEmployee');

        return reject(ex);
      }
    }.bind(this));
  });
}

function afterSave(context, task) {
  task.chainTask(require('./../tasks/feedback/gather-general-goal'), context);
  return Promise.resolve(true);
}

module.exports = PersistFtueEmployee;