'use strict';

const assert = require('assert');
const ModelUser = require('./../../models/user');
const ModelFunction = require('./../../models/function');
const ModelOkrFeedback = require('./../../models/okr-feedback');
const ModelUserOkrGoal = require('./../../models/user-okr-goal');
const ModelOkrGoal = require('./../../models/okr-goal');
const Co = require('co');
const Logger = require('./../../libs/logger');
const jackrabbit = require('jackrabbit');
const CONSTANTS = require('./../../constants/constants');
const Config = require('./../../configs/config');
const Helper = require('./../libs/helper');

class PersistGatherOkrFeedback {

  static run(context, task) {
    return new Promise((resolve, reject) => {
      Co(function *() {
        try {
          var result = yield saveToDb(context);
          if (result === true) {
            yield afterSave(context, task);
          }
          return resolve(true);
        }
        catch(ex) {
          Logger.error(__filename, 'Failed to persist data for PersistGatherFeedback', ex, ex.stack);
          return resolve(false);
        }
      }.bind(this));
    });
  }
}

function saveToDb(context) {
  assert(typeof context.slackUserId === 'string', 'Context slackUserId (String) is required');
  assert(typeof context.advisorId === 'string', 'Context advisorId (String) is required');
  assert(typeof context.userOkrGoalId === 'string', 'Context userOkrGoalId (String) is required');
  assert(typeof context.feedbackRating === 'number', 'Context feedbackRating (Number) is required');
  assert(typeof context.targetUserId === 'string', 'Context targetUserId (String) is required');
  context.feedbackComment && assert(typeof context.feedbackComment === 'string', 'Context feedbackComment (String) is required');
  context.feedbackEmoji && assert(typeof context.feedbackEmoji === 'string', 'Context feedbackEmoji (String) is required');

  return new Promise((resolve, reject) => {
    Co(function *() {
      try {
        var feedback = new ModelOkrFeedback();
        feedback.advisor = context.advisorId;
        feedback.user = context.targetUserId;
        feedback.userOkrGoal = context.userOkrGoalId;
        feedback.isSelfAssessment = (feedback.advisor.toString() === feedback.user.toString());
        feedback.feedbackRating = context.feedbackRating;
        if (context.feedbackComment) {
          feedback.feedbackComment = context.feedbackComment;
        }
        if (context.feedbackEmoji) {
          feedback.feedbackEmoji = context.feedbackEmoji;
        }
        feedback.status = CONSTANTS.DB.STATUS.ACTIVE;
        context.feedback = yield feedback.save();

        if ( ! (context.user && context.user instanceof ModelUser)) {
          context.user = yield ModelUser.findOne({ slackUserId: context.slackUserId });
        }
        if (context.user.manager) {
          context.userManager = yield ModelUser.findOneActive(context.user.manager.toString());
        }

        context.advisor = yield ModelUser.findOneActive(context.advisorId);

        return resolve(true);
      }
      catch(ex) {
        Logger.error('Failed to persist data for PersistGatherFeedback', ex, ex.stack);
        return resolve(false);
      }
    }.bind(this));
  });
}

function afterSave(context, task) {
  assert(typeof context.targetUserId === 'string', 'Context targetUserId (String) is required');
  assert(typeof context.advisorId === 'string', 'Context advisorId (String) is required');
  assert(typeof context.targetUserGoalName === 'string', 'Context targetUserGoalName (String) is required');

  // Notify manager
  // if feedback rating is advisor is not manager
  if (context.advisor && context.userManager && (context.userManager.id !== context.advisorId)) {
    task.emit(CONSTANTS.BOT_EVENT.TASK, {
      slackUserId: context.userManager.slackUserId,
      context: {
        managerFirstName: context.userManager.firstName,
        employeeFirstName: context.user.firstName,
        advisorFirstName: context.advisor.firstName,
        targetUserGoalName: context.targetUserGoalName,
        userFeedback: JSON.stringify(Helper.buildOkrFeedbackMessage(context.targetUserGoalName, context.feedbackEmoji, context.feedbackComment))
      },
      task: (context.feedback.isSelfAssessment)
              ? require('./../tasks/feedback/feedback/notify-manager-employee-self-assessment.js')
              : require('./../tasks/feedback/feedback/notify-manager-employee-okr-feedback.js')
    });
  }

  // Notify employee
  //if ( ! context.isSelfAssessment) {
  //  task.emit(CONSTANTS.BOT_EVENT.TASK, {
  //    slackUserId: context.targetUser.slackUserId,
  //    context: {
  //      userFirstName: context.targetUser.firstName,
  //      advisorFirstName: context.advisor.firstName,
  //      targetUserGoalName: context.targetUserGoalName,
  //      userFeedback: JSON.stringify(Helper.buildFeedbackMessage(context.targetUserGoalName, context.feedbackEmoji, context.feedbackComment))
  //    },
  //    task: require('./../tasks/feedback/feedback/notify-user-feedback.js')
  //  });
  //}

  return Promise.resolve(true);
}

module.exports = PersistGatherOkrFeedback;