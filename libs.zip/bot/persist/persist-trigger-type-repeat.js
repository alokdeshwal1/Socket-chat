'use strict';

const assert = require('assert');
const ModelUser = require('./../../models/user');
const ModelFunction = require('./../../models/function');
const Co = require('co');
const Logger = require('./../../libs/logger');
const jackrabbit = require('jackrabbit');
const CONSTANTS = require('./../../constants/constants');
const Config = require('./../../configs/config');

class PersistTriggerTypeRepeat {

  static run(context, task) {
    assert(typeof context.slackUserId === 'string', 'Context slackUserId (String) is required');
    assert(typeof context.trigger === 'string' || typeof context.trigger === 'object', 'Context trigger (String|Object) is required');

    return new Promise((resolve, reject) => {
      Co(function *() {
        try {
          if(context.trigger === 'no') {
            delete context.goalCategory;
            task.chainTask(require('./../tasks/feedback/gather-goal-repeat'), context);
          }
          else {
            switch(context.trigger.systemKey) {
              case 'Google Calendar Integration':
                task.chainTask(require('./../tasks/feedback/gather-google-calendar-authentication'), context);
                break;

              case 'Google Gmail Integration':
                task.chainTask(require('./../tasks/feedback/gather-gmail-authentication'), context);
                break;

              case 'Regular Time Interval':
                task.chainTask(require('./../tasks/feedback/gather-manual-trigger'), context);
                break;
            }
          }

          resolve(true);
        }
        catch(ex) {
          Logger.error(__filename, 'Failed to persist data for PersistTriggerTypeRepeat', ex, ex.stack);
          return reject(ex);
        }
      }.bind(this));
    });
  }
}

module.exports = PersistTriggerTypeRepeat;