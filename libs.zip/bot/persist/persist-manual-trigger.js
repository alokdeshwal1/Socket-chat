'use strict';

const assert = require('assert');
const ModelUser = require('./../../models/user');
const ModelFunction = require('./../../models/function');
const ModelUserTrigger = require('./../../models/user-trigger');
const Co = require('co');
const Logger = require('./../../libs/logger');
const jackrabbit = require('jackrabbit');
const CONSTANTS = require('./../../constants/constants');
const Config = require('./../../configs/config');

class PersistManualTrigger {

  static run(context, task) {
    return new Promise((resolve, reject) => {
      Co(function *() {
        try {
          var modelChanges = yield saveToDb(context);
          yield afterSave(context, task);

          return resolve(modelChanges);
        }
        catch(ex) {
          Logger.error(__filename, 'Failed to persist data for PersistManualTrigger', ex, ex.stack);
          return reject(ex);
        }
      }.bind(this));
    });
  }
}

function saveToDb(context) {
  assert(typeof context.slackUserId === 'string', 'Context slackUserId (String) is required');
  assert(typeof context.userGoal === 'object', 'Context userGoal (Object) is required');
  assert(typeof context.trigger === 'object', 'Context trigger (Object) is required');
  assert(typeof context.manualTrigger === 'object', 'Context manualTrigger (Object) is required');
  assert(typeof context.manualTrigger.expression === 'string', 'Context manualTrigger.expression (String) is required');
  assert(typeof context.manualTrigger.userText === 'string', 'Context manualTrigger.userText (String) is required');

  return new Promise((resolve, reject) => {
    Co(function *() {
      try {
        const user = yield ModelUser.findOne({ slackUserId: context.slackUserId.toString() }).populate('company, manager');
        if ( ! user) {
          return reject('User is not found with slackUserId: '+ context.slackUserId);
        }

        const modelChanges = [];
        var userTrigger = new ModelUserTrigger();
        userTrigger.trigger = context.trigger._id;
        userTrigger.userGoal = context.userGoal._id;
        userTrigger.user = user._id;
        userTrigger.frequencyCron = context.manualTrigger.expression;
        if (context.manualTrigger.modifier) {
          userTrigger.frequencyCronModifier = context.manualTrigger.modifier;
        }
        if (context.manualTrigger.startDate) {
          userTrigger.frequencyStartDate = context.manualTrigger.startDate;
        }
        userTrigger.frequencyUserText = context.manualTrigger.userText;
        userTrigger.status = CONSTANTS.DB.STATUS.ACTIVE;

        context.userTrigger = yield userTrigger.save();
        context.userTriggers = context.userTriggers || [];
        context.userTriggers.push(Object.assign(context.userTrigger));
        modelChanges.push(context.userTrigger);

        return resolve(modelChanges);
      }
      catch(ex) {
        Logger.error(__filename, 'Failed to persist data for PersistManualTrigger', ex, ex.stack);
        return reject(ex);
      }
    }.bind(this));
  });
}

function afterSave(context, task) {
  // add job to scheduler
  task.emit(CONSTANTS.BOT_EVENT.QUEUE_JOB, {
    queueName: CONSTANTS.JOB_QUEUE.CRON_SCHEDULER,
    job: {
      type: CONSTANTS.SCHEDULER_JOB_TYPE.ADD,
      triggerId: context.userTrigger.id
    }
  });

  // append task to ask for another trigger
  delete context.trigger;
  task.chainTask(require('./../tasks/feedback/gather-trigger-type-repeat'), context);
  return Promise.resolve(true);
}

module.exports = PersistManualTrigger;