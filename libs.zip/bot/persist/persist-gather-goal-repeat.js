'use strict';

const assert = require('assert');
const ModelUser = require('./../../models/user');
const ModelFunction = require('./../../models/function');
const ModelUserTrigger = require('./../../models/user-trigger');
const ModelUserGoal = require('./../../models/user-goal');
const Helper = require('./../libs/helper');
const Co = require('co');
const Logger = require('./../../libs/logger');
const jackrabbit = require('jackrabbit');
const CONSTANTS = require('./../../constants/constants');
const Config = require('./../../configs/config');
const mongoose = require('./../../libs/mongoose-connection')();
const _ = require('lodash');
const Join = require('join-component');

class PersistGatherGoalRepeat {

  static run(context, task) {
    assert(typeof context.slackUserId === 'string', 'Context slackUserId (String) is required');
    assert(typeof context.goalCategory === 'string' || typeof context.goalCategory === 'object',
        'Context goalCategory (String|Objects) is required');
    assert(Array.isArray(context.userGoals), 'Context userGoals (Array) is required');

    return new Promise((resolve, reject) => {
      Co(function *() {
        try {
          if ( ! (context.user && context.user instanceof ModelUser)) {
            context.user = yield ModelUser.findBySlackId(context.slackUserId);
          }

          if(context.goalCategory === 'no') {
            if(! (Array.isArray(context.userGoals) && context.userGoals.length > 0)) {
              Logger.error(__filename, 'Calling Persist Gather Goal repeat to end conversation but without userGoals', context);
              return reject('Calling Persist Gather Goal repeat to end conversation but without userGoals');
            }

            // get a list of triggers for the goals
            var goalIds = context.userGoals.map(item => {
              return mongoose.Types.ObjectId(item._id);
            });
            var userGoals = yield ModelUserGoal.find({ _id: { $in: goalIds}, 'status': CONSTANTS.DB.STATUS.ACTIVE }).populate('goal advisors');

            try {
              if(context.user.manager && context.user.manager.slackUserId) {
                var attachmentMessages = yield Helper.buildGoalCreatedMessage(goalIds);
                if(attachmentMessages) {
                  var taskNotifyManager = require('./../tasks/feedback/notify-manager-employee-goal');
                  task.emit(CONSTANTS.BOT_EVENT.TASK, {
                    slackUserId: context.user.manager.slackUserId,
                    context: {
                      managerFirstName: context.user.manager.firstName,
                      employeeFirstName: context.user.firstName,
                      employeeSlackUserName: context.user.slackUserName,
                      employeeGoalAttachmentMessages: JSON.stringify(attachmentMessages)
                    },
                    task: taskNotifyManager
                  });
                }
              }
            }
            catch(ex) {
              Logger.error('Failed to send notification message to manager', ex, ex.stack, context);
            }

            // Notify Reviewers
            var triggerStrings = yield Helper.getTriggerString(goalIds);
            for(let userGoal of userGoals) {
              var advisorAttachmentMessage = yield Helper.buildGoalCreatedMessage([userGoal.id], true /* DO NOT show feedback givers */);
              if (userGoal.advisors && Array.isArray(userGoal.advisors)) {
                if (triggerStrings[userGoal.id]) {
                  for(let advisor of userGoal.advisors) {
                    // do not fire notification to manager
                    if (context.user.manager && context.user.manager.id === advisor.id) {
                      continue;
                    }

                    task.emit(CONSTANTS.BOT_EVENT.TASK, {
                      slackUserId: advisor.slackUserId,
                      context: {
                        userFirstName: advisor.firstName,
                        employeeFirstName: context.user.firstName,
                        trigger: Join(triggerStrings[userGoal.id], ', and'),
                        goalName: userGoal.name || (userGoal.goal && userGoal.goal.name),
                        employeeGoalAttachmentMessages: JSON.stringify(advisorAttachmentMessage)
                      },
                      task: require('./../tasks/feedback/notify-advisor-employee-goal')
                    });
                  }
                }
              }
            }

            task.chainTask({
              name: 'EndFtue',
              interactions: [
                {
                  type: 'ActionMessage',
                  message: 'Great, you\'re all set. If you need me, say `help`...otherwise bye for now! :wave:' +
                            (context.isFtueFlow ?
                              '\nhttps://s3-us-west-1.amazonaws.com/careerlark-assets/congratulation.gif' :
                              ''
                            )
                }
              ]
            }, context);
          }
          else {
            var taskRepeatGoal = {
              name: 'GatherGoal',
              interactions: [
                {
                  type: 'ActionGatherGoalCompetency',
                  message: 'Great, pick one of these [[goalCategoryName]] suggested goals or write in your own!'
                },
                {
                  type: 'ActionGatherUser',
                  message: 'Cool, who would you like to get feedback from for this? (Slack names please)',
                  saveContextKey: 'advisors'
                },
                {
                  type: 'ActionGatherTriggerType',
                  message: 'Great! How should I ask them?'
                }
              ],
              persist: 'PersistGatherGoal'
            };

            task.chainTask(taskRepeatGoal, context);
          }

          return resolve(true);
        }
        catch(ex) {
          Logger.error(__filename, 'Failed to persist data for PersistGatherGoalRepeat', ex, ex.stack);
          return reject(ex);
        }
      }.bind(this));
    });
  }
}

module.exports = PersistGatherGoalRepeat;