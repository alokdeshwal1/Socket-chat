'use strict';

class Intent {
  constructor() {
    this.task = null;
    this.context = {};
  }
}

module.exports = Intent;