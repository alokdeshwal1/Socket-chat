'use strict';

const Logger = require('./../libs/logger');
const Co = require('co');
const Config = require('../configs/config');
const botMessages = require('../configs/bot-messages');
const assert = require('assert');
const Bot = require('./bot');
const Util = require('util');
const CONSTANTS = require('./../constants/constants');
const witAiParser = require('./parsers/witai');
const IntentActionConversation = require('./libs/intent-action-conversation');
const Task = require('./task');
const MessageStore = require('./libs/message-store');
const Conversation = require('./libs/conversation');
const Serialization = require('./libs/serialization');
const fs = require('fs');
const path = require('path');
const uuid = require('node-uuid');
const _ = require('lodash');
const models = require('./../models'); // preload all models so that there is no dependencies issues
const BotMessages = require('./../configs/bot-messages');
const ConversationLogger = require('./../libs/conversation-logger');
const TaskConfigs = require('./tasks');
const Commands = require('./commands');
const trim = require('trim');
const Helper = require('./libs/helper');

class TalkingBot extends Bot {

  constructor(modules, connection, teamName, teamId, accessToken, name, events) {
    super(accessToken, name, events);

    assert(connection.amqb, 'AMQP connection is required');
    assert(connection.redis, 'Redis connection is required');

    this.modules = this._enabledModules(modules);
    this.teamKey = Helper.getBotTeamKey(teamName, teamId);
    this.queueName = Helper.getBotQueueName(teamName, teamId);
    this.parser = new witAiParser();
    this.amqb = connection.amqb;
    this.redis = connection.redis;
    this.convos = {};
    this.actions = {};
    this.archive = new ConversationLogger(Config.aws.tableName, teamName, teamId);
    this._reconnectInterval = 1000; // milliseconds
    this._reconnectAttempt = 10;

    // listen to websocket message event
    this.on('message', this._eventAction.bind(this));
    this.on('openSlackWs', this.init.bind(this));
    this.on('closeSlackWs', this._reconnectSlackWs.bind(this));
  }

  static getTeamKey(teamName, teamId) {
    return teamName +'-'+ teamId;
  }

  init() {
    Co(function *() {
      try {
        //yield this.restoreMemory();
        yield this.amqb.createQueue(this.queueName);
        this.amqb.handle(this.queueName, this.handleQueue.bind(this));

        // mostly for unit test purpose
        this.emit('ready');
      }
      catch(ex) {
        Logger.error({ex, exStack: ex.stack, queueName: this.queueName}, 'Talking bot init failed');
      }
    }.bind(this));
  }

  handleQueue(job, ack) {
    if (job.type === CONSTANTS.BOT_JOB_TYPE.INTEGRATION_MESSAGE) {
      this._addIntegrationMessage(job);
      ack && ack();
    }
    else {
      this._queueTask(job)
        .then(() => {
          ack && ack();
        })
        .catch((err) => {
          Logger.error({err, job}, 'Fail to queue task from AMPQ queue');
          ack && ack();
        });
    }
  }

  restoreMemory() {
    return new Promise((resolve) => {
      this.redis.get(this.teamKey, (err, data) => {
        if(err) {
          Logger.error({err, data}, 'Failed to restore memory');
          return resolve(false);
        }
        if ( ! data) {
          return resolve(false);
        }
        if(typeof data !== 'string') {
          Logger.error({err, data}, 'Restore memory is getting invalid data');
          return resolve(false);
        }

        var restoredConvos = this._deSerialize(data);
        if (restoredConvos && typeof restoredConvos === 'object') {
          this.convos = restoredConvos;
          resolve(true);
        }
        return resolve(false);
      });
    });
  }

  saveMemory() {
    return new Promise((resolve) => {
      var saveString = this._serialize();
      if ( ! saveString || typeof saveString !== 'string') {
        Logger.error({ saveString }, 'Getting wrong output from serialize command');
        return resolve(false);
      }

      this.redis.set(this.teamKey, saveString, function(err, data) {
        if(err) {
          Logger.error({err, data}, 'Failed to save data to redis');
          return resolve(false);
        }
        return resolve(true);
      });
    });
  }

  _enabledModules(modules) {
    if (_.isObject(modules) && _.compact(_.values(modules)).length > 0) {
      return modules;
    }
    modules = {};
    modules[CONSTANTS.MODULES.PERSONAL_GOAL] = true;

    return modules;
  }

  _serialize() {
    try {
      return JSON.stringify(this.convos);
    }
    catch (ex) {
      Logger.error({ex, exStack: ex.stack, conversation: this.convos}, 'Failed to serialize data');
      return null;
    }
  }

  _deSerialize(jsonString) {
    try {
      var data = JSON.parse(jsonString);

      // restore the tasks
      Object.keys(data).forEach(team => {
        Object.keys(data[team]).forEach(channel => {
          var tasks = [];
          data[team][channel]['_tasks'].map(task => {
            var newTask = Task.restore(task, this);
            newTask = this._bindTask(newTask, channel);
            tasks.push(newTask);
          });
          data[team][channel]['_tasks'] = tasks || [];
          data[team][channel] = Conversation.restore(data[team][channel], this);

        });
      });

      return data;
    }
    catch (ex) {
      Logger.error({ex, exStack: ex.stack, conversation: this.convos}, 'Failed to deSerialize data');
      return null;
    }
  }

  _reconnectSlackWs() {
    this._reconnectSlackWSCount = this._reconnectSlackWSCount || 0;
    if (this._reconnectSlackWSCount++ >= 10) {
      var botObject;
      try {
        botObject = JSON.stringify(this);
      }
      catch (ex) {}
      Logger.error({ bot: botObject }, 'Slack Connection Dropped: Tried more than '+ this._reconnectAttempt + ' times to reconnect')
    }
    else {
      setTimeout(() => {
        Logger.warn('Trying to reconnect Slack WS');
        this.connect();
      }, this._reconnectInterval * this._reconnectSlackWSCount);
    }
  }

  listen(userId, channel, message, skipParser) {
    assert(typeof userId === 'string', 'UserId (required) must be a String');
    assert(typeof channel === 'string', 'Channel (required) must be a String');
    assert(typeof message === 'string', 'Message (required) must be a String');

    Co(function *() {
      try {
        this._update(channel, userId);

        var shouldFire = yield this._shouldFireImportantTask(message, channel, userId);
        if (shouldFire) {
          return;
        }
        else if(skipParser || ! this._shouldParseMessage(message, channel, userId)) {
          this._addMessage(message, channel);
          return;
        }

        // idle time?
        if (this.convos[this.teamKey][channel].isAllCompleted()) {
          var intentAction = new IntentActionConversation(witAiParser);
          var intentMessage = yield intentAction.process(message);
          if (typeof intentMessage === 'string') {
            this.speak(channel, intentMessage);
          }
          else {
            this.speak(channel, BotMessages.NotUnderstoodCommand);
          }
          return;
        }

        this._addMessage(message, channel);
      }
      catch(ex) {
        Logger.error('Failed to execute listen function', ex, ex.stack);
      }
    }.bind(this));
  }

  speak(channel, message, messageId, emojiReaction, params) {
    try {
      assert(typeof channel === 'string', 'Channel (required) must be a String');
      assert(typeof message === 'string', 'Message (required) must be a String');
      messageId = messageId || uuid.v1();

      this.convos[this.teamKey][channel].messageStore.add({
        'type': CONSTANTS.BOT_EVENT.MESSAGE,
        'func': 'postMessage',
        'id': messageId,
        'emojiReaction': emojiReaction,
        'args': [channel, message, params]
      });

      // for unit test purpose
      this.emit(CONSTANTS.BOT_EVENT.MESSAGE_QUEUED, {
        'channel': channel,
        'messageId': messageId,
        'message': message,
        'emojiReaction': emojiReaction,
        'params': params
      });
    }
    catch (ex) {
      Logger.error('Failed to executed Speak', ex, ex.stack, arguments);
      return false;
    }

    return true;
  }

  attachmentMessage(channel, attachment) {
    assert(typeof channel === 'string', 'Channel (required) must be a String');
    assert(typeof attachment === 'object', 'Attachment (required) must be an Object');

    var messageId = attachment.id || attachment.messageId || uuid.v1();
    var attachments = attachment.message || attachment;

    this.convos[this.teamKey][channel].messageStore.add({
      'type': CONSTANTS.BOT_EVENT.ATTACHMENT_MESSAGE,
      'func': 'postMessage',
      'id': messageId,
      'emojiReaction': attachment && attachment.emojiReaction,
      'attachments': attachments,
      'args': [channel, '', { attachments: attachments }]
    });

    // for unit test purpose
    this.emit(CONSTANTS.BOT_EVENT.MESSAGE_QUEUED, {
      'channel': channel,
      'messageId': messageId,
      'attachments': attachments,
      'emojiReaction': attachment && attachment.emojiReaction
    });
  }

  emojiReaction(channel, uniqueId, emojis) {
    assert(typeof channel === 'string', 'Channel (String) is required');
    assert(typeof uniqueId === 'string', 'uniqueId (String) is required');
    assert(Array.isArray(emojis), 'Emoji (Array) is required');

    this.postEmojis(channel, emojis)
      .then(data => {
        if (this.convos[this.teamKey][channel].currentTask) {
          this.convos[this.teamKey][channel].currentTask.emit(CONSTANTS.BOT_EVENT.EMOJI_REACTION_POSTED, uniqueId);
        }
      })
      .catch(err => {
        Logger.error('Failed to posted reaction emojis', err, err.stack);
      });
  }

  _eventAction(event) {
    try {
      if ( ! (event && event.type)) {
        return false;
      }

      const ignoreEvents = ['user_typing', 'reconnect_url', 'presence_change'];
      if (ignoreEvents.indexOf(event.type) !== -1) {
        return false;
      }
      switch(event.type) {
        case 'hello' :
          Logger.info(this.teamKey +' bot has started successfully');
          break;

        case 'message':
          if (event.subtype === 'bot_message') {
            // our message is posted, update the posted timestamp
            this.convos[this.teamKey][event.channel].messageStore.messageIsPosted(event.ts);
          }
          else if (event.subtype === 'message_changed') {
            return;
          }
          else {
            this.archive.receive({
              channel: event.channel,
              userId: event.user,
              message: event.text,
              slackTimeStamp: event.ts,
              rawData: event
            });

            this.listen(event.user, event.channel, event.text);
          }
          break;

        case 'user_change':
            var ModelUser = require('./../models/user');
            var ModelIntegration = require('./../models/slack-integration');
            ModelIntegration.findOne({teamId: event.user.team_id, status: CONSTANTS.DB.STATUS.ACTIVE})
              .then(integration => {
                return ModelUser.upsertSlackUser(integration.company, integration.id, event.user);
              })
              .then(data => {
                (typeof data === 'object') && Logger.debug({event}, 'user_change event updated successfully');
              })
              .catch(err => {
                Logger.error({err, event}, 'user_change event error');
              });
          break;

        case 'reaction_added':
          var conversation = this.convos[this.teamKey][event.item.channel];
          var messageStore = conversation.messageStore;
          if (conversation.userId === event.user) {
            this.archive.receive({
              channel: event.item.channel,
              userId: this.convos[this.teamKey][event.item.channel].userId,
              selectEmoji: event.reaction,
              slackTimeStamp: event.ts,
              rawData: event
            });

            this.addEmojiMessage(event.reaction, event.item.channel);
          }
          else {
            messageStore.emojiIsPosted(event.item.ts, event.ts, event.reaction);
          }

          break;
      }
    }
    catch(ex) {
      Logger.error({ex, exStack: ex.stack, event}, 'Failed to match event in eventAction');
    }
  }

  _addMessage(message, channel) {
    var currentTask;
    try {
      currentTask = this.convos[this.teamKey][channel].currentTask;
      if (currentTask) {
        currentTask.addMessage(message);
      }
      else {
        Logger.warn({message, channel, currentTask: currentTask.toJSON()},
          'Adding message to currentTask that doesn\'t exist');
      }
    }
    catch (ex) {
      Logger.error({ex, exStack: ex.stack, message, channel}, 'Failed to add message to interaction');
    }

    this.saveMemory();
  }

  addButtonAction(message, channel) {
    try {
      this.convos[this.teamKey][channel].currentTask.addButtonAction(message);
    }
    catch (ex) {
      Logger.error('Failed to add EmojiActionto interaction', ex, ex.stack, arguments);
      return false;
    }

    return true;
  }

  addEmojiMessage(message, channel) {
    try {
      this.convos[this.teamKey][channel].currentTask.addEmojiMessage(message);
    }
    catch (ex) {
      Logger.error('Failed to add Emoji message to interaction', ex, ex.stack, arguments);
      return false;
    }

    return true;
  }

  emitMessagePosted(channel, message) {
    if (this.convos[this.teamKey][channel].currentTask) {
      this.convos[this.teamKey][channel].currentTask.emit(CONSTANTS.BOT_EVENT.MESSAGE_POSTED, message);
    }
  }

  _addTask(channel, userId, taskConfig, taskContext) {
    this._createConversationKey(channel, userId);
    var newTask = new Task(taskConfig, taskContext, this);
    const task = this._bindTask(newTask, channel);
    const channelInfo = this.convos[this.teamKey][channel];

    // when user fire help command one after another, we cancel the previous help command
    if (this._isHelpCommandFireOneAfterAnother(channelInfo, task)) {
      channelInfo.tasks.splice(channelInfo.step + 1, 0, task);
      channelInfo.currentTask && channelInfo.currentTask.end();
    }
    else if (task.type === CONSTANTS.TASK_TYPE.HELP_COMMAND) {
      channelInfo.tasks.splice(channelInfo.step + 1, 0, task);
      channelInfo.currentTask && channelInfo.currentTask.end();
    }
    else {
      var isInserted = false;
      for(var i = channelInfo.step; i < channelInfo.tasks.length; i++) {
        var item = channelInfo.tasks[i];
        if (item && item.priority && item.type !== CONSTANTS.TASK_TYPE.CHAINED_TASK &&
          taskConfig.priority && taskConfig.priority < item.priority) {

          channelInfo.tasks.splice(i, 0, task);

          // are we replacing injecting something above the current task?
          if(i === channelInfo.step) {
            channelInfo.currentTask && channelInfo.currentTask.suspend();
            channelInfo.currentTask = channelInfo.tasks[i];
            channelInfo.currentTask.start();
          }

          isInserted = true;
          break;
        }
      }
      if ( ! isInserted) {
        channelInfo.tasks.push(task);
      }
    }

    // start the first task
    if ( ! channelInfo.currentTask || (channelInfo.currentTask && channelInfo.currentTask.isEnded)) {
      channelInfo.nextTask();
    }

    this.saveMemory();
  }

  _addIntegrationMessage(job) {
    return new Promise((resolve, reject) => {
      Co(function *() {
        try {
          assert(typeof job.slackUserId === 'string', 'User\' slackUserId does not exist');
          job.context && assert(typeof job.context === 'object', 'job.context must be an object');

          const channel = yield this._getChannel(job.slackUserId);
          this._createConversationKey(channel, job.slackUserId);
          const channelInfo = this.convos[this.teamKey][channel];
          if(job.integrationType === CONSTANTS.INTEGRATION_TYPE.INTERACTIVE_MESSAGE) {
            this.addButtonAction(job.payload.actions[0].value, channel);
          }
          else {
            channelInfo.currentTask.addMessage(job.context);
          }
        }
        catch(ex) {
          Logger.error({ex, exStack: ex.stack, job}, 'Failed to add integration message');
          return reject(ex);
        }

        return resolve(true);
      }.bind(this));
    });
  }

  _queueTask(job) {
    return new Promise((resolve, reject) => {
      Co(function *() {
        try {
          assert(typeof job.slackUserId === 'string', 'User\' slackUserId does not exist');
          job.task && assert(typeof job.task === 'object', 'job.task must be an object');
          job.context && assert(typeof job.context === 'object', 'job.context must be an object');

          const channel = yield this._getChannel(job.slackUserId);
          this._addTask(channel, job.slackUserId, job.task, job.context);
        }
        catch(ex) {
          Logger.error({ ex, exStack: ex.stack, job }, 'Failed to queue task');
          return reject(ex);
        }

        return resolve(true);
      }.bind(this));
    });
  }

  _getChannel(slackUserId) {
    return new Promise((resolve, reject) => {
      this.openIm(slackUserId)
        .then(function(data) {
          resolve(data.channel.id);
        })
        .catch(reject);
    });
  }

  _onMessage(channel) {
    return (params) => {
      try {
        if (typeof params === 'string') {
          this.speak(channel, params, uuid.v1());
        }
        else {
          this.speak(channel, params.message, params.messageId || params.id, params.emojiReaction);
        }
      }
      catch (ex) {
        Logger.error('_onMessage error', ex, ex.stack, arguments);
      }
    };
  }

  _onTask(channel) {
    return (params) => {
      try {
        this._queueTask(params);
      }
      catch (ex) {
        Logger.error('_onTask error', ex, ex.stack, arguments);
      }
    };
  }

  _onAttachmentMessage(channel) {
    return (attachment) => {
      try {
        this.attachmentMessage(channel, attachment);
      }
      catch (ex) {
        Logger.error('_onAttachmentMessage error', ex, ex.stack, arguments);
      }
    };
  }

  _onRemoveEmojiReaction(channel) {
    return (params) => {
      try {
        this.convos[this.teamKey][channel].messageStore.removeEmojis(params.id, params.emojis);
      }
      catch(ex) {
        Logger.error('_onEmojiReactionDelete error', ex, ex.stack, arguments);
      }
    };
  }

  _onQueueJob() {
    return (params) => {
      try {
        Logger.debug(__filename, 'Fire Queue Job', params.queueName, params.job);
        this.amqb.queueJob(params.queueName, params.job);
      }
      catch (ex) {
        Logger.error('_onQueueJob error', ex, ex.stack, arguments);
      }
    };
  }

  _onEnd(channel) {
    return () => {
      try {
        const channelInfo = this.convos[this.teamKey][channel];
        // for unit test purpose
        this.emit(CONSTANTS.BOT_EVENT.END, channelInfo.currentTask.name || '');
        channelInfo.nextTask();
      }
      catch (ex) {
        Logger.error('_onEnd error', ex, ex.stack);
      }
    };
  }

  _onError(channel) {
    return (message) => {
      try {
        const channelInfo = this.convos[this.teamKey][channel];
        if (message) {
          this.postMessage(channel, message);
        }
        else {
          this.postMessage(channel, botMessages.Error());
        }

        channelInfo.nextTask();
      }
      catch (ex) {
        Logger.error('_onError error', ex, ex.stack, arguments);
      }
    };
  }

  _onChainTask(channel) {
    return (chainAfterTaskId, taskConfig, taskContext) => {
      try {
        var newTask = new Task(taskConfig, taskContext, this);
        newTask.parentTaskId = chainAfterTaskId;
        newTask.chainAfterTask = this._onChainTask.call(this, channel);
        const task = this._bindTask(newTask, channel);
        const channelInfo = this.convos[this.teamKey][channel];
        var index = _.findIndex(channelInfo.tasks, { id: chainAfterTaskId });
        channelInfo.tasks.splice(index + 1, 0, task);
      }
      catch (ex) {
        Logger.error('_onChainTask error', ex, ex.stack, arguments);
      }
    }
  }

  _shouldFireImportantTask(message, channel, userId) {
    var messageLowerCase = trim(String(message).toLowerCase());
    var intent = (new Commands['CommandHelp']()).parse(messageLowerCase);
    if (intent && intent.task) {
      var task;
      if (this.modules[CONSTANTS.MODULES.OKR] && _.compact(_.values(this.modules)).length === 1) {
        task = this._bindTask(new Task(TaskConfigs['HelpOKR'], {}), channel, this);
      }
      else {
        task = this._bindTask(new Task(TaskConfigs['Help'], {}), channel, this);
      }
      this._addTask(channel, userId, task, {});
      return Promise.resolve(true);
    }
    else if(messageLowerCase === 'back') {
      Co(function *() {
        try {
          if (this.convos[this.teamKey][channel] &&
            this.convos[this.teamKey][channel].currentTask) {

            if ( ! this.convos[this.teamKey][channel].currentTask.back()) {
              // can we go back as a task?
              var canGoBackTask = yield this.convos[this.teamKey][channel].back();
              if ( ! canGoBackTask) {
                this.speak(channel, botMessages.BackError());
              }
            }
          }
          else {
            this.speak(channel, botMessages.BackError());
            if (this.convos[this.teamKey][channel].currentTask) {
              this.convos[this.teamKey][channel].currentTask.repeat();
            }
          }
        }
        catch(ex) {
          Logger.error('Failed to executed back command', ex, ex.stack);
        }
      }.bind(this));

      return Promise.resolve(true);
    }
    else if(messageLowerCase === 'cancel' || messageLowerCase === 'exit') {
      if (this.convos[this.teamKey][channel] && this.convos[this.teamKey][channel].currentTask) {
        try {
          this.convos[this.teamKey][channel].currentTask.cancel();
          this.convos[this.teamKey][channel].nextTask();

          this.speak(channel, botMessages.Cancel(), uuid.v1());
        }
        catch (ex) {
          Logger.error(__filename, 'Failed to cancel task', ex, ex.stack);
        }
      }
      else {
        this.speak(channel, botMessages.CancelError(), uuid.v1());
      }

      return Promise.resolve(true);
    }
    else {
      var isMatch = false;
      Object.keys(Commands).forEach(className => {
        if ( ! isMatch && (! (this.modules[CONSTANTS.MODULES.OKR] && className === 'CommandGoalCrud'))) {
          var command = new Commands[className]();
          var intent = command.parse(message);
          if (intent && intent.task) {
            isMatch = true;
            intent.task.type = CONSTANTS.TASK_TYPE.HELP_COMMAND;
            this._addTask(channel, userId, intent.task, Object.assign({ slackUserId: userId }, intent.context));
          }
        }
      });

      return Promise.resolve(isMatch);
    }
  }

  _shouldParseMessage(message, channel) {
    return (message.indexOf('@' + Config.slack.botName) !== -1 ||
            channel.charAt(0) === 'D');
  }

  _bindTask(task, channel) {
    task.on(CONSTANTS.BOT_EVENT.MESSAGE, this._onMessage.call(this, channel));
    task.on(CONSTANTS.BOT_EVENT.ATTACHMENT_MESSAGE, this._onAttachmentMessage.call(this, channel));
    task.on(CONSTANTS.BOT_EVENT.REMOVE_EMOJI_REACTION, this._onRemoveEmojiReaction.call(this, channel));
    task.on(CONSTANTS.BOT_EVENT.TASK, this._onTask.call(this, channel));
    task.on(CONSTANTS.BOT_EVENT.QUEUE_JOB, this._onQueueJob.call(this));
    task.on(CONSTANTS.BOT_EVENT.END, this._onEnd.call(this, channel));
    task.on(CONSTANTS.BOT_EVENT.ERROR, this._onError.call(this, channel));
    task.chainAfterTask = this._onChainTask.call(this, channel);

    return task;
  }

  _createConversationKey(channel, userId) {
    if ( ! this.convos[this.teamKey]) {
      this.convos[this.teamKey] = {};
    }
    if ( ! this.convos[this.teamKey][channel]) {
      this.convos[this.teamKey][channel] = new Conversation(this, userId, channel);
    }
  }

  _update(channel, userId) {
    this._createConversationKey(channel, userId);
    this.convos[this.teamKey][channel].updatedAt = + (new Date()); // UTC time
  }

  _isHelpCommandFireOneAfterAnother(channelInfo, task) {
    return !!(channelInfo && channelInfo.currentTask && channelInfo.currentTask.type &&
              channelInfo.currentTask.type === CONSTANTS.TASK_TYPE.HELP_COMMAND &&
              ! channelInfo.currentTask.isEnded && task.type === CONSTANTS.TASK_TYPE.HELP_COMMAND);
  }
}

module.exports = TalkingBot;