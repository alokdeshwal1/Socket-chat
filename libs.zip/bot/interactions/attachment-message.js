'use strict';

const assert = require('assert');
const Action = require('./action');
const CONSTANTS = require('./../../constants/constants');
const Logger = require('./../../libs/logger');

class ActionAttachmentMessage extends Action {

  constructor(message, context, saveContextKey, emojiReaction, overwrite) {
    super(message, context, saveContextKey, emojiReaction, overwrite);
    this.init();
  }

  init() {
    // so that subscriber can subscribe to on event after initialization
    setImmediate(() => {
      try {
        super.init() && this.think();
      }
      catch (ex) {
        Logger.error({ex, exStack: ex.stack, object: this}, 'Failed to trigger think method');
        this.emit(CONSTANTS.BOT_EVENT.ERROR);
      }
    });
  }

  think() {
    try {
      this.message = (typeof this.message === 'string') ? JSON.parse(this.message) : this.message;
      if ( ! Array.isArray(this.message)) {
        this.message = [this.message];
      }

      this.message.forEach(item => {
        assert(Array.isArray(item.fields), 'Message.fields (Array) is required');
      });
    }
    catch (ex) {
      Logger.error(__filename, 'Failed to parse message or missing variables for ActionAttachmentMessage', ex, ex.stack);
      this.emit(CONSTANTS.BOT_EVENT.ERROR, ex.message);
      return;
    }

    this.emit(CONSTANTS.BOT_EVENT.ATTACHMENT_MESSAGE, this.message);
    this.endAction();
  }
}

module.exports = ActionAttachmentMessage;
