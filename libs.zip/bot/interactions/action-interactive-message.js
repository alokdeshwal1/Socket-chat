'use strict';

const CONSTANTS = require('./../../constants/constants');
const Util = require('util');
const assert = require('assert');
const Request = require('request');
const Config = require('./../../configs/config');
const BotError = require('./../../errors/bot-error');
const Action = require('./action');
const ModelGoal = require('./../../models/goal');
const Co = require('co');
const Logger = require('./../../libs/logger');
const NumberToWords = require('number-to-words');
const WordsToNumber = require('words-to-num');
const RangeValidation = require('./../validations/range');
const uuid = require('uuid');
const trim = require('trim');
const Helper = require('./../libs/helper');
const R = Helper.replaceMessagePlaceholder.bind(Helper);

class ActionInteractiveMessage extends Action {

  static requireAction() {
    return true;
  }

  constructor(message, context, saveContextKey, config) {
    super(message, context, saveContextKey, config);

    assert(typeof context.slackUserId === 'string', 'Context slackUserId (String) is missing');

    this.saveContextKey = saveContextKey;
    this.requiredEntities = [this.saveContextKey];
    this.state = this.requiredEntities[0];
    this.sizePerPage = 4;
    this.values = this.values || [];

    this.buttons = [];
    this.allowedValues = [];
    this.paging = [];
    this.currentPage = 0;
  }

  _setUp(message) {
    return new Promise((resolve, reject) => {
      Co(function*() {
        try {
          if (Array.isArray(this.values)) {
            var options = [];
            this.values.forEach((item, key) => {
              var emoji;
              var selectionNumber = ++key;
              if (selectionNumber < 10) {
                emoji = ':'+ NumberToWords.toWords(selectionNumber) +':';
              }
              else {
                emoji = selectionNumber + '. ';
              }
              options.push(emoji +' '+ item.name);
              this.buttons.push(emoji);
              this.allowedValues.push(key);
            });


            // no point creating pagination if next page contains one item
            if (options.length === (this.sizePerPage + 1)) {
              this.paging.push(options);
            }
            else {
              this.paging.push(options.slice(0, this.sizePerPage));
              this.paging.push(options.slice(this.sizePerPage));
            }
          }

          if (this.paging[0].length === 0 && this.message.noValueText) {
            this.message = {
              'fallback': this.message.noValueFallback,
              'color': Config.botAttachmentMessageColor.action,
              'fields': [{
                value: this.message.noValueText
              }]
            };
          }
          else {
            if(this.paging.length > 1 && this.paging[1] && this.paging[1].length > 0) {
              this.paging[0].push(':'+ NumberToWords.toWords(this.sizePerPage + 1) +': ' + ( this.nextPageTitle || 'Other' ));
            }

            var fieldSetting = {
              value: this.paging[this.currentPage].join('\n') +
              '\n\n' +
              ((this.message && this.message.footer) || 'Pick one by tapping on a button:')
            };

            if (this.message && this.message.fieldTitle) {
              fieldSetting.title = this.message.fieldTitle;
            }

            this.message.fields = [fieldSetting];
            this.message.actions = this.buttons.slice(0, this.sizePerPage + 1);

            this.validator = new RangeValidation(this.allowedValues);
          }

          return resolve(true);
        }
        catch (ex) {
          Logger.error({ex, exStack: ex.stack, 'this': this}, 'ActionInteractiveMessage failed to generate attachment message');
          return reject(ex);
        }
      }.bind(this));
    });
  }

  buildButtons(buttons) {
    var output = [];
    if (Array.isArray(buttons)) {
      buttons.forEach(item => {
        output.push({
          name: item,
          text: item,
          type: 'button',
          style: 'primary',
          value: item
        });
      });
    }

    return output;
  }

  addButtonAction(message, outcome) {
    this.addMessage(message.replace(/:/ig, ''), outcome);
  }

  nextPage() {
    this.currentPage++;
    var attachmentMessage = [{
      'fallback': this.message.nextPageFallback,
      'color': Config.botAttachmentMessageColor.action,
      'pretext': this.message.nextPagePretext,
      'mrkdwn_in': ['fields', 'pretext'],
      "fields": [
        {
          value: this.paging[this.currentPage].join('\n') +
          '\n\n' +
          Util.format(this.message.nextPageFooter, this.allowedValues.length)
        }
      ]
    }];
    this.emit(CONSTANTS.BOT_EVENT.ATTACHMENT_MESSAGE, attachmentMessage);
  }

  addMessage(message, skipSaveContext) {
    message = trim(message.toString());
    if (message === 'keycap_ten') { // take care of emoji 'keycap_ten' (Other)
      message = 'ten';
    }
    if ( ! isNaN(WordsToNumber.convert(message))) {
      message = WordsToNumber.convert(message);
    }

    if (this.currentPage === 0 && this.paging.length > 1 && message == (this.sizePerPage + 1)) {
      this.nextPage();
    }
    else {
      if (! Number(message)) {
        this.validator = null;
        super.addMessage(message, skipSaveContext);
      }
      else {
        this.validator = new RangeValidation(this.allowedValues);
        super.addMessage(message, skipSaveContext);
      }
    }
  }

  toSlackStructure(values, callbackIdPrefix) {
    var output = {
      'callback_id': (callbackIdPrefix || '') + '_' + uuid.v1(),
      'mrkdwn_in': ['fields', 'pretext', 'text'],
      'color': Config.botAttachmentMessageColor.action,
      'attachment_type': 'default'
    };

    ['pretext', 'text', 'title', 'fields', 'actions', 'fallback'].forEach(objectKey => {
      if (! (typeof values[objectKey] === 'undefined' || values[objectKey] === null)) {
        if (objectKey === 'actions') {
          output[objectKey] = this.buildButtons(values.actions)
        }
        else {
          output[objectKey] = values[objectKey];
        }
      }
    });

    return [output];
  }

  think() {
    try {
      if(this._isCompleted()) {
        if (this.entities[this.state] !== 'Other') {
          // convert the selected value to object id
          this.entities[this.state] = this.values[Number(this.entities[this.state]) - 1];
          this.context[this.saveContextKey] = this.entities[this.state];
        }

        this.endAction();
      }
      else {
        this.emitAttachmentMessage(this.toSlackStructure(this.message));
      }
    }
    catch (ex) {
      Logger.error('Failed to execute think', ex, ex.stack);
      this.emit(CONSTANTS.BOT_EVENT.ERROR);
    }
  }
}

module.exports = ActionInteractiveMessage;
