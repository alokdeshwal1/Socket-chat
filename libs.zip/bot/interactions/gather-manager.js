'use strict';

const CONSTANTS = require('./../../constants/constants');
const Util = require('util');
const assert = require('assert');
const Request = require('request');
const Config = require('./../../configs/config');
const BotError = require('./../../errors/bot-error');
const Action = require('./action');
const ValidationGatherUser = require('./../validations/gather-user');
const Co = require('co');
const ModelUser = require('./../../models/user');

class ActionGatherManager extends Action {

  static requireAction() {
    return true;
  }

  constructor(message, context, saveContextKey, emojiReaction, overwrite) {
    super(message, context, saveContextKey, emojiReaction, overwrite);

    if (context.userManagerFirstName) {
      this.message = 'Ok, currently it\'s '+ context.userManagerFirstName +'. ' + this.message;
    }

    this.saveContextKey = this.saveContextKey || 'managerSlackUserId';
    this.validator = new ValidationGatherUser('I don\'t quite understand :disappointed:, who are you refereeing to?');
    this.requiredEntities = [this.saveContextKey];
    this.state = this.requiredEntities[0];

    if (context.addManagerSlackUserId || context.changeManagerSlackUserId) {
      var theUserId;
      if (context.addManagerSlackUserId) {
        theUserId = '<@'+ context.addManagerSlackUserId +'>';
      }
      if (context.changeManagerSlackUserId) {
        theUserId = '<@'+ context.changeManagerSlackUserId +'>';
      }
      this.addMessage(theUserId);
    }
    else if (context.addManagerSlackUserName || context.changeManagerSlackUserName) {
      this.addMessage(context.addManagerSlackUserName || context.changeManagerSlackUserName);
    }
    else {
      this.init();
    }
  }

  init() {
    // so that subscriber can subscribe to on event after initialization
    setImmediate(() => {
      try {
        super.init() && this.think();
      }
      catch (ex) {
        Logger.error({ex, exStack: ex.stack, object: this}, 'Failed to trigger think method');
        this.emit(CONSTANTS.BOT_EVENT.ERROR);
      }
    });
  }

  think() {
    if (this._isCompleted()) {
      this.endAction();
    }
    else {
      this.emit(CONSTANTS.BOT_EVENT.MESSAGE, this.message);
    }
  }

}

module.exports = ActionGatherManager;
