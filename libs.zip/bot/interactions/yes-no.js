'use strict';

const CONSTANTS = require('./../../constants/constants');
const Util = require('util');
const assert = require('assert');
const Request = require('request');
const Config = require('./../../configs/config');
const BotMessages = require('./../../configs/bot-messages');
const BotError = require('./../../errors/bot-error');
const Action = require('./action');
const ValidationYesNo = require('./../validations/yes-no');

class ActionYesNo extends Action {

  static requireAction() {
    return true;
  }

  constructor(message, context, saveContextKey, emojiReaction, overwrite) {
    super(message, context, saveContextKey, emojiReaction, overwrite);

    this.saveContextKey = this.saveContextKey || 'yesNo';
    this.validator = new ValidationYesNo();
    this.requiredEntities = ['yesNo'];
    this.state = this.requiredEntities[0];

    this.init();
  }

  init() {
    // so that subscriber can subscribe to on event after initialization
    setImmediate(() => {
      try {
        super.init() && this.think();
      }
      catch (ex) {
        Logger.error({ex, exStack: ex.stack, object: this}, 'Failed to trigger think method');
        this.emit(CONSTANTS.BOT_EVENT.ERROR);
      }
    });
  }

  think() {
    if (this._isCompleted()) {
      const value = this.context[this.saveContextKey];
      if (this.actions && this.actions[value].type === 'Task') {
        this.emit(CONSTANTS.BOT_EVENT.TASK, this.actions[value].name);
      }
      this.endAction();
    }
    else {
      this.emit(CONSTANTS.BOT_EVENT.MESSAGE, this.message);
    }
  }

}

module.exports = ActionYesNo;
