'use strict';

const CONSTANTS = require('./../../constants/constants');
const Util = require('util');
const assert = require('assert');
const Request = require('request');
const Config = require('./../../configs/config');
const BotError = require('./../../errors/bot-error');
const Action = require('./action');
const ValidationGatherUser = require('./../validations/gather-user');
const Co = require('co');
const ModelUser = require('./../../models/user');

class ActionGatherAdvisor extends Action {

  static requireAction() {
    return true;
  }

  constructor(message, context, saveContextKey, emojiReaction, overwrite) {
    super(message, context, saveContextKey, emojiReaction, overwrite);

    this.saveContextKey = this.saveContextKey || 'advisorSlackUserInfo';
    this.validator = new ValidationGatherUser();
    this.requiredEntities = [this.saveContextKey];
    this.state = this.requiredEntities[0];

    if (context.addAdvisorSlackUserId || context.removeAdvisorSlackUserId) {
      var theUserId;
      if (context.addAdvisorSlackUserId) {
        theUserId = '<@'+ context.addAdvisorSlackUserId +'>';
      }
      if (context.removeAdvisorSlackUserId) {
        theUserId = '<@'+ context.removeAdvisorSlackUserId +'>';
      }
      this.addMessage(theUserId);
    }
    else if (context.addAdvisorSlackUserName || context.removeAdvisorSlackUserName) {
      this.addMessage(context.addAdvisorSlackUserName || context.removeAdvisorSlackUserName);
    }
    else {
      this.init();
    }
  }

  init() {
    // so that subscriber can subscribe to on event after initialization
    setImmediate(() => {
      try {
        super.init() && this.think();
      }
      catch (ex) {
        Logger.error({ex, exStack: ex.stack, object: this}, 'Failed to trigger think method');
        this.emit(CONSTANTS.BOT_EVENT.ERROR);
      }
    });
  }

  think() {
    if (this._isCompleted()) {
      this.endAction();
    }
    else {
      this.emit(CONSTANTS.BOT_EVENT.MESSAGE, this.message);
    }
  }

}

module.exports = ActionGatherAdvisor;
