'use strict';

const CONSTANTS = require('./../../constants/constants');
const Util = require('util');
const assert = require('assert');
const Request = require('request');
const Config = require('./../../configs/config');
const BotError = require('./../../errors/bot-error');
const Action = require('./action');
const ModelGoalCategory = require('./../../models/goal-category');
const ModelUser = require('./../../models/user');
const Co = require('co');
const Logger = require('./../../libs/logger');
const NumberToWords = require('number-to-words');
const WordsToNumber = require('words-to-num');
const FreeFormTextValidation = require('./../validations/free-form-text');
const uuid = require('uuid');
const trim = require('trim');
const google = require('googleapis');
const OAuth2 = google.auth.OAuth2;
const oauth2Client = new OAuth2(Config.google.clientId, Config.google.clientSecret, Config.baseUrl + '/google/redirect');
const googleUrl = new (require('google-url'))({key: Config.google.apiKey});
const GCalParser = require('./../../libs/google-calendar-parser');

class ActionGoogleCalendarAuthentication extends Action {

  static requireAction() {
    return true;
  }

  constructor(message, context, saveContextKey, emojiReaction, overwrite) {
    super(message, context, saveContextKey, emojiReaction, overwrite);

    assert(typeof context.slackUserId === 'string', 'Context SlackUserId is missing');

    this.saveContextKey = this.saveContextKey || 'googleOauthToken';
    this.requiredEntities = ['googleOauthToken'];
    this.state = this.requiredEntities[0];

    this.integrationRequestId = null;
    this.validator = new FreeFormTextValidation();

    this.init();
  }

  init() {
    // so that subscriber can subscribe to on event after initialization
    setImmediate(() => {
      try {
        super.init() && this.think();
      }
      catch (ex) {
        Logger.error({ex, exStack: ex.stack, object: this}, 'Failed to trigger think method');
        this.emit(CONSTANTS.BOT_EVENT.ERROR);
      }
    });
  }

  _getOauthTokenUrl() {
    return oauth2Client.generateAuthUrl(Object.assign({
      state: JSON.stringify({
        fromSlack: true,
        slackUserId: this.context.slackUserId,
        integrationRequestId: this.integrationRequestId
      }),
      redirect_uri: Config.webApplicationUrl + '/google/redirect',
      origin: Config.webApplicationUrl
    }, Config.integration.googleCalendar));
  }

  addMessage(message, outcome, skipSaveContext) {
    assert(typeof message === 'object',  'message (Object) is required');

    if (message.integrationRequestId === this.integrationRequestId) {
      this.entities[this.state] = message.googleOauthToken;
      this.context[this.saveContextKey] = message.googleOauthToken;
      this.context['isGatheredCalendarAuthentication'] = true;
      this.think();
    }
    else {
      Logger.error(__filename, 'Integration message request id mismatched');
    }
  }

  think() {
    if (this._isCompleted()) {
      Co(function *() {
        try {
          this.context.user.googleOauthToken = this.context[this.saveContextKey];
          var parser = new GCalParser(this.context.user.googleOauthToken);
          var googleUserEmail = yield parser.getEmail();
          // make sure the email domain match
          if (trim(googleUserEmail) !== this.context.user.email) {
            this.reset();
            var reauthenticationMessage = Util.format('In order to use your calendar with CareerLark, ' +
              'please sign in with %s, the same email that you use for Slack, on your default browser. ' +
              'Make sure to select %s when you authenticate with Google.', this.context.user.email, this.context.user.email);

            this.integrationRequestId = uuid.v1();
            this.requestTokenUrl = this._getOauthTokenUrl();
            googleUrl.shorten(this.requestTokenUrl, (err, url) => {
              if (url && url.length > 0) {
                this.emit(CONSTANTS.BOT_EVENT.MESSAGE, reauthenticationMessage +'\n'+ url);
              }
              else {
                this.emit(CONSTANTS.BOT_EVENT.MESSAGE, reauthenticationMessage +'\n'+ this.requestTokenUrl);
              }
            });

            return;
          }

          yield this.context.user.save();
          this.endAction();
        }
        catch(ex) {
          Logger.error(__filename, 'Failed to save google Oauth token', ex, ex.stack);
          this.endAction();
        }
      }.bind(this))
    }
    else {
      Co(function *() {
        try {
          if ( ! (this.context.user && this.context.user instanceof ModelUser)) {
            this.context.user = yield ModelUser.findBySlackId(this.context.slackUserId);
          }

          // check and see if token is still valid
          if (this.context.user.googleOauthToken) {
            var parser = new GCalParser(this.context.user.googleOauthToken);
            // calling is valid will update context.user.googleOauthToken token
            var isTokenValid = yield parser.isTokenValid();
            if (isTokenValid === true) {
              this.entities[this.saveContextKey] = this.context.user.googleOauthToken;
              this.context[this.saveContextKey] = this.context.user.googleOauthToken;
              this.think();

              // persist user's token
              yield this.context.user.save();

              return;
            }
          }

          this.integrationRequestId = uuid.v1();
          this.requestTokenUrl = this._getOauthTokenUrl();
          googleUrl.shorten(this.requestTokenUrl, (err, url) => {
            if (url && url.length > 0) {
              this.emit(CONSTANTS.BOT_EVENT.MESSAGE, this.message +'\n'+ url);
            }
            else {
              this.emit(CONSTANTS.BOT_EVENT.MESSAGE, this.message +'\n'+ this.requestTokenUrl);
            }
          });
        }
        catch (ex) {
          Logger.error(__filename, 'Failed to generate Google authentication request url', ex, ex.stack);
          this.emit(CONSTANTS.BOT_EVENT.ERROR);
        }
      }.bind(this));
    }
  }
}

module.exports = ActionGoogleCalendarAuthentication;
