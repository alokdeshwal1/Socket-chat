'use strict';

const CONSTANTS = require('./../../constants/constants');
const Util = require('util');
const assert = require('assert');
const Request = require('request');
const Config = require('./../../configs/config');
const BotError = require('./../../errors/bot-error');
const ActionInteractiveMessage = require('./action-interactive-message');
const ModelTrigger = require('./../../models/trigger');
const Co = require('co');
const Logger = require('./../../libs/logger');
const NumberToWords = require('number-to-words');
const WordsToNumber = require('words-to-num');
const RangeValidation = require('./../validations/range');
const YesNoValidation = require('./../validations/yes-no');
const uuid = require('uuid');
const trim = require('trim');

class ActionGatherTriggerType extends ActionInteractiveMessage {

  constructor(message, context, saveContextKey, config, overwrite) {
    super(message, context, saveContextKey || 'trigger', config, overwrite);

    assert(typeof context.slackUserId === 'string', 'Context SlackUserId is missing');

    this.init();
  }

  /**
   * @override
   */
  init() {
    // so that subscriber can subscribe to on event after initialization
    this._setUp(this.message).then(() => {
      setImmediate(() => {
        try {
          super.init() && this.think();
        }
        catch (ex) {
          Logger.error({ex, exStack: ex.stack, object: this}, 'Failed to trigger think method');
          this.emit(CONSTANTS.BOT_EVENT.ERROR);
        }
      })
    })
      .catch(err => {
        this.emit(CONSTANTS.BOT_EVENT.ERROR, err);
      });
  }

  /**
   * @override
   */
  _setUp(message) {
    var parentSetup = super._setUp;

    return new Promise((resolve, reject) => {
      Co(function*() {
        try {
          this.values = yield ModelTrigger.find({
            $and: [
              {'$or': [{company: null}, {status: CONSTANTS.DB.STATUS.ACTIVE}]},
              {'$or': [{company: this.context.companyId}, {status: CONSTANTS.DB.STATUS.ACTIVE}]}
            ]
          }).sort('priority');

          yield parentSetup.call(this, message);

          return resolve(true);
        }
        catch (ex) {
          Logger.error({ex, exStack: ex.stack, 'this': this},
            'ActionGatherGoalCategory failed to generate attachment message');
          return reject(ex);
        }
      }.bind(this));
    });
  }

  /**
   * @override
   */
  addMessage(message, skipSaveContext) {
    message = trim(message.toString());
    if (message === 'keycap_ten') { // take care of emoji 'keycap_ten' (Other)
      message = 'ten';
    }
    if ( ! isNaN(WordsToNumber.convert(message))) {
      message = WordsToNumber.convert(message);
    }

    if (this.currentPage === 0 && this.paging.length > 1 && message == (this.sizePerPage + 1)) {
      this.nextPage();
    }
    else {
      // support 'Yes' 'No' question for ending repeat question
      var validation = new YesNoValidation();
      validation.validate(String(message), this.context)
        .then((data) => {
          if (data.status === 'success' && data.result === 'no') {
            this.context[this.saveContextKey] = 'no';
            this.endAction();
          }
          else {
            super.addMessage(message, skipSaveContext);
          }
        })
        .catch((err) => {
          Logger.error({err, message}, 'Validation throws exception');
        });
    }
  }

  think() {
    if(this._isCompleted()) {
      // convert the selected value to object id
      this.entities[this.state] = this.values[Number(this.entities[this.state]) - 1];
      this.context[this.saveContextKey] = this.entities[this.state];

      this.endAction();
    }
    else {
      this.emitAttachmentMessage(this.toSlackStructure(this.message, 'gather-trigger-type'));
    }
  }
}

module.exports = ActionGatherTriggerType;
