'use strict';

const CONSTANTS = require('./../../constants/constants');
const Util = require('util');
const assert = require('assert');
const Request = require('request');
const Config = require('./../../configs/config');
const BotError = require('./../../errors/bot-error');
const Action = require('./action');
const ModelGoalCategory = require('./../../models/goal-category');
const Co = require('co');
const Logger = require('./../../libs/logger');
const NumberToWords = require('number-to-words');
const WordsToNumber = require('words-to-num');
const FreeFormTextValidation = require('./../validations/free-form-text');
const Helper = require('./../libs/helper');
const uuid = require('uuid');
const trim = require('trim');

class ActionGatherOkrFeedbackComment extends Action {

  static requireAction() {
    return true;
  }

  constructor(message, context, saveContextKey, emojiReaction, overwrite) {
    super(message, context, saveContextKey, emojiReaction, overwrite);

    this.saveContextKey = this.saveContextKey || 'feedbackComment';
    this.requiredEntities = [this.saveContextKey];
    this.state = this.requiredEntities[0];
    this.validator = new FreeFormTextValidation();

    this.init();
  }

  init() {
    // so that subscriber can subscribe to on event after initialization
    setImmediate(() => {
      try {
        super.init() && this.think();
      }
      catch (ex) {
        Logger.error({ex, exStack: ex.stack, object: this}, 'Failed to trigger think method');
        this.emit(CONSTANTS.BOT_EVENT.ERROR);
      }
    });
  }

  think() {
    if (this._isCompleted()) {
      this.endAction();
    }
    else {
      this.emit(CONSTANTS.BOT_EVENT.MESSAGE, this.message);
    }
  }
}

module.exports = ActionGatherOkrFeedbackComment;
