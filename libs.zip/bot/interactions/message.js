'use strict';

const assert = require('assert');
const Action = require('./action');
const CONSTANTS = require('./../../constants/constants');
const uuid = require('node-uuid');

class ActionMessage extends Action {

  constructor(message, context, saveContextKey, emojiReaction, overwrite) {
    super(message, context, saveContextKey, emojiReaction, overwrite);

    this.init();
  }

  init() {
    // so that subscriber can subscribe to on event after initialization
    setImmediate(() => {
      try {
        super.init() && this.think();
      }
      catch (ex) {
        Logger.error({ex, exStack: ex.stack, object: this}, 'Failed to trigger think method');
        this.emit(CONSTANTS.BOT_EVENT.ERROR);
      }
    });
  }

  think() {
    this.postedMessageId = uuid.v1();
    this.on(CONSTANTS.BOT_EVENT.MESSAGE_POSTED, (messageInfo) => {
      if (this.postedMessageId === messageInfo.id) {
        this.endAction();
      }
    });

    this.emit(CONSTANTS.BOT_EVENT.MESSAGE, {
      messageId: this.postedMessageId,
      message: this.message
    });
  }
}

module.exports = ActionMessage;
