'use strict';

const CONSTANTS = require('./../../constants/constants');
const Util = require('util');
const assert = require('assert');
const Request = require('request');
const Config = require('./../../configs/config');
const BotError = require('./../../errors/bot-error');
const Action = require('./action');
const ModelGoalCategory = require('./../../models/goal-category');
const ModelUser = require('./../../models/user');
const Co = require('co');
const Logger = require('./../../libs/logger');
const NumberToWords = require('number-to-words');
const WordsToNumber = require('words-to-num');
const FreeFormTextValidation = require('./../validations/free-form-text');
const uuid = require('uuid');
const trim = require('trim');
const google = require('googleapis');
const OAuth2 = google.auth.OAuth2;
const oauth2Client = new OAuth2(Config.google.clientId, Config.google.clientSecret, Config.baseUrl + '/google/redirect');
const googleUrl = new (require('google-url'))({key: Config.google.apiKey});
const GmailParser = require('./../../libs/gmail-parser');

class ActionGoogleGmailAuthentication extends Action {

  static requireAction() {
    return true;
  }

  constructor(message, context, saveContextKey, emojiReaction, overwrite) {
    super(message, context, saveContextKey, emojiReaction, overwrite);

    this.saveContextKey = this.saveContextKey || 'googleOauthToken';
    this.requiredEntities = ['googleOauthToken'];
    this.state = this.requiredEntities[0];

    this.integrationRequestId = null;
    this.validator = new FreeFormTextValidation();

    this.init();
  }

  init() {
    // so that subscriber can subscribe to on event after initialization
    setImmediate(() => {
      try {
        super.init() && this.think();
      }
      catch (ex) {
        Logger.error({ex, exStack: ex.stack, object: this}, 'Failed to trigger think method');
        this.emit(CONSTANTS.BOT_EVENT.ERROR);
      }
    });
  }

  _getOauthTokenUrl() {
    return oauth2Client.generateAuthUrl(Object.assign({
      state: JSON.stringify({
        fromSlack: true,
        slackUserId: this.context.slackUserId,
        integrationRequestId: this.integrationRequestId
      })
    }, Config.integration.gmail));
  }

  addMessage(message, outcome, skipSaveContext) {
    assert(typeof message === 'object',  'message (Object) is required');
    assert(message.integrationRequestId === this.integrationRequestId, 'Integration message request id mismatched');

    this.entities[this.state] = message.googleOauthToken;
    this.context[this.saveContextKey] = message.googleOauthToken;
    this.think();
  }

  think() {
    if (this._isCompleted()) {
      Co(function *() {
        try {
          this.context.user.googleOauthToken = this.context[this.saveContextKey];
          var parser = new GmailParser(this.context.user.googleOauthToken);
          var googleUser = yield parser.getProfile();
          if (googleUser && googleUser.emailAddress) {
            // make sure the email domain match
            if (trim(googleUser.emailAddress.replace(/.*@/, '')) !== this.context.user.email.replace(/.*@/, '')) {
              this.reset();
              var reauthenticationMessage = 'CareerLark only supports your work email/calendar. ' +
                'Please re-authenticate using the same email you use for Slack.';

              this.integrationRequestId = uuid.v1();
              this.requestTokenUrl = this._getOauthTokenUrl();
              googleUrl.shorten(this.requestTokenUrl, (err, url) => {
                if (url && url.length > 0) {
                  this.emit(CONSTANTS.BOT_EVENT.MESSAGE, reauthenticationMessage +'\n'+ url);
                }
                else {
                  this.emit(CONSTANTS.BOT_EVENT.MESSAGE, reauthenticationMessage +'\n'+ this.requestTokenUrl);
                }
              });

              return;
            }
          }

          yield this.context.user.save();
          this.endAction();
        }
        catch(ex) {
          Logger.error(__filename, 'Failed to save google Oauth token', ex, ex.stack);
          this.endAction();
        }
      }.bind(this))
    }
    else {
      Co(function *() {
        try {
          if ( ! (this.context.user && this.context.user instanceof ModelUser)) {
            this.context.user = yield ModelUser.findBySlackId(this.context.slackUserId);
          }

          // check and see if token is still valid
          if (this.context.user.googleOauthToken) {
            var parser = new GmailParser(this.context.user.googleOauthToken);
            var isTokenValid = yield parser.isTokenValid();
            if (isTokenValid === true) {
              this.entities[this.saveContextKey] = this.context.user.googleOauthToken;
              this.context[this.saveContextKey] = this.context.user.googleOauthToken;
              this.think();

              // persist user's token
              yield this.context.user.save();

              return;
            }
          }

          this.integrationRequestId = uuid.v1();
          this.requestTokenUrl = this._getOauthTokenUrl();
          googleUrl.shorten(this.requestTokenUrl, (err, url) => {
            if (url && url.length > 0) {
              this.emit(CONSTANTS.BOT_EVENT.MESSAGE, this.message +'\n'+ url);
            }
            else {
              this.emit(CONSTANTS.BOT_EVENT.MESSAGE, this.message +'\n'+ this.requestTokenUrl);
            }
          });
        }
        catch(ex) {
          Logger.error(__filename, 'Failed to generate Gmail request url', ex, ex.stack);
          this.emit(CONSTANTS.BOT_EVENT.ERROR, ex);
        }
      }.bind(this));
    }
  }
}

module.exports = ActionGoogleGmailAuthentication;
