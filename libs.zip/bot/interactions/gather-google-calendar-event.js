'use strict';

const CONSTANTS = require('./../../constants/constants');
const Util = require('util');
const assert = require('assert');
const Request = require('request');
const Config = require('./../../configs/config');
const BotError = require('./../../errors/bot-error');
const Action = require('./action');
const ModelTrigger = require('./../../models/trigger');
const Co = require('co');
const Logger = require('./../../libs/logger');
const NumberToWords = require('number-to-words');
const WordsToNumber = require('words-to-num');
const YesNoValidation = require('./../validations/yes-no');
const GatherUserValidation = require('./../validations/gather-user');
const RecurrenceDateValidation = require('./../validations/recurrence-date');
const trim = require('trim');
const ParserCalendar = require('./../parsers/calendar-command-parser');
const GCalParser = require('./../../libs/google-calendar-parser');
const ModelUser = require('./../../models/user');
const fuzzy = require('fuzzy');
const moment = require('moment');
const RRule = require('rrule').RRule;
const uuid = require('uuid');

class ActionGatherGoogleCalendarEvent extends Action {

  static requireAction() {
    return true;
  }

  constructor(message, context, saveContextKey, emojiReaction, overwrite) {
    super(message, context, saveContextKey, emojiReaction, overwrite);

    assert(typeof context.slackUserId === 'string', 'Context SlackUserId (String) is missing');
    assert(typeof context.googleOauthToken === 'object', 'Context googleOauthToken (Object) is missing');

    this.saveContextKey = this.saveContextKey || 'googleCalendarTrigger';
    this.requiredEntities = ['googleCalendarTrigger', 'confirmation'];
    this.state = this.requiredEntities[0];
    this.isRepeat = false;

    try {
      this.languageParser = new ParserCalendar();
      this.gcalParser = new GCalParser(context.googleOauthToken);
    }
    catch (ex) {
      Logger.error({ex, exStack: ex.stack, object: this}, 'Failed to initialize wit.ai / GCalParser using the context token');
      throw ex;
    }

    this.init();
  }

  init() {
    // so that subscriber can subscribe to on event after initialization
    setImmediate(() => {
      try {
        super.init() && this.think();
      }
      catch (ex) {
        Logger.error({ex, exStack: ex.stack, object: this}, 'Failed to trigger think method');
        this.emit(CONSTANTS.BOT_EVENT.ERROR);
      }
    });
  }

  addMessage(message, outcome) {
    if (this.state === this.requiredEntities[1]) {
      this.validator = new YesNoValidation();
      super.addMessage(message, outcome, true /* dont save context */);
    }
    else {
      var parentAddMessage = super.addMessage;
      Co(function *() {
        try {
          if ( ! (this.context.user && this.context.user instanceof ModelUser)) {
            this.context.user = yield ModelUser.findBySlackId(this.context.slackUserId);
          }
          const outcome = yield this.languageParser.process(message);
          if (Object.keys(outcome).length < 1) {
            this.emit(CONSTANTS.BOT_EVENT.MESSAGE, 'Sorry, I don\'t quite understand what you said :disappointed:.');
            return;
          }

          const criteria = yield this._getSearchCriteria(this.context.slackUserId, outcome);
          var events;
          if (criteria && typeof criteria === 'object') {
            events = yield this.gcalParser.findEvents(criteria);
          }
          if (events && Array.isArray(events) && events.length > 0) {
            parentAddMessage.call(this, {
              criteria: criteria,
              events: events,
              text: message
            });
          }
          else {
            this.emit(CONSTANTS.BOT_EVENT.MESSAGE, 'Sorry. I couldn\'t find any meetings that match your search :disappointed:. Please try another search');
          }
        }
        catch (ex) {
          Logger.error(__filename, 'Failed to parse user string against Google Calendar API', ex, ex.stack);
          this.emit(CONSTANTS.BOT_EVENT.ERROR);
        }

      }.bind(this));
    }
  }

  think() {
    try {
      if(this._isCompleted()) {
        if (this.entities[this.requiredEntities[1]] === 'yes') {
          this.postedMessageId = uuid.v1();
          this.emit(CONSTANTS.BOT_EVENT.MESSAGE, {
            messageId: this.postedMessageId,
            message: 'Got it!'
          });
          this.on(CONSTANTS.BOT_EVENT.MESSAGE_POSTED, (messageInfo) => {
            if (this.postedMessageId !== messageInfo.messageId) {
              return;
            }
            this.endAction();
          });
        }
        else {
          this.state = this.requiredEntities[0];
          delete this.context[this.saveContextKey];
          delete this.validator;
          this.isRepeat = true;
          this.entities = {};
          this.think();
        }
      }
      else if (this.state === this.requiredEntities[1]) {
        var outputString = this.entities[this.requiredEntities[0]].events.map(item => {
            if (item.recurrence && Array.isArray(item.recurrence) && item.recurrence.length > 0) {
              var occurences = [];
              item.recurrence.forEach(occur => {
                try {
                  var rule = new RRule(RRule.parseString(occur.replace('RRULE:', '')));
                  occurences.push(rule.toText());
                }
                catch (ex) {
                  Logger.error('Failed to parse RRule', ex, ex.stack);
                }
              });

              return Util.format('%s\n _occurs %s at %s_', item.summary, occurences.join('\n'),
                moment(item.start.dateTime).tz(this.context.user.timezone).format('h:mmA'));
            }
            else {
              return moment(item.start.dateTime).tz(this.context.user.timezone).format('M/D dddd h:mmA') +' '+ item.summary;
            }
          }) || [];

        if (outputString.length > 3) {
          outputString = outputString.slice(0, 3);
          outputString.push('_...and more..._');
        }

        var attachmentMessage = [{
          'fallback': 'Cool. Here\'s what I see that matches. Look right?',
          'color': Config.botAttachmentMessageColor.action,
          'pretext': 'Cool. Here\'s what I see that matches. Look right?',
          'mrkdwn_in': ['fields', 'pretext'],
          'fields': [
            {
              value: outputString.join('\n')
            }
          ]
        }];
        this.emit(CONSTANTS.BOT_EVENT.ATTACHMENT_MESSAGE, attachmentMessage);
      }
      else {
        if (this.isRepeat) {
          this.emit(CONSTANTS.BOT_EVENT.MESSAGE, 'Ok, Let\'s try that again. Here are the types of things that ' +
            'I understand (I\'m working on it but I\'m a bot after all :simple_smile:)\n' +
            '`organized by Katie`\n' +
            '`has more than 5 people`\n' +
            '`has attendees richard erlich and ashley`\n' +
            '`name has product sync`');
        }
        else {
          var message = this.message;
          if (this.context.isGatheredCalendarAuthentication) {
            message = 'Success! :tada: We\'re connected. ' + message;
          }
          this.emit(CONSTANTS.BOT_EVENT.MESSAGE, message);
        }
      }
    }
    catch(ex) {
      Logger.error('Error generating Google Calendar Events think method', ex, ex.stack);
      this.emit(CONSTANTS.BOT_EVENT.ERROR);
    }
  }

  _getSearchCriteria(slackUserId, outcome) {
    return new Promise((resolve, reject) => {
      Co(function *() {
        try {
          const criteria = {};
          if (outcome) {
            const user = yield ModelUser.findBySlackId(slackUserId);
            const allUsers = yield ModelUser.find({slackIntegration: user.slackIntegration, status: CONSTANTS.DB.STATUS.ACTIVE});
            const list = allUsers.map(item => {
              return {
                name: item.firstName +' '+ item.lastName,
                email: item.email,
                slackUserId: item.slackUserId
              };
            });

            if (outcome.numberOfAttendees && outcome.numberOfAttendees.total) {
              criteria.minNumberOfAttendees = outcome.numberOfAttendees.total;
              criteria.numberOfAttendees = outcome.numberOfAttendees;
            }

            if (outcome.title) {
              criteria.meetingTitle = Array.isArray(outcome.title) ? outcome.title[0] : outcome.title;
            }

            if (outcome.organizer) {
              if (trim(outcome.organizer[0].toLowerCase()) === 'me') {
                criteria.organizerEmail = user.email;
              }
              else if (outcome.organizer[0].indexOf('<@') === 0) {
                var userValidation = new GatherUserValidation();
                var users = yield userValidation.validate(outcome.organizer[0], {user: user});
                if (users && users.result && users.result[0] && users.result[0].email) {
                  criteria.organizerEmail = users.result[0].email;
                }
              }
              else {
                var results = fuzzy.filter(outcome.organizer[0], list, { extract: (el) => { return el.name }});
                if (results && results[0] && results[0].score >= 50) {
                  criteria.organizerEmail = results[0].original.email;
                }
              }
            }

            if (outcome.attendees && Array.isArray(outcome.attendees)) {
              for(let item of outcome.attendees) {
                criteria.attendeeEmails = criteria.attendeeEmails || [];
                if (trim(item.toLowerCase()) === 'me') {
                  criteria.attendeeEmails.push(user.email);
                }
                else if (item.indexOf('<@') === 0) {
                  var userValidation = new GatherUserValidation();
                  var users = yield userValidation.validate(item, {user: user});
                  if (users && users.result && users.result[0] && users.result[0].email) {
                    criteria.attendeeEmails.push(users.result[0].email);
                  }
                }
                else {
                  var results = fuzzy.filter(item, list, { extract: (el) => { return el.name }});
                  if (results && results[0] && results[0].score >= 50) {
                    criteria.attendeeEmails = criteria.attendeeEmails || [];
                    criteria.attendeeEmails.push(results[0].original.email);
                  }
                }
              }
            }
          }

          return resolve((Object.keys(criteria).length > 0) ? criteria : null);
        }
        catch(ex) {
          Logger.error('Failed to parse outcome', ex, ex.stack);
          return reject(ex);
        }
      });
    });
  }
}

module.exports = ActionGatherGoogleCalendarEvent;
