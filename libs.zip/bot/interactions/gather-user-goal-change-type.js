'use strict';

const CONSTANTS = require('./../../constants/constants');
const Util = require('util');
const assert = require('assert');
const Request = require('request');
const Config = require('./../../configs/config');
const BotError = require('./../../errors/bot-error');
const Action = require('./action');
const ActionListChoices = require('./action-list-choices');
const ModelGoal = require('./../../models/goal');
const ModelUser = require('./../../models/user');
const Co = require('co');
const Logger = require('./../../libs/logger');
const NumberToWords = require('number-to-words');
const WordsToNumber = require('words-to-num');
const RangeValidation = require('./../validations/range');
const uuid = require('uuid');
const trim = require('trim');
const ModelUserGoal = require('./../../models/user-goal');
const ModelUserTrigger = require('./../../models/user-trigger');

class ActionGatherUserGoalChangeType extends Action {

  static requireAction() {
    return true;
  }

  constructor(message, context, saveContextKey, emojiReaction, overwrite) {
    super(message, context, saveContextKey || 'selectedUserGoal', emojiReaction, overwrite);

    assert(typeof context.selectedUserGoal === 'object', 'Context selectedUserGoal (object) is required');

    this.saveContextKey = this.saveContextKey || 'userGoalChangeType';
    this.requiredEntities = [this.saveContextKey];
    this.state = this.requiredEntities[0];

    this.init();
  }

  init() {
    // so that subscriber can subscribe to on event after initialization
    this._setUp(this.message).then(() => {
      setImmediate(() => {
        try {
          super.init() && this.think();
        }
        catch (ex) {
          Logger.error(ex, ex.stack);
          this.emit(CONSTANTS.BOT_EVENT.ERROR);
        }
      });
    })
    .catch(err => {
      this.emit(CONSTANTS.BOT_EVENT.ERROR, err);
    });
  }

  _setUp(message) {
    return new Promise((resolve, reject) => {
      Co(function*() {
        try {
          context.userGoal = yield ModelUserGoal.findOne({ _id: context.selectedUserGoal.id }).populate('goal advisors');
          const userTriggers = yield ModelUserTrigger.findActiveUserTrigger({userGoal: context.userGoal.id});

          this.message = [{
            'fallback': 'Which prompt should I delete?',
            'color': Config.botAttachmentMessageColor.action,
            'pretext': originalMessage,
            "fields": [
              {
                title: 'Goal',
                value: context.userGoal.goal && context.userGoal.goal.name || context.userGoal.name
              },
              {
                title: 'Trigger',
                value: userTriggers.map(item => {
                  return Util.format('%s %s %s', item.trigger.name);
                }).join('\n')
              }
            ]
          }];

          this.validator = new RangeValidation(this.allowedValues);

          return resolve(true);
        }
        catch (ex) {
          Logger.error(__filename, 'ActionGatherGoalCategory failed to generate attachment message', ex, ex.stack);
          return reject(ex);
        }
      }.bind(this));
    });
  }

  think() {
    if(this._isCompleted()) {
      if ( ! (this.entities[this.state] === 'Other' || this.entities[this.state] === 'no')) {
        // convert the selected value to object id
        this.entities[this.state] = this.goalCategories[Number(this.entities[this.state]) - 1];
        this.context[this.saveContextKey] = this.entities[this.state];
        this.context['goalCategoryName'] = this.entities[this.state].name;
      }

      this.endAction();
    }
    else {
      this.emojiReactionMessageId = this.emitAndId(CONSTANTS.BOT_EVENT.ATTACHMENT_MESSAGE, {
        message: this.message,
        emojiReaction: this.emojiReaction
      });
    }
  }
}

module.exports = ActionGatherUserGoalChangeType;
