'use strict';

const CONSTANTS = require('./../../constants/constants');
const Util = require('util');
const assert = require('assert');
const Request = require('request');
const Config = require('./../../configs/config');
const BotError = require('./../../errors/bot-error');
const BotMessages = require('./../../configs/bot-messages');
const Action = require('./action');
const ActionInteractiveMessage = require('./action-interactive-message');
const ModelGoal = require('./../../models/goal');
const ModelUser = require('./../../models/user');
const Co = require('co');
const Logger = require('./../../libs/logger');
const NumberToWords = require('number-to-words');
const WordsToNumber = require('words-to-num');
const RangeValidation = require('./../validations/range');
const uuid = require('uuid');
const trim = require('trim');
const ModelUserGoal = require('./../../models/user-goal');

class ActionGatherUserGoal extends ActionInteractiveMessage {

  constructor(message, context, saveContextKey, config, overwrite) {
    super(message, context, saveContextKey || 'selectedUserGoal', config, overwrite);

    this.init();
  }

  /**
   * @override
   */
  init() {
    // so that subscriber can subscribe to on event after initialization
    this._setUp(this.message).then(() => {
      setImmediate(() => {
        try {
          super.init() && this.think();
        }
        catch (ex) {
          Logger.error(ex, ex.stack);
          this.emit(CONSTANTS.BOT_EVENT.ERROR);
        }
      });
    })
    .catch(err => {
      this.emit(CONSTANTS.BOT_EVENT.ERROR, err);
    });
  }

  /**
   * @override
   */
  _setUp(message) {
    var parentSetup = super._setUp;

    return new Promise((resolve, reject) => {
      Co(function *() {
        try {
          if ( ! (this.context.user && this.context.user instanceof ModelUser)) {
            this.context.user = yield ModelUser.findBySlackId(this.context.slackUserId);
          }
          this.values = yield ModelUserGoal.findUserGoalsByUserId(this.context.user.id);
          this.values = this.values.filter(item => { return ! item.isGeneral });
          if ( ! (this.values && Array.isArray(this.values) && this.values.length > 0)) {
            setImmediate(() => {
              this.emitMessage(this.message.noValueError);
              this.emit(CONSTANTS.BOT_EVENT.END_TASK);
            });
            return resolve(true);
          }

          this.values = this.values.map(item => {
            return {
              id: item.id,
              name: item.goal && item.goal.name || item.name
            };
          });

          yield parentSetup.call(this, message);

          return resolve(true);
        }
        catch (ex) {
          Logger.error({ex, exStack: ex.stack, 'this': this},
            'ActionGatherUserGoal failed to generate attachment message');
          return reject(ex);
        }
      }.bind(this));

    });
  }

}

module.exports = ActionGatherUserGoal;
