'use strict';

const EventEmitter = require('events').EventEmitter;
const CONSTANTS = require('./../../constants/constants');
const Util = require('util');
const assert = require('assert');
const BotMessages = require('./../../configs/bot-messages');
const BotError = require('./../../errors/bot-error');
const Logger = require('./../../libs/logger');
const Task = require('./../task');
const uuid = require('node-uuid');
const Serialization = require('./../libs/serialization');

class Action extends EventEmitter {

  constructor(message, context, saveContextKey, config, overwrite) {
    super();

    this.message = message;
    this.context = context;
    this.saveContextKey = saveContextKey;
    this.config = config || {};
    this.entities = {};
    this.requiredEntities = config && config.requiredEntities || [this.saveContextKey];
    this.isEnded = false;
    this.overwrite = overwrite || true;
  }

  init() {
    // if data was already collected, let's end this
    if (! this.overwrite &&
          this.saveContextKey &&
        ! (this.context[this.saveContextKey] === null || this.context[this.saveContextKey] === undefined))
    {

      this.endAction();
      return false;
    }

    return true;
  }

  setSkipParser(value) {
    this.skipParser = value;
  }

  addMessage(message, skipSaveContext) {
    if ( ! this.validator) {
      Logger.warn(__filename, '%s has no validator', this.constructor.name);
      this.entities[this.state] = message;
      if ( ! skipSaveContext) {
        this.context[this.saveContextKey] = message;
      }
      var next = this._nextEntity();
      if(next) {
        this.state = next;
      }
      this.think();
      return;
    }

    this.validator.validate(message, this.context)
      .then((data) => {
        if (data.status === 'success') {
          this.entities[this.state] = data.result;
          if ( ! skipSaveContext) {
            this.context[this.saveContextKey] = data.result;
          }
          var next = this._nextEntity();
          if(next) {
            this.state = next;
          }
          this.think();
        }
        else {
          this.emit('message', data.error);
        }
      })
      .catch((err) => {
        Logger.error({err, 'this': this}, 'Validation throws exception');
      });
  }

  endAction() {
    // ensure event is fired once only
    if ( ! this.isEnded) {
      this.isEnded = true;
      this.emit(CONSTANTS.BOT_EVENT.END);
    }
  }

  reset() {
    this.entities = {};
    this.requiredEntities = [];
    this.isEnded = false;
    delete this.context[this.saveContextKey];
    delete this.attachmentMessageInfo;
    delete this.postedEmojis;
  }

  emitAttachmentMessage(params) {
    return this.emitAndId(CONSTANTS.BOT_EVENT.ATTACHMENT_MESSAGE, {message: Array.isArray(params) ? params : [params]});
  }

  emitMessage(params) {
    return this.emitAndId(CONSTANTS.BOT_EVENT.MESSAGE, params);
  }

  emitAndId(type, params) {
    var emitTs = + (new Date());
    var messageId = uuid.v1();
    if (typeof params === 'string') {
      params = {
        message: params
      }
    }
    this.emit(type, Object.assign({id: messageId, emitTs: emitTs}, params));
    return messageId;
  }

  _isCompleted() {
    var isCompleted = true;
    for(var i = 0; i < this.requiredEntities.length; i ++) {
      var value = this.entities[this.requiredEntities[i]];
      if(typeof value === 'undefined' || value === null) {
        isCompleted = false;
        break;
      }
    }
    return isCompleted;
  }

  _nextEntity() {
    var currentIndex = this.requiredEntities.indexOf(this.state);
    return (currentIndex + 1 >= this.requiredEntities.length) ? undefined : this.requiredEntities[currentIndex + 1];
  }

  toJSON() {
    return Serialization.toJSON.apply(this);
  }
}

module.exports = Action;
