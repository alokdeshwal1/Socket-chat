'use strict';

const CONSTANTS = require('./../../constants/constants');
const Util = require('util');
const assert = require('assert');
const Request = require('request');
const Config = require('./../../configs/config');
const BotError = require('./../../errors/bot-error');
const Action = require('./action');
const ActionInteractiveMessage = require('./action-interactive-message');
const ModelGoalCategory = require('./../../models/goal-category');
const Co = require('co');
const Logger = require('./../../libs/logger');
const NumberToWords = require('number-to-words');
const WordsToNumber = require('words-to-num');
const RangeValidation = require('./../validations/range');
const YesNoValidation = require('./../validations/yes-no');
const uuid = require('uuid');
const trim = require('trim');

class ActionGatherGoalCategory extends ActionInteractiveMessage {

  static requireAction() {
    return true;
  }

  constructor(message, context, saveContextKey, config, overwrite) {
    super(message, context, saveContextKey || 'goalCategory', config, overwrite);

    assert(typeof context.companyId === 'string', 'Context CompanyId is missing');
    assert(typeof context.companyName === 'string', 'Context CompanyName is missing');

    this.init();
  }

  /**
   * @override
   */
  init() {
    // so that subscriber can subscribe to on event after initialization
    this._setUp(this.message).then(() => {
      setImmediate(() => {
        try {
          super.init() && this.think();
        }
        catch (ex) {
          Logger.error({ex, exStack: ex.stack, object: this}, 'Failed to trigger think method');
          this.emit(CONSTANTS.BOT_EVENT.ERROR);
        }
      })
    })
    .catch(err => {
      this.emit(CONSTANTS.BOT_EVENT.ERROR, err);
    });
  }

  /**
   * @override
   */
  _setUp(message) {
    var parentSetup = super._setUp;

    return new Promise((resolve, reject) => {
      Co(function*() {
        try {
          this.values = yield ModelGoalCategory.getCategories(this.context.function.id, this.context.companyId);
          yield parentSetup.call(this, message);

          return resolve(true);
        }
        catch (ex) {
          Logger.error({ex, exStack: ex.stack, 'this': this},
            'ActionGatherGoalCategory failed to generate attachment message');
          return reject(ex);
        }
      }.bind(this));
    });
  }

  /**
   * @override
   */
  addMessage(message, outcome) {
    message = trim(message);

    if (message === 'keycap_ten') {
      message = 'ten';
    }
    if ( ! isNaN(WordsToNumber.convert(message))) {
      message = WordsToNumber.convert(message);
    }

    if (this.currentPage === 0 && this.paging.length > 1 && message == (this.sizePerPage + 1)) {
      this.nextPage();
    }
    else {
      if (String(message).toLowerCase() === 'other') {
        this.entities[this.state] = 'Other';
        this.context[this.saveContextKey] = 'Other';
        this.think();
      }
      else {
        // support 'Yes' 'No' question for ending repeat question
        var validation = new YesNoValidation();
        validation.validate(String(message), this.context)
          .then((data) => {
            if (data.status === 'success' && data.result === 'no') {
              this.context[this.saveContextKey] = 'no';
              this.endAction();
            }
            else {
              super.addMessage(message, outcome);
            }
          })
          .catch((err) => {
            Logger.error({err}, 'Validation throws exception:');
          });
      }
    }
  }

  think() {
    try {
      if(this._isCompleted()) {
        if ( ! (this.entities[this.state] === 'Other' || this.entities[this.state] === 'no')) {
          // convert the selected value to object id
          this.entities[this.state] = this.values[Number(this.entities[this.state]) - 1];
          this.context[this.saveContextKey] = this.entities[this.state];
          this.context['goalCategoryName'] = this.entities[this.state].name;
        }

        this.endAction();
      }
      else {
        this.emitAttachmentMessage(this.toSlackStructure(this.message, 'gather-goal-category'));
      }
    }
    catch (ex) {
      Logger.error({ex, exStack: ex.stack}, 'Error generating Gather Goal Category think method');
      this.emit(CONSTANTS.BOT_EVENT.ERROR);
    }
  }
}

module.exports = ActionGatherGoalCategory;
