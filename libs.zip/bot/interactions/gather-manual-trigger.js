'use strict';

const CONSTANTS = require('./../../constants/constants');
const Util = require('util');
const assert = require('assert');
const Request = require('request');
const Config = require('./../../configs/config');
const BotError = require('./../../errors/bot-error');
const Action = require('./action');
const ModelTrigger = require('./../../models/trigger');
const ModelUser = require('./../../models/user');
const Co = require('co');
const Logger = require('./../../libs/logger');
const NumberToWords = require('number-to-words');
const WordsToNumber = require('words-to-num');
const YesNoValidation = require('./../validations/yes-no');
const ValidationRecurrenceDate = require('./../validations/recurrence-date');
const trim = require('trim');
const uuid = require('uuid');

class ActionGatherManualTrigger extends Action {

  static requireAction() {
    return true;
  }

  constructor(message, context, saveContextKey, emojiReaction, overwrite) {
    super(message, context, saveContextKey, emojiReaction, overwrite);

    assert(typeof context.slackUserId === 'string', 'Context SlackUserId (String) is missing');

    this.saveContextKey = this.saveContextKey || 'manualTrigger';
    this.requiredEntities = ['manualTrigger', 'confirmation'];
    this.state = this.requiredEntities[0];

    Co(function *() {
      try {
        // we need to get user's timezone
        if ( ! (context.user && context.user instanceof ModelUser)) {
          context.user = yield ModelUser.findBySlackId(context.slackUserId);
        }
        this.timezone = context.user.timezone;
        this.validator = new ValidationRecurrenceDate(this.timezone);
        this.init();
      }
      catch(ex) {
        this.emit(CONSTANTS.BOT_EVENT.ERROR, ex);
      }
    }.bind(this));
  }

  init() {
    // so that subscriber can subscribe to on event after initialization
    setImmediate(() => {
      try {
        super.init() && this.think();
      }
      catch (ex) {
        Logger.error({ex, exStack: ex.stack, object: this}, 'Failed to trigger think method');
        this.emit(CONSTANTS.BOT_EVENT.ERROR);
      }
    });
  }

  addMessage(message) {
    if (this.state === this.requiredEntities[1]) {
      this.validator = new YesNoValidation();
      super.addMessage(message, true /* dont save context */);
    }
    else {
      this.validator = new ValidationRecurrenceDate(this.timezone);
      super.addMessage(message);
    }
  }

  think() {
    if(this._isCompleted()) {
      if (this.entities[this.requiredEntities[1]] === 'yes') {
        this.postedMessageId = uuid.v1();
        this.emit(CONSTANTS.BOT_EVENT.MESSAGE, {
          messageId: this.postedMessageId,
          message: 'Got it!'
        });

        this.endAction();
      }
      else {
        this.state = this.requiredEntities[0];
        delete this.context[this.saveContextKey];
        this.entities = {};
        this.think();
      }
    }
    else if (this.state === this.requiredEntities[1]) {
      var attachmentMessage = [{
        'fallback': 'Cool, this is what I have. Sound good? Say `yes` or `no`',
        'color': Config.botAttachmentMessageColor.action,
        'pretext': 'Cool, this is what I have. Sound good? Say `yes` or `no`',
        'mrkdwn_in': ['fields', 'pretext'],
        "fields": [
          {
            value: this.entities[this.requiredEntities[0]].sampleDates.join('\n')
          }
        ]
      }];
      this.emit(CONSTANTS.BOT_EVENT.ATTACHMENT_MESSAGE, attachmentMessage);
    }
    else {
      this.emit(CONSTANTS.BOT_EVENT.MESSAGE, this.message);
    }
  }
}

module.exports = ActionGatherManualTrigger;
