'use strict';

const CONSTANTS = require('./../../constants/constants');
const Util = require('util');
const assert = require('assert');
const Request = require('request');
const Config = require('./../../configs/config');
const BotError = require('./../../errors/bot-error');
const ActionInteractiveMessage = require('./action-interactive-message');
const ModelGoal = require('./../../models/goal');
const Co = require('co');
const Logger = require('./../../libs/logger');
const NumberToWords = require('number-to-words');
const WordsToNumber = require('words-to-num');
const RangeValidation = require('./../validations/range');
const uuid = require('uuid');
const trim = require('trim');

class ActionGatherGoalCompetency extends ActionInteractiveMessage {

  static requireAction() {
    return true;
  }

  constructor(message, context, saveContextKey, config, overwrite) {
    super(message, context, saveContextKey || 'goalCompetency', config, overwrite);

    assert(typeof context.companyId === 'string', 'Context CompanyId (String) is missing');
    assert(typeof context.companyName === 'string', 'Context CompanyName (String) is missing');
    assert(typeof context.goalCategory === 'object', 'Context GoalCategory (Object) is missing');

    this.init();
  }

  /**
   * @override
   */
  init() {
    // so that subscriber can subscribe to on event after initialization
    this._setUp(this.message).then(() => {
      setImmediate(() => {
        try {
          super.init() && this.think();
        }
        catch (ex) {
          Logger.error({ex, exStack: ex.stack, object: this}, 'Failed to trigger think method');
          this.emit(CONSTANTS.BOT_EVENT.ERROR);
        }
      })
    })
    .catch(err => {
      this.emit(CONSTANTS.BOT_EVENT.ERROR, err);
    });
  }

  /**
   * @override
   */
  _setUp(message) {
    var parentSetup = super._setUp;

    return new Promise((resolve, reject) => {
      Co(function*() {
        try {
          this.values = yield ModelGoal.find({
            company: this.context.companyId,
            status: CONSTANTS.DB.STATUS.ACTIVE,
            goalCategory: this.context.goalCategory._id,
            name: {'$ne': 'Other' }
          }).sort('priority');

          if ( ! (this.values && Array.isArray(this.values) && this.values.length > 0)) {
            this.values = yield ModelGoal.find({
              status: CONSTANTS.DB.STATUS.ACTIVE,
              goalCategory: this.context.goalCategory._id,
              company: null,
              name: {'$ne': 'Other' }
            }).sort('priority');
          }

          yield parentSetup.call(this, message);

          return resolve(true);
        }
        catch (ex) {
          Logger.error({ex, exStack: ex.stack, 'this': this},
            'ActionGatherGoalCompetency failed to generate attachment message');
          return reject(ex);
        }
      }.bind(this));
    });
  }

  think() {
    try {
      if(this._isCompleted()) {
        if (! isNaN(Number(this.entities[this.state]))) {
          // convert the selected value to object id
          this.entities[this.state] = this.values[Number(this.entities[this.state]) - 1];
          this.context[this.saveContextKey] = this.entities[this.state];
        }

        this.endAction();
      }
      else {
        this.emitAttachmentMessage(this.toSlackStructure(this.message, 'gather-goal-competency'));
      }
    }
    catch (ex) {
      Logger.error({ex, exStack: ex.stack}, 'Error generating Gather Goal Competency think method');
      this.emit(CONSTANTS.BOT_EVENT.ERROR);
    }
  }
}

module.exports = ActionGatherGoalCompetency;
