'use strict';

const assert = require('assert');
const Action = require('./action');
const Logger = require('./../../libs/logger');
const CONSTANTS = require('./../../constants/constants');

class ActionDirectMessage extends Action{

  constructor(message, context, saveContextKey, emojiReaction, overwrite) {
    super(message, context, saveContextKey, emojiReaction, overwrite);
    this.init();
  }

  init() {
    // so that subscriber can subscribe to on event after initialization
    setImmediate(() => {
      try {
        super.init() && this.think();
      }
      catch (ex) {
        Logger.error({ex, exStack: ex.stack, object: this}, 'Failed to trigger think method');
        this.emit(CONSTANTS.BOT_EVENT.ERROR);
      }
    });
  }

  think() {
    this.emit('directMessage', {
      slackUserId: this.context.slackUserId,
      message: this.context.message
    });
    this.endAction();
  }
}

module.exports = ActionDirectMessage;
