'use strict';

const CONSTANTS = require('./../../constants/constants');
const Util = require('util');
const assert = require('assert');
const Request = require('request');
const Config = require('./../../configs/config');
const BotError = require('./../../errors/bot-error');
const Action = require('./action');
const ModelGoal = require('./../../models/goal');
const Co = require('co');
const Logger = require('./../../libs/logger');
const NumberToWords = require('number-to-words');
const WordsToNumber = require('words-to-num');
const RangeValidation = require('./../validations/range');
const uuid = require('uuid');
const trim = require('trim');

class ActionListChoices extends Action {

  static requireAction() {
    return true;
  }

  constructor(message, context, saveContextKey, emojiReaction, overwrite) {
    super(message, context, saveContextKey, emojiReaction, overwrite);

    assert(typeof context.slackUserId === 'string', 'Context slackUserId (String) is missing');

    this.requiredEntities = [this.saveContextKey];
    this.state = this.requiredEntities[0];
    this.emojiReaction = [];
    this.sizePerPage = 9;
    this.values = this.values || [];

    this.options = [];
    this.allowedValues = [];
    this.paging = [];
    this.currentPage = 0;
  }

  _setUp(message) {
    return new Promise((resolve, reject) => {
      Co(function*() {
        try {
          const originalMessage = message;
          const fields = [];

          if (Array.isArray(this.values)) {
            this.values.forEach((item, key) => {
              var emoji;
              var selectionNumber = ++key;
              if (selectionNumber < 10) {
                emoji = ':'+ NumberToWords.toWords(selectionNumber) +':';
                this.emojiReaction.push(emoji);
              }
              else {
                emoji = selectionNumber + '. ';
              }
              this.options.push(emoji +' '+ item.name);
              this.allowedValues.push(key);
            });
          }
          this.paging.push(this.options.slice(0, this.sizePerPage));
          this.paging.push(this.options.slice(this.sizePerPage));
          if(this.paging.length > 1 && this.paging[1] && this.paging[1].length > 0) {
            this.paging[0].push(':keycap_ten: ' + ( this.nextPageTitle || 'Other' ));
            this.emojiReaction.push(':keycap_ten:');
          }

          var fieldSetting = {
            value: this.paging[this.currentPage].join('\n') +
            '\n\n' +
            (this.footerText || 'Pick one by tapping on a reaction:')
          };

          if (this.fieldTitle) {
            fieldSetting.title = this.fieldTitle
          }

          this.message = [{
            'fallback': this.fallbackMessage,
            'color': Config.botAttachmentMessageColor.action,
            'pretext': originalMessage,
            'mrkdwn_in': ['fields', 'pretext'],
            'fields': [fieldSetting]
          }];

          this.validator = new RangeValidation(this.allowedValues);

          return resolve(true);
        }
        catch (ex) {
          Logger.error(__filename, 'ActionListChoice failed to generate attachment message', ex, ex.stack);
          return reject(ex);
        }
      }.bind(this));
    });
  }

  addEmojiMessage(message, outcome) {
    this.addMessage(message, outcome);
  }

  _deleteEmojis(message) {
    if (Array.isArray(this.emojiReaction)) {
      var deleteEmojis = this.emojiReaction.filter(emoji => {
        emoji = emoji.replace(/:/ig, '');
        if (message == 10) {
          return emoji !== 'keycap_ten';
        }
        else {
          return emoji !== NumberToWords.toWords(message);
        }
      });

      // delete the rest of emojis
      this.emit(CONSTANTS.BOT_EVENT.REMOVE_EMOJI_REACTION, {id: this.emojiReactionMessageId, emojis: deleteEmojis});
    }
  }

  nextPage() {
    this.currentPage++;
    var attachmentMessage = [{
      'fallback': 'OK, is it one of these?',
      'color': Config.botAttachmentMessageColor.action,
      'pretext': 'OK, is it one of these?',
      'mrkdwn_in': ['fields', 'pretext'],
      "fields": [
        {
          value: this.paging[this.currentPage].join('\n') +
          '\n\n' +
          'Pick any option from 1-'+ this.allowedValues.length +'.'
        }
      ]
    }];
    this.emit(CONSTANTS.BOT_EVENT.ATTACHMENT_MESSAGE, attachmentMessage);
  }

  addMessage(message, outcome) {
    message = trim(message.toString());
    // take care of emoji 'keycap_ten' (Other)
    if (message === 'keycap_ten') {
      message = 'ten';
    }
    if ( ! isNaN(WordsToNumber.convert(message))) {
      message = WordsToNumber.convert(message);
      this._deleteEmojis(message);
    }

    if (this.currentPage === 0 && this.paging.length > 1 && message == 10) {
      this.nextPage();
    }
    else {
      if (! Number(message)) {
        this.validator = null;
        super.addMessage(message, outcome);
      }
      else {
        this.validator = new RangeValidation(this.allowedValues);
        super.addMessage(message, outcome);
      }
    }
  }

  think() {
    try {
      if(this._isCompleted()) {
        if (this.entities[this.state] !== 'Other') {
          // convert the selected value to object id
          this.entities[this.state] = this.values[Number(this.entities[this.state]) - 1];
          this.context[this.saveContextKey] = this.entities[this.state];
        }

        this.endAction();
      }
      else {
        this.emojiReactionMessageId = this.emitAndId(CONSTANTS.BOT_EVENT.ATTACHMENT_MESSAGE, {
          message: this.message,
          emojiReaction: this.emojiReaction
        });
      }
    }
    catch (ex) {
      Logger.error('Failed to execute think', ex, ex.stack);
      this.emit(CONSTANTS.BOT_EVENT.ERROR);
    }
  }
}

module.exports = ActionListChoices;
