const fs = require('fs');
const Interactions = {};

fs.readdirSync(__dirname).forEach(function(file) {
  var klass = require('./'+ file);
  if (klass.__proto__.name !== 'Object') {
    Interactions[klass.name] = klass;
  }
});

module.exports = Interactions;