'use strict';

const CONSTANTS = require('./../../constants/constants');
const Util = require('util');
const assert = require('assert');
const Request = require('request');
const Config = require('./../../configs/config');
const BotError = require('./../../errors/bot-error');
const Action = require('./action');
const ModelTrigger = require('./../../models/trigger');
const Co = require('co');
const Logger = require('./../../libs/logger');
const NumberToWords = require('number-to-words');
const WordsToNumber = require('words-to-num');
const YesNoValidation = require('./../validations/yes-no');
const RecurrenceDateValidation = require('./../validations/recurrence-date');
const trim = require('trim');
const ParserEmail = require('./../parsers/email-command-parser');
const GmailParser = require('./../../libs/gmail-parser');
const ModelUser = require('./../../models/user');
const fuzzy = require('fuzzy');
const moment = require('moment');
const RRule = require('rrule').RRule;

class ActionGatherGmailTrigger extends Action {

  static requireAction() {
    return true;
  }

  constructor(message, context, saveContextKey, emojiReaction, overwrite) {
    super(message, context, saveContextKey, emojiReaction, overwrite);

    assert(typeof context.slackUserId === 'string', 'Context SlackUserId (String) is missing');
    assert(typeof context.googleOauthToken === 'object', 'Context googleOauthToken (Object) is missing');

    this.saveContextKey = this.saveContextKey || 'gmailTrigger';
    this.requiredEntities = ['gmailTrigger', 'confirmation'];
    this.state = this.requiredEntities[0];
    this.isRepeat = false;

    try {
      this.languageParser = new ParserEmail();
      this.gmailParser = new GmailParser(context.googleOauthToken);
    }
    catch (ex) {
      Logger.error({ex, exStack: ex.stack}, 'Failed to initialize wit.ai / GmailParser using the context token');
      throw ex;
    }

    this.init();
  }

  init() {
    // so that subscriber can subscribe to on event after initialization
    setImmediate(() => {
      try {
        super.init() && this.think();
      }
      catch (ex) {
        Logger.error({ex, exStack: ex.stack, object: this}, 'Failed to trigger think method');
        this.emit(CONSTANTS.BOT_EVENT.ERROR);
      }
    });
  }

  addMessage(message, outcome) {
    if (this.state === this.requiredEntities[1]) {
      this.validator = new YesNoValidation();
      super.addMessage(message, outcome, true /* dont save context */);
    }
    else {
      var parentAddMessage = super.addMessage;
      Co(function *() {
        try {
          if ( ! (this.context.user && this.context.user instanceof ModelUser)) {
            this.context.user = yield ModelUser.findOne({ slackUserId: this.context.slackUserId,
                                  status: CONSTANTS.DB.STATUS.ACTIVE });
          }
          const outcome = yield this.languageParser.process(message);
          if (! (outcome && Object.keys(outcome).length > 0)) {
            this.emit(CONSTANTS.BOT_EVENT.MESSAGE, 'Sorry, I don\'t quite understand what you said :disappointed:.');
            return;
          }
          const criteria = yield this._getSearchCriteria(this.context.slackUserId, outcome);
          const events = yield this.gmailParser.find(criteria);

          if (events && Array.isArray(events) && events.length > 0) {
            parentAddMessage.call(this, {
              criteria: criteria,
              events: events,
              text: message
            });
          }
          else {
            this.emit(CONSTANTS.BOT_EVENT.MESSAGE, 'I can\'t find any email that matches what you want :disappointed:. ' +
              'Please try again');
          }
        }
        catch (ex) {
          Logger.error(__filename, 'Failed to parse user string against Google Calendar API', ex, ex.stack);
          this.emit(CONSTANTS.BOT_EVENT.ERROR);
        }

      }.bind(this));
    }
  }

  think() {
    try {
      if(this._isCompleted()) {
        if (this.entities[this.requiredEntities[1]] === 'yes') {
          this.postedMessageId = uuid.v1();
          this.emit(CONSTANTS.BOT_EVENT.MESSAGE, {
            messageId: this.postedMessageId,
            message: 'Got it!'
          });
          this.on(CONSTANTS.BOT_EVENT.MESSAGE_POSTED, (messageInfo) => {
            if (this.postedMessageId !== messageInfo.messageId) {
              return;
            }
            this.endAction();
          });
        }
        else {
          this.state = this.requiredEntities[0];
          delete this.context[this.saveContextKey];
          delete this.validator;
          this.isRepeat = true;
          this.entities = {};
          this.think();
        }
      }
      else if (this.state === this.requiredEntities[1]) {
        var outputString = this.entities[this.requiredEntities[0]].events.map(item => {
            return Util.format('%s %s\nSent to %s. From %s',
              moment(item.headers.Date.value).tz(this.context.user.timezone).format('M/D'),
              item.headers.Subject.value,
              item.headers.To.value,
              item.headers.From.value);
          }) || [];

        if (outputString.length > 3) {
          outputString = outputString.slice(0, 3);
          outputString.push('_...and more..._');
        }

        var attachmentMessage = [{
          'fallback': 'Cool, this is what I have. Sound good? Say `yes` or `no`',
          'color': Config.botAttachmentMessageColor.action,
          'pretext': 'Cool, this is what I have. Sound good? Say `yes` or `no`',
          'mrkdwn_in': ['fields', 'pretext'],
          'unfurl_links': true, // don't show email addresses as links
          'fields': [
            {
              value: outputString.join('\n')
            }
          ]
        }];
        this.emit(CONSTANTS.BOT_EVENT.ATTACHMENT_MESSAGE, attachmentMessage);
      }
      else {
        if (this.isRepeat) {
          this.emit(CONSTANTS.BOT_EVENT.MESSAGE, 'Ok, Let\'s try that again. Here are the types of things that ' +
            'I understand (I\'m working on it but I\'m a bot after all :simple_smile:)\n' +
            '`emails that I replied to`\n' +
            '`email thread that I started`\n' +
            '`sent to susan and kenny only`\n' +
            '`subject line short code review`');
        }
        else {
          var message = this.message;
          if (! (this.context.userTriggerGmails && this.context.userTriggerGmails.length > 0)) {
            message = 'Success! :tada: We\'re connected. ' + message;
          }
          this.emit(CONSTANTS.BOT_EVENT.MESSAGE, message);
        }
      }
    }
    catch (ex) {
      Logger.error('Error generating Google Gmail Trigger think method', ex, ex.stack);
      this.emit(CONSTANTS.BOT_EVENT.ERROR);
    }
  }

  _findUsersInList(list, names, currentUser) {
    if ( ! Array.isArray(names)) {
      names = [names];
    }
    var result = [];
    names.forEach(name => {
      var nameLC = name.toLowerCase();
      if (nameLC === 'i' || nameLC === 'me') {
        result.push(currentUser.email);
      }
      else {
        var results = fuzzy.filter(name, list, { extract: (el) => { return el.name }});
        if (results && results[0] && results[0].score >= 50) {
          result.push(results[0].original.email);
        }
      }
    });
    return result;
  }

  _replaceUser(list, currentUser) {
    list = Array.isArray(list) ? list : [list];
    list = list.map((item) => {
      var itemLC = item.toLowerCase();
      if (itemLC === 'i' || itemLC === 'me') {
        if (currentUser.firstName !== currentUser.lastName) {
          return currentUser.firstName +' '+ currentUser.lastName;
        }
        else {
          return currentUser.firstName;
        }
      }

      return item;
    });
    return list;
  }

  _getSearchCriteria(slackUserId, outcome) {
    return new Promise((resolve, reject) => {
      Co(function *() {

        try {
          const criteria = {};
          if (outcome) {
            const user = yield ModelUser.findOne({slackUserId: slackUserId, status: CONSTANTS.DB.STATUS.ACTIVE});
            if (outcome.personReply) {
              criteria.personReply = this._replaceUser(outcome.personReply, user);
            }

            if (outcome.subject) {
              criteria.subject = outcome.subject;
            }

            if (outcome.recipients) {
              criteria.recipients = this._replaceUser(outcome.recipients, user);
            }

            if (outcome.emailSender) {
              criteria.from = this._replaceUser(outcome.emailSender, user);
            }
          }

          return resolve((Object.keys(criteria).length > 0) ? criteria : null);
        }
        catch(ex) {
          Logger.error('Failed to get search criterias for email parsing outcome', ex, ex.stack);
          return reject(ex);
        }
      }.bind(this));
    });
  }
}

module.exports = ActionGatherGmailTrigger;
