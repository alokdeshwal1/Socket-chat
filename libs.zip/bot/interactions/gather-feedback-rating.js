'use strict';

const CONSTANTS = require('./../../constants/constants');
const Util = require('util');
const assert = require('assert');
const Request = require('request');
const Config = require('./../../configs/config');
const BotError = require('./../../errors/bot-error');
const BotMessages = require('./../../configs/bot-messages');
const Action = require('./action');
const ModelGoalCategory = require('./../../models/goal-category');
const ActionInteractiveMessage = require('./action-interactive-message');
const Co = require('co');
const Logger = require('./../../libs/logger');
const NumberToWords = require('number-to-words');
const WordsToNumber = require('words-to-num');
const RangeValidation = require('./../validations/range');
const YesNoValidation = require('./../validations/yes-no');
const Task = require('./../task');
const uuid = require('uuid');
const trim = require('trim');
const _ = require('lodash');
const Helper = require('./../libs/helper');

class ActionGatherFeedbackRating extends ActionInteractiveMessage {

  static requireAction() {
    return true;
  }

  constructor(message, context, saveContextKey, config, overwrite) {
    super(message, context, saveContextKey || 'feedbackEmoji', config, overwrite);
    this.reset();

    if (this.context['meetingGoal']) {
      this.message = BotMessages.ActionGatherFeedbackRating.hasMeetingTitle();
    }
    this.allowedValues = Config.feedbackRatingOptions.map(item => {
      return item.emoji;
    });
    this.buttons = (config && config.buttons) || Array.from(this.allowedValues);
    this.validator = new RangeValidation(this.allowedValues);
    this.message.actions = _.cloneDeep(this.buttons);

    this.init();
  }

  /**
   * @override
   */
  init() {
    // so that subscriber can subscribe to on event after initialization
    setImmediate(() => {
      try {
        super.init() && this.think();
      }
      catch (ex) {
        Logger.error({ex, exStack: ex.stack, 'this': this}, 'Failed to trigger think method');
        this.emit(CONSTANTS.BOT_EVENT.ERROR);
      }
    });
  }

  /**
   * @override
   */
  reset() {
    super.reset();
    this.requiredEntities = ['feedbackEmoji', 'confirmation'];
    this.state = this.requiredEntities[0];
  }

  /**
   * @override
   */
  addButtonAction(message) {
    if (this.buttons.indexOf(message) === -1) {
      return;
    }

    // if user tap on emoji, no confirmation is required, that's why we set yes for this
    this.entities['confirmation'] = 'yes';
    this.addMessage(message);
  }

  /**
   * @override
   */
  addMessage(message) {
    if (this.state === this.requiredEntities[1]) {
      this.validator = new YesNoValidation();
      super.addMessage(message, true /* skip saving context */);
    }
    else {
      this.validator = new RangeValidation(this.allowedValues);
      super.addMessage(message);
    }
  }

  /**
   * @override
   */
  think() {
    try {
      if(this._isCompleted()) {
        if (this.entities[this.requiredEntities[1]] === 'no') {
          this.reset();
          var temp = _.cloneDeep(this.message);
          temp.text = this.message.alternativeMessage;
          this.emitAttachmentMessage(this.toSlackStructure(temp, 'feedback'));
        }
        else {
          var feedbackRating = _.findWhere(Config.feedbackRatingOptions, {emoji: this.entities[this.requiredEntities[0]]});
          if (feedbackRating && feedbackRating.value) {
            this.context.feedbackRating = feedbackRating.value;
          }
          this.endAction();
        }
      }
      else if (this.state === this.requiredEntities[1]) {
        this.emitMessage(this.message.confirmation);
      }
      else {
        this.emitAttachmentMessage(this.toSlackStructure(this.message, 'feedback'));
      }
    }
    catch (ex) {
      Logger.error({ex, exStack: ex.stack, 'this': this}, 'Failed to generate feedback rating think');
      this.emit(CONSTANTS.BOT_EVENT.ERROR);
    }
  }
}

module.exports = ActionGatherFeedbackRating;
