'use strict';

const EventEmitter = require('events').EventEmitter;
const jrWrapper = require('./../libs/jackrabbit-wrapper');
const Redis = require('redis');
const CONSTANTS = require('./../constants/constants');
const Config = require('./../configs/config');
const ModelSlackIntegration = require('./../models/slack-integration');
const Co = require('co');
const Logger = require('./../libs/logger');
const TalkingBot = require('./../bot/talking-bot');
const _ = require('lodash');
const uuid = require('node-uuid');

class Server extends EventEmitter {
  constructor(serverId) {
    super();

    this._serverId = Number(serverId);
    this._bots = {};
    this._queueName = CONSTANTS.JOB_QUEUE.BOT_SERVER;
    this._numOfServices = 2; // Redis + AMQP
    this._reconnectInterval = 1000; // milliseconds

    this._startQueue();
    this.on('queue:ready', this._init.bind(this));
    this.on('queue:error', this._reconnectQueue);
    this.on('queue:close', this._reconnectQueue);
    this.on('queue:disconnected', this._reconnectQueue);

    this._startRedis();
    this.on('redis:ready', this._init.bind(this));
    this.on('redis:error', this._reconnectRedis);
    this.on('redis:close', this._reconnectRedis);
    this.on('redis:disconnected', this._reconnectRedis);
  }

  get serverId() {
    return this._serverId;
  }

  _init() {
    this._servicesStarted = this._servicesStarted || 0;
    if (++this._servicesStarted < this._numOfServices) {
      return false;
    }

    Co(function *() {
      try {
        yield this.amqb.createQueue(this._queueName);
        this.amqb.handle(this._queueName, this._handleQueue.bind(this));
        const id = this.serverId - 1;
        const totalIntegrations = yield ModelSlackIntegration.count({ status: CONSTANTS.DB.STATUS.ACTIVE });
        const botsPerWorker = Math.ceil(Number(totalIntegrations) / Number(Config.botConcurrency));
        var integrations = yield ModelSlackIntegration
                            .find({ status: CONSTANTS.DB.STATUS.ACTIVE })
                            .populate('company')
                            .limit(botsPerWorker)
                            .skip(id * botsPerWorker);

        for (let integration of integrations) {
          integration = integration.toJSON();
          var enabledModules = {};
          enabledModules[CONSTANTS.MODULES.PERSONAL_GOAL] = integration.company[CONSTANTS.MODULES.PERSONAL_GOAL];
          enabledModules[CONSTANTS.MODULES.OKR] = integration.company[CONSTANTS.MODULES.OKR];
          this._startBot(enabledModules, integration.teamName, integration.teamId, integration.bot.bot_access_token, Config.slack.botName);
        }
      }
      catch (ex) {
        Logger.error({ex, exStack: ex.stack}, 'Failed to start slack bots');
      }
    }.bind(this));
  }

  _handleQueue(job, ack) {
    try {
      this._startBot(job.enabledModules, job.teamName, job.teamId, job.bot.bot_access_token, Config.slack.botName, job.newInstallation);
    }
    catch (ex) {
      Logger.error({ex, exStack: ex.stack, job}, 'Failed to handle server job to boot a new boot');
    }

    ack && ack();
  }

  _reconnectQueue() {
    setTimeout(() => {
      Logger.warn('Trying to reconnect Queue');
      this._startQueue();
    }, this._reconnectInterval);
  }

  _reconnectRedis() {
    setTimeout(() => {
      Logger.warn('Trying to reconnect Redis');
      this._startRedis();
    }, this._reconnectInterval);
  }

  _startBot(enabledModules, teamName, teamId, botAccessToken, botName, newInstallation) {
    // @TODO: move this to a redis shared document later
    var key = TalkingBot.getTeamKey(teamName, teamId);
    if ( ! this._bots[key] || (this._bots[key] && this._bots[key].accessToken !== botAccessToken)) {
      this._bots[key] = new TalkingBot(enabledModules, {
        amqb: this.amqb,
        redis: this.redis
      }, teamName, teamId, botAccessToken, botName);

      if (newInstallation) {
        this._bots[key].on('ready', () => {
          if (newInstallation.job) {
            this._bots[key]._queueTask(newInstallation.job);
          }
        });
      }
    }
    else if (newInstallation && newInstallation.job) {
      this._bots[key]._queueTask(newInstallation.job);
    }

    Logger.info('Boot up a new bot', teamName, teamId);
  }

  _startQueue() {
    this.amqb = jrWrapper(Config.rabbitUrl)
      .on('connected', () => {
        this.emit('queue:ready');
      })
      .on('error', (err) => {
        this.emit('queue:error', err, {msg: err, service: 'rabbitmq'});
      })
      .on('close', () => {
        this.emit('queue:close');
      })
      .on('disconnected', () => {
        this.emit('queue:disconnected', {msg: 'disconnected', service: 'rabbitmq'});
      });
  }

  _startRedis() {
    this.redis = Redis.createClient(Config.redisUrl, {no_ready_check: true});
    this.redis
      .on('ready', () => {
        this.emit('redis:ready')
      })
      .on('error', (err) => {
        this.emit('redis:error', err, {msg: err, service: 'redis'});
      })
      .on('close', (str) => {
        this.emit('redis:close', str, {msg: 'closed', service: 'redis'});
      })
      .on('disconnected', function() {
        this.emit('redis:disconnected', {msg: 'disconnected', service: 'redis'});
      });
  }

}

module.exports = Server;