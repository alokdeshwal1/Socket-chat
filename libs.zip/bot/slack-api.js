'use strict';

const Logger = require('./../libs/logger');
const WebSocket = require('ws');
const Request = require('request');
const Co = require('co');
const Config = require('./../configs/config');
const assert = require('assert');
const EventEmitter = require('events').EventEmitter;
const Bluebird = require('bluebird');

Promise.prototype.finally = Promise.prototype.finally || function(onResolveOrReject) {
  return this.catch(function(reason){
    return reason;
  }).then(onResolveOrReject);
};

class SlackAPI {

  constructor(accessToken) {
    assert.equal(typeof accessToken, 'string', 'AccessToken (String) is required');
    this.accessToken = accessToken;
  }

  _find(arr, params) {
    var result = {};

    arr.forEach(function(item) {
      if (Object.keys(params).every(function(key) { return item[key] === params[key];})) {
        result = item;
      }
    });

    return result;
  }

  _api(methodName, params) {
    assert.equal(typeof methodName, 'string', 'MethodName (String) is required');
    params && assert.equal(typeof params, 'object', 'Params must be an object');

    const data = {
      url: 'https://slack.com/api/' + methodName,
      form: this._preprocessParams(params)
    };

    return new Promise(function(resolve, reject) {
      Request.post(data, function(err, request, body) {
        if(err) {
          reject(err);
          return false;
        }

        try {
          body = JSON.parse(body);

          // Response always contain a top-level boolean property ok,
          // indicating success or failure
          if(body.ok) {
            resolve(body);
          } else {
            reject(body);
          }

        } catch(e) {
          reject(e);
        }
      });
    });
  }

  getChannels() {
    if(this.channels) {
      return Promise.resolve({channels: this.channels});
    }
    return this._api('channels.list');
  }

  getUsers() {
    if(this.users) {
      return Promise.resolve({members: this.users});
    }

    return this._api('users.list');
  }

  getGroups() {
    if(this.groups) {
      return Promise.resolve({groups: this.groups});
    }

    return this._api('groups.list');
  }

  getUser(name) {
    assert.equal(typeof name, 'string', 'Name (String) is required');
    return this.getUsers().then(function(data) {
      return this._find(data.members, {name: name});
    }.bind(this));
  }

  getUserById(id) {
    assert.equal(typeof id, 'string', 'Id (String) is required');
    return this.getUsers().then(function(data) {
      return this._find(data.members, {id: id});
    }.bind(this));
  }

  getUserByFirstName(firstName) {
    assert.equal(typeof firstName, 'string', 'FirstName (String) is required');
    return this.getUsers().then(function(data) {
      return new Promise(function(resolve, reject) {
        var result = null;
        data.members.forEach(function(item) {
          if ( ! result && item.profile && item.profile.first_name &&
              item.profile.first_name.toLowerCase() === firstName.toLowerCase()) {

            result = item;
          }
        });

        resolve(result);
      });
    }.bind(this));
  }

  getChannel(name) {
    assert.equal(typeof name, 'string', 'Name (String) is required');
    return this.getChannels().then(function(data) {
      return this._find(data.channels, {name: name});
    }.bind(this));
  }

  getGroup(name) {
    assert.equal(typeof name, 'string', 'Name (String) is required');
    return this.getGroups().then(function(data) {
      return this._find(data.groups, {name: name});
    }.bind(this));
  }

  getChannelId(name) {
    return this.getChannel(name).then(function(channel) {
      return channel.id;
    });
  }

  getGroupId(name) {
    assert.equal(typeof name, 'string', 'Name (String) is required');
    return this.getGroup(name).then(function(group) {
      return group.id;
    });
  }

  getChatId(name) {
    assert.equal(typeof name, 'string', 'Name (String) is required');

    return this.getUser(name)
      .then(function(data) {
        var chatId = this._find(this.ims, {user: data.id}).id;
        return chatId || this.openIm(data.id);
      }.bind(this))
      .then(function(data) {
        return typeof data === 'string' ? data : data.channel.id;
      });
  }

  /**
   * Preprocessing of params
   * @param params
   * @returns {object}
   * @private
   */
  _preprocessParams(params) {
    params = Object.assign(params || {}, {token: this.accessToken});

    Object.keys(params).forEach(function(name) {
      var param = params[name];

      if(param && typeof param === 'object') {
        params[name] = JSON.stringify(param);
      }
    });

    return params;
  }
}


module.exports = SlackAPI;
