'use strict';

const EventEmitter = require('events').EventEmitter;
const fs = require('fs');
const path = require('path');
const Logger = require('./../libs/logger');
const BotError = require('./../errors/bot-error');
const Util = require('util');
const CONSTANTS = require('./../constants/constants');
const Config = require('./../configs/config');
const Co = require('co');
const _ = require('lodash');
const uuid = require('node-uuid');
const Interactions = require('./interactions');
const Persist = require('./persist');
const Hooks = require('./hooks');
const Serialization = require('./libs/serialization');
const Helper = require('./libs/helper');

class Task extends EventEmitter {

  constructor(taskConfig, context, bot) {
    super();

    this.taskConfig = taskConfig;
    this.context = context;
    this.bot = bot;
    this.id = uuid.v1();

    this.name = taskConfig.name || null;
    this.type = taskConfig.type;
    this.priority = taskConfig.priority || null;
    this.step = (Number(taskConfig.step) >= 0) ? Number(taskConfig.step) : -1; // what step of interaction the task is at
    this.updatedAt = taskConfig.updatedAt || null;
    this.interactions = taskConfig.interactions || [];
    this.persist = taskConfig.persist;
    this.before = taskConfig.before; // before hooks
    this.after = taskConfig.after;   // after hooks

    this.modelChanges = [];
    this.createdAt = + new Date();
    this.isStarted = false;
    this.overwrite = true; // overwrite data in context even through data is already exist in context
    this.isEnded = undefined;
    this.isSuspended = undefined;
    this.isCancelled = undefined;
    this.isError = undefined;
    this.parentTaskId = undefined;

    this.on(CONSTANTS.BOT_EVENT.MESSAGE_POSTED, (data) => {
      if ( ! this.currentInteraction) {
        Logger.warn('Receive MESSAGE_POSTED event when there is no current interaction', data, this);
        return;
      }
      this.currentInteraction.emit(CONSTANTS.BOT_EVENT.MESSAGE_POSTED, data);
    });

    this.on(CONSTANTS.BOT_EVENT.EMOJI_REACTION_POSTED, (data) => {
      if ( ! this.currentInteraction) {
        Logger.warn('Receive EMOJI_REACTION_POSTED event when there is no current interaction', data, this);
        return;
      }
      this.currentInteraction.emit(CONSTANTS.BOT_EVENT.EMOJI_REACTION_POSTED, data);
    });
  }

  static restore(values, bot) {
    try {
      const task =  new Task(values.taskConfig || values, values.context, bot);
      task.id = values.id || task.id;
      task.step = values.step || task.step;
      task.isStarted = values.isStarted || task.isStarted;
      task.isEnded = values.isEnded || task.isEnded;
      task.isCancelled = values.isCancelled || task.isCancelled;
      task.isError = values.isError || task.isError;
      task.createdAt = values.createdAt || task.createdAt;
      task.parentTaskId = values.parentTaskId || task.parentTaskId;
      task.overwrite = false;

      return task;
    }
    catch (ex) {
      Logger.error({ ex, exStack: ex.stack, values }, 'Failed to restore Task');
    }
  }

  start() {
    this.isStarted = true;

    this._runBeforeHooks()
      .then((result) => {
        if (result === false) {
          this.terminate();
        }
        else {
          this.reminderInterval = this._setReminderInterval();
          if (this.interactions) {
            this.nextInteraction();
          }
          else {
            this.errorOut();
            Logger.error(__filename, 'Bad use of Task class: initialize class without interaction', taskConfig);
          }
        }
      })
      .catch(err => {
        this.errorOut(err);
      });
  }

  resume() {
    try {
      this.step = (this.step < 0) ? -1 : this.step - 1;
      this.nextInteraction();
    }
    catch (ex) {
      Logger.error('Failed to resume task', ex, ex.stack);
      return false;
    }

    return true;
  }

  addMessage(message, outcome) {
    if ( ! this.currentInteraction) {
      Logger.warn({ message, task: this.toJSON() }, 'calling addMessage when there is no current interaction');
      return;
    }

    this._stayActive();
    this.currentInteraction.addMessage(message, outcome);
  }

  addEmojiMessage(message, outcome) {
    if ( ! (this.currentInteraction && this.currentInteraction.addEmojiMessage)) {
      Logger.warn(__filename, 'calling addEmojiMessage when there is no current interaction', arguments, this);
      return;
    }

    this._stayActive();
    this.currentInteraction.addEmojiMessage(message, outcome);
  }

  addButtonAction(message) {
    if ( ! (this.currentInteraction && this.currentInteraction.addButtonAction)) {
      Logger.warn('calling addButtonAction when there is no current interaction', arguments, this);
      return;
    }

    this._stayActive();
    this.currentInteraction.addButtonAction(message);
  }

  backToLastStep(inputStep) {
    inputStep = (inputStep >= 0) ? inputStep : (this.interactions.length - 1);
    if (this.interactions[inputStep]) {
      const Klass = Interactions[this.interactions[inputStep].type];
      if ( ! (Klass.requireAction && Klass.requireAction())) {
        return this.backToLastStep(inputStep - 1);
      }

      this.step = inputStep - 1; // calling nextInteration will take out -1
      this.nextInteraction();
      return true;
    }

    return false;
  }

  isBackableToLastStep(inputStep) {
    inputStep = (inputStep >= 0) ? inputStep : (this.interactions.length - 1);
    if (this.interactions[inputStep]) {
      const Klass = Interactions[this.interactions[inputStep].type];
      if ( ! (Klass.requireAction && Klass.requireAction())) {
        return this.isBackableToLastStep(inputStep - 1);
      }

      return true;
    }

    return false;
  }

  back(inputStep) {
    this._stayActive();
    inputStep = (inputStep >= 0) ? inputStep : this.step;
    var backStep = inputStep - 1;
    if (backStep >= 0) {
      try {
        const Klass = Interactions[this.interactions[backStep].type];
        if ( ! (Klass.requireAction && Klass.requireAction())) {
          return this.back(inputStep - 1);
        }
        else {
          this._deleteCurrentInteraction();
          this.step = backStep - 1; // calling nextInteraction will remove -1
          this.nextInteraction();
        }
      }
      catch (ex) {
        Logger.error(__filename, 'Failed to go back for task', ex, ex.stack);
        throw new BotError(BotError.INTERACTION_BACK_ERROR, 'Failed to go back for task');
      }
      return true;
    }

    return false;
  }

  repeat() {
    try {
      if (this.step >= 0 && this.interactions[this.step - 1]) {
        this.step--;
        this.nextInteraction();

        return true;
      }
    }
    catch (ex) {
      Logger.error('Failed to repeat task', ex, ex.stack);
    }

    return false;
  }

  cancel() {
    try {
      clearInterval(this.reminderInterval);
      this.isCancelled = true;
      this.isEnded = true;
    }
    catch (ex) {
      Logger.error('Failed to cancel task', ex, ex.stack);
      return false;
    }

    return true;
  }

  suspend() {
    try {
      clearInterval(this.reminderInterval);
      this.isSuspended = true;
      this.previousInteraction();
    }
    catch (ex) {
      Logger.error('Failed to suspend task', ex, ex.stack);
      return false;
    }

    return true;
  }

  end() {
    try {
      clearInterval(this.reminderInterval);
      this.isEnded = true;
      this.emit(CONSTANTS.BOT_EVENT.END);
    }
    catch(ex) {
      Logger.error('Failed to end task', ex, ex.stack);
      return false;
    }

    return true;
  }

  terminate() {
    try {
      this.isTerminated = true;
      this.end();
    }
    catch(ex) {
      Logger.error('Failed to terminate task', ex, ex.stack);
      return false;
    }

    return true;
  }

  rollback() {
    if (this.persistObject && this.persistObject.rollback) {
      return this.persistObject.rollback();
    }
    return Promise.resolve(false);
  }

  errorOut(err) {
    try {
      this.isError = true;
      this.isEnded = true;
      this.bot.saveMemory();
      clearInterval(this.reminderInterval);
      this.emit(CONSTANTS.BOT_EVENT.ERROR);
    }
    catch(ex) {
      Logger.error('Failed to error out task', ex, ex.stack);
      return false;
    }

    return true;
  }

  _onEndInteraction() {
    this.bot.saveMemory();
    (! this.isEnded) && this.nextInteraction();
  }

  _onErrorInteraction() {
    this.errorOut();
  }

  _persistData() {
    if (typeof Persist[this.persist].run === 'function') {
      return Persist[this.persist].run(this.context, this);
    }
    else if (typeof Persist[this.persist] === 'function') {  // is a class
      this.persistObject = new Persist[this.persist]();
      return this.persistObject.run(this.context, this);
    }
    else {
      Logger.warn(__filename, 'Task persist %s has no run function', this.persist);
      return Promise.resolve(false);
    }
  }

  _runAfterHooks() {
    return new Promise((resolve, reject) => {
      if ( ! (this.after && Array.isArray(this.after) && this.after.length > 0)) {
        return resolve(true);
      }

      Co(function *() {
        try {
          for(var i = 0; i < this.after.length; i++) {
            var hookName = this.after[i];
            yield Hooks[hookName].run(this.context, this);
          }
          return resolve(true);
        }
        catch (ex) {
          Logger.error(__filename, 'Failed to run hook '+ hookName, ex, ex.stack);
          return reject(ex);
        }
      }.bind(this));
    });
  }

  _runBeforeHooks() {
    return new Promise((resolve, reject) => {
      if ( ! (this.before && Array.isArray(this.before) && this.before.length > 0)) {
        return resolve(true);
      }

      var hookName;
      Co(function *() {
        try {
          for(var i = 0; i < this.before.length; i++) {
            hookName = this.before[i];
            var result = yield Hooks[hookName].run(this.context, this);
            if (result === false) {
              return resolve(false);
            }
          }
          return resolve(true);
        }
        catch (ex) {
          Logger.error(__filename, 'Failed to run hook '+ hookName, ex, ex.stack);
          return reject(ex);
        }
      }.bind(this));
    });
  }

  _setReminderInterval() {
    return setInterval(() => {
      //this.emit(CONSTANTS.BOT_EVENT.MESSAGE, this.reminderMessage || 'Knock knock, are you there?');
      setTimeout(() => {
        this.repeat();
      }, 3000);
    }, Config.botReminderIntervalSec * 1000);
  }

  _stayActive() {
    clearInterval(this.reminderInterval);
    this.reminderInterval = this._setReminderInterval();
  }

  _deleteCurrentInteraction() {
    try {
      if (this.currentInteraction) {
        this.currentInteraction.removeAllListeners();
        delete this.currentInteraction;
      }
    }
    catch (ex) {
      Logger.error('Failed to remove listeners for current task', ex, ex.stack);
    }
  }

  _bindEvents(interaction) {
    interaction.on(CONSTANTS.BOT_EVENT.MESSAGE, (params) => {
      this.emit(CONSTANTS.BOT_EVENT.MESSAGE, params);
    });
    interaction.on(CONSTANTS.BOT_EVENT.ATTACHMENT_MESSAGE, (params) => {
      this.emit(CONSTANTS.BOT_EVENT.ATTACHMENT_MESSAGE, params);
    });
    interaction.on(CONSTANTS.BOT_EVENT.EMOJI_REACTION, (params) => {
      this.emit(CONSTANTS.BOT_EVENT.EMOJI_REACTION, params);
    });
    interaction.on(CONSTANTS.BOT_EVENT.REMOVE_EMOJI_REACTION, (params) => {
      this.emit(CONSTANTS.BOT_EVENT.REMOVE_EMOJI_REACTION, params);
    });
    interaction.on(CONSTANTS.BOT_EVENT.TASK, (params) => {
      this.emit(CONSTANTS.BOT_EVENT.TASK, params);
    });

    // The difference between END_TASK and END is
    // END - terminate the interaction
    // END_TASK - terminate the entire task, skip the rest of interactions in the task and also hooks
    interaction.on(CONSTANTS.BOT_EVENT.END_TASK, (params) => {
      this.end();
    });
    interaction.on(CONSTANTS.BOT_EVENT.END, this._onEndInteraction.bind(this));
    interaction.on(CONSTANTS.BOT_EVENT.ERROR, this._onErrorInteraction.bind(this));
  }

  chainTask(task, context) {
    this.chainAfterTask(this.id, Object.assign(task, { type: this.type }), context);
  }

  previousInteraction() {
    try {
      this.step--;
      this.step = (this.step < -2) ? -1 : this.step;
    }
    catch (ex) {
      Logger.error('Failed to go back previous interaction', ex, ex.stack);
      return false;
    }

    return true;
  }

  nextInteraction() {
    if (this.step + 1 >= this.interactions.length) {
      try {
        if (this.after) {
          this._runAfterHooks().then(() => {
            this.end();
          })
          .catch(err => {
            this.errorOut(err);
          });
        }
        else if (this.persist) {
          this._persistData().then((modelChanges) => {
            if (_.isObject(modelChanges)) {
              this.modelChanges.push(modelChanges);
            }
            else if (Array.isArray(modelChanges)) {
              this.modelChanges = this.modelChanges.concat(modelChanges);
            }

            this.end();
          })
          .catch(err => {
            Logger.error('Failed to persist data', err, err.stack);
            this.errorOut(err);
          });
        }
        else {
          this.end();
        }
      }
      catch(ex) {
        Logger.error(__filename, 'Failed to persist data', ex, ex.stack);
        // we continue to the next task
        this.errorOut(ex);
      }
    }
    else {
      this.step++;
      if (this.interactions && this.interactions[this.step] && this.interactions[this.step].type) {
        const targetInteraction = this.interactions[this.step];
        if (Helper.areParamsFulfilled(targetInteraction.message, this.context)) {
          try {
            // replace placeholders with context variables
            const newMessage = Helper.replaceMessagePlaceholder(_.cloneDeep(targetInteraction.message), this.context);
            const Klass = Interactions[this.interactions[this.step].type];
            this._deleteCurrentInteraction();
            this.currentInteraction = new Klass(newMessage, this.context, targetInteraction.saveContextKey,
              targetInteraction.config || targetInteraction.emojiReaction, this.overwrite);
            this._bindEvents(this.currentInteraction);
            if (targetInteraction.skipParser && targetInteraction.skipParser === true) {
              this.currentInteraction.setSkipParser(true);
            }
          }
          catch(ex) {
            Logger.error(BotError.INTERACTION_FAILED_INITIALIZATION, ex, ex.stack);
            this.errorOut(ex);
          }
        }
        else {
          Logger.error('Action params are not fulfilled', this.interactions, this.context);
          throw new BotError(BotError.UNFULFILLED_ACTION_CONTEXT, Util.format('Action %s params are not fulfilled', targetInteraction.type));
        }
      }
    }
  }

  toJSON() {
    return Serialization.toJSON.apply(this);
  }
}

module.exports = Task;