'use strict';

const Command = require('./command');
const Intent = require('./../intents/intent');
const _ = require('lodash');

class CommandGoalCrud extends Command {
  constructor() {
    super();

    this.regExps = [
      /^\s*archive a goal\s*$/ig,
      /^\s*archive goal\s*$/ig,
      /^\s*archive goals\s*$/ig,
      /^\s*complete goal\s*$/ig,
      /^\s*finish goal\s*$/ig,
      /^\s*end goal\s*$/ig,

      /^\s*delete a goal\s*$/ig,
      /^\s*delete goal\s*$/ig,
      /^\s*delete goals\s*$/ig,

      /^\s*edit a goal\s*$/ig,
      /^\s*change goal\s*$/ig,
      /^\s*change a goal\s*$/ig,
      /^\s*change goals\s*$/ig,
      /^\s*edit goal\s*$/ig,
      /^\s*edit goals\s*$/ig,


      /^\s*add a goal\s*$/ig,
      /^\s*add new goal\s*$/ig,
      /^\s*add new goals\s*$/ig,
      /^\s*new goals\s*$/ig,
      /^\s*new goal\s*$/ig,
      /^\s*add goal\s*$/ig,
      /^\s*add goals\s*$/ig,
      /^\s*create new goals\s*$/ig,
      /^\s*create a new goal\s*$/ig
    ];
  }

  parse(message) {
    var matches = super.parse(message);
    if ( ! (matches && matches.length > 0)) {
      return null;
    }

    var foundRegPos;
    for(var i = 0; i < matches.length; i++) {
      if (matches[i]) {
        foundRegPos = i;
        break;
      }
    }

    var context = {};
    var intent = new Intent();
    switch(i) {
      case 0:
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:

        intent.task = require('./../tasks/feedback/archive-goal');
        break;

      case 6:
      case 7:
      case 8:

        intent.task = require('./../tasks/feedback/delete-goal');
        break;

      case 9:
      case 10:
      case 11:
      case 12:
      case 13:
      case 14:
        //intent.task = require('./../tasks/feedback/edit-goal');

        break;

      case 15:
      case 16:
      case 17:
      case 18:
      case 19:
      case 20:
      case 21:
      case 22:
      case 23:
        intent.task = require('./../tasks/feedback/add-goal');
        break;
    }
    intent.context = context;
    return intent;
  }
}

module.exports = CommandGoalCrud;