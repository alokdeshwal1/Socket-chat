'use strict';

const Command = require('./command');
const Intent = require('./../intents/intent');

class CommandManagerCrud extends Command {
  constructor() {
    super();
    this.regExps = [
      /^\s*change manager\s*$/ig,
      /^\s*change manager @*([a-zA-Z0-9.\-_]*)\s*$/ig,
      /^\s*change manager to @*([a-zA-Z0-9.\-_]*)\s*$/ig,
      /^\s*change manager <@([a-zA-Z0-9.\-_]*)>:?\s*$/ig,
      /^\s*change manager to <@([a-zA-Z0-9.\-_]*)>:?\s*$/ig,
      /^\s*add manager\s*$/ig,
      /^\s*add manager @*([a-zA-Z0-9.\-_]*)\s*$/ig,
      /^\s*add manager to @*([a-zA-Z0-9.\-_]*)\s*$/ig,
      /^\s*add manager <@([a-zA-Z0-9.\-_]*)>:?\s*$/ig,
      /^\s*add manager to <@([a-zA-Z0-9.\-_]*)>:?\s*$/ig
    ];
  }

  parse(message) {
    var matches = super.parse(message);
    if ( ! (matches && matches.length > 0)) {
      return null;
    }

    var foundRegPos;
    for(var i = 0; i < matches.length; i++) {
      if (matches[i]) {
        foundRegPos = i;
        break;
      }
    }

    var context = {};
    var intent = new Intent();
    switch(i) {
      case 0:
        intent.task = require('./../tasks/feedback/change-manager');
        break;

      case 1:
      case 2:
        intent.task = require('./../tasks/feedback/change-manager');
        if (matches[i][1]) {
          context.changeManagerSlackUserName = matches[i][1];
        }
        break;

      case 3:
      case 4:
        intent.task = require('./../tasks/feedback/change-manager');
        if (matches[i][1]) {
          context.changeManagerSlackUserId = matches[i][1];
        }
        break;

      case 5:
        intent.task = require('./../tasks/feedback/add-manager');
        break;

      case 6:
      case 7:
        intent.task = require('./../tasks/feedback/add-manager');
        if (matches[i][1]) {
          context.addManagerSlackUserName = matches[i][1];
        }
        break;

      case 8:
      case 9:
        intent.task = require('./../tasks/feedback/add-manager');
        if (matches[i][1]) {
          context.addManagerSlackUserId = matches[i][1];
        }
        break;

    }
    intent.context = context;
    return intent;
  }
}

module.exports = CommandManagerCrud;