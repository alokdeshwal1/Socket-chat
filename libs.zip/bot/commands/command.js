'use strict';

const _ = require('lodash');

class Command {
  constructor() {
    this.regExps = [];
  }

  parse(message) {
    var matches = [];
    this.regExps.forEach(reg => {
      matches.push(reg.exec(message));
    });
    if (_.compact(matches).length < 1) {
      return null;
    }

    return matches;
  }
}

module.exports = Command;