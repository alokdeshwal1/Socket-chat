'use strict';

const Command = require('./command');
const Intent = require('./../intents/intent');

class CommandAdvisorCrud extends Command {
  constructor() {
    super();
    this.regExps = [
      /^\s*take me off as reviewer\s*$/ig,
      /^\s*take me off as a reviewer\s*$/ig,
      /^\s*take me off as reviewer @*([a-zA-Z0-9.\-_]*)\s*$/ig,
      /^\s*I no longer want to review @*([a-zA-Z0-9.\-_]*)\s*$/ig,
      /^\s*take me off as reviewer <@([a-zA-Z0-9.\-_]*)>:?\s*$/ig,
      /^\s*I no longer want to review <@([a-zA-Z0-9.\-_]*)>:?\s*$/ig
    ];
  }

  parse(message) {
    var matches = super.parse(message);
    if ( ! (matches && matches.length > 0)) {
      return null;
    }

    var foundRegPos;
    for(var i = 0; i < matches.length; i++) {
      if (matches[i]) {
        foundRegPos = i;
        break;
      }
    }

    var context = {};
    var intent = new Intent();
    switch(i) {
      case 0:
      case 1:
        intent.task = require('./../tasks/feedback/remove-advisor');
        break;

      case 2:
      case 3:
        intent.task = require('./../tasks/feedback/remove-advisor');
        if (matches[i][1]) {
          context.removeAdvisorSlackUserName = matches[i][1];
        }
        break;

      case 4:
      case 5:
        intent.task = require('./../tasks/feedback/remove-advisor');
        if (matches[i][1]) {
          context.removeAdvisorSlackUserId = matches[i][1];
        }
        break;

    }
    intent.context = context;
    return intent;
  }
}

module.exports = CommandAdvisorCrud;