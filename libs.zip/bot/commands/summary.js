'use strict';

const Command = require('./command');
const Intent = require('./../intents/intent');
const _ = require('lodash');
const moment = require('moment-timezone');
const trim = require('trim');
const assert = require('assert');
const CONSTANTS = require('./../../constants/constants');

class CommandSummary extends Command {
  constructor(timezone) {
    super();

    this.userTimezone = timezone;
    this.regExps = [
      {
        //                   group: 1                                               group: 2                       group: 3/4                         group: 4/5                      group 6
        'regExp': /^\s*(my|today|weekly|monthly|team)? ?(?:summary|feedback) ?(weekly|monthly|today)? ?(?:for (<?@?([a-zA-Z0-9.\-_]*)>?)*:?)? ?(?:from (<?@?([a-zA-Z0-9.\-_]*)>?)*:?)? ?(archived|active)?\s*$/ig,
        'action': summary
      }
    ];
  }

  parse(message, context) {
    var matches = [];
    _.pluck(this.regExps, 'regExp').forEach(reg => {
      matches.push(reg.exec(message));
    });
    if (_.compact(matches).length < 1) {
      return null;
    }
    else {
      var intent = new Intent();
      var foundPos;
      for(var i = 0; i < matches.length; i++) {
        if (matches[i]) {
          foundPos = i;
          break;
        }
      }

      intent.task = require('./../tasks/feedback/summary-report');
      if (typeof this.regExps[foundPos].action === 'function') {
        intent.context = this.regExps[foundPos].action.call(this, matches[foundPos]);
        if (intent.context && typeof intent.context === 'object') {
          intent.context.userCommandText = message;
        }
      }
      return intent;
    }
  }
}


function summary(matches) {
  const context = {};
  context.summary = {};
  matches = matches.map((item) => {
    return item && trim(item.toLowerCase());
  });

  if (matches[0]) {
    switch (matches[1]) {
      case 'weekly':
        context.summary.startDate = moment().tz(this.userTimezone || 'utc').utc().subtract(7, 'days').format();
        context.summary.endDate = moment().tz(this.userTimezone || 'utc').utc().format();

        break;

      case 'monthly':
        context.summary.startDate = moment().tz(this.userTimezone || 'utc').utc().subtract(1, 'months').format();
        context.summary.endDate = moment().tz(this.userTimezone || 'utc').utc().format();

        break;

      case 'today':
        context.summary.startDate = moment().tz(this.userTimezone || 'utc').utc().hours(0).minutes(0).seconds(0).format();
        context.summary.endDate = moment().tz(this.userTimezone || 'utc').utc().hours(23).minutes(59).seconds(59).format();

        break;

      case 'my':
        context.summary.user = 'I';
        break;
    }

    switch (matches[2]) {
      case 'weekly':
        context.summary.startDate = moment().tz(this.userTimezone || 'utc').utc().subtract(7, 'days').format();
        context.summary.endDate = moment().tz(this.userTimezone || 'utc').utc().format();

        break;

      case 'monthly':
        context.summary.startDate = moment().tz(this.userTimezone || 'utc').utc().subtract(1, 'months').format();
        context.summary.endDate = moment().tz(this.userTimezone || 'utc').utc().format();

        break;

      case 'today':
        context.summary.startDate = moment().tz(this.userTimezone || 'utc').utc().hours(0).minutes(0).seconds(0).format();
        context.summary.endDate = moment().tz(this.userTimezone || 'utc').utc().hours(23).minutes(59).seconds(59).format();

        break;
    }

    if (matches[4]) {
      switch(matches[4]) {
        case 'team':
          context.summary.isTeamSummary = true;

          break;

        case 'i':
        case 'me':
          context.summary.user = 'I';

          break;

        default:
          if (matches[3] && matches[3] !== matches[4] && matches[3].indexOf('<') === 0) {
            context.summary.user = matches[3];
          }
          else {
            context.summary.user = matches[4];
          }

          break;
      }
    }

    if (matches[6]) {
      switch(matches[6]) {
        case 'i':
        case 'me':
          context.summary.fromUser = 'I';

          break;

        default:
          if (matches[5] && matches[5] !== matches[6] && matches[5].indexOf('<') === 0) {
            context.summary.fromUser = matches[5];
          }
          else {
            context.summary.fromUser = matches[6];
          }

          break;
      }
    }

    if (matches[7]) {
      switch(matches[7]) {
        case CONSTANTS.DB.STATUS.ACTIVE:
          context.summary.status = CONSTANTS.DB.STATUS.ACTIVE;
          break;

        case CONSTANTS.DB.STATUS.ARCHIVED:
          context.summary.status = CONSTANTS.DB.STATUS.ARCHIVED;
          break;
      }
    }

    if ( ! (context.summary.startDate && context.summary.endDate)) {
      context.summary.startDate = moment().tz(this.userTimezone || 'utc').utc().subtract(7, 'days').format();
      context.summary.endDate = moment().tz(this.userTimezone || 'utc').utc().format();
    }
  }

  return context;
}


module.exports = CommandSummary;