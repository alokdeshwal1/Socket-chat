'use strict';

const Command = require('./command');
const Intent = require('./../intents/intent');
const _ = require('lodash');

class CommandChangeSelfAssessmentTime extends Command {
  constructor() {
    super();

    this.regExps = [
      /^\s*(?:change|update) ?(?:self)? assessment ?(time)?\s*$/ig,
    ];
  }

  parse(message) {
    var matches = super.parse(message);
    if ( ! (matches && matches.length > 0)) {
      return null;
    }

    var foundRegPos;
    for(var i = 0; i < matches.length; i++) {
      if (matches[i]) {
        foundRegPos = i;
        break;
      }
    }

    var context = {};
    var intent = new Intent();
    switch(i) {
      case 0:
        intent.task = require('./../tasks/feedback/change-self-assessment-time');
        break;
    }
    intent.context = context;
    return intent;
  }
}

module.exports = CommandChangeSelfAssessmentTime;