'use strict';

const Command = require('./command');
const Intent = require('./../intents/intent');
const _ = require('lodash');
const moment = require('moment-timezone');
const trim = require('trim');
const assert = require('assert');
const CONSTANTS = require('./../../constants/constants');

class CommandMyProfile extends Command {
  constructor() {
    super();

    this.regExps = [
      {
        'regExp': /^\s*my profiles?\s*$/ig,
        'action': myProfile
      },
      {
        'regExp': /^\s*view my profiles?\s*$/ig,
        'action': myProfile
      }
    ];
  }

  parse(message, context) {
    var matches = [];
    _.pluck(this.regExps, 'regExp').forEach(reg => {
      matches.push(reg.exec(message));
    });
    if (_.compact(matches).length < 1) {
      return null;
    }
    else {
      var intent = new Intent();
      var foundPos;
      for(var i = 0; i < matches.length; i++) {
          if (matches[i]) {
            foundPos = i;
            break;
          }
      }

      intent.task = require('./../tasks/feedback/my-profile');
      if (typeof this.regExps[foundPos].action === 'function') {
        intent.context = this.regExps[foundPos].action.call(this, matches[foundPos]);
        if (intent.context && typeof intent.context === 'object') {
          intent.context.userCommandText = message;
        }
      }
      return intent;
    }
  }
}

function myProfile() {
  return {};
}

module.exports = CommandMyProfile;