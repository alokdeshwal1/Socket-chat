'use strict';

const Command = require('./command');
const Intent = require('./../intents/intent');

class CommandTeamMember extends Command {
  constructor() {
    super();
    this.regExps = [
      /^\s*add (?:team member|direct report|team members|direct reports)\s*$/ig,

      /^\s*add (?:team member|direct report|team members|direct reports) @*([a-zA-Z0-9_]*)\s*$/ig,
      /^\s*add @*([a-zA-Z0-9_]*) to my team\s*$/ig,

      /^\s*add (?:team member|direct report|team members|direct reports) <@([a-zA-Z0-9.\-_]*)>:?\s*$/ig,
      /^\s*add <@([a-zA-Z0-9.\-_]*)>:? to my team\s*$/ig,

      /^\s*(?:remove|phase out) (?:team member|direct report|team members|direct reports)\s*$/ig,

      /^\s*(?:remove|phase out) (?:team member|direct report|team members|direct reports) @*([a-zA-Z0-9_]*)\s*$/ig,
      /^\s*(?:remove|phase out) @*([a-zA-Z0-9_]*) from my team\s*$/ig,

      /^\s*(?:remove|phase out) (?:team member|direct report|team members|direct reports) <@([a-zA-Z0-9.\-_]*)>:?\s*$/ig,
      /^\s*(?:remove|phase out) <@([a-zA-Z0-9.\-_]*)>:? from my team\s*$/ig
    ];
  }

  parse(message) {
    var matches = super.parse(message);
    if ( ! (matches && matches.length > 0)) {
      return null;
    }

    var foundRegPos;
    for(var i = 0; i < matches.length; i++) {
      if (matches[i]) {
        foundRegPos = i;
        break;
      }
    }

    var context = {};
    var intent = new Intent();
    switch(i) {
      case 0:
        intent.task = require('./../tasks/feedback/add-team-member');
        break;

      case 1:
      case 2:
        if (matches[i][1]) {
          context.addTeamMemberSlackUserName = matches[i][1];
        }
        intent.task = require('./../tasks/feedback/add-team-member');
        break;

      case 3:
      case 4:
        if (matches[i][1]) {
          context.addTeamMemberSlackUserId = matches[i][1];
        }
        intent.task = require('./../tasks/feedback/add-team-member');
        break;

      case 5:
        intent.task = require('./../tasks/feedback/remove-team-member');
        break;

      case 6:
      case 7:
        if (matches[i][1]) {
          context.removeTeamMemberSlackUserName = matches[i][1];
        }
        intent.task = require('./../tasks/feedback/remove-team-member');
        break;

      case 8:
      case 9:
        if (matches[i][1]) {
          context.removeTeamMemberSlackUserId = matches[i][1];
        }
        intent.task = require('./../tasks/feedback/remove-team-member');
        break;
    }
    intent.context = context;
    return intent;
  }
}

module.exports = CommandTeamMember;