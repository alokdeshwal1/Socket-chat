'use strict';

const Command = require('./command');
const Intent = require('./../intents/intent');
const _ = require('lodash');

class CommandHelp extends Command {
  constructor() {
    super();

    this.regExps = [
      {
        regExp: /^\s*(?:please)? ?help ?(?:me)? ?(?:please)?\s*$/ig
      },
      {
        regExp: /^\s*(?:can)? ?(?:you)? ?(?:please)? ?(?:help) ?(?:me)? ?(?:please)?\s*$/ig
      },
      {
        regExp: /^\s*(?:i need help|i'm confused)\s*$/ig
      }
    ];
  }

  parse(message, context) {
    var matches = [];
    _.pluck(this.regExps, 'regExp').forEach(reg => {
      matches.push(reg.exec(message));
    });
    if (_.compact(matches).length < 1) {
      return null;
    }
    else {
      var intent = new Intent();
      var foundPos;
      for(var i = 0; i < matches.length; i++) {
        if (matches[i]) {
          foundPos = i;
          break;
        }
      }

      intent.task = require('./../tasks/feedback/help');
      if (typeof this.regExps[foundPos].action === 'function') {
        intent.context = this.regExps[foundPos].action.call(this, matches[foundPos]);
        if (intent.context && typeof intent.context === 'object') {
          intent.context.userCommandText = message;
        }
      }
      return intent;
    }
  }
}

module.exports = CommandHelp;