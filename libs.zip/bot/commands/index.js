const fs = require('fs');
const Commands = {};

fs.readdirSync(__dirname).forEach(function(file) {
  var klass = require('./'+ file);
  if (klass.__proto__.name === 'Command') {
    Commands[klass.name] = klass;
  }
});

module.exports = Commands;