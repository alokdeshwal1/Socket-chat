'use strict';

const Command = require('./command');
const Intent = require('./../intents/intent');
const _ = require('lodash');
const moment = require('moment-timezone');
const trim = require('trim');
const assert = require('assert');
const CONSTANTS = require('./../../constants/constants');

class CommandRequestFeedback extends Command {
  constructor() {
    super();

    this.regExps = [
      {
        'regExp': /^\s*request feedback\s*$/ig
      },
      {
        'regExp': /^\s*request feedback from <?@*([a-zA-Z0-9.\-_]*)>?\s*$/ig,
        'action': function (matches) {
          const context = {};
          context.requestFeedbackFromUser = matches[1];
          return context;
        }
      }
    ];
  }

  parse(message, context) {
    var matches = [];
    _.pluck(this.regExps, 'regExp').forEach(reg => {
      matches.push(reg.exec(message));
    });
    if (_.compact(matches).length < 1) {
      return null;
    }
    else {
      var intent = new Intent();
      var foundPos;
      for(var i = 0; i < matches.length; i++) {
          if (matches[i]) {
            foundPos = i;
            break;
          }
      }

      intent.task = require('./../tasks/feedback/request-feedback');
      if (typeof this.regExps[foundPos].action === 'function') {
        intent.context = this.regExps[foundPos].action.call(this, matches[foundPos]);
        if (intent.context && typeof intent.context === 'object') {
          intent.context.userCommandText = message;
        }
      }
      return intent;
    }
  }
}

module.exports = CommandRequestFeedback;