'use strict';

class Validation {
  constructor() {
    this.errorCount = 0;
  }

  toJSON() {
    var keys = Object.keys(this);
    var copy = {};
    keys.forEach(key => {
      // we don't want event emitter object (_events, _eventsCount, _maxListeners)
      if (key.charAt(0) !== '_') {
        copy[key] = this[key];
      }
    });

    return JSON.stringify(Object.assign(copy, { __className: this.constructor.name }));
  }
}

module.exports = Validation;