'use strict';

const BotMessages = require('./../../configs/bot-messages');
const Validation = require('./validation');
const Validator = require('validator');
const Config = require('./../../configs/config');

class ValidationFreeFormText extends Validation {

  constructor(configuration) {
    super();
    this.errorMessage = BotMessages.Validation.freeFormText();
    this.minTextLength = configuration && configuration.minTextLength || 1;
  }

  validate(message) {
    if (message.length > this.minTextLength) {
      return Promise.resolve({
        status: 'success',
        result: message
      });
    }
    else {
      this.errorCount++;
      return Promise.resolve({
        status: 'error',
        error: this.errorMessage
      });
    }
  }
}

module.exports = ValidationFreeFormText;