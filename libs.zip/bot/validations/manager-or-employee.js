'use strict';

const BotMessages = require('./../../configs/bot-messages');
const Validation = require('./validation');
const Validator = require('validator');
const trim = require('trim');

class ValidationManagerOrEmployee extends Validation {

  constructor() {
    super();
    this.errorMessage = BotMessages.Validation.managerOrEmployee();
  }

  validate(message) {
    const manager = ['yes', 'I am a manager', 'for my team', 'my team', 'yess', 'yap', 'yup', 'yeah', 'manager'];
    const employee = ['n', 'no', 'na', 'noo', 'my own goals', 'my own goal', 'own goals', 'personal goals', 'personal goal', 'individual', 'individual goal', 'individual feedback', 'individual feedbacks', 'individual goals', 'for my goals', 'my goal', 'employee', 'employees'];

    if (Validator.isIn(message.toLowerCase(), manager) || Validator.isIn(message.toLowerCase(), employee)) {
      return Promise.resolve({
        status: 'success',
        result: Validator.isIn(trim(message.toLowerCase()), manager) ? 'manager' : 'employee'
      });
    }
    else {
      this.errorCount++;
      return Promise.resolve({
        status: 'error',
        error: this.errorMessage
      });
    }
  }
}

module.exports = ValidationManagerOrEmployee;