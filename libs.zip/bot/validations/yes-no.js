'use strict';

const BotMessages = require('./../../configs/bot-messages');
const Validation = require('./validation');
const Validator = require('validator');

class ValidationYesNo extends Validation {

  constructor() {
    super();
    this.errorMessage = BotMessages.Validation.yesNo();
  }

  validate(message) {
    const yeses = ['y', 'yes', 'ya', 'yess', 'sure', 'definitely', 'yap', 'yup', 'yeah', 'yep', 'yeah', 'yea', 'si', 'ya', 'ok'];
    const noes = ['n', 'no', 'na', 'noo', 'done', 'i\'m done', 'nope', 'nah', 'nope'];

    if (Validator.isIn(message.toLowerCase(), yeses) || Validator.isIn(message.toLowerCase(), noes)) {
      return Promise.resolve({
        status: 'success',
        result: Validator.isIn(message.toLowerCase(), yeses) ? 'yes' : 'no'
      });
    }
    else {
      this.errorCount++;
      return Promise.resolve({
        status: 'error',
        error: this.errorMessage
      });
    }
  }
}

module.exports = ValidationYesNo;