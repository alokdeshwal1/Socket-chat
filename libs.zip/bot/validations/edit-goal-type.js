'use strict';

const BotMessages = require('./../../configs/bot-messages');
const Validation = require('./validation');
const Validator = require('validator');

class ValidationEditGoalType extends Validation {

  constructor() {
    super();
    this.errorMessage = BotMessages.Validation.editGoalType();
  }

  validate(message) {
    const prompt = ['prompts', 'prompt', 'prompth', 'prompths', 'prom', 'pompth'];
    const giver = ['giver', 'givers', 'give', 'advisor', 'advisor'];

    if (Validator.isIn(message.toLowerCase(), prompt) || Validator.isIn(message.toLowerCase(), giver)) {
      return Promise.resolve({
        status: 'success',
        result: Validator.isIn(message.toLowerCase(), prompt) ? 'prompt' : 'giver'
      });
    }
    else {
      this.errorCount++;
      return Promise.resolve({
        status: 'error',
        error: this.errorMessage
      });
    }
  }
}

module.exports = ValidationEditGoalType;