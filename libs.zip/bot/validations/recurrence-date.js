'use strict';

const BotMessages = require('./../../configs/bot-messages');
const Validation = require('./validation');
const Validator = require('validator');
const Chrono = require('chrono-node');
const CronParser = require('cron-parser');
const MomentTimezone = require('moment-timezone');
const Util = require('util');
const assert = require('assert');
const moment = require('moment-timezone');
const Logger = require('./../../libs/logger');
const _ = require('lodash');
const trim = require('trim');

class ValidationRecurrenceDate extends Validation {

  constructor(timezone) {
    super();
    this.errorMessage = BotMessages.Validation.recurrenceDate();
    this.numberOfDates = 3;
    this.supportedModifiers = {
      'first': 1,
      'second': 2,
      'third': 3,
      'fourth': 4,
      '1st': 1,
      '2nd': 2,
      '3rd': 3,
      '4th': 4,
      'every other': 'every other'
    };
    this.timezone = timezone || 'utc';
  }

  _sanitize(message) {
    assert(typeof message == 'string', 'Message (String) is required');

    const list = {
      'mondays': 'monday',
      'tuesdays': 'tuesday',
      'wednesdays': 'wednesday',
      'thursdays': 'thursday',
      'fridays': 'friday',
      'saturdays': 'saturday',
      'sundays': 'sunday'
    };

    message = message.toLowerCase();
    Object.keys(list).forEach(itemKey => {
      message = message.replace(itemKey, list[itemKey]);
    });

    return message;
  }

  /**
   * Convert Chrono output to our own flavor of cron expression
   * we are adding modifier to specify the the rate to
   * will run on 'first', 'second', 'third', of the specified date
   *
   * example: 0 15 * * * | second
   *
   * @param message
   * @param data
   * @returns {*}
   * @private
   */
  _convert(message, data) {
    assert(typeof message === 'string', 'message (String) is required');
    assert(Array.isArray(data), 'data (Array) is required');
    message = trim(message);

    if (data.length < 1) {
      return null;
    }

    var days = [];
    var hour;
    var minute;
    var modifier;
    var makingAssumption = false;

    data.forEach(item => {
      const value = item.start.knownValues;

      if (typeof(value.weekday) !== 'undefined') {
        days.push(value.weekday);
      }
      if (typeof(value.hour) !== 'undefined') {
        hour = value.hour;
      }
      if (typeof(value.minute) !== 'undefined') {
        minute = value.minute;
      }
    });

    // check whether it is 1st, 2nd, third and etc, exclude ..of the month, of month, and month
    // example: first monday at 3pm
    Object.keys(this.supportedModifiers).forEach(m => {
      var regExp = eval('/\\s*'+ m +' ?((?!of the month|of month|of every month|month).)*\\s*/ig');
      var matches = regExp.exec(message);
      if (matches && matches[0] && trim(matches[0]) !== trim(m)) {
        modifier = m;
      }
    });

    if (typeof minute === 'undefined' && typeof hour === 'undefined') {
      var messageLC = message.toLowerCase();
      if (messageLC.indexOf('morning') !== -1) {
        hour = '10';
        minute = '0';
        makingAssumption = true;
      }
      else if (messageLC.indexOf('afternoon') !== -1) {
        hour = '14';
        minute = '0';
        makingAssumption = true;
      }
      else {
        hour = '10';
        minute = '0';
        makingAssumption = true;
      }
    }

    return {
      'expression': Util.format('%s %s * * %s',
                                (typeof minute !== 'undefined') ? minute : '*',
                                (typeof hour !== 'undefined') ? hour : '*',
                                (days.length > 0) ? days.join(',') : '1-5'),
      'modifier': modifier,
      'userText': message,
      'makingAssumption': makingAssumption
    }
  }

  /**
   * Add additional support for "1st", "2nd" of the month and etc
   */
  _refine(cron, message) {
    var regExp = /([0-9]+)(?:st|nd|rd|th) ?(?:of the month|of month|month|of every month)+/ig;
    var matches = regExp.exec(message);
    if (matches && matches[1] && Number(trim(matches[1])) > 0) {
      if ( ! (cron && cron.expression)) {
        cron = {
          expression: '0 10 * * *'
        };
      }

      var cronArray = cron.expression.split(' ');
      cronArray[2] = trim(matches[1]);
      cronArray[4] = '*';

      return {
        'expression': cronArray.join(' '),
        'userText': message,
        'makingAssumption': false
      };
    }

    return cron;
  }

  /**
   * This is to make user's input default to PM for hours (1 to 5) if input has no PM or AM defined
   */
  _changeOutputHours(cronExp, message) {
    try {
      var cronArray = cronExp.split(' ');
      if (Number(cronArray[1]) >= 1 && Number(cronArray[1]) <= 6 && message.toLowerCase().indexOf('am') === -1) {
        cronArray[1] = Number(cronArray[1]) + 12;
      }
      return cronArray.join(' ');
    }
    catch (ex) {
      Logger.error('Failed to excuted changeOutputHours', ex);
    }

    return cronExp;
  }

  _getIntervalDates(cronInterval, timezone, numberOfDates) {
    var result = {
      original: [],
      formatted: [],
      moment: []
    };
    while(result.original.length < numberOfDates) {
      var date = cronInterval.next().toString();
      result.original.push(date);
      var formattedDate = moment.tz(moment(date, 'ddd MMM DD YYYY H:mm:ss').format('YYYY-MM-DD HH:mm:ss'), timezone);
      result.formatted.push(formattedDate.format());
      result.moment.push(formattedDate);
      //result.formatted.push(moment(date, 'ddd MMM DD YYYY H:mm:ss').format('YYYY/MM/DD HH:mm ZZ').replace('+0000', moment().tz(timezone).format('ZZ')).format(outputDateFormat));
    }

    return result;
  }

  /**
   * Get dates by user input text
   *
   * @param message
   * @param currentDate - moment date in UTC timezone
   * @param startDate - use this for Unit test purpose
   * @param outputDateFormat
   * @returns {*}
   */
  getDates(message, currentDate, startDate, outputDateFormat) {
    assert(typeof message === 'string', 'Message (String) is required');
    currentDate = (currentDate) ? moment(currentDate).tz(this.timezone) : moment().tz(this.timezone);
    startDate = (startDate) ? moment(startDate).tz(this.timezone) : currentDate;
    outputDateFormat = outputDateFormat || 'M/D dddd h:mmA';
    message = this._sanitize(message);
    const cron = this._refine(this._convert(message, Chrono.parse(message)), message);
    if ( ! cron) {
      return null;
    }

    cron.expression = this._changeOutputHours(cron.expression, message);
    var parserOption = {};
    try {
      if (this.timezone && this.timezone.length > 0) {
        // we only interested in user's date time, not the timezone as Parse works in UTC timezone
        parserOption.currentDate = Number(moment(startDate.format('ddd MMM DD YYYY H:mm:ss') + ' UTC', 'ddd MMM DD YYYY H:mm:ss z').format('x'));
      }
    }
    catch (ex) {
      Logger.error('Failed to convert user timezone to triggerDate for CronParser', ex, ex.stack);
    }

    const interval = CronParser.parseExpression(cron.expression, Object.keys(parserOption).length > 0 ? parserOption : undefined);
    const result = this._getIntervalDates(interval, this.timezone, this.numberOfDates * 2, outputDateFormat); // get more than we need just in case
    var originalDates = result.original;
    var dates = result.formatted;

    // contains modifier that specify whether it is a 1st, 2nd, third, and etc.
    if ( ! Number.isNaN(Number(this.supportedModifiers[cron.modifier]))) {
      dates = this.findDatesWithModifier(originalDates[0], this.supportedModifiers[cron.modifier], this.numberOfDates, this.timezone, outputDateFormat);
    }
    else if (typeof cron.modifier === 'string') {
      switch(cron.modifier) {
        case 'every other':
          dates = dates.filter((item, key) => {
            return moment(item).diff(currentDate) >= -(60 * 1000) && (key % 2 === 0);
          });
          if (dates.length <= 0) {
            dates = this._getEveryOtherWeekDates(currentDate, interval, this.timezone, this.numberOfDates * 2);
          }

          break;
      }
    }

    cron.sampleDates = dates.slice(0, this.numberOfDates).map((item) => {
      return moment(item).tz(this.timezone).format(outputDateFormat);
    });
    cron.startDate = startDate.format();
    cron.timezone = this.timezone;
    return cron;
  }

  _getEveryOtherWeekDates(currentDate, cronInterval, timezone, numberOfDates) {
    var dates = this._getIntervalDates(cronInterval, timezone, numberOfDates).formatted;
    dates = dates.filter((item, key) => {
      return moment(item).diff(currentDate) >= 0 && (key % 2 === 0);
    });

    if (dates.length <= 0) {
      return this._getEveryOtherWeekDates(currentDate, cronInterval, timezone, numberOfDates);
    }

    return dates;
  }


  /**
   * Find matching dates that fulfill the cron modifier expression
   *
   * @param startingDate - UTC date
   * @param modifierValue
   * @param numberOfDates
   * @returns {Array}
   */
  findDatesWithModifier(startingDate, modifierValue, numberOfDates, timezone) {
    var result = [];
    var refDate = moment(startingDate, 'ddd MMM DD YYYY H:mm:ss z ZZ');
    var searchDate = moment(refDate);
    const pos = modifierValue;

    while(result.length < numberOfDates) {
      searchDate = searchDate.startOf('month');
      var matches = [];
      var matchDates = [];

      // loop through and find matching day (ex: Monday, Tuesday) of the month
      // cannot use moment.day() because it could be back dated
      var loopEnd = moment(searchDate).endOf('month').format('D');
      for(var i = 1; i < loopEnd; i ++) {
        if(searchDate.format('dddd') === refDate.format('dddd')) {
          matches.push(moment(searchDate));
          if(matches.length === pos) {
            break;
          }
        }
        searchDate = moment(searchDate).add(1, 'days');
      }

      matchDates.push(matches.pop());

      // March 8, 2016 11:25 AM
      //matchDate = moment(matchDate.format('LL') +' '+ refDate.format('LT'), '');
      matchDates.forEach(item => {
        item.set('hour', refDate.get('hours'));
        item.set('minute', refDate.get('minute'));
        item.set('second', refDate.get('second'));

        if(refDate.diff(item) <= 0) {
          var formattedDate = moment.tz(moment(item, 'ddd MMM DD YYYY H:mm:ss').format('YYYY-MM-DD HH:mm:ss'), timezone);
          result.push(formattedDate);
        }
      });

      searchDate = moment(searchDate).startOf('month').add(1, 'months');
    }

    return result;
  }

  validate(message) {
    var result;
    try {
      result = this.getDates(message);
    }
    catch(ex) {
      Logger.error('Failed to fire getDates', ex, ex.stack);
      return Promise.resolve({
        status: 'error',
        error: 'Failed to read the date input'
      });
    }

    if (result) {
      return Promise.resolve({
        status: 'success',
        result: result
      });
    }
    else {
      this.errorCount++;
      return Promise.resolve({
        status: 'error',
        error: this.errorMessage
      });
    }
  }
}

module.exports = ValidationRecurrenceDate;