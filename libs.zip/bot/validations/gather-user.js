'use strict';

const CONSTANTS = require('./../../constants/constants');
const BotMessages = require('./../../configs/bot-messages');
const Validation = require('./validation');
const ModelUser = require('./../../models/user');
const ModelSlackIntegration = require('./../../models/slack-integration');
const assert = require('assert');
const _ = require('lodash');
const trim = require('trim');
const Util = require('util');
const Co = require('co');
const SlackAPI = require('./../slack-api');
const Logger = require('./../../libs/logger');

class ValidationGatherUser extends Validation {

  constructor(errorMessage) {
    super();
    const BotMessages = require('./../../configs/bot-messages');
    this.errorMessage = errorMessage || BotMessages.Validation.gatherUser();
  }

  _parseTextToUsersList(message) {
    if ( ! (message && message.length > 0)) {
      return;
    }

    var commaSeparated = [];
    message.split(',').map((user) => {
      if (user.indexOf(':') !== -1) {
        user = user.split(':');
      }
      commaSeparated = commaSeparated.concat(user);
    });
    commaSeparated = _.compact(commaSeparated.map((user) => {
      return user.replace(/ /g, '')
    }));

    var spaceSeparated = [];
    message.split(' ').map((user) => {
      if (user.indexOf(':') !== -1) {
        user = user.split(':');
      }
      spaceSeparated = spaceSeparated.concat(user);
    });
    spaceSeparated = _.compact(spaceSeparated.map((user) => {
      return user.replace(/ /g, '');
    }));
    spaceSeparated = _.filter(spaceSeparated, (user) => {
      return (trim(user) !== ',');
    });

    return commaSeparated.length >= spaceSeparated.length ? commaSeparated : this._removeUnnecessaryCharacters(spaceSeparated);
  }

  _removeUnnecessaryCharacters(input) {
    if (Array.isArray(input)) {
      input = input.map((item) => {
        return item.replace(/,/ig, '');
      });
    }
    return input;
  }

  _findUserBySlackUserId(slackIntegration, slackUserId) {
    return new Promise((resolve, reject) => {
      Co(function *() {
        try {
          var user = yield ModelUser.findOne({
            slackUserId: slackUserId,
            slackIntegration: slackIntegration.id,
            status: CONSTANTS.DB.STATUS.ACTIVE
          }).populate('manager');

          if (user) {
            return resolve(user);
          }

          // try to find user through SlackAPI
          const slackApi = new SlackAPI(slackIntegration.accessToken);
          user = yield slackApi.getUserById(slackUserId);
          if (user) {
            user = yield ModelUser.upsertSlackUser(slackIntegration.company.toString(), slackIntegration.id, user);
            return resolve(user);
          }
        }
        catch (ex) {
          Logger.error({ex, exStack: ex.stack, slackIntegration, slackUserId}, '_findUserBySlackUserId error');
        }

        return resolve(null);
      }.bind(this));
    });
  }

  _findUserBySlackName(slackIntegration, slackUserName) {
    return new Promise((resolve, reject) => {
      Co(function *() {
        try {
          var user = yield ModelUser.findOne({
            slackUserNameLower: slackUserName.toLowerCase(),
            slackIntegration: slackIntegration.id,
            status: CONSTANTS.DB.STATUS.ACTIVE
          }).populate('manager');

          if (user) {
            return resolve(user);
          }

          // try to find user through SlackAPI
          const slackApi = new SlackAPI(slackIntegration.accessToken);
          user = yield slackApi.getUser(slackUserName);
          if (user) {
            user = yield ModelUser.upsertSlackUser(slackIntegration.company.toString(), slackIntegration.id, user);
            return resolve(user);
          }
        }
        catch (ex) {
          Logger.error({ex, exStack: ex.stack, slackIntegration, slackUserName}, '_findUserBySlackName error');
        }

        return resolve(null);
      }.bind(this));
    });
  }

  validate(message, context) {
    try {
      assert(typeof context.slackIntegrationId === 'string', 'Context SlackIntegrationId (String) is required but missing');
    }
    catch (ex) {
      // try to find slackIntegrationId ourselves
      if (context.user && context.user.slackIntegration) {
        if (context.user.slackIntegration instanceof ModelSlackIntegration) {
          context.slackIntegrationId = context.user.slackIntegration.id;
        }
        else {
          context.slackIntegrationId = context.user.slackIntegration.toString();
        }
      }
      else {
        throw ex;
      }
    }

    return new Promise((resolve, reject) => {
      Co(function *() {
        try {
          const users = this._parseTextToUsersList(message);
          if (! (users && Array.isArray(users))) {
            return resolve({
              status: 'error',
              error: this.errorMessage
            })
          }
          const slackIntegration = yield ModelSlackIntegration.findOne({
            _id: context.slackIntegrationId,
            status: CONSTANTS.DB.STATUS.ACTIVE
          });

          const actions = [];
          users.forEach((user) => {
            var regExp = /^\s*<@([a-zA-Z0-9.\-_]*)>:?\s*$/ig;
            var regMatch = regExp.exec(user);
            if(regMatch && regMatch[1] && trim(regMatch[1]).length > 0) {
              actions.push(this._findUserBySlackUserId(slackIntegration, trim(regMatch[1])));
            }
            else {
              actions.push(this._findUserBySlackName(slackIntegration, user.toLowerCase()));
            }
          });

          var data = yield Promise.all(actions);
          for(var i = 0; i < data.length; i++) {
            if ( ! data[i]) {
              return resolve({
                status: 'error',
                error: Util.format(BotMessages.ValidationGatherUser.userIsNotFound(), users[i])
              });
              break;
            }
          }

          return resolve({
            status: 'success',
            result: data
          });
        }
        catch (ex) {
          Logger.error({ex, exStack: ex.stack, message, context}, 'Gather User Validate failed');
          return resolve({status: 'error', error: this.errorMessage});
        }
      }.bind(this));
    });
  }
}

module.exports = ValidationGatherUser;