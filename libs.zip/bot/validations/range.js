'use strict';

const CONSTANTS = require('./../../constants/constants');
const BotMessages = require('./../../configs/bot-messages');
const Validation = require('./validation');
const Validator = require('validator');
const assert = require('assert');
const _ = require('lodash');

class ValidationRange extends Validation {

  constructor(allowedRange) {
    super();
    this.allowedRange = allowedRange || [];
    this.errorMessage = BotMessages.Validation.range();
  }

  validate(message) {
    return new Promise((resolve, reject) => {
      try {
        if (Validator.isIn(message, this.allowedRange)) {
          return resolve({
            'status': 'success',
            'result': message
          });
        }
        else {
          return resolve({
            'status': 'error',
            'error': BotMessages.Validation.rangeNotFound({ inputText: message})
          });
        }
      }
      catch(ex) {
        reject(ex);
      }
    });
  }
}

module.exports = ValidationRange;