'use strict';

const Logger = require('./../libs/logger');
const WebSocket = require('ws');
const Request = require('request');
const Co = require('co');
const Config = require('./../configs/config');
const assert = require('assert');
const EventEmitter = require('events').EventEmitter;
const Bluebird = require('bluebird');

Promise.prototype.finally = Promise.prototype.finally || function(onResolveOrReject) {
  return this.catch(function(reason){
    return reason;
  }).then(onResolveOrReject);
};

class Bot extends EventEmitter {

  constructor(accessToken, name, events) {
    super();

    assert.equal(typeof accessToken, 'string', 'AccessToken (String) is required');
    assert.equal(typeof name, 'string', 'Name (String) is required');
    events && assert.equal(Array.isArray(events), true, 'Events must be an array');

    this.accessToken = accessToken;
    this.name = name;
    this.events = events || Config.slack.botEvents;

    this.login();
  }

  _find(arr, params) {
    var result = {};

    arr.forEach(function(item) {
      if (Object.keys(params).every(function(key) { return item[key] === params[key];})) {
        result = item;
      }
    });

    return result;
  }

  _api(methodName, params) {
    assert.equal(typeof methodName, 'string', 'MethodName (String) is required');
    params && assert.equal(typeof params, 'object', 'Params must be an object');

    const data = {
      url: 'https://slack.com/api/' + methodName,
      form: this._preprocessParams(params)
    };

    return new Promise(function(resolve, reject) {
      Request.post(data, function(err, request, body) {
        if(err) {
          reject(err);
          return false;
        }

        try {
          body = JSON.parse(body);

          // Response always contain a top-level boolean property ok,
          // indicating success or failure
          if(body.ok) {
            resolve(body);
          } else {
            reject(body);
          }

        } catch(e) {
          reject(e);
        }
      });
    });
  }

  login() {
    this.loginTry = this.loginTry || 0;
    this._api('rtm.start').then((data) => {
      this.wsUrl = data.url;
      this.self = data.self;
      this.team = data.team;
      this.channels = data.channels;
      this.users = data.users;
      this.ims = data.ims;
      this.groups = data.groups;

      this.emit('loginSlack');

      this.connect();
    }).catch((data) => {
      if (this.loginTry++ < 3 ) {
        return this.login();
      }
      else {
        Logger.error('Slack bot rtm.start failed', data, this);
      }
    });
  }

  connect() {
    this.ws = new WebSocket(this.wsUrl);

    this.ws.on('open', function(data) {
      this.emit('openSlackWs', data);
    }.bind(this));

    this.ws.on('close', function(data) {
      this.emit('closeSlackWs', data);
    }.bind(this));

    this.events.forEach(function(event) {
      this.ws.on(event, function(data) {
        try {
          this.emit(event, JSON.parse(data));
        } catch(e) {
          Logger.error(e);
        }
      }.bind(this));
    }.bind(this));
  }

  getChannels() {
    if(this.channels) {
      return Promise.resolve({channels: this.channels});
    }
    return this._api('channels.list');
  }

  getUsers() {
    if(this.users) {
      return Promise.resolve({members: this.users});
    }

    return this._api('users.list');
  }

  getGroups() {
    if(this.groups) {
      return Promise.resolve({groups: this.groups});
    }

    return this._api('groups.list');
  }

  getUser(name) {
    assert.equal(typeof name, 'string', 'Name (String) is required');
    return this.getUsers().then(function(data) {
      return this._find(data.members, {name: name});
    }.bind(this));
  }

  getUserById(id) {
    assert.equal(typeof id, 'string', 'Id (String) is required');
    return this.getUsers().then(function(data) {
      return this._find(data.members, {id: id});
    }.bind(this));
  }

  getUserByFirstName(firstName) {
    assert.equal(typeof firstName, 'string', 'FirstName (String) is required');
    return this.getUsers().then(function(data) {
      return new Promise(function(resolve, reject) {
        var result = null;
        data.members.forEach(function(item) {
          if ( ! result && item.profile && item.profile.first_name &&
              item.profile.first_name.toLowerCase() === firstName.toLowerCase()) {

            result = item;
          }
        });

        resolve(result);
      });
    }.bind(this));
  }

  getChannel(name) {
    assert.equal(typeof name, 'string', 'Name (String) is required');
    return this.getChannels().then(function(data) {
      return this._find(data.channels, {name: name});
    }.bind(this));
  }

  getGroup(name) {
    assert.equal(typeof name, 'string', 'Name (String) is required');
    return this.getGroups().then(function(data) {
      return this._find(data.groups, {name: name});
    }.bind(this));
  }

  getChannelId(name) {
    return this.getChannel(name).then(function(channel) {
      return channel.id;
    });
  }

  getGroupId(name) {
    assert.equal(typeof name, 'string', 'Name (String) is required');
    return this.getGroup(name).then(function(group) {
      return group.id;
    });
  }

  getChatId(name) {
    assert.equal(typeof name, 'string', 'Name (String) is required');

    return this.getUser(name)
      .then(function(data) {
        var chatId = this._find(this.ims, {user: data.id}).id;
        return chatId || this.openIm(data.id);
      }.bind(this))
      .then(function(data) {
        return typeof data === 'string' ? data : data.channel.id;
      });
  }

  openIm(userId) {
    assert.equal(typeof userId, 'string', 'UserId (String) is required');
    return this._api('im.open', {user: userId});
  }

  postMessage(id, text, params) {
    assert.equal(typeof id, 'string', 'Id (String) is required');
    assert.equal(typeof text, 'string', 'Text (String) is required');
    params && assert.equal(typeof params, 'object', 'params must be an Object');

    params = Object.assign({
      text: text,
      channel: id,
      username: this.name
    }, params || {});

    return this._api('chat.postMessage', params);
  }

  postMessageToUser(name, text, params, cb) {
    return this._post('user', name, text, params, cb);
  }

  postMessageToChannel(name, text, params, cb) {
    return this._post('channel', name, text, params, cb);
  }

  postMessageToGroup(name, text, params, cb) {
    return this._post('group', name, text, params, cb);
  }

  postEmojis(channel, emojis) {
    return Bluebird.each(emojis, item => {
      return this._api('reactions.add', {
        name: item.emoji,
        channel: channel,
        timestamp: item.ts
      }).then((result) => {
        // to solve the problem that Slack UI is not showing emoji icons in the right sequence
        return new Promise((resolve, reject) => {
          setTimeout(() => {
            return resolve(result);
          }, 100);
        });
      });
    });
  }

  deleteEmojis(channel, emojis) {
    return Bluebird.map(emojis, item => {
      return this._api('reactions.remove', {
        name: item.emoji,
        channel: channel,
        timestamp: item.ts
      });
    });
  }

  postEmojiToChannel(channel, emoji, timestamp) {
    return this._api('reactions.add', {
      name: emoji,
      channel: channel,
      timestamp: timestamp
    });
  }

  _post(type, name, text, params, cb) {
    var method = ({
      'group': 'getGroupId',
      'channel': 'getChannelId',
      'user': 'getChatId'
    })[type];

    if(typeof params === 'function') {
      cb = params;
      params = null;
    }

    return this[method](name)
      .then(function(itemId) {
        return this.postMessage(itemId, text, params);
      }.bind(this))
      .finally(function(data) {
        if(cb) {
          cb(data._value);
        }
      });
  }

  postTo(name, text, params, cb) {
    return Promise.all([this.getChannels(), this.getUsers(), this.getGroups()]).then(function(data) {

      var all = [].concat(data[0].channels, data[1].members, data[2].groups);
      var result = this._find(all, {name: name});

      assert(Object.keys(result).length, 'wrong name');

      if(result['is_channel']) {
        return this.postMessageToChannel(name, text, params, cb);
      } else if(result['is_group']) {
        return this.postMessageToGroup(name, text, params, cb);
      } else {
        return this.postMessageToUser(name, text, params, cb);
      }
    }.bind(this));
  }

  /**
   * Preprocessing of params
   * @param params
   * @returns {object}
   * @private
   */
  _preprocessParams(params) {
    params = Object.assign(params || {}, {token: this.accessToken});

    Object.keys(params).forEach(function(name) {
      var param = params[name];

      if(param && typeof param === 'object') {
        params[name] = JSON.stringify(param);
      }
    });

    return params;
  }
}


module.exports = Bot;
