'use strict';

const assert = require('assert');
const ModelUser = require('./../../models/user');
const ModelFunction = require('./../../models/function');
const ModelUserGoal = require('./../../models/user-goal');
const ModelUserTrigger = require('./../../models/user-trigger');
const Co = require('co');
const Logger = require('./../../libs/logger');
const jackrabbit = require('jackrabbit');
const CONSTANTS = require('./../../constants/constants');
const Config = require('./../../configs/config');
const Task = require('./../../bot/task');
const BotMessages = require('./../../configs/bot-messages');
const Helper = require('./../../bot/libs/helper');

class HookConfirmAddManager {

  static run(context, task) {
    assert(typeof context.slackUserId === 'string', 'Context slackUserId (string) is required');
    assert(typeof context.newManagerId === 'string', 'Context newManagerId (string) is required');
    assert(typeof context.confirmAddManager === 'string', 'Context confirmAddManager (string) is required');

    return new Promise((resolve, reject) => {
      Co(function *() {
        try {
          if ( ! (context.user && context.user instanceof ModelUser)) {
            context.user = yield ModelUser.findOne({ slackUserId: context.slackUserId });
          }

          if (context.confirmAddManager === 'yes') {
            context.user.manager = context.newManagerId;
            yield context.user.save();

            task.emit(CONSTANTS.BOT_EVENT.MESSAGE, 'Great! Done');
          }
          else {
            task.emit(CONSTANTS.BOT_EVENT.MESSAGE, 'No worries. I didn’t change anything');
          }

          return resolve(true);
        }
        catch(ex) {
          Logger.error(__filename, 'Failed to run HookConfirmAddManager', ex, ex.stack);
          return reject(ex);
        }
      }.bind(this));
    });
  }
}

module.exports = HookConfirmAddManager;