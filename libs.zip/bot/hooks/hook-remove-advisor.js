'use strict';

const assert = require('assert');
const ModelUser = require('./../../models/user');
const ModelUserGoal = require('./../../models/user-goal');
const Co = require('co');
const Logger = require('./../../libs/logger');
const jackrabbit = require('jackrabbit');
const CONSTANTS = require('./../../constants/constants');
const Config = require('./../../configs/config');
const _ = require('lodash');
const Util = require('util');
const Join = require('join-component');
const Helper = require('./../libs/helper');

class HookRemoveAdvisor {

  static run(context, task) {
    assert(typeof context.slackUserId === 'string', 'Context slackUserId (string) is required');
    assert(Array.isArray(context.removeAdvisorSlackUser), 'Context removeAdvisorSlackUser (array) is required');

    return new Promise((resolve, reject) => {
      Co(function *() {
        try {
          if (! (context.user && context.user instanceof ModelUser)) {
            context.user = yield ModelUser.findBySlackId(context.slackUserId);
          }

          var notRemoveableUsers = [];
          var removeAbleGoals = {};
          for(let removeFromUser of context.removeAdvisorSlackUser) {
            var userGoals = yield ModelUserGoal.find({ user: removeFromUser.id, advisors: context.user.id, status: CONSTANTS.DB.STATUS.ACTIVE }).populate('goal');
            if (userGoals && Array.isArray(userGoals) && userGoals.length > 0) {
              removeAbleGoals[removeFromUser.id] = {
                'user': removeFromUser,
                'userGoals': userGoals
              }
            }
            else {
              notRemoveableUsers.push(removeFromUser);
            }
          }

          if (notRemoveableUsers.length > 0) {
            task.emit(CONSTANTS.BOT_EVENT.MESSAGE, Util.format('It doesn\'t look like you’re currently a reviewer for %s',
              Join(_.pluck(notRemoveableUsers, 'firstName'), ', and')));
          }
          else if (removeAbleGoals && Object.keys(removeAbleGoals).length > 0) {
            var attachmentFields = [];
            var goalKeys = Object.keys(removeAbleGoals);
            for(var i = 0; i < goalKeys.length; i++) {
              var row = removeAbleGoals[goalKeys[i]];
              var goalString = Join(_.map(row.userGoals, (item) => {
                return item.name || item.goal && item.goal.name;
              }), ', and');

              attachmentFields.push({
                title: 'Goal #'+ (i+1),
                value: goalString
              });
            }

            context.removeAbleGoals = removeAbleGoals;
            context.removeGoalsAttachment = JSON.stringify(Helper.buildAttachmentMessage({
              fallback: 'Confirm delete goals',
              pretext: Util.format('Ok. You’re currently giving *%s* on the following goals.',
                        Join(_.pluck(removeAbleGoals, 'user.firstName'), ', and')),
              color: Config.botAttachmentMessageColor.action,
              fields: attachmentFields
            }));

            task.chainTask({
              name: 'RemoveAdvisorConfirmation',
              priority: 2,
              interactions: [
                {
                  type: 'ActionAttachmentMessage',
                  message: '[[removeGoalsAttachment]]'
                },
                {
                  type: 'ActionYesNo',
                  message: Util.format('Are you sure you want to stop giving *%s* feedback?', Join(_.pluck(removeAbleGoals, 'user.firstName'), ', and')),
                  saveContextKey: 'confirmRemoveAdvisor'
                }
              ],
              after: ['HookConfirmRemoveAdvisor']
            }, context);
          }

          return resolve(true);
        }
        catch(ex) {
          Logger.error(__filename, 'Failed to run HookRemoveAdvisor', ex, ex.stack);
          return reject(ex);
        }
      }.bind(this));
    });
  }
}

module.exports = HookRemoveAdvisor;