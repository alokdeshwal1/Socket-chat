'use strict';

const assert = require('assert');
const ModelUser = require('./../../models/user');
const ModelFunction = require('./../../models/function');
const ModelUserGoal = require('./../../models/user-goal');
const ModelUserTrigger = require('./../../models/user-trigger');
const Co = require('co');
const Logger = require('./../../libs/logger');
const jackrabbit = require('jackrabbit');
const CONSTANTS = require('./../../constants/constants');
const Config = require('./../../configs/config');

class HookConfirmManager {

  static run(context, task) {
    assert(typeof context.slackUserId === 'string', 'Context slackUserId (string) is required');
    assert(typeof context.confirmManager === 'string', 'Context confirmManager (string) is required');
    assert(typeof context.employeeFirstName === 'string', 'Context employeeFirstName (string) is required');
    assert(typeof context.managerFirstName === 'string', 'Context managerFirstName (string) is required');
    assert(typeof context.managerSlackUserId === 'string', 'Context managerSlackUserId (string) is required');
    assert(typeof context.currentManagerFirstName === 'string', 'Context currentManagerFirstName (string) is required');

    return new Promise((resolve, reject) => {
      Co(function *() {
        try {
          if (! (context.user && context.user instanceof ModelUser)) {
            context.user = yield ModelUser.findBySlackId(context.slackUserId);
          }

          if (context.confirmManager === 'yes') {
            var replacedManager = context.user.manager;
            if ( ! (replacedManager instanceof ModelUser)) {
              replacedManager = yield ModelUser.findOne({ _id: replacedManager.toString() });
            }
            var replacedManagerSlackUserId = replacedManager.slackUserId;

            // update the db record
            context.user.manager = context.managerUserId;
            yield context.user.save;

            // tell the employee
            task.emit(CONSTANTS.BOT_EVENT.TASK, {
              slackUserId: context.slackUserId,
              context: {
                slackUserId: context.slackUserId,
                managerFirstName: context.managerFirstName
              },
              task: require('./../tasks/feedback/confirm-manager-yes-employee')
            });

            // tell the manager
            task.emit(CONSTANTS.BOT_EVENT.TASK, {
              slackUserId: context.managerSlackUserId,
              context: {
                slackUserId: context.managerSlackUserId,
                employeeFirstName: context.employeeFirstName
              },
              task: require('./../tasks/feedback/confirm-manager-yes-manager')
            });

            // tell the replaced manager
            task.emit(CONSTANTS.BOT_EVENT.TASK, {
              slackUserId: replacedManagerSlackUserId,
              context: {
                slackUserId: replacedManagerSlackUserId,
                employeeFirstName: context.employeeFirstName,
                managerFirstName: context.managerFirstName
              },
              task: require('./../tasks/feedback/confirm-manager-yes-replaced-manager')
            });

          }
          else {
            // tell the employee
            task.emit(CONSTANTS.BOT_EVENT.TASK, {
              slackUserId: context.slackUserId,
              context: {
                slackUserId: context.slackUserId
              },
              task: require('./../tasks/feedback/confirm-manager-no-employee')
            });

            // tell the manager
            task.emit(CONSTANTS.BOT_EVENT.TASK, {
              slackUserId: context.managerSlackUserId,
              context: {
                slackUserId: context.managerSlackUserId,
                employeeFirstName: context.employeeFirstName
              },
              task: require('./../tasks/feedback/confirm-manager-no-manager')
            });
          }

          return resolve(true);
        }
        catch(ex) {
          Logger.error(__filename, 'Failed to run HookConfirmManager', ex, ex.stack);
          return reject(ex);
        }
      }.bind(this));
    });
  }
}

module.exports = HookConfirmManager;