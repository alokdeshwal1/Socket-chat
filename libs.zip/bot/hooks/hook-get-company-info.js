'use strict';

const assert = require('assert');
const ModelUser = require('./../../models/user');
const ModelFunction = require('./../../models/function');
const ModelUserGoal = require('./../../models/user-goal');
const ModelUserTrigger = require('./../../models/user-trigger');
const Co = require('co');
const Logger = require('./../../libs/logger');
const jackrabbit = require('jackrabbit');
const CONSTANTS = require('./../../constants/constants');
const Config = require('./../../configs/config');

class HookGetCompanyInfo {

  static run(context) {
    return new Promise((resolve, reject) => {
      assert(typeof context.slackUserId === 'string', 'Context slackUserId (string) is required');

      Co(function *() {
        try {
          if ( ! (context.user && context.user instanceof ModelUser)) {
            context.user = yield ModelUser.findBySlackId(context.slackUserId);
          }

          assert(typeof context.user.company.id === 'string', 'User\'s company id is not found');
          context.company = context.user.company;

          return resolve(true);
        }
        catch(ex) {
          Logger.error({ex, exStack: ex.stack, context} , 'Failed to run '+ this.constructor.name);
          return reject(ex);
        }
      }.bind(this));
    });
  }
}

module.exports = HookGetCompanyInfo;