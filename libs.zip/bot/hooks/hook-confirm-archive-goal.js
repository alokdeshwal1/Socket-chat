'use strict';

const assert = require('assert');
const ModelUser = require('./../../models/user');
const ModelFunction = require('./../../models/function');
const ModelUserGoal = require('./../../models/user-goal');
const ModelUserTrigger = require('./../../models/user-trigger');
const Co = require('co');
const Logger = require('./../../libs/logger');
const jackrabbit = require('jackrabbit');
const CONSTANTS = require('./../../constants/constants');
const Config = require('./../../configs/config');
const Helper = require('./../libs/helper');

class HookConfirmArchiveGoal {

  static run(context, task) {
    assert(typeof context.selectedUserGoal === 'object', 'Context selectedUserGoal (object) is required');
    assert(typeof context.confirmArchiveGoal === 'string', 'Context confirmArchiveGoal (string) is required');

    return new Promise((resolve, reject) => {
      Co(function *() {
        try {
          if (context.confirmArchiveGoal === 'yes') {
            const userGoal = yield ModelUserGoal.findOne({ _id: context.selectedUserGoal.id });
            userGoal.status = CONSTANTS.DB.STATUS.ARCHIVED;
            yield userGoal.save();

            // tell the scheduler that the goal is gone
            yield Helper.archiveOrDeleteGoal(task, userGoal.id, CONSTANTS.DB.STATUS.ARCHIVED);
            task.emit(CONSTANTS.BOT_EVENT.MESSAGE, 'OK, done! :tada:');
          }
          else {
            task.emit(CONSTANTS.BOT_EVENT.MESSAGE, 'OK, I didn\'t change anything.');
          }

          return resolve(true);
        }
        catch(ex) {
          Logger.error(__filename, 'Failed to run HookConfirmArchiveGoal', ex, ex.stack);
          return reject(ex);
        }
      }.bind(this));
    });
  }
}

module.exports = HookConfirmArchiveGoal;