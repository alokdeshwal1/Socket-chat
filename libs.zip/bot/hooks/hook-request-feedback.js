'use strict';

const assert = require('assert');
const ModelUser = require('./../../models/user');
const ModelFunction = require('./../../models/function');
const ModelUserGoal = require('./../../models/user-goal');
const ModelUserTrigger = require('./../../models/user-trigger');
const Co = require('co');
const Logger = require('./../../libs/logger');
const jackrabbit = require('jackrabbit');
const CONSTANTS = require('./../../constants/constants');
const Config = require('./../../configs/config');
const Task = require('./../../bot/task');
const BotMessages = require('./../../configs/bot-messages');
const Helper = require('./../../bot/libs/helper');

class HookRequestFeedback {

  static run(context, task) {
    assert(typeof context.slackUserId === 'string', 'Context slackUserId (string) is required');
    assert(Array.isArray(context.requestFeedbackFromUsers), 'Context requestFeedbackFromUsers (array) is required');
    assert(typeof context.selectedUserGoal === 'object', 'Context selectedUserGoal (object) is required');

    return new Promise((resolve, reject) => {
      Co(function *() {
        try {
          if ( ! (context.user && context.user instanceof ModelUser)) {
            context.user = yield ModelUser.findOne({ slackUserId: context.slackUserId });
          }

          var theTask = (context.selectedUserGoal.isGeneral === true) ? require('./../../bot/tasks/feedback/gather-general-feedback') : require('./../../bot/tasks/feedback/gather-feedback');
          theTask.priority = 3;
          context.requestFeedbackFromUsers.forEach(requestFrom => {
            task.emit(CONSTANTS.BOT_EVENT.TASK, {
              slackUserId: requestFrom.slackUserId,
              context: {
                appName: Config.appName,
                advisor: requestFrom,
                userGoal: context.selectedUserGoal,
                slackUserId: requestFrom.slackUserId,
                userFirstName: requestFrom.firstName,
                targetUser: context.user,
                targetUserFirstName: context.user.firstName,
                targetUserGoalName: context.selectedUserGoal && context.selectedUserGoal.goal &&
                                    context.selectedUserGoal.goal.name || context.selectedUserGoal.name
              },
              task: theTask
            });
          });

          task.emit(CONSTANTS.BOT_EVENT.MESSAGE, 'OK, done! :tada:');

          return resolve(true);
        }
        catch(ex) {
          Logger.error('Failed to run HookRequestFeedback', ex, ex.stack);
          return reject(ex);
        }
      }.bind(this));
    });
  }
}

module.exports = HookRequestFeedback;