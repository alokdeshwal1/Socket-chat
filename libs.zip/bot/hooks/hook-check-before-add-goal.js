'use strict';

const assert = require('assert');
const ModelUser = require('./../../models/user');
const ModelFunction = require('./../../models/function');
const ModelUserGoal = require('./../../models/user-goal');
const ModelUserTrigger = require('./../../models/user-trigger');
const Co = require('co');
const Logger = require('./../../libs/logger');
const jackrabbit = require('jackrabbit');
const CONSTANTS = require('./../../constants/constants');
const Config = require('./../../configs/config');
const _ = require('lodash');

class HookCheckBeforeAddGoal {

  static run(context, task) {
    assert(typeof context.slackUserId === 'string', 'Context slackUserId (string) is required');

    return new Promise((resolve, reject) => {
      Co(function *() {
        try {
          // redirect user to gather function if function object is not found
          if ( ! (context['function'] && context['function'].id)) {
            var newTask = _.cloneDeep(require('./../tasks/feedback/gather-function'));
            task.chainTask({
              name: 'GatherFunction',
              interactions: [newTask.interactions[1]],
              persist: 'PersistJobFunction'
            }, context);

            return resolve(false);
          }

          return resolve(true);
        }
        catch(ex) {
          Logger.error({ex, exStack: ex.stack, context, task}, 'Failed to run HookCheckBeforeAddGoal');
          return reject(ex);
        }
      }.bind(this));
    });
  }
}

module.exports = HookCheckBeforeAddGoal;