'use strict';

const assert = require('assert');
const ModelUser = require('./../../models/user');
const ModelFunction = require('./../../models/function');
const ModelUserGoal = require('./../../models/user-goal');
const ModelUserTrigger = require('./../../models/user-trigger');
const Co = require('co');
const Logger = require('./../../libs/logger');
const jackrabbit = require('jackrabbit');
const CONSTANTS = require('./../../constants/constants');
const Config = require('./../../configs/config');

class HookArchiveGoal {

  static run(context, task) {
  assert(typeof context.selectedUserGoal === 'object', 'Context selectedUserGoal (object) is required');

    return new Promise((resolve, reject) => {
      Co(function *() {
        try {
          // tell the scheduler that the goal is gone
          const userGoal = yield ModelUserGoal.findOne({ _id: context.selectedUserGoal.id });
          if (userGoal) {
            userGoal.status = CONSTANTS.DB.STATUS.ARCHIVED;
            yield userGoal.save();
          }

          const userTriggers = yield ModelUserTrigger.find({ userGoal: context.selectedUserGoal.id });
          for(var i = 0; i < userTriggers.length; i++) {
            var trigger = userTriggers[i];
            trigger.status = CONSTANTS.DB.STATUS.ARCHIVED;
            yield trigger.save();

            // tell the scheduler to remove the trigger
            task.emit(CONSTANTS.BOT_EVENT.QUEUE_JOB, {
              queueName: CONSTANTS.JOB_QUEUE.CRON_SCHEDULER,
              job: {
                type: CONSTANTS.SCHEDULER_JOB_TYPE.REMOVE,
                triggerId: trigger.id
              }
            });
          }

          return resolve(true);
        }
        catch(ex) {
          Logger.error(__filename, 'Failed to run HookArchiveGoal', ex, ex.stack);
          return reject(ex);
        }
      }.bind(this));
    });
  }
}

module.exports = HookArchiveGoal;