'use strict';

const assert = require('assert');
const ModelUser = require('./../../models/user');
const ModelFunction = require('./../../models/function');
const ModelUserGoal = require('./../../models/user-goal');
const ModelUserTrigger = require('./../../models/user-trigger');
const Co = require('co');
const Logger = require('./../../libs/logger');
const jackrabbit = require('jackrabbit');
const CONSTANTS = require('./../../constants/constants');
const Config = require('./../../configs/config');
const Task = require('./../../bot/task');
const BotMessages = require('./../../configs/bot-messages');
const Helper = require('./../../bot/libs/helper');

class HookAddManager {

  static run(context, task) {
    assert(typeof context.slackUserId === 'string', 'Context slackUserId (string) is required');
    assert(Array.isArray(context.addManagerSlackUserId), 'Context addManagerSlackUserId (array) is required');

    return new Promise((resolve, reject) => {
      Co(function *() {
        try {
          const BotMessages = require('./../../configs/bot-messages');

          if ( ! (context.user && context.user instanceof ModelUser)) {
            context.user = yield ModelUser.findOne({ slackUserId: context.slackUserId });
          }
          if (context.user.manager && ! context.user.manager instanceof ModelUser) {
            context.user.manager = yield ModelUser.findOne({ _id: context.user.manager });
          }

          const newManager = context.addManagerSlackUserId[0];
          if ( ! (newManager && newManager instanceof ModelUser)) {
            Logger.error('Trying to add new manager that does not have right format of data', newManager);
            return resolve(false);
          }

          if (context.user.manager && context.user.manager.id) { // has current manager
            task.emit(CONSTANTS.BOT_EVENT.TASK, {
              slackUserId: context.user.slackUserId,
              context: {
                slackUserId: context.user.slackUserId,
                employeeFirstName: context.user.firstName,
                appName: Config.appName,
                currentManagerFirstName: context.user.manager.firstName,
                newManagerFirstName: newManager.firstName,
                newManagerId: newManager.id
              },
              task: {
                name: 'ConfirmAddManager',
                priority: 2,
                interactions: [
                  {
                    type: 'ActionYesNo',
                    message: 'Your manager is currently set as [[currentManagerFirstName]]. Can you confirm that you want to change your manager to [[newManagerFirstName]]? Remember that your manager can see all of your goals and feedback.',
                    saveContextKey: 'confirmAddManager'
                  }
                ],
                after: ['HookConfirmAddManager']
              }
            });
          }
          else { // no current manager
            context.user.manager = newManager.id;
            yield context.user.save;

            task.emit(CONSTANTS.BOT_EVENT.MESSAGE, BotMessages.ActionAddManager.success({
              managerFirstName: newManager.firstName
            }));

            // if manager already signup?
            var isManagerAlreadySignup = yield ModelUser.isUserSignUp(newManager.slackUserId);
            if (isManagerAlreadySignup) {
              task.emit(CONSTANTS.BOT_EVENT.TASK,
                        Helper.generateMessageTask(
                          newManager.slackUserId, BotMessages.ActionAddManager.messageToManagerAlreadySetup({
                            employeeFirstName: context.user.firstName
                          }), { slackUserId: newManager.slackUserId }, 'NotifyManager', 3));
            }
            else {
              task.emit(CONSTANTS.BOT_EVENT.TASK, {
                slackUserId: newManager.slackUserId,
                context: {
                  slackUserId: newManager.slackUserId,
                  employeeFirstName: context.user.firstName,
                  appName: Config.appName
                },
                task: {
                  name: 'FtueManager',
                  priority: 10,
                  reminderMessage: 'Knock knock! You account is not set up yet.',
                  interactions: [
                    {
                      type: 'ActionMessage',
                      message: 'Hi! [[employeeFirstName]] just added you as a manager on [[appName]]. We\'ll be ' +
                      'prompting you periodically for some lightweight feedback once [[employeeFirstName]] ' +
                      'has set up some goals.'
                    },
                    {
                      type: 'ActionGatherUser',
                      message: '\n' +
                              'I can help you give lightweight feedback to your other team member as well on areas that they want to grow in. ' +
                              'Let’s get the rest of your reports set up. Can you tell me their slack names?',
                      saveContextKey: 'directs',
                      skipParser: true
                    },
                    {
                      type: 'ActionMessage',
                      message: 'Great, thanks! :+1: I\'m going to now ping them and get them set up with their goals. Once they\'re done ' +
                      'I\'ll let you know and we\'ll start pinging you for quick feedback.'
                    },
                    {
                      type: 'ActionMessage',
                      message: 'Now try typing `help`!'
                    }
                  ],
                  persist: 'PersistFtueManager'
                }
              });
            }
          }

          return resolve(true);
        }
        catch(ex) {
          Logger.error('Failed to run HookAddManager', ex, ex.stack);
          return reject(ex);
        }
      }.bind(this));
    });
  }
}

module.exports = HookAddManager;