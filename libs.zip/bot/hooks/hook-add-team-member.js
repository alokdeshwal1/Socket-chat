'use strict';

const assert = require('assert');
const ModelUser = require('./../../models/user');
const ModelFunction = require('./../../models/function');
const ModelUserGoal = require('./../../models/user-goal');
const ModelUserTrigger = require('./../../models/user-trigger');
const Co = require('co');
const Logger = require('./../../libs/logger');
const jackrabbit = require('jackrabbit');
const CONSTANTS = require('./../../constants/constants');
const Config = require('./../../configs/config');
const Join = require('join-component');
const Helper = require('./../../bot/libs/helper');

class HookAddTeamMember {

  static run(context, task) {
    assert(typeof context.slackUserId === 'string', 'Context slackUserId (string) is required');
    assert(Array.isArray(context.addTeamMemberSlackUser), 'Context addTeamMemberSlackUser (array) is required');

    return new Promise((resolve, reject) => {
      Co(function *() {
        try {
          const manager = yield ModelUser.findOne({ slackUserId: context.slackUserId }).populate('company');
          const directNeedConfirmation = [];
          const directAdded = [];
          for(var i = 0; i < context.addTeamMemberSlackUser.length; i++) {
            const direct = context.addTeamMemberSlackUser[i];

            // direct already in your team;
            if (direct.manager && direct.manager.id === manager.id) {
              task.emit(CONSTANTS.BOT_EVENT.MESSAGE, Helper.replaceMessagePlaceholder(
                'I\'ve already got [[employeeFirstName]] listed as one of your direct reports. If you want to add another direct report, type `add direct report`', {
                  employeeFirstName: direct.firstName
                }));

              continue;
            }

            // direct already has manager
            if (direct.manager && direct.manager.id.length > 0) {
              // direct already has manager, trigger confirmation task
              task.emit(CONSTANTS.BOT_EVENT.TASK, {
                slackUserId: direct.slackUserId,
                context: {
                  slackUserId: direct.slackUserId,
                  userFirstName: direct.firstName,
                  employeeFirstName: direct.firstName,
                  managerFirstName: manager.firstName,
                  managerSlackUserId: manager.slackUserId,
                  managerUserId: manager.id,
                  currentManagerFirstName: direct.manager.firstName,
                  appName: Config.appName,
                  companyName: manager.company.name, // it is safe to assume that
                  companyId: manager.company.id
                },
                task: require('./../tasks/feedback/confirm-manager')
              });

              directNeedConfirmation.push(direct.firstName);
            }
            else {
              direct.manager = manager.id;
              yield direct.save();
              directAdded.push(direct.firstName);

              try {
                // schedule jobs for the directs to set up goals
                task.emit(CONSTANTS.BOT_EVENT.TASK, {
                  slackUserId: direct.slackUserId,
                  context: {
                    userFirstName: direct.firstName,
                    managerFirstName: manager.firstName,
                    slackUserId: direct.slackUserId,
                    appName: Config.appName,
                    companyName: manager.company.name, // it is safe to assume that
                    companyId: manager.company.id,
                    slackIntegrationId: direct.slackIntegration.toString()
                  },
                  task: require('./../tasks/feedback/ftue-employee')
                });
              }
              catch (ex) {
                Logger.error('Failed to schedue task for new direct to set up goal', ex, ex.stack);
              }
            }
          }

          if (directNeedConfirmation.length > 0) {
            task.emit(CONSTANTS.BOT_EVENT.MESSAGE, Helper.replaceMessagePlaceholder(
              'Ok! Just sent [[employeeFirstName]] a quick message to confirm', {
                employeeFirstName: Join(directNeedConfirmation, ', and')
              }));
          }
          else {
            if (directAdded.length > 0) {
              task.emit(CONSTANTS.BOT_EVENT.MESSAGE, Helper.replaceMessagePlaceholder('great, done!', {}));
            }
          }

          return resolve(true);
        }
        catch(ex) {
          Logger.error(__filename, 'Failed to run HookAddTeamMember', ex, ex.stack);
          return reject(ex);
        }
      }.bind(this));
    });
  }
}

module.exports = HookAddTeamMember;