'use strict';

const assert = require('assert');
const ModelUser = require('./../../models/user');
const ModelFunction = require('./../../models/function');
const ModelUserGoal = require('./../../models/user-goal');
const ModelUserTrigger = require('./../../models/user-trigger');
const Co = require('co');
const Logger = require('./../../libs/logger');
const jackrabbit = require('jackrabbit');
const CONSTANTS = require('./../../constants/constants');
const Config = require('./../../configs/config');
const Helper = require('./../libs/helper');
const Join = require('join-component');

class HookRemoveTeamMember {

  static run(context, task) {
    assert(typeof context.slackUserId === 'string', 'Context slackUserId (string) is required');
    assert(Array.isArray(context.removeTeamMemberSlackUser), 'Context removeTeamMemberSlackUser (array) is required');

    return new Promise((resolve, reject) => {
      Co(function *() {
        try {
          if (! (context.user && context.user instanceof ModelUser)) {
            context.user = yield ModelUser.findBySlackId(context.slackUserId);
          }

          var actions = [];
          var deletedUsers = [];
          var notDeletedUsers = [];
          context.removeTeamMemberSlackUser.forEach(item => {
            // only delete if user is currently a manager of the user
            if (item.manager && item.manager.id === context.user.id) {
              item.manager = undefined;
              actions.push(item.save());
              deletedUsers.push(item.firstName);
            }
            else {
              notDeletedUsers.push(item.firstName);
            }
          });

          yield Promise.all(actions);

          if (deletedUsers.length > 0 && notDeletedUsers.length === 0) {
            task.emit(CONSTANTS.BOT_EVENT.MESSAGE, 'Great! Done.');
          }
          else if(deletedUsers.length > 0 && notDeletedUsers.length > 0) {
            task.emit(CONSTANTS.BOT_EVENT.MESSAGE, 'I have removed '+ Join(deletedUsers, ', and') +', but not '+
              Join(notDeletedUsers, ', and') + ' because '+ Join(notDeletedUsers, ', and') + ' is not in your team' );
          }
          else if(notDeletedUsers.length > 0) {
            task.emit(CONSTANTS.BOT_EVENT.MESSAGE, Helper.replaceMessagePlaceholder(
              'Doesn\'t look like [[employeeFirstName]] is on your team', {
                employeeFirstName: Join(notDeletedUsers, ', and')
              }));
          }

          return resolve(true);
        }
        catch(ex) {
          Logger.error({ex, exStack: ex.stack, context, task}, 'Failed to run HookRemoveTeamMember');
          return reject(ex);
        }
      }.bind(this));
    });
  }
}

module.exports = HookRemoveTeamMember;