'use strict';

const assert = require('assert');
const ModelUser = require('./../../models/user');
const ModelFunction = require('./../../models/function');
const ModelUserGoal = require('./../../models/user-goal');
const ModelUserTrigger = require('./../../models/user-trigger');
const Co = require('co');
const Logger = require('./../../libs/logger');
const jackrabbit = require('jackrabbit');
const CONSTANTS = require('./../../constants/constants');
const Config = require('./../../configs/config');
const BotMessages = require('./../../configs/bot-messages');

class HookCheckBeforeDeleteGoal {

  static run(context, task) {
    assert(typeof context.slackUserId === 'string', 'Context slackUserId (string) is required');

    return new Promise((resolve, reject) => {
      Co(function *() {
        try {
          if (! (context.user && context.user instanceof ModelUser)) {
            context.user = yield ModelUser.findBySlackId(context.slackUserId);
          }

          var userGoals = yield ModelUserGoal.findUserGoalsByUserId(context.user.id);
          if ( ! (userGoals && Array.isArray(userGoals) && userGoals.length > 0)) {
            task.emit(CONSTANTS.BOT_EVENT.MESSAGE, BotMessages.ActionDeleteGoal.noGoal);

            // end the task
            return resolve(false);
          }

          return resolve(true);
        }
        catch(ex) {
          Logger.error(__filename, 'Failed to run HookCheckBeforeDeleteGoal', ex, ex.stack);
          return reject(ex);
        }
      }.bind(this));
    });
  }
}

module.exports = HookCheckBeforeDeleteGoal;