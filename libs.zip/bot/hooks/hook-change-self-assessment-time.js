'use strict';

const assert = require('assert');
const ModelUser = require('./../../models/user');
const ModelFunction = require('./../../models/function');
const ModelUserGoal = require('./../../models/user-goal');
const ModelUserTrigger = require('./../../models/user-trigger');
const Co = require('co');
const Logger = require('./../../libs/logger');
const jackrabbit = require('jackrabbit');
const CONSTANTS = require('./../../constants/constants');
const Config = require('./../../configs/config');
const Task = require('./../../bot/task');
const BotMessages = require('./../../configs/bot-messages');
const Helper = require('./../../bot/libs/helper');

class HookChangeSelfAssessmentTime {

  static run(context, task) {
    assert(typeof context.slackUserId === 'string', 'Context slackUserId (String) is required');
    assert(typeof context.manualTrigger === 'object', 'Context manualTrigger (Object) is required');

    return new Promise((resolve, reject) => {
      Co(function *() {
        try {
          if ( ! (context.user && context.user instanceof ModelUser)) {
            context.user = yield ModelUser.findOne({ slackUserId: context.slackUserId });
          }

          context.user.selfAssessment = {
            frequencyCron: context.manualTrigger.expression,
            frequencyUserText: context.manualTrigger.userText
          };
          if (context.manualTrigger.modifier) {
            context.user.selfAssessment.frequencyCronModifier = context.manualTrigger.modifier;
          }
          if (context.manualTrigger.startDate) {
            context.user.selfAssessment.frequencyStartDate = context.manualTrigger.startDate;
          }

          yield context.user.save();

          task.emit(CONSTANTS.BOT_EVENT.QUEUE_JOB, {
            queueName: CONSTANTS.JOB_QUEUE.CRON_SCHEDULER,
            job: {
              type: CONSTANTS.SCHEDULER_JOB_TYPE.UPDATE,
              module: CONSTANTS.MODULES.OKR,
              userId: context.user.id
            }
          });

          task.emit(CONSTANTS.BOT_EVENT.MESSAGE, 'Done');

          return resolve(true);
        }
        catch(ex) {
          Logger.error(__filename, 'Failed to run HookChangeSelfAssessmentTime', ex, ex.stack);
          return reject(ex);
        }
      }.bind(this));
    });
  }
}

module.exports = HookChangeSelfAssessmentTime;