'use strict';

const assert = require('assert');
const ModelUser = require('./../../models/user');
const ModelFunction = require('./../../models/function');
const ModelUserGoal = require('./../../models/user-goal');
const ModelUserTrigger = require('./../../models/user-trigger');
const ModelUserTriggerGmail = require('./../../models/user-trigger-gmail');
const ModelUserTriggerGoogleCalendar = require('./../../models/user-trigger-google-calendar');
const ModelFeedback = require('./../../models/feedback');
const Co = require('co');
const Logger = require('./../../libs/logger');
const jackrabbit = require('jackrabbit');
const CONSTANTS = require('./../../constants/constants');
const Config = require('./../../configs/config');
const Helper = require('./../libs/helper');

class HookDeleteGoal {

  static run(context, task) {
  assert(typeof context.selectedUserGoal === 'object', 'Context selectedUserGoal (object) is required');

    return new Promise((resolve, reject) => {
      Co(function *() {
        try {
          var userGoal = context.selectedUserGoal;
          if ( ! (userGoal instanceof ModelUserGoal)) {
            userGoal = yield ModelUserGoal.findOne({ _id: userGoal.id });
          }
          var feedbackCount = yield ModelFeedback.count({ userGoal: userGoal.id, status: CONSTANTS.DB.STATUS.ACTIVE });
          if (feedbackCount === 0) {
            userGoal.status = CONSTANTS.DB.STATUS.DELETE;
            yield userGoal.save();
            yield Helper.archiveOrDeleteGoal(task, context.selectedUserGoal.id, CONSTANTS.DB.STATUS.DELETE);
            task.emit(CONSTANTS.BOT_EVENT.MESSAGE, 'OK, done! :tada:');
          }
          else { // no delete goal has has feedback allowed
            task.chainTask({
                name: 'ArchiveGoalConfirmation',
                priority: 2,
                interactions: [
                  {
                    type: 'ActionYesNo',
                    message: 'You’ve already gotten some feedback on this goal, so we can’t delete it. ' +
                              'Would you like to archive it instead?',
                    saveContextKey: 'confirmArchiveGoal'
                  }
                ],
                after: ['HookConfirmArchiveGoal']
              }, context);
          }

          return resolve(true);
        }
        catch(ex) {
          Logger.error(__filename, 'Failed to run HookDeleteGoal', ex, ex.stack);
          return reject(ex);
        }
      }.bind(this));
    });
  }
}

module.exports = HookDeleteGoal;