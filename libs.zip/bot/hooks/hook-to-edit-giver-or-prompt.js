'use strict';

const assert = require('assert');
const ModelUser = require('./../../models/user');
const ModelFunction = require('./../../models/function');
const ModelUserGoal = require('./../../models/user-goal');
const ModelUserTrigger = require('./../../models/user-trigger');
const Co = require('co');
const Logger = require('./../../libs/logger');
const jackrabbit = require('jackrabbit');
const CONSTANTS = require('./../../constants/constants');
const Config = require('./../../configs/config');

class HookToEditGiverOrPrompt {

  static run(context, task) {
    assert(typeof context.slackUserId === 'string', 'Context slackUserId (string) is required');
    assert(typeof context.editGoalType === 'string', 'Context editGoalType (string) is required');

    return new Promise((resolve, reject) => {
      Co(function *() {
        try {
          if ( ! (context.user && context.user instanceof ModelUser)) {
            context.user = yield ModelUser.findBySlackId(context.slackUserId);
          }
          context.companyId = context.companyId || context.user.company.id;
          context.companyName = context.user.company.name;

          if (context.editGoalType === 'giver') {
            var taskEditGiver = require('./../tasks/feedback/edit-giver');
            taskEditGiver.priority = 2;
            task.emit(CONSTANTS.BOT_EVENT.TASK, {
              slackUserId: context.slackUserId.toString(),
              context: context,
              task: taskEditGiver
            });
          }
          else {
            var taskEditGiver = require('./../tasks/feedback/edit-prompt');
            taskEditGiver.priority = 2;
            task.emit(CONSTANTS.BOT_EVENT.TASK, {
              slackUserId: context.slackUserId.toString(),
              context: context,
              task: taskEditGiver
            });
          }

          return resolve(true);
        }
        catch(ex) {
          Logger.error(__filename, 'Failed to run HookToEditGiverOrPrompt', ex, ex.stack);
          return reject(ex);
        }
      }.bind(this));
    });
  }
}

module.exports = HookToEditGiverOrPrompt;