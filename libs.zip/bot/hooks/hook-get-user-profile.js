'use strict';

const assert = require('assert');
const ModelUser = require('./../../models/user');
const ModelFunction = require('./../../models/function');
const ModelUserGoal = require('./../../models/user-goal');
const ModelUserTrigger = require('./../../models/user-trigger');
const Co = require('co');
const Logger = require('./../../libs/logger');
const jackrabbit = require('jackrabbit');
const CONSTANTS = require('./../../constants/constants');
const Config = require('./../../configs/config');
const Util = require('util');
const Helper = require('./../libs/helper');

class HookGetUserProfile {

  static run(context, task) {
    assert(typeof context.slackUserId === 'string', 'Context slackUserId (string) is required');

    return new Promise((resolve, reject) => {
      Co(function *() {
        try {
          if (! (context.user && context.user instanceof ModelUser)) {
            context.user = yield ModelUser.findOne({ slackUserId: context.slackUserId })
                                          .populate('manager slackIntegration company jobFunction');
          }
          context.userProfile = yield Helper.buildMyProfile(task.bot.modules, context.user.id);
          context.userProfile = Array.isArray(context.userProfile) ? JSON.stringify(context.userProfile) : context.userProfile;
          if ( ! context.userProfile) {
            return resolve(false);
          }

          return resolve(true);
        }
        catch(ex) {
          Logger.error(__filename, 'Failed to run HookGetUserProfile', ex, ex.stack);
          return reject(ex);
        }
      }.bind(this));
    });
  }
}

module.exports = HookGetUserProfile;