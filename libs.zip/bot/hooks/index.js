const fs = require('fs');
const Hooks = {};

fs.readdirSync(__dirname).forEach(function(file) {
  var klass = require('./'+ file);
  Hooks[klass.name] = klass;
});

module.exports = Hooks;