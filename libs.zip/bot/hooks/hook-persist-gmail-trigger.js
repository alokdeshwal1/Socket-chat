'use strict';

const assert = require('assert');
const ModelUser = require('./../../models/user');
const ModelFunction = require('./../../models/function');
const ModelUserTrigger = require('./../../models/user-trigger');
const ModelUserGmailTrigger = require('./../../models/user-trigger-gmail');
const ModelGooglePushNotification = require('./../../models/google-push-notification');
const Co = require('co');
const Logger = require('./../../libs/logger');
const jackrabbit = require('jackrabbit');
const CONSTANTS = require('./../../constants/constants');
const Config = require('./../../configs/config');
const GmailParser = require('./../../libs/gmail-parser');
const uuid = require('node-uuid');

class HookPersistGmailTrigger {

  static run(context, task) {
    return new Promise((resolve, reject) => {
      Co(function *() {
        try {
          yield HookPersistGmailTrigger.saveToDb(context);
          return resolve(true);
        }
        catch(ex) {
          Logger.error(__filename, 'Failed to persist data for HookPersistGmailTrigger', ex, ex.stack);
          return reject(ex);
        }
      }.bind(this));
    });
  }

  static saveToDb(context) {
    assert(typeof context.slackUserId === 'string', 'Context slackUserId (String) is required');
    assert(typeof context.userGoal === 'object', 'Context userGoal (Object) is required');
    assert(typeof context.trigger === 'object', 'Context trigger (Object) is required');
    assert(typeof context.gmailTrigger === 'object', 'Context gmailTrigger (Object) is required');
    assert(typeof context.gmailTrigger.criteria === 'object', 'Context gmailTrigger.criteria (Object) is required');
    assert(typeof context.gmailTrigger.text === 'string', 'Context gmailTrigger.text (String) is required');

    return new Promise((resolve, reject) => {
      Co(function *() {
        try {
          if (! (context.user && context.user instanceof ModelUser)) {
            context.user = yield ModelUser.findOne({ slackUserId: context.slackUserId.toString() }).populate('company, manager');
          }
          if ( ! context.user) {
            return reject('User is not found with slackUserId: '+ context.slackUserId);
          }

          const userId = context.user.id || context.user._id;
          var userTriggerGmail = new ModelUserGmailTrigger();
          userTriggerGmail.trigger = context.trigger._id;
          userTriggerGmail.userGoal = context.userGoal._id;
          userTriggerGmail.user = userId;
          userTriggerGmail.criteria = context.gmailTrigger.criteria;
          userTriggerGmail.userCriteriaText = context.gmailTrigger.text;
          userTriggerGmail.status = CONSTANTS.DB.STATUS.ACTIVE;

          context.userTriggerGmail = yield userTriggerGmail.save();
          context.userTriggerGmails = context.userTriggerGmails || [];
          context.userTriggerGmails.push(Object.assign(context.userTriggerGmail));

          // get user's info
          try {
            var parser = new GmailParser(context.googleOauthToken);
            var gmailUser = yield parser.getProfile();
            if (gmailUser && gmailUser.emailAddress) {
              context.user.googleEmailAccount = gmailUser.emailAddress;
              yield context.user.save();
            }
            else {
              Logger.error('Gmail parser getProfile does not return emailAddress', gmailUser);
            }
          }
          catch(ex) {
            Logger.error('Failed to get Gmail parser getProfile', ex, ex.stack);
          }

          // save Google Watch push notification
          try {
            var currentRecord = yield ModelGooglePushNotification.findOne({
              user: userId,
              resourceUri: Config.google.gmail.resourceUrl
            });
            if ( ! currentRecord) {
              var parser = new GmailParser(context.googleOauthToken);
              var uniqueId = uuid.v1();
              var watchResult = yield parser.saveWatch(uniqueId, userId);
              if (typeof watchResult === 'object') {
                yield ModelGooglePushNotification.upsert({
                  user: userId,
                  resourceUri: Config.google.gmail.resourceUrl
                }, {
                  uuid: uniqueId,
                  user: userId,
                  watchInfo: watchResult,
                  watchType: 'pubSub',
                  resourceUri: Config.google.gmail.resourceUrl,
                  watchTriggerUri: Config.google.gmail.watchUrl,
                  pubSubTopic: Util.format('projects/%s/topics/%s', Config.googleProjectId, Config.google.gmail.pubSubTopic),
                  status: CONSTANTS.DB.STATUS.ACTIVE
                });
              }
            }
          }
          catch(ex) {
            Logger.error('Failed to save Google Watch push notification', ex, ex.stack);
          }

          return resolve(true);
        }
        catch(ex) {
          Logger.error(__filename, 'Failed to persist data for HookPersistGmailTrigger', ex, ex.stack);
          return reject(ex);
        }
      }.bind(this));
    });
  }

}

module.exports = HookPersistGmailTrigger;