'use strict';

const assert = require('assert');
const ModelUser = require('./../../models/user');
const ModelFunction = require('./../../models/function');
const ModelUserGoal = require('./../../models/user-goal');
const ModelUserTrigger = require('./../../models/user-trigger');
const Co = require('co');
const Logger = require('./../../libs/logger');
const jackrabbit = require('jackrabbit');
const CONSTANTS = require('./../../constants/constants');
const Config = require('./../../configs/config');

class HookGetUserInfo {

  static run(context, task) {
    assert(typeof context.slackUserId === 'string', 'Context slackUserId (string) is required');

    return new Promise((resolve, reject) => {
      Co(function *() {
        try {
          if (! (context.user && context.user instanceof ModelUser)) {
            context.user = yield ModelUser.findOne({ slackUserId: context.slackUserId })
                            .populate('manager slackIntegration company jobFunction');
          }

          if (context.user) {
            if (context.user.manager && context.user.manager.firstName) {
              context.userManagerFirstName = context.userManagerFirstName || context.user.manager.firstName;
            }
            if (context.user.slackIntegration && context.user.slackIntegration.id) {
              context.slackIntegrationId = context.slackIntegrationId || context.user.slackIntegration.id;
            }
            if (context.user.slackIntegration && context.user.slackIntegration.id) {
              context.slackIntegrationId = context.slackIntegrationId || context.user.slackIntegration.id;
            }
            if (context.user.company && context.user.company.id) {
              context.companyId = context.companyId || context.user.company.id;
            }
            if (context.user.jobFunction && Array.isArray(context.user.jobFunction) && context.user.jobFunction.length > 0) {
              context['function'] = context['function'] || context.user.jobFunction[0];
            }
            if (context.user.company && context.user.company.name) {
              context.companyName = context.companyName || context.user.company.name;
            }
          }

          return resolve(true);
        }
        catch(ex) {
          Logger.error(__filename, 'Failed to run HookGetUserInfo', ex, ex.stack);
          return reject(ex);
        }
      }.bind(this));
    });
  }
}

module.exports = HookGetUserInfo;