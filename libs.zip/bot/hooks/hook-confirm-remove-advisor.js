'use strict';

const assert = require('assert');
const ModelUser = require('./../../models/user');
const ModelFunction = require('./../../models/function');
const ModelUserGoal = require('./../../models/user-goal');
const ModelUserTrigger = require('./../../models/user-trigger');
const Co = require('co');
const Logger = require('./../../libs/logger');
const jackrabbit = require('jackrabbit');
const CONSTANTS = require('./../../constants/constants');
const Config = require('./../../configs/config');
const Helper = require('./../libs/helper');
const _ = require('lodash');
const Join = require('join-component');

class HookConfirmRemoveAdvisor {

  static run(context, task) {
    assert(typeof context.slackUserId === 'string', 'Context slackUserId (string) is required');
    assert(Array.isArray(context.removeAdvisorSlackUser), 'Context removeAdvisorSlackUser (array) is required');
    assert(typeof context.confirmRemoveAdvisor === 'string', 'Context confirmRemoveAdvisor (string) is required');
    assert(typeof context.removeAbleGoals === 'object', 'Context removeAbleGoals (object) is required');

    return new Promise((resolve, reject) => {
      Co(function *() {
        try {
          if (! (context.user && context.user instanceof ModelUser)) {
            context.user = yield ModelUser.findOne({ slackUserId: context.slackUserId });
          }

          if (context.confirmRemoveAdvisor === 'yes') {
            for (let fromUser of context.removeAdvisorSlackUser) {
              yield ModelUserGoal.update({
                'user': fromUser.id
              }, {
                $pullAll: {advisors: [context.user.id]}
              }, {
                multi: true
              });
            }

            task.emit(CONSTANTS.BOT_EVENT.MESSAGE, 'OK, done! :tada:');

            Object.keys(context.removeAbleGoals).forEach(key => {
              var row = context.removeAbleGoals[key];
              var goalString = _.map(row.userGoals, (item) => {
                return item.name || item.goal && item.goal.name;
              });
              goalString = Join(goalString, ', and');

              task.emit(CONSTANTS.BOT_EVENT.TASK, {
                slackUserId: row.user.slackUserId,
                context: {
                  slackUserId: row.user.slackUserId,
                  advisorName: context.user.firstName,
                  goalString: goalString
                },
                task: {
                  name: 'AdvisorRemovedNotification',
                  priority: 3,
                  interactions: [
                    {
                      type: 'ActionMessage',
                      message: '[[advisorName]] is no longer able to provide you with feedback on [[goalString]].'
                    }
                  ]
                }
              });
            });
          }
          else {
            task.emit(CONSTANTS.BOT_EVENT.MESSAGE, 'OK, I didn\'t change anything.');
          }

          return resolve(true);
        }
        catch(ex) {
          Logger.error(__filename, 'Failed to run HookConfirmRemoveAdvisor', ex, ex.stack);
          return reject(ex);
        }
      }.bind(this));
    });
  }
}

module.exports = HookConfirmRemoveAdvisor;