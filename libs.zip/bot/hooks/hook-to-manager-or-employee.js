'use strict';

const assert = require('assert');
const ModelUser = require('./../../models/user');
const ModelFunction = require('./../../models/function');
const ModelUserGoal = require('./../../models/user-goal');
const ModelUserTrigger = require('./../../models/user-trigger');
const Co = require('co');
const Logger = require('./../../libs/logger');
const jackrabbit = require('jackrabbit');
const CONSTANTS = require('./../../constants/constants');
const Config = require('./../../configs/config');
const _ = require('lodash');

class HookToManagerOrEmployee {

  static run(context, task) {
    assert(typeof context.slackUserId === 'string', 'Context slackUserId (string) is required');
    assert(typeof context.managerOrEmployee === 'string', 'Context managerOrEmployee (string) is required');

    return new Promise((resolve, reject) => {
      Co(function *() {
        try {
          if ( ! (context.user && context.user instanceof ModelUser)) {
            context.user = yield ModelUser.findBySlackId(context.slackUserId);
          }
          context.companyId = context.companyId || context.user.company.id;
          context.companyName = context.user.company.name;
          context.appName = Config.appName;

          if (context.managerOrEmployee === 'employee') {
            task.chainTask(require('./../tasks/feedback/gather-general-goal'), context);
          }
          else {
            task.chainTask(require('./../tasks/feedback/ftue-manager'), context);
          }

          return resolve(true);
        }
        catch(ex) {
          Logger.error(__filename, 'Failed to run HookToManagerOrEmployee', ex, ex.stack);
          return reject(ex);
        }
      }.bind(this));
    });
  }
}

module.exports = HookToManagerOrEmployee;