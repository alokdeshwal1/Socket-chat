'use strict';

const assert = require('assert');
const ModelUser = require('./../../models/user');
const ModelFunction = require('./../../models/function');
const ModelUserGoal = require('./../../models/user-goal');
const ModelUserTrigger = require('./../../models/user-trigger');
const Co = require('co');
const Logger = require('./../../libs/logger');
const jackrabbit = require('jackrabbit');
const CONSTANTS = require('./../../constants/constants');
const Config = require('./../../configs/config');

class HookAddAnotherTrigger {

  static run(context, task) {
    assert(typeof context.slackUserId === 'string', 'Context slackUserId (string) is required');

    // append task to ask for another trigger
    var newTask = _.cloneDeep(require('./../tasks/feedback/gather-trigger-type-repeat'));
    newTask.interactions['saveContextKey'] = 'trigger' + (context.triggers && context.triggers.size());
    task.chainTask(newTask, context);
    return Promise.resolve(true);
  }
}

module.exports = HookAddAnotherTrigger;