const fs = require('fs');
const path = require('path');
const Tasks = {};

//fs.readdirSync(__dirname).forEach(function(file) {
//  var klass = require('./'+ file);
//  Tasks[klass.name] = klass;
//});

console.log(__dirname + path.sep + 'feedback');

['feedback'].forEach(moduleDir => {
  fs.readdirSync(__dirname + path.sep + moduleDir).forEach(function(file) {
    var klass = require('./'+ path.sep + moduleDir + path.sep + file);
    Tasks[klass.name] = klass;
  });
});



module.exports = Tasks;