const CONSTANTS = require('./../../../constants/constants');
const task = {
  name: 'RemoveAdvisor',
  module: CONSTANTS.MODULES.FEEDBACK,
  priority: 2,
  before: ['HookGetUserInfo'],
  interactions: [
    {
      type: 'ActionGatherAdvisor',
      message: 'OK, from whom? ' +
              '\n\n' +
              ':bulb:Tip: You can type @ to see a dropdown with all of your coworkers',
      saveContextKey: 'removeAdvisorSlackUser'
    }
  ],
  after: ['HookRemoveAdvisor']
};

module.exports = task;