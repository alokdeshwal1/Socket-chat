const CONSTANTS = require('./../../../constants/constants');
const task = {
  name: 'ConfirmManagerNoEmployee',
  module: CONSTANTS.MODULES.FEEDBACK,
  priority: 3,
  interactions: [
    {
      type: 'ActionMessage',
      message: 'Ok! I didn\'t change anything'
    }
  ]
};

module.exports = task;