const CONSTANTS = require('./../../../constants/constants');
const task = {
  name: 'ArchiveGoal',
  module: CONSTANTS.MODULES.FEEDBACK,
  priority: 2,
  interactions: [
    {
      type: 'ActionGatherUserGoal',
      message: {
        pretext: 'Alrighty, which goal?',
        fallback: 'Select a goal',
        fieldTitle: 'Goals',
        footer: 'Pick a button:',
        nextPageFallback: 'OK, is it one of these?',
        nextPagePretext: 'OK, is it one of these?',
        nextPageFooter: 'Pick a goal from 1-%d.',
        noValueError: 'It looks like you don\'t currently have any active goals.'
      }
    },
    {
      type: 'ActionMessage',
      message: 'OK, done! :tada:'
    }
  ],
  after: ['HookArchiveGoal']
};

module.exports = task;