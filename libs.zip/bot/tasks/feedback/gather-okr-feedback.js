const CONSTANTS = require('./../../../constants/constants');
const task = {
  name: 'GatherOkrFeedback',
  module: CONSTANTS.MODULES.OKR,
  priority: 10,
  interactions: [
    {
      type: 'ActionGatherFeedbackRating',
      message: 'Hey [[userFirstName]], How do you think [[targetUserFirstName]] did this week on the OKR: *[[targetUserGoalName]]*' +
      '\n\n' +
      'Pick a reaction:'
    },
    {
      type: 'ActionGatherOkrFeedbackComment',
      message: 'Great, What progress did [[targetUserFirstName]] make towards this OKR? Anything else [[targetUserFirstName]]’d like to add?'
    },
    {
      type: 'ActionMessage',
      message: 'Cool. Thanks! I\'ll make sure this is tracked and sent to your manager as well. :+1: Bye for now. :wave:'
    }
  ],
  persist: 'PersistGatherOkrFeedback'
};

module.exports = task;