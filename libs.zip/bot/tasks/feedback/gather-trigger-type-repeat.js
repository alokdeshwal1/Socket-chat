const CONSTANTS = require('./../../../constants/constants');
const task = {
  name: 'PersistTriggerTypeRepeat',
  module: CONSTANTS.MODULES.FEEDBACK,
  priority: 10,
  interactions: [
    {
      type: 'ActionGatherTriggerType',
      message: {
        pretext: 'Cool, want to add another prompt? If not, tell me `no`.',
        fallback: 'Cool, want to add another prompt? If not, tell me `no`.',
        fieldTitle: 'Prompt types:',
        footer: 'Pick a button:',
        nextPageFallback: 'OK, is it one of these?',
        nextPagePretext: 'OK, is it one of these?',
        nextPageFooter: 'Pick any prompt from 1-%d.'
      }
    }
  ],
  persist: 'PersistTriggerTypeRepeat'
};

module.exports = task;