const CONSTANTS = require('./../../../constants/constants');
const task = {
  name: 'GatherGmailAuthentication',
  module: CONSTANTS.MODULES.FEEDBACK,
  priority: 10,
  interactions: [
    {
      type: 'ActionGoogleGmailAuthentication',
      message: 'OK, can you hook us up with your email? We only use this info for setting up prompts and will never share with anyone else.'
    },
    {
      type: 'ActionGatherGmailTrigger',
      message: 'Now...can you tell me what kind of emails? Here are the types of things that ' +
                'I understand (I\'m working on it but I\'m a bot after all :simple_smile:)\n' +
                '`emails that I replied to`\n' +
                '`email thread that I started`\n' +
 //               '`sent to richard, erlich, ashley`\n' +
                '`sent to susan and kenny only`\n' +
                '`subject line short code review`\n'
    }
  ],
  after: ['HookPersistGmailTrigger', 'HookAddAnotherTrigger']
};

module.exports = task;