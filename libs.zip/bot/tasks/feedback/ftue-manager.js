const CONSTANTS = require('./../../../constants/constants');
const task = {
  name: 'FtueManager',
  module: CONSTANTS.MODULES.FEEDBACK,
  priority: 2,
  reminderMessage: 'Knock knock! You account is not set up yet.',
  before: ['HookCheckBeforeFtue'],
  interactions: [
    {
      type: 'ActionGatherUser',
      message: 'Great! Who are your direct reports? I\'ll send them invites to get started.' +
                '\n\n' +
                ':bulb: Tip: type @ to see a dropdown with all of your coworkers. Select as many as you want.',
      saveContextKey: 'directs',
      skipParser: true
    }
  ],
  persist: 'PersistFtueManager'
};

module.exports = task;