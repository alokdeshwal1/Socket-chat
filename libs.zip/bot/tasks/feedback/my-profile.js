const CONSTANTS = require('./../../../constants/constants');
const task = {
  name: 'MyProfile',
  module: CONSTANTS.MODULES.FEEDBACK,
  priority: 2,
  before: ['HookGetUserProfile'],
  interactions: [
    {
      type: 'ActionAttachmentMessage',
      message: '[[userProfile]]'
    }
  ]
};

module.exports = task;