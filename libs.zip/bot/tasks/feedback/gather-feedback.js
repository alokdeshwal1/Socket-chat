const CONSTANTS = require('./../../../constants/constants');
const task = {
  name: 'GatherFeedback',
  module: CONSTANTS.MODULES.FEEDBACK,
  priority: 10,
  interactions: [
    {
      type: 'ActionGatherFeedbackRating',
      message: {
        text: 'Hey [[userFirstName]], How did *[[targetUserFirstName]]* do on: *[[targetUserGoalName]]*' +
              '\n\n' +
              'Pick one:',
        fallback: 'Feedback for [[targetUserFirstName]]',
        title: 'Feedback for [[targetUserFirstName]]',
        alternativeMessage: 'How\'d [[targetUserFirstName]] do on: *[[targetUserGoalName]]*',
        confirmation: 'Great, to confirm this is for *[[targetUserFirstName]]*\'s goal of *[[targetUserGoalName]]*?'
      }
    },
    {
      type: 'ActionGatherFeedbackComment',
      message: 'Great, thanks! What in particular do you want see *[[targetUserFirstName]]* do ' +
                'next time?'
    },
    {
      type: 'ActionMessage',
      message: 'Awesome! :+1: I\'ll make sure to give [[targetUserFirstName]] the message. Bye for now. :wave:'
    }
  ],
  persist: 'PersistGatherFeedback'
};

module.exports = task;