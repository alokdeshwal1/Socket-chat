const CONSTANTS = require('./../../../constants/constants');
const task = {
  name: 'ConfirmManagerYesReplacedManager',
  module: CONSTANTS.MODULES.FEEDBACK,
  priority: 3,
  interactions: [
    {
      type: 'ActionMessage',
      message: '[[employeeFirstName]] has changed their manager to [[managerFirstName]]. If you think this is an error, talk to [[employeeFirstName]] directly. Thanks!'
    }
  ]
};

module.exports = task;