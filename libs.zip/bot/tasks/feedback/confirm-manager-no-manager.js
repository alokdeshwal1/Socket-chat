const CONSTANTS = require('./../../../constants/constants');
const task = {
  name: 'ConfirmManagerNoManager',
  module: CONSTANTS.MODULES.FEEDBACK,
  priority: 3,
  interactions: [
    {
      type: 'ActionMessage',
      message: '[[employeeFirstName]] already has another manager. Talk to [[employeeFirstName]] directly to change ' +
                'this if you think it\'s an error'
    }
  ]
};

module.exports = task;