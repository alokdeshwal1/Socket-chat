const CONSTANTS = require('./../../../constants/constants');
const task = {
  name: 'Ftue',
  module: CONSTANTS.MODULES.FEEDBACK,
  priority: 2,
  before: ['HookCheckBeforeFtue'],
  interactions: [
    {
      type: 'ActionManagerOrEmployee',
      message: 'Hi [[userFirstName]] :wave:! I\'m [[appName]], your friendly :robot_face:. I’m going to help you give and get micro-feedback to take your career to the next level. Let\'s get you set up. This will only take a few moments.' +
                '\n' +
                'If you’re a manager looking to get your team set up to give and receive feedback type `manager`. Otherwise, type `individual feedback` to start getting micro-feedback from your coworkers.' +
                '\n\n' +
                'You can also type `help` at any point if you get stuck.'
    }
  ],
  after: ['HookToManagerOrEmployee']
};

module.exports = task;