const CONSTANTS = require('./../../../constants/constants');
const task = {
  name: 'GatherManualTrigger',
  module: CONSTANTS.MODULES.FEEDBACK,
  priority: 10,
  interactions: [
    {
      type: 'ActionGatherManualTrigger',
      message: 'OK, can you tell me at what interval? Here are the types of things that I understand (I\'m working on it but ' +
                'I\'m a bot after all :simple_smile:) \n'     +
                '`every Monday at 3:30pm` \n'     +
                '`1st Tues of every month` \n'   +
                '`9PM on Sundays` \n' +
                '`every other Tuesday at 9am` \n\n' +
                ':bulb:Tip: We recommend asking for feedback at most once a week'
    }
  ],
  persist: 'PersistManualTrigger'
};

module.exports = task;