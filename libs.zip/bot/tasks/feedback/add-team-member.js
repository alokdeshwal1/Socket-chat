const CONSTANTS = require('./../../../constants/constants');
const task = {
  name: 'AddTeamMember',
  module: CONSTANTS.MODULES.FEEDBACK,
  priority: 2,
  before: ['HookGetUserInfo'],
  interactions: [
    {
      type: 'ActionGatherTeamMember',
      message: 'OK, who would you like to add? ' +
                '\n\n' +
                ':bulb:Tip: You can type @ to see a dropdown with all of your coworkers. Select as many as you want',
      saveContextKey: 'addTeamMemberSlackUser'
    }
  ],
  after: ['HookAddTeamMember']
};

module.exports = task;