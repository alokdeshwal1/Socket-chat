const CONSTANTS = require('./../../../constants/constants');
const task = {
  name: 'NotifyUserFeedback',
  module: CONSTANTS.MODULES.FEEDBACK,
  priority: 10,
  interactions: [
    {
      type: 'ActionMessage',
      message: 'Hey [[userFirstName]]! *[[advisorFirstName]]* has some feedback for you.'
    },
    {
      type: 'ActionAttachmentMessage',
      message: '[[userFeedback]]'
    }
  ]
};

module.exports = task;