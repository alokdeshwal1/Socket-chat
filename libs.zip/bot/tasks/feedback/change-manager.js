const CONSTANTS = require('./../../../constants/constants');
const task = {
  name: 'ChangeManager',
  module: CONSTANTS.MODULES.FEEDBACK,
  priority: 2,
  before: ['HookGetUserInfo'],
  interactions: [
    {
      type: 'ActionGatherManager',
      message: 'OK, who would you like to add? ' +
                '\n\n' +
                ':bulb:Tip: You can type @ to see a dropdown with all of your coworkers',
      saveContextKey: 'addManagerSlackUserId'
    }
  ],
  after: ['HookAddManager']
};

module.exports = task;