const CONSTANTS = require('./../../../constants/constants');
const task = {
  name: 'FtueEmployee',
  module: CONSTANTS.MODULES.FEEDBACK,
  priority: 2,
  before: ['HookCheckBeforeFtue'],
  interactions: [
    {
      type: 'ActionMessage',
      message: 'Hi [[userFirstName]]! :wave: Your manager [[managerFirstName]] just signed you up for [[appName]], a friendly :robot_face: that is going to help you give and receive lightweight feedback. ' +
                'Let’s get your goals set up so you can take your career to the next level! This will only take a few minutes.\n\n' +
                '(pro tip: type `back` to re-enter, `cancel` to end the current task, or `help` for other commands)'
    }
  ],
  persist: 'PersistFtueEmployee'
};

module.exports = task;