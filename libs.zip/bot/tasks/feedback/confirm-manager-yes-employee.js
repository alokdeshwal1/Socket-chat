const CONSTANTS = require('./../../../constants/constants');
const task = {
  name: 'ConfirmManagerYesEmployee',
  module: CONSTANTS.MODULES.FEEDBACK,
  priority: 3,
  interactions: [
    {
      type: 'ActionMessage',
      message: 'Great! [[managerFirstName]] is now your manager'
    }
  ]
};

module.exports = task;