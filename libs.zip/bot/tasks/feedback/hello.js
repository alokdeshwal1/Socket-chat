const BotMessages = require('./../../../configs/bot-messages');
const CONSTANTS = require('./../../../constants/constants');
const task = {
  name: 'Help',
  priority: 1,
  interactions: [
    {
      type: 'ActionMessage',
      message: BotMessages.Hello
    }
  ]
};

module.exports = task;