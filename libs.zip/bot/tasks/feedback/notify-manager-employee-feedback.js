const CONSTANTS = require('./../../../constants/constants');
const task = {
  name: 'NotifyManagerEmployeeFeedback',
  module: CONSTANTS.MODULES.FEEDBACK,
  priority: 10,
  interactions: [
    {
      type: 'ActionMessage',
      message: 'Hey [[managerFirstName]], thought you\'d like to know that [[employeeFirstName]] got this feedback from ' +
        '[[advisorFirstName]]'
    },
    {
      type: 'ActionAttachmentMessage',
      message: '[[userFeedback]]'
    }
  ]
};

module.exports = task;