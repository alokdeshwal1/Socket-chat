const CONSTANTS = require('./../../../constants/constants');
const task = {
  name: 'GatherGoal',
  module: CONSTANTS.MODULES.FEEDBACK,
  priority: 10,
  interactions: [
    {
      type: 'ActionMessage',
      message: 'Great! Which of the following goal categories look interesting to you?'
    },
    {
      type: 'ActionGatherGoalCategory',
      message: {
        pretext: 'Pick one of the following categories:',
        fallback: 'Pick one of the following categories:',
        fieldTitle: 'Goal categories:',
        footer: 'Select a button:',
        nextPageFallback: 'OK, is it one of these?',
        nextPagePretext: 'OK, is it one of these?',
        nextPageFooter: 'Pick any category from 1-%d. Otherwise' +
                        '\n' +
                        'type "Other".'
      }
    },
    {
      type: 'ActionGatherGoalCompetency',
      message: {
        pretext: 'Great, pick one of these [[goalCategoryName]] suggested goals or write in your own!',
        fallback: 'Great, pick one of these [[goalCategoryName]] suggested goals or write in your own!',
        fieldTitle: 'Suggested goals:',
        footer: 'Pick a button. Or write in your own!',
        nextPageFallback: 'OK, is it one of these?',
        nextPagePretext: 'OK, is it one of these?',
        nextPageFooter: 'Pick any goal from 1-%d. Or write in your own!',
        noValueText: 'Looks like we don\'t have suggested goals for [[goalCategoryName]]. Please write in your own!',
        noValueFallback: 'Write in your own goal:'
      }
    },
    {
      type: 'ActionGatherUser',
      message: 'Cool, who would you like to get feedback from for this? ' +
                '\n\n' +
                ':bulb:Tip: You can type @ to see a dropdown with all of your coworkers. Select as many as you want',
      saveContextKey: 'advisors'
    },
    {
      type: 'ActionGatherTriggerType',
      message: {
        pretext: 'Great! How should I ask them?',
        fallback: 'Great! How should I ask them?',
        fieldTitle: 'Prompt types:',
        footer: 'Pick a button:',
        nextPageFallback: 'OK, is it one of these?',
        nextPagePretext: 'OK, is it one of these?',
        nextPageFooter: 'Pick any prompt from 1-%d.'
      }
    }
  ],
  persist: 'PersistGatherGoal'
};

module.exports = task;