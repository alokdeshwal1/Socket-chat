const CONSTANTS = require('./../../../constants/constants');
const task = {
  name: 'NotifyManagerEmployeeSelfAssessment',
  module: CONSTANTS.MODULES.OKR,
  priority: 10,
  interactions: [
    {
      type: 'ActionMessage',
      message: 'Hey [[managerFirstName]], here\'s [[employeeFirstName]]\' self-assessment'
    },
    {
      type: 'ActionAttachmentMessage',
      message: '[[userFeedback]]'
    }
  ]
};

module.exports = task;