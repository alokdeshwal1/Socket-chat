const CONSTANTS = require('./../../../constants/constants');
const task = {
  name: 'GatherGeneralFeedback',
  module: CONSTANTS.MODULES.FEEDBACK,
  priority: 10,
  interactions: [
    {
      type: 'ActionGatherFeedbackRating',
      message: {
        text: 'Hey [[userFirstName]], How\'s *[[targetUserFirstName]]* doing this week?' +
        '\n\n' +
        'Pick a reaction:',
        fallback: 'Feedback for [[userFirstName]]',
        title: 'Feedback for [[userFirstName]]',
        alternativeMessage: 'How\'d [[targetUserFirstName]] do?',
        confirmation: 'Great, to confirm this is for *[[targetUserFirstName]]*?'
      }
    },
    {
      type: 'ActionGatherFeedbackComment',
      message: 'Great, thanks! Do you have any comments you\'d like to share? It\'s particularly useful if you can ' +
                'provide concrete examples of things you’d like to see *[[targetUserFirstName]]* do next time.'
    },
    {
      type: 'ActionMessage',
      message: 'Awesome! :+1: I\'ll make sure to give [[targetUserFirstName]] the message. Bye for now. :wave:'
    }
  ],
  persist: 'PersistGatherGeneralFeedback'
};

module.exports = task;