const CONSTANTS = require('./../../../constants/constants');
const task = {
  name: 'GatherFunction',
  module: CONSTANTS.MODULES.FEEDBACK,
  priority: 3,
  interactions: [
    {
      type: 'ActionMessage',
      message: 'Hi [[userFirstName]]! :wave: Your manager [[managerFirstName]] just signed you up for [[appName]]. ' +
                'Let’s get your goals set up so you can take your career to the next level! This will only take a few minutes.\n\n' +
                '(pro tip: type `back` to re-enter or `help` for other commands!)'
    },
    {
      type: 'ActionGatherFunction',
      message: {
        pretext: 'First, what is your job function? We use this info to tailor suggested goals for you.',
        fallback: 'Pick a function:',
        fieldTitle: 'Job Functions:',
        footer: 'Pick a reaction:',
        nextPageFallback: 'OK, is it one of these?',
        nextPagePretext: 'OK, is it one of these?',
        nextPageFooter: 'Pick any function from 1-%d. Otherwise' +
                        '\n' +
                        'type "Other".'
      }
    }
  ],
  persist: 'PersistJobFunction'
};

module.exports = task;