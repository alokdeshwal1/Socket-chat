const CONSTANTS = require('./../../../constants/constants');
const task = {
  name: 'SummaryReport',
  module: CONSTANTS.MODULES.FEEDBACK,
  priority: 2,
  interactions: [
    {
      type: 'ActionMessage',
      message: 'Got it! Let me pull up a summary report for you.'
    }
  ],
  persist: 'PersistSummaryReport'
};

module.exports = task;