const CONSTANTS = require('./../../../constants/constants');
const task = {
  name: 'ConfirmManagerYesManager',
  module: CONSTANTS.MODULES.FEEDBACK,
  priority: 3,
  interactions: [
    {
      type: 'ActionMessage',
      message: 'Great! [[employeeFirstName]] is now on your team!'
    }
  ]
};

module.exports = task;