const CONSTANTS = require('./../../../constants/constants');
const task = {
  name: 'ConfirmManager',
  module: CONSTANTS.MODULES.FEEDBACK,
  priority: 3,
  interactions: [
    {
      type: 'ActionYesNo',
      message: '[[managerFirstName]] wants to add you to their team. Can you confirm that [[managerFirstName]] ' +
                'is in fact your manager? If so, your info will be updated.',
      saveContextKey: 'confirmManager'
    }
  ],
  after: ['HookConfirmManager']
};

module.exports = task;