const CONSTANTS = require('./../../../constants/constants');
const task = {
  name: 'NotifyAdvisorEmployeeGoal',
  module: CONSTANTS.MODULES.FEEDBACK,
  priority: 10,
  interactions: [
    {
      type: 'ActionMessage',
      message: 'Hi [[userFirstName]]! I\'m CareerLark, your friendly bot that helps everyone share more feedback. ' +
                'Your coworker [[employeeFirstName]] has selected you as a feedback giver. Here is more detail'
    },
    {
      type: 'ActionAttachmentMessage',
      message: '[[employeeGoalAttachmentMessages]]'
    }
  ]
};

module.exports = task;