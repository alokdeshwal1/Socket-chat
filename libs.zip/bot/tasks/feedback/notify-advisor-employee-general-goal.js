const CONSTANTS = require('./../../../constants/constants');
const task = {
  name: 'NotifyAdvisorEmployeeGeneralGoal',
  module: CONSTANTS.MODULES.FEEDBACK,
  priority: 10,
  interactions: [
    {
      type: 'ActionMessage',
      message: 'Hi [[userFirstName]]! I\'m CareerLark, your friendly bot that helps everyone share more feedback. ' +
                'Your coworker [[employeeFirstName]] has selected you as a feedback giver. I\'ll prompt you to give [[employeeFirstName]] feedback [[frequencyString]]'
    }
  ]
};

module.exports = task;