const CONSTANTS = require('./../../../constants/constants');
const task = {
  name: 'Report1on1Feedback',
  module: CONSTANTS.MODULES.FEEDBACK,
  priority: 10,
  interactions: [
    {
      type: 'ActionMessage',
      message: 'Hey [[userFirstName]]! Looks like you and [[employeeFirstName]] have your 1:1 coming up soon. ' +
      'Here\'s [[employeeFirstName]] feedback over the last 7 days. I\'ll email this to you as well. Have a good meeting! :wave:'
    },
    {
      type: 'ActionAttachmentMessage',
      message: '[[userFeedback]]'
    }
  ]
};

module.exports = task;