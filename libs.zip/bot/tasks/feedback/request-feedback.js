const CONSTANTS = require('./../../../constants/constants');
const task = {
  name: 'RequestFeedback',
  module: CONSTANTS.MODULES.FEEDBACK,
  priority: 2,
  before: ['HookGetUserInfo'],
  interactions: [
    {
      type: 'ActionGatherUser',
      message: 'OK, who would you like request feedback from?' +
                '\n\n' +
                ':bulb:Tip: You can type @ to see a dropdown with all of your coworkers. Select as many as you want',

      saveContextKey: 'requestFeedbackFromUsers'
    },
    {
      type: 'ActionGatherUserGoal',
      message: {
        pretext: 'Alrighty, which goal?',
        fallback: 'Select a goal',
        fieldTitle: 'Goals',
        footer: 'Pick a button:',
        nextPageFallback: 'OK, is it one of these?',
        nextPagePretext: 'OK, is it one of these?',
        nextPageFooter: 'Pick a goal from 1-%d.',
        noValueError: 'It looks like you don\'t currently have any active goals.'
      }
    }
  ],
  after: ['HookRequestFeedback']
};

module.exports = task;