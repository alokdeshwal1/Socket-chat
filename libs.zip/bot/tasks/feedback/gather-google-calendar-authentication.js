const CONSTANTS = require('./../../../constants/constants');
const task = {
  name: 'GatherGoogleCalendarAuthentication',
  module: CONSTANTS.MODULES.FEEDBACK,
  priority: 10,
  interactions: [
    {
      type: 'ActionGoogleCalendarAuthentication',
      message: 'OK, can you hook us up with your calendar? We only use this info for setting up prompts and will never share with anyone else.'
    },
    {
      type: 'ActionGatherGoogleCalendarEvent',
      message: 'Now...can you tell me what kind of meetings? Here are the types of things that ' +
                'I understand (I\'m working on it but I\'m a bot after all :simple_smile:)\n' +
                '`organized by Katie`\n' +
                '`has more than 5 people`\n' +
                '`has attendees richard erlich and ashley`\n' +
                '`name has product sync`'
    }
  ],
  persist: 'PersistGoogleCalendarTrigger'
};

module.exports = task;