const BotMessages = require('./../../../configs/bot-messages');
const CONSTANTS = require('./../../../constants/constants');
const task = {
  name: 'Help',
  module: CONSTANTS.MODULES.FEEDBACK,
  priority: 1,
  interactions: [
    {
      type: 'ActionMessage',
      message: BotMessages.Help
    }
  ]
};

module.exports = task;