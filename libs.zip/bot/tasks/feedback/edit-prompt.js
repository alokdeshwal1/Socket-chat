const CONSTANTS = require('./../../../constants/constants');
const task = {
  name: 'EditGiver',
  module: CONSTANTS.MODULES.FEEDBACK,
  priority: 3,
  interactions: [
    {
      type: 'ActionGatherUser',
      message: 'OK, tell me the names of people you want to add or take off'
    }
  ],
  after: ['HookAfterEditGiver']
};

module.exports = task;