const CONSTANTS = require('./../../../constants/constants');
const task = {
  name: 'GatherGeneralGoal',
  module: CONSTANTS.MODULES.FEEDBACK,
  priority: 10,
  interactions: [
    {
      type: 'ActionGatherUser',
      message: 'Great! Let’s get you set up! Who would you like to get feedback from?' +
                '\n\n' +
                'We recommend choosing folks that you work closely with, who can provide you with meaningful guidance. ' +
                'We\'ll let them know that you value their input and are adding them as reviewers. ' +
                '\n\n' +
                ':bulb:Tip: You can type @ to see a dropdown with all of your coworkers. Select as many as you want',
      saveContextKey: 'advisors'
    },
    {
      type: 'ActionMessage',
      message: 'Sweet! I\'ll be pinging them for feedback for you every 2 weeks.'
    }
  ],
  persist: 'PersistGatherGeneralGoal'
};

module.exports = task;