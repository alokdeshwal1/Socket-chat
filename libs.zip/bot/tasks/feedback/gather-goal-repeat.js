const CONSTANTS = require('./../../../constants/constants');
const task = {
  name: 'GatherGoalRepeat',
  module: CONSTANTS.MODULES.FEEDBACK,
  priority: 10,
  interactions: [
    {
      type: 'ActionGatherGoalCategory',
      message: {
        pretext: 'OK! want to add another goal? If so, pick one of the following categories. If not, tell me `no`. You can always go back and add more later.',
        fallback: 'OK! want to add another goal? If so, pick one of the following categories. If not, tell me `no`. You can always go back and add more later.',
        fieldTitle: 'Goal categories:',
        footer: 'Select a button:',
        nextPageFallback: 'OK, is it one of these?',
        nextPagePretext: 'OK, is it one of these?',
        nextPageFooter: 'Pick any category from 1-%d. Otherwise' +
        '\n' +
        'type "Other".'
      }
    }
  ],
  persist: 'PersistGatherGoalRepeat'
};

module.exports = task;