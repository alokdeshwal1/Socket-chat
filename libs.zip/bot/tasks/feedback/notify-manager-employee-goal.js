const CONSTANTS = require('./../../../constants/constants');
const task = {
  name: 'NotifyManagerEmployeeGoal',
  module: CONSTANTS.MODULES.FEEDBACK,
  priority: 10,
  interactions: [
    {
      type: 'ActionMessage',
      message: 'Hey [[managerFirstName]], [[employeeFirstName]] ([[employeeSlackUserName]]) updated goals.'
    },
    {
      type: 'ActionAttachmentMessage',
      message: '[[employeeGoalAttachmentMessages]]'
    }
  ]
};

module.exports = task;