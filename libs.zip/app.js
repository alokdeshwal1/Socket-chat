const app = require('koa')();
const server = require('http').createServer(app.callback());
const io = require('socket.io')(server);
const router = require('koa-router')();
const cors = require('koa-cors');
const etag = require('koa-etag');
const compress = require('koa-compress');
const bodyParser = require('koa-bodyparser');
const Config = require('./configs/config');
const Blocked = require('blocked');
const Logger = require('./libs/logger');
const Routes = require('./configs/routes');
const Connections = require('./queue/connections');
const Queue = require('./queue/index');
const koaBunyanLogger = require('koa-bunyan-logger');
const Co = require('co');
const jwtAuthentication = require('./middlewares/jwt-authentication');
const errorCatcher = require('./middlewares/error-catcher');
const apiGenerator = require('./libs/api-generator');

/**
 * blow up if TZ variable is not found
 */

if (! (process.env.TZ && process.env.TZ === 'utc')) {
  throw new Error('process.env.TZ variable is not set to \'utc\'');
}

/**
 * Middleware
 */

//app.use(jwtAuthentication(app));
app.use(compress({
  threshold: 2048,
  flush: require('zlib').Z_SYNC_FLUSH
}));
app.use(errorCatcher);
app.use(bodyParser());
app.use(cors({
  origin: true
}));
app.use(etag());
app.use(koaBunyanLogger(Logger));
app.use(koaBunyanLogger.requestLogger());
app.use(koaBunyanLogger.requestIdContext());

/**
 * Routes
 */

app.use(Routes(router).routes());
//apiGenerator(app, router, require('./models/user'), '/v1');
//apiGenerator(app, router, require('./models/slack-integration'), '/v1');
//apiGenerator(app, router, require('./models/company'), '/v1');

/**
 * Websocket Initialization
 */

//io.on('connection', function(socket){
//  socket.on('error', function(err)  {
//    Debug('Socket error occurred %j', err);
//  });
//});

/**
 * Initialization
 */

app.server = server;
app.mongoose = require('./libs/mongoose-connection')();

if(! module.parent) {
  GLOBAL.queue = app.queue = new Queue(Config);

  Co(function *() {
    yield (() => {
      return new Promise((resolve) => {
        GLOBAL.queue.on('ready', resolve);
      });
    })();

    yield (() => {
      return new Promise((resolve) => {
        app.mongoose.connection.on('open', () => {
          resolve(true);
        });
      });
    })();
  });

  app.server.listen(process.env.PORT || 8080);
}

/**
 * Suppressing default error stack traces for koa-bunyan-logger
 * To ensure that stack traces from request handling don't get logged in their raw non-JSON forms.
 */

app.on('error', () => {});

/**
 * Warning for Blocked process
 */

Blocked((ms) => {
  Logger.warn('BLOCKED FOR %sms', ms | 0);
});

module.exports = app;