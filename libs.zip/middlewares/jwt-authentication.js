const jwt = require('koa-jwt');
const fs = require('fs');

module.exports = function(app) {
  return function *(next) {
    try {
      var publicKey = fs.readFileSync('configs/private.rsa.pub');
      app.use(jwt({ secret: publicKey }));
    }
    catch (err) {
      throw err;
    }

    yield* next;
  };
};