function bodyToObject(body) {
  return (typeof body === 'object') ? JSON.parse(JSON.stringify(body)) : body;
}

function errorTypeToCode(err) {
  if (err.name === 'BadRequestError') {
    return 400
  }

  return 500;
}


module.exports = function *(next) {
  const ctx = this;

  try {
    yield* next;
  }
  catch(err) {
    if ( ! ctx.noOverWriteBodyOutput) {
      if ( ! ctx.body) {
        ctx.body = {};
      }
      ctx.status = errorTypeToCode(err);
      ctx.body = bodyToObject(ctx.body);
      ctx.body.status = 'error';
      ctx.body.error = err.message || err;
    }
    this.log.error(__filename, err, err.stack);
    return;
  }

  if ( ! ctx.noOverWriteBodyOutput) {
    if ( ! ctx.body) {
      ctx.body = {};
    }
    if ( ! ctx.body.status) {
      var originalBody = bodyToObject(ctx.body);
      var newBody = {};
      newBody.status = 'success';
      newBody.result = originalBody;
      ctx.body = newBody;
    }
  }

};