const fs = require('fs');
const path = require('path');
const models = {};

fs.readdirSync(__dirname).forEach(function(file) {
  if (file !== 'index.js' || file !== 'model.js') {
    var model = require('./' + file);
    models[model.name] = model;
  }
});

module.exports = models;