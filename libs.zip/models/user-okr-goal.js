const assert = require('assert');
const CONSTANTS = require('./../constants/constants');
const mongoose = require('./../libs/mongoose-connection')();
const modelName = 'UserOkrGoal';
const schema = require('./../schemas/user-okr-goal');
const model = Object.assign(mongoose.model(modelName, schema, modelName), require('./model'));

model.findUserGoalsByUserId = function(userId) {
  assert(typeof userId === 'string',  'userId (String) is required');
  return this.find( { user: userId, status: CONSTANTS.DB.STATUS.ACTIVE }).populate('goal');
};

module.exports = model;