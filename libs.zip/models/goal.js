const mongoose = require('./../libs/mongoose-connection')();
const modelName = 'Goal';
const schema = require('./../schemas/goal');
const model = Object.assign(mongoose.model(modelName, schema, modelName), require('./model'));
module.exports = model;