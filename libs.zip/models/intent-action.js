const mongoose = require('./../libs/mongoose-connection')();
const modelName = 'IntentAction';
const schema = require('./../schemas/intent-action');
const model = Object.assign(mongoose.model(modelName, schema, modelName), require('./model'));
module.exports = model;