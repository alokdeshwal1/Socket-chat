const mongoose = require('./../libs/mongoose-connection')();
const modelName = 'GoalCategory';
const schema = require('./../schemas/goal-category');
const CONSTANTS = require('./../constants/constants');
const Logger = require('./../libs/logger');
const Co = require('co');
const model = Object.assign(mongoose.model(modelName, schema, modelName), require('./model'));

model.getCategories = function(functionId, companyId) {
  return new Promise((resolve, reject) => {
    Co(function *() {
      try {
        var generalGoalCategories = yield this.find({
          company: companyId,
          status: CONSTANTS.DB.STATUS.ACTIVE,
          jobFunction: null
        }).sort('priority');

        if ( ! (generalGoalCategories && Array.isArray(generalGoalCategories) && generalGoalCategories.length > 0)) {
          generalGoalCategories = yield this.find({
            status: CONSTANTS.DB.STATUS.ACTIVE,
            jobFunction: null
          }).sort('priority');
        }

        if (functionId) {
          var jobFunctionGoalCategories = yield this.find({
            status: CONSTANTS.DB.STATUS.ACTIVE,
            jobFunction: functionId,
            company: companyId
          }).sort('priority');

          if ( ! (jobFunctionGoalCategories && Array.isArray(jobFunctionGoalCategories) && jobFunctionGoalCategories.length > 0)) {
            jobFunctionGoalCategories = yield this.find({
              status: CONSTANTS.DB.STATUS.ACTIVE,
              jobFunction: functionId,
              company: null
            }).sort('priority');
          }
        }

        generalGoalCategories = generalGoalCategories || [];
        jobFunctionGoalCategories = jobFunctionGoalCategories || [];
        return resolve([].concat(generalGoalCategories).concat(jobFunctionGoalCategories));
      }
      catch (ex) {
        Logger.error({ex, exStack: ex.stack}, 'Failed to get categories');
        return resolve([]);
      }
    }.bind(this));
  });
};

module.exports = model;