const mongoose = require('./../libs/mongoose-connection')();
const modelName = 'Feature';
const schema = require('./../schemas/feature');
const model = Object.assign(mongoose.model(modelName, schema, modelName), require('./model'));
module.exports = model;