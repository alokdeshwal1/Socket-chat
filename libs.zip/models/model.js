const CONSTANTS = require('./../constants/constants');
const assert = require('assert');

/**
 * The base model functions that should be inherited by other models
 */

module.exports.findOneActive = function(id, populatedFields) {
  assert(typeof id === 'string',  'id (String) is required');
  if (populatedFields) {
    return this.findOne( { _id: id, status: CONSTANTS.DB.STATUS.ACTIVE }).populate(populatedFields);
  }
  return this.findOne( { _id: id, status: CONSTANTS.DB.STATUS.ACTIVE });
};