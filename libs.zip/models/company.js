const mongoose = require('./../libs/mongoose-connection')();
const modelName = 'Company';
const schema = require('./../schemas/company');
const model = Object.assign(mongoose.model(modelName, schema, modelName), require('./model'));
module.exports = model;