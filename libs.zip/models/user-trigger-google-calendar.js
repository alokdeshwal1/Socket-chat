const mongoose = require('./../libs/mongoose-connection')();
const modelName = 'UserTriggerGoogleCalendar';
const schema = require('./../schemas/user-trigger-google-calendar');
const model = Object.assign(mongoose.model(modelName, schema, modelName), require('./model'));
module.exports = model;