const mongoose = require('./../libs/mongoose-connection')();
const modelName = 'UserTriggerGmail';
const schema = require('./../schemas/user-trigger-gmail');
const model = Object.assign(mongoose.model(modelName, schema, modelName), require('./model'));
module.exports = model;