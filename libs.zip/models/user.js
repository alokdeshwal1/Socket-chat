const Logger = require('./../libs/logger');
const assert = require('assert');
const mongoose = require('./../libs/mongoose-connection')();
const modelName = 'User';
const schema = require('./../schemas/user');
const model = Object.assign(mongoose.model(modelName, schema, modelName), require('./model'));
const CONSTANTS = require('./../constants/constants');

model.upsertSlackUser = function(companyId, slackIntegrationId, userInfo) {
  assert(typeof companyId === 'object', 'companyId (String) is required');
  assert(typeof slackIntegrationId === 'string', 'slackIntegrationId (String) is required');
  assert(typeof userInfo === 'object', 'userInfo (Object) is required');

  try {
    var inputItem = {
      company: companyId,
      email: userInfo.profile.email,
      name: userInfo.profile.real_name || userInfo.name,
      firstName: userInfo.profile.first_name || userInfo.name,
      lastName: userInfo.profile.last_name || userInfo.name,
      isCreatedViaSlack: true,
      slackIntegration: slackIntegrationId,
      slackUserId: userInfo.id,
      slackUserName: userInfo.name,
      slackUserNameLower: userInfo.name.toLowerCase(),
      timezone: userInfo.tz || commonTimezone,
      timezoneLabel: userInfo.tz_label,
      pictureUrl: userInfo.profile.image_72,
      pictureSource: 'Slack',
      status: CONSTANTS.DB.STATUS.ACTIVE
    };

    // upsert doesn't support middleware or hook for update, that's why the pre validate or pre save hooks doesn't work
    if ( ! Number.isNaN(Number(userInfo.tz_offset))) {
      inputItem.timezoneOffset = userInfo.tz_offset;
    }

    if ( ! (userInfo.is_bot || userInfo.id === 'USLACKBOT' /* really? slackbot is not a bot */)) {
      return this.upsert({
        email: userInfo.profile.email,
        slackIntegration: slackIntegrationId
      }, inputItem);
    }
    else {
      return Promise.resolve(false);
    }
  }
  catch (ex) {
    Logger.error({ex, exStack: ex.stack, slackIntegrationId, userInfo}, 'upsertSlackUser error');
    return Promise.resolve(false);
  }
};

model.findBySlackId = function(slackUserId) {
  assert(typeof slackUserId === 'string',  'slackUserId (String) is required');
  return this.findOne( { slackUserId: slackUserId }).populate('slackIntegration manager company');
};

model.isUserSignUp = function(slackUserId) {
  assert(typeof slackUserId === 'string',  'slackUserId (String) is required');
  return new Promise((resolve, reject) => {
    this.findOne( { slackUserId: slackUserId })
      .then(user => {
        if (user.jobFunction && Array.isArray(user.jobFunction) && user.jobFunction.length > 0) {
          return resolve(true);
        }

        return resolve(false);
      })
      .catch(err => {
        Logger.error('Failed to execute find user in isUserSignUp', err);
        return resolve(false);
      });
  });
};

module.exports = model;