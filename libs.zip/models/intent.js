const mongoose = require('./../libs/mongoose-connection')();
const modelName = 'Intent';
const schema = require('./../schemas/intent');
const model = Object.assign(mongoose.model(modelName, schema, modelName), require('./model'));
module.exports = model;