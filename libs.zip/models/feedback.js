const mongoose = require('./../libs/mongoose-connection')();
const modelName = 'Feedback';
const schema = require('./../schemas/feedback');
const model = Object.assign(mongoose.model(modelName, schema, modelName), require('./model'));
module.exports = model;