const mongoose = require('./../libs/mongoose-connection')();
const modelName = 'UserTrigger';
const schema = require('./../schemas/user-trigger');
const ModelTriggerGmail = require('./user-trigger-gmail');
const ModelTriggerGoogleCalendar = require('./user-trigger-google-calendar');
const model = Object.assign(mongoose.model(modelName, schema, modelName), require('./model'));

model.findActiveUserTrigger = function(criteria) {
  assert(typeof criteria === 'object', 'criteria (Object) is required');

  criteria = Object.assign({
    status: CONSTANTS.DB.STATUS.ACTIVE
  }, criteria);

  return this.find(criteria).populate('trigger');
};

module.exports = model;