const mongoose = require('./../libs/mongoose-connection')();
const modelName = 'Function';
const schema = require('./../schemas/function');
const model = Object.assign(mongoose.model(modelName, schema, modelName), require('./model'));
module.exports = model;