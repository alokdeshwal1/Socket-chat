const mongoose = require('./../libs/mongoose-connection')();
const modelName = 'OkrGoal';
const schema = require('./../schemas/okr-goal');
const model = Object.assign(mongoose.model(modelName, schema, modelName), require('./model'));
module.exports = model;