const mongoose = require('./../libs/mongoose-connection')();
const modelName = 'SlackIntegration';
const schema = require('./../schemas/slack-integration');
const model = Object.assign(mongoose.model(modelName, schema, modelName), require('./model'));
module.exports = model;