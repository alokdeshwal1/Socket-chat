const mongoose = require('./../libs/mongoose-connection')();
const modelName = 'Module';
const schema = require('./../schemas/module');
const model = Object.assign(mongoose.model(modelName, schema, modelName), require('./model'));
const Logger = require('./../libs/logger');

model.isModuleEnabled = function(companyId, moduleId) {
  return new Promise((resolve) => {
    Co(function *() {
      try {
        var company = yield this.findOne({companyId: companyId, enabledModules: moduleId});
        return resolve(!!company);
      }
      catch (ex) {
        Logger.error({ex, exStack: ex.stack, companyId, moduleId}, 'Failed to run isModuleEnabled');
        return resolve(false);
      }
    }.bind(this));
  });
};

model.findCompanyModules = function (companyId) {
  return new Promise((resolve) => {
    Co(function *() {
      try {
        var company = yield this.findOne({companyId: companyId}).populate('modules');
        return resolve(company && company.enabledModules);
      }
      catch (ex) {
        Logger.error({ex, exStack: ex.stack, companyId}, 'Failed to run findCompanyModules');
        return resolve(null);
      }
    }.bind(this));
  });
};

module.exports = model;