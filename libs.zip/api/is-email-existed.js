const assert = require('http-assert');
const EmailExistence = require('email-existence');
const Validator = require('validator');

module.exports = function *(next) {
  const _this = this;
  const request = this.request.body;
  assert(typeof request.params === 'object', 400, 'params are required');
  const emailAddress = request.params.emailAddress;
  assert(Validator.isEmail(emailAddress) === true, 400, 'A valid email address is required');

  EmailExistence.check('emailAddress', function(err, res) {
    if(err) {
      _this.status = 200;
      _this.body = {
        status: 'error'
      }
    } else {
      _this.status = 200;
      _this.body = {
        status: 'success'
      }
    }
  });

  yield* next;
}
