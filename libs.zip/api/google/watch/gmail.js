const Request = require('request-promise');
const Config = require('./../../../configs/config');
const Co = require('co');
const CONSTANTS = require('./../../../constants/constants');
const Bluebird = require('bluebird');
const google = require('googleapis');
const OAuth2 = google.auth.OAuth2;
const oauth2Client = new OAuth2(Config.google.clientId, Config.google.clientSecret, Config.baseUrl + '/google/redirect');
const ModelUser = require('./../../../models/user');
const ModelUserGmailTrigger = require('./../../../models/user-trigger-gmail');
const ModelUserGoal = require('./../../../models/user-goal');
const GmailParser = require('./../../../libs/gmail-parser');
const TalkingBot = require('./../../../bot/talking-bot');
const Logger = require('./../../../libs/logger');
const assert = require('assert');

module.exports = function *(next) {
  const request = this.request.body;
  var message;
  try {
    message = new Buffer(request.message.data, 'base64').toString('utf-8');
    message = JSON.parse(message);
    assert(typeof message.emailAddress === 'string', 'message.emailAddress is not found');
    assert(message.historyId, 'message.historyId is not found');
  }
  catch(ex) {
    Logger.error('Failed to parse Gmail push notification message', ex, ex.stack);
    yield* next;
  }

  try {
    const user = yield ModelUser.findOne({ googleEmailAccount: message.emailAddress, status: CONSTANTS.DB.STATUS.ACTIVE });
    const historyId = message.historyId;
    //const historyId = 39275;
    const triggers = yield ModelUserGmailTrigger.find({ user: user.id, status: CONSTANTS.DB.STATUS.ACTIVE }).populate('user trigger userGoal');

    var parser = new GmailParser(user.googleOauthToken);
    var history = yield parser.listHistory('me', historyId);
    var allMessages = {};
    if (history && Array.isArray(history.history)) {
      for(var ii = 0; ii < history.history.length; ii++) {
        if (history.history[ii].messages && Array.isArray(history.history[ii].messages)) {
          for(var jj = 0; jj < history.history[ii].messages.length; jj++) {
            allMessages[history.history[ii].messages[jj].id] = true;
          }
        }
      }
    }

    var messageKeys = Object.keys(allMessages);
    for (var ii = 0; ii < messageKeys.length; ii++) {
      var result =  yield parser.getFulfilledTriggers(triggers, messageKeys[ii]);
      if (result && Array.isArray(result)) {
        for (var jj = 0; jj < result.length; jj++) {
          yield sendFeedbackRequest(result[jj], this.app.queue.queueJob);
        }
      }
    }
  }
  catch (ex) {
    Logger.error('Failed to send feedback request based on gmail push notification', ex, ex.stack);
  }

  yield* next;
};


function *sendFeedbackRequest (userTriggerGmail, queueJob) {
  if (! (userTriggerGmail.userGoal && userTriggerGmail.userGoal.advisors && Array.isArray(userTriggerGmail.userGoal.advisors))) {
    return false;
  }

  var actions = [];
  var user = yield ModelUser.findOne( { _id: userTriggerGmail.user.id, status: CONSTANTS.DB.STATUS.ACTIVE }).populate('slackIntegration');
  var userGoal = yield ModelUserGoal.findOne( { _id: userTriggerGmail.userGoal.id, status: CONSTANTS.DB.STATUS.ACTIVE }).populate('goal');
  if ( ! user) {
    return false;
  }

  userTriggerGmail.userGoal.advisors.forEach(advisor => {
    actions.push(ModelUser.findOne( { _id: advisor.toString(), status: CONSTANTS.DB.STATUS.ACTIVE }).populate('slackIntegration'));
  });

  var advisors = yield Promise.all(actions);
  if (Array.isArray(advisors)) {
    advisors.forEach(advisor => {
      queueJob('Bot-'+ TalkingBot.getTeamKey(advisor.slackIntegration.teamName, advisor.slackIntegration.teamId), {
        slackUserId: advisor.slackUserId,
        context: {
          appName: Config.appName,
          advisor: advisor,
          userGoal: userTriggerGmail.userGoal,
          trigger: userTriggerGmail,
          slackUserId: advisor.slackUserId,
          userFirstName: advisor.firstName,
          targetUser: user,
          targetUserFirstName: user.firstName,
          targetUserGoalName: userGoal && userGoal.goal && userGoal.goal.name || userGoal.name
        },
        task: require('./../../../bot/tasks/feedback/gather-feedback')
      });
    });
  }

}
