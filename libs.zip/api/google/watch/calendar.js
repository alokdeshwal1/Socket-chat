'use strict';

const Request = require('request-promise');
const Config = require('./../../../configs/config');
const Co = require('co');
const CONSTANTS = require('./../../../constants/constants');
const Bluebird = require('bluebird');
const google = require('googleapis');
const OAuth2 = google.auth.OAuth2;
const oauth2Client = new OAuth2(Config.google.clientId, Config.google.clientSecret, Config.baseUrl + '/google/redirect');
const ModelGooglePushNotification = require('./../../../models/google-push-notification');
const ModelTriggerGoogleCalendar = require('./../../../models/user-trigger-google-calendar');
const ModelUserTrigger = require('./../../../models/user-trigger');
const ModelUser = require('./../../../models/user');
const ModelTrigger = require('./../../../models/trigger');
const GCalParser = require('./../../../libs/google-calendar-parser');
const TalkingBot = require('./../../../bot/talking-bot');
const Logger = require('./../../../libs/logger');
const _ = require('lodash');
const deepEqual = require('deep-equal');

module.exports = function *(next) {
  const headers = this.request.headers;
  //const request = this.request.body;

  if (headers['user-agent'].indexOf('APIs-Google') !== 0) {
    Logger.warn('Calendar watch is called by user-agent other than APIs-Google', headers);
    yield* next;
    return;
  }

  // get the user Id
  if ( ! headers['x-goog-resource-id']) {
    Logger.error('receiving push notification from Google that has no x-goog-resource-id', headers);
    yield* next;
    return;
  }

  const pn = yield ModelGooglePushNotification.findOne({ 'watchInfo.resourceId': headers['x-goog-resource-id'],
                  'status': CONSTANTS.DB.STATUS.ACTIVE }).populate('user');
  const user = pn.user;

  if (! (pn && pn.user)) {
    Logger.error('push notification or push notification.user is not found with the x-goog-resource-id', headers);
    yield* next;
    return;
  }

  const userTriggers = yield ModelUserTrigger.find({ user: user.id, googleCalendarObject: {'$ne': null}, status: CONSTANTS.DB.STATUS.ACTIVE }).populate('userTriggerGoogleCalendar');
  const userGCalTriggers = yield ModelTriggerGoogleCalendar.find({ user: user.id, status: CONSTANTS.DB.STATUS.ACTIVE }).populate('userGoal user');
  const parser = new GCalParser(user.googleOauthToken);
  const tokenStatus = yield parser.isTokenValid();
  if (tokenStatus !== true) {
    Logger.error({
      user: user,
      userTriggers: userTriggers,
      userGCalTriggers: userGCalTriggers,
      tokenStatus: tokenStatus
    }, 'token is not valid or expired');
    yield* next;
    return;
  }

  // find whether there is a change in the current user triggers
  // get a list of googleCalEventId and check for any changes
  var existingEventIds = _.uniq(_.pluck(userTriggers, 'googleCalendarObject.id'));
  for(let userTrigger of userTriggers) {
    if ( ! (userTrigger && userTrigger.googleCalendarObject && userTrigger.googleCalendarObject.id)) {
      continue;
    }

    var eventInfo = yield parser.getEvent(userTrigger.googleCalendarObject.id);
    // deleted?
    if ( ! eventInfo) {
      yield deleteUserTrigger(userTrigger, this.app.queue.queueJob);
      continue;
    }

    // any update? yes, check whether the criteria still fulfilled and update the trigger
    var compareEventInfo = _.pick(eventInfo, 'attendees', 'creator', 'end', 'organizer', 'recurrence', 'start', 'summary');
    var compareCalendarObject = _.pick(userTrigger.googleCalendarObject, 'attendees', 'creator', 'end', 'organizer', 'recurrence', 'start', 'summary');
    if ( ! deepEqual(compareEventInfo, compareCalendarObject)) {
      if (parser.isEventFulfillCriteria(userTrigger.userTriggerGoogleCalendar.criteria, eventInfo)) {
        try {
          // update the trigger
          userTrigger.googleCalendarObject = eventInfo;
          userTrigger.rrule = {
            start: eventInfo.start,
            rules: eventInfo.recurrence
          };
          yield userTrigger.save();

          // tell scheduler about that
          // @TODO - should move this to schema hook
          yield this.app.queue.queueJob(CONSTANTS.JOB_QUEUE.CRON_SCHEDULER, {
            type: 'update',
            triggerId: userTrigger.id
          });
        }
        catch(ex) {
          Logger.error({
            ex: ex,
            exStack: ex.stack,
            userTrigger: userTrigger,
            eventInfo: eventInfo
          }, 'Failed to update user trigger');
        }

        continue;
      }
      else {
        yield deleteUserTrigger(userTrigger, this.app.queue.queueJob);
        continue;
      }
    }
  }

  // find new events that could match criteria that user set before
  for(let gCalTrigger of userGCalTriggers) {
    let events = yield parser.findEvents(gCalTrigger.criteria);
    let trigger = yield ModelTrigger.findOne({ systemKey: 'Google Calendar Integration', status: CONSTANTS.DB.STATUS.ACTIVE });

    if (events && Array.isArray(events)) {
      for(let event of events) {
        // skip if event is already taken care of before
        if (existingEventIds.indexOf(event.id) !== -1) {
          continue;
        }

        try {
          var userTrigger = new ModelUserTrigger();
          userTrigger.trigger = trigger.id;
          userTrigger.userGoal = gCalTrigger.userGoal.id;
          userTrigger.user = gCalTrigger.user.id;
          if (event.recurrence) {
            userTrigger.rrule = {
              start: event.start,
              rules: event.recurrence
            };
          }
          userTrigger.userTriggerGoogleCalendar = gCalTrigger.id;
          userTrigger.googleCalendarObject = event;
          userTrigger.status = CONSTANTS.DB.STATUS.ACTIVE;

          var nextTrigger = yield userTrigger.save();

          this.app.queue.queueJob(CONSTANTS.JOB_QUEUE.CRON_SCHEDULER, {
            type: 'add',
            triggerId: nextTrigger.id
          });
        }
        catch (ex) {
          Logger.error({
            ex: ex,
            exStack: ex.stack,
            gCalTrigger: gCalTrigger,
            event: event
          }, 'Failed to save gcaltrigger');

          continue;
        }
      }
    }
  }

  yield* next;
};

function *deleteUserTrigger(userTrigger, queueJob) {
  try {
    yield userTrigger.remove();

    // tell scheduler about that
    // @TODO - should move this to schema hook
    yield queueJob(CONSTANTS.JOB_QUEUE.CRON_SCHEDULER, {
      type: 'remove',
      triggerId: userTrigger.id
    });
  }
  catch (ex) {
    Logger.error({
      ex: ex,
      exStack: ex.stack,
      userTrigger: userTrigger
    }, 'Failed to remove user trigger');
    return false
  }

  return true;
}