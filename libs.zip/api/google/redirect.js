const Request = require('request-promise');
const Config = require('./../../configs/config');
const Co = require('co');
const CONSTANTS = require('./../../constants/constants');
const Bluebird = require('bluebird');
const google = require('googleapis');
const OAuth2 = google.auth.OAuth2;
const oauth2Client = new OAuth2(Config.google.clientId, Config.google.clientSecret, Config.baseUrl + '/google/redirect');
const ModelUser = require('./../../models/user');
const TalkingBot = require('./../../bot/talking-bot');

module.exports = function *(next) {
  const request = this.request.body;
  const code = request.code;
  const state = request.state && JSON.parse(request.state);
  const slackUserId = state.slackUserId;
  const integrationRequestId = state.integrationRequestId;

  this.assert(typeof code === 'string', 400, 'Code (String) is required');
  state && this.assert(typeof state === 'object', 400, 'State (Object) is required');
  slackUserId && this.assert(typeof slackUserId === 'string', 400, 'SlackUserId (String) is required');
  integrationRequestId && this.assert(typeof integrationRequestId === 'string', 400, 'integrationRequestId (String) is required');

  // exchange temporary code for access token
  const resultOauthAccess = yield function(code) {
    return new Promise((resolve, reject) => {
      oauth2Client.getToken(code, (err, tokens) => {
        if (err) {
          return reject(err);
        }
        return resolve(tokens);
      });
    });
  }(code);

  this.log.info(__filename, 'Google oauth access result', resultOauthAccess);

  const user = yield ModelUser.findOne({ slackUserId: slackUserId, status: CONSTANTS.DB.STATUS.ACTIVE }).populate('slackIntegration');
  if ( ! user) {
    this.body = this.body || {};
    this.body.status = 'error';
    this.body.error = 'User is not found';
    return;
  }

  user.googleOauthToken = resultOauthAccess;
  yield user.save();

  // everything is good, let's tell the slack bot
  yield this.app.queue.queueJob('Bot-'+ TalkingBot.getTeamKey(user.slackIntegration.teamName, user.slackIntegration.teamId), {
    type: CONSTANTS.BOT_JOB_TYPE.INTEGRATION_MESSAGE,
    slackUserId: slackUserId,
    context: {
      slackUserId: slackUserId,
      googleOauthToken: resultOauthAccess,
      integrationRequestId: integrationRequestId
    }
  });

  this.body = this.body || {};
  this.body.user = user;

  yield* next;
};
