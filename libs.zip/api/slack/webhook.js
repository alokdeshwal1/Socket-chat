'use strict';

const Request = require('request-promise');
const Config = require('./../../configs/config');
const Co = require('co');
const CONSTANTS = require('./../../constants/constants');
const ModelUser = require('./../../models/user');
const ModelCompany = require('./../../models/company');
const Helper = require('./../../bot/libs/helper');
const Slack = require('./../../libs/slack');
const Bot = require('./../../bot/bot');
const _ = require('lodash');
const ModelSlackIntegration = require('./../../models/slack-integration');

module.exports = function *(next) {
  const request = this.request.body;
  const headers = this.request.headers;
  const code = request.code;
  const state = request.state;

  // run through a list of services


  this.assert(headers['session-token'] === Config.sessionSecret, 'Session token is invalid.');
  this.assert(typeof code === 'string', 'Code (String) is required');
  state && this.assert(typeof state === 'string', 'State (String) is required');

  // exchange temporary code for access token
  this.log.info('Slack token:', code);
  const resultOauthAccess = yield Slack.exchangeCodeForAccessToken(code);
  this.log.info('Slack redirect result: ', resultOauthAccess);
  var accessInfo;
  try {
    accessInfo = JSON.parse(resultOauthAccess);
    this.assert(typeof accessInfo.access_token === 'string', '(access_token) is not valid or exists');
  }
  catch (ex) {
    this.log.error('accessInfo.access_token error', ex, ex.stack);
    throw new Error('Slack Access token is invalid');
  }

  // get the user's id for retrieving user's info
  const resultAuthTest = yield Slack.getUserId(accessInfo.access_token);
  this.log.info('Slack auth test result: ', resultOauthAccess);
  const slackAuthInfo = JSON.parse(resultAuthTest);

  var params = {};
  params.accessToken = accessInfo.access_token;
  params.incomingWebHook = accessInfo.incoming_webhook;
  params.scope = accessInfo.scope;
  params.teamId = accessInfo.team_id;
  params.teamName = accessInfo.team_name;
  params.bot = accessInfo.bot;
  params.rawData = accessInfo;
  params.installerSlackUserId = slackAuthInfo.user_id;
  params.installerSlackUserName = slackAuthInfo.user;
  params.status = CONSTANTS.DB.STATUS.ACTIVE;

  // output body
  this.body = this.body || {};
  this.body.teamId = params.teamId;
  this.body.teamName = params.teamName;
  this.body.domain = params.domain;

  const bot = new Bot(params.bot.bot_access_token, Config.slack.botName);
  const users = yield bot.getUsers();
  if ( ! (users && users.members && Array.isArray(users.members))) {
    this.log.error('users members list is empty or undefined', users);
    // continue the installation...
  }

  // find the installer's from the users list
  const installer = _.findWhere(users.members, {id: params.installerSlackUserId});
  if (! (installer && installer.id)) {
    this.log.error('Installer is not found from list of users', params.installerSlackUserId, installer);
    throw new Error('Emm..it looks like your account is not found in your Slack team');
  }
  params.installerSlackUserEmail = installer.profile.email;

  // insert the slack integration
  var result = yield ModelSlackIntegration.upsert({
    teamId: params.teamId
  }, params);

  if ( ! (result && result.id)) {
    this.log.error('Slack Integration is not returning object id', result);
    throw new Error('Emm... we are so sorry. Something is broken. Could you please try again?');
  }

  const actions = [];
  if (Array.isArray(users.members)) {
    var commonTimezone;

    // make sure all users has timezone information, if not we use the common timezone
    for(let member of users.members) {
      if (member.tz) {
        commonTimezone = member.tz;
        break;
      }
    }

    users.members.forEach((item) => {
      var inputItem = {
        company: result.company,
        email: item.profile.email,
        name: item.profile.real_name || item.name,
        firstName: item.profile.first_name || item.name,
        lastName: item.profile.last_name || item.name,
        isCreatedViaSlack: true,
        slackIntegration: result.id,
        slackUserId: item.id,
        slackUserName: item.name,
        slackUserNameLower: item.name.toLowerCase(),
        timezone: item.tz || commonTimezone,
        timezoneLabel: item.tz_label,
        pictureUrl: item.profile.image_72,
        pictureSource: 'Slack',
        status: CONSTANTS.DB.STATUS.ACTIVE
      };

      // upsert doesn't support middleware or hook for update, that's why the pre validate or pre save hooks doesn't work
      if ( ! Number.isNaN(Number(item.tz_offset))) {
        inputItem.timezoneOffset = item.tz_offset;
      }

      if ( ! (item.is_bot || item.id === 'USLACKBOT' /* really? slackbot is not a bot */)) {
        actions.push(ModelUser.upsert({
          email: item.profile.email,
          slackIntegration: result.id
        }, inputItem));
      }
    });
  }

  try {
    // Make promise.all continue execute other promises even though one or more promises failed
    yield Promise.all(actions.map((promise) => {
      return promise.then(
        (v) => {
          return {v: v, status: "resolved"}
        },
        (e) => {
          this.log.error('Failed to save Slack users in installation', e, e.stack);
          return {e: e, status: "rejected"}
        });
    }));
  }
  catch (ex) {
    this.log.error('Failed to save Slack users in installation', ex, ex.stack);
    throw new Error(ex.message);
  }

  // check and see what features are enabled for this company
  var companyInfo;
  try {
    companyInfo = yield ModelCompany.findOneActive(result.company.toString());
  }
  catch (ex) {
    this.log.error('Failed to get companyInfo in installation', ex, ex.stack);
  }

  params.enabledModules = {};
  params.enabledModules[CONSTANTS.MODULES.OKR] = companyInfo.featureOkrGoal;
  params.enabledModules[CONSTANTS.MODULES.PERSONAL_GOAL] = companyInfo.featurePersonalGoal;

  // create a new installation job
  params.newInstallation = {
    queueName: Helper.getBotQueueName(params.teamName, params.teamId),
    job: {
      slackUserId: params.installerSlackUserId,
      context: {
        userFirstName: installer.profile.first_name || installer.name,
        slackUserId: installer.id,
        appName: Config.appName,
        slackIntegrationId: result.id,
        companyId: result.company.toString(),
        isNewBotInstallation: true
      },
      task: (companyInfo && companyInfo.featureOkrGoal === true && ! companyInfo.featurePersonalGoal) ? undefined : require('../../bot/tasks/feedback/ftue')
    }
  };
  yield this.app.queue.queueJob(CONSTANTS.JOB_QUEUE.BOT_SERVER, params);

  yield* next;
};
