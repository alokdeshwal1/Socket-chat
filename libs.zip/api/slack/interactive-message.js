'use strict';

const Request = require('request-promise');
const Config = require('./../../configs/config');
const Co = require('co');
const CONSTANTS = require('./../../constants/constants');
const ModelUser = require('./../../models/user');
const ModelCompany = require('./../../models/company');
const Helper = require('./../../bot/libs/helper');
const Slack = require('./../../libs/slack');
const Bot = require('./../../bot/bot');
const _ = require('lodash');
const ModelSlackIntegration = require('./../../models/slack-integration');
const assert = require('assert');

module.exports = function *(next) {
  const body = this.request.body;
  const headers = this.request.headers;
  const payload = JSON.parse(body.payload);

  assert(headers['user-agent'].indexOf('Slackbot') === 0, 'Invalid user agent');
  assert.equal(payload.token, Config.slack.token, 'Slack Token is mismatched');

  // get the team name
  const slackIntegration = yield ModelSlackIntegration.findOne({ teamId: payload.team.id });
  const slackUserId = payload.user.id;

  // everything is good, let's tell the bot
  delete payload.token;
  yield this.app.queue.queueJob(Helper.getBotQueueName(slackIntegration.teamName, slackIntegration.teamId), {
    type: CONSTANTS.BOT_JOB_TYPE.INTEGRATION_MESSAGE,
    slackUserId: slackUserId,
    integrationType: CONSTANTS.INTEGRATION_TYPE.INTERACTIVE_MESSAGE,
    payload: payload,
    context: {
      slackUserId: slackUserId
    }
  });

  // update the button
  var originalMessage = _.cloneDeep(payload.original_message.attachments[0]);
  originalMessage.actions = originalMessage.actions.filter(item => { return item.value === payload.actions[0].value });

  this.noOverWriteBodyOutput = true; // stop error-catcher middleware from changing the output format
  this.body = {
    attachments: [originalMessage]
  };

  // route the message back to the bot server
  yield* next;
};