const Util = require('util');
const Helper = require('./../bot/libs/helper');

function randMessage(messages) {
  return function(placeholderValues) {
    var randKey = Math.floor(Math.random() * 10000 % messages.length);
    return (typeof placeholderValues === 'object') ?
              Helper.replaceMessagePlaceholder(messages[randKey], placeholderValues) :
              messages[randKey];
  };
}

function placeholderMessage(messages) {
  return (params) => {
    if (typeof messages === 'string') {
      messages = [messages];
    }
    return Helper.replaceMessagePlaceholder(randMessage(messages)(), params);
  }
}

module.exports = {
  Validation: {
    'yesNo': randMessage(['Interesting ... Do you mean `yes` or `no`?']), 
    'editGoalType': randMessage(['Interesting...do you mean `prompts` or `givers`?']),
    'managerOrEmployee': randMessage(['Interesting...do you mean `manager` or `individual goal`?']),
    'range': randMessage(['I don\'t understand :disappointed:, could you pick one from the list?']),
    'rangeNotFound': randMessage(['Sorry, I don\'t understand "[[inputText]]" as a response to this question. Please try again. You can also type `cancel` to exit out of the current task']),
    'gatherUser': randMessage(['I don\'t quite understand :disappointed:, who are your employees?']),
    'recurrenceDate': randMessage(['So sorry but I don\'t understand :disappointed:. Please try again.']),
    'freeFormText': randMessage(['Could you try again with a longer answer?'])
  },
  ActionSetupGoal: {
    title: function(managerName, userName) {
      return Util.format('Hi %s, your manager %s has invited me, Larkbot, to your Slack team. I\'m here to help you ' +
        'setup your goals', managerName, userName);
    },
    goal: randMessage(['What is your goal?']),
    triggers: randMessage(['What prompt do you want me to set up?'])
  },

  'ActionGatherFeedbackRating': {
    'default': randMessage(['Hey [[userFirstName]], How\'d [[targetUserFirstName]] do on: ' +
                '*[[targetUserGoal]]*']),
    hasMeetingTitle: randMessage(['Hey [[userFirstName]], looks like you have just wrapped up the *[[meetingName]]* ' +
                      'meeting with *[[targetUserFirstName]]* How\'d [[targetUserFirstName]] do on: ' +
                      '*[[targetUserGoal]]*'])
  },

  'ActionSummaryReport': {
    'noReport': randMessage(['Sorry, you haven\'t received any feedback yet.']),
    'noDirectReport': randMessage(['The team summary is a snapshot of feedback provided to your direct reports. ' +
                                    'It looks like you don’t have any direct reports set up yet. If you’d like to add ' +
                                    'some, type `add direct reports` now']),
    'hasNotCreateAGoal': randMessage(['It looks like you haven\'t created a goal yet.']),
    'directReportHasNotCreateAGoal': randMessage(['It looks like %s hasn\'t created a goal yet.']),
    'userIsNotFound': randMessage(['looks like "%s" has not joined our service. Feel free to pull up another summary.']),
    'statusIsNotValid': randMessage(['looks like you have entered a summary status that is not valid.']),
    'reviewerIsNotAdvisor': randMessage(['%s isn\'t currently reviewing you on any of your goals. If you’d like to add %s to an existing goal you can edit your goals, or create a new goal']),
    'userIsNotYourDirectReport': randMessage(['Sorry, only %s’s manager can see that feedback summary'])
  },

  'ActionSummaryOkrReport': {
    'noReport': randMessage(['Sorry, you haven\'t completed any OKR assessments yet']),
    'noDirectReport': randMessage(['The team summary is a snapshot of update provided from your direct reports. ' +
                                    'It looks like you don’t have any direct reports set up yet. If you’d like to add ' +
                                    'some, type `add direct reports` now']),
    'hasNotCreateAGoal': randMessage(['It looks like you don’t have any OKR’s set up yet']),
    'directReportHasNotCreateAGoal': randMessage(['It looks like %s hasn\'t create an OKR yet.']),
    'userIsNotFound': randMessage(['looks like "%s" has not joined our service. Feel free to pull up another summary.']),
    'statusIsNotValid': randMessage(['looks like you have entered an update status that is not valid.']),
    'reviewerIsNotAdvisor': randMessage(['%s isn\'t currently reviewing you on any of your OKR. If you’d like to add %s to an existing ORK you can edit your ORKs, or create a new OKR']),
    'userIsNotYourDirectReport': randMessage(['Sorry, only %s’s manager can see that update summary'])
  },

  'ActionAddManager': {
    'success': placeholderMessage('Awesome. I just added [[managerFirstName]] as your manager.'),
    'messageToManagerNotSignedUp': placeholderMessage('Hi! [[employeeFirstName]] just added you as a manager on CareerLark. We\'ll be ' +
                                    'prompting you periodically for some lightweight feedback once [[employeeFirstName]] ' +
                                    'has set up some goals.' +
                                    '\n' +
                                    'I can help you give lightweight feedback to your other direct reports as well on areas that they want to grow in. ' +
                                    'Let’s get the rest of your reports set up. Can you tell me their slack names?'),

    'messageToManagerAlreadySetup': placeholderMessage('[[employeeFirstName]] just added you as a manager. You can now see [[employeeFirstName]]\'s goals and feedback')
  },

  'ActionDeleteGoal': {
    'noGoal': 'It looks you haven\'t don\'t have any goals set up yet. Do that first and then you can delete them if you really want :wink:'
  },

  'ValidationGatherUser': {
    'userIsNotFound': randMessage(['%s is not found. Can you try another person?'])
  },

  ValidationGatherUserFromSlack: {
    'userIsNotFound': randMessage(['%s is not found on your Slack team. Please re-enter.'])
  },


  Hello: randMessage(['Hello!', 'Hi!']),

  Error: randMessage(['Oh no! Something is broken. :disappointed: Please try again', 'This is embarrassing. :slightly_frowning_face: Something is broken please try again.']),

  BackError: randMessage(['Hmm, looks like I can\'t go back. Sorry about that! :slightly_frowning_face:']),

  NotUnderstoodCommand: 'Sorry, I didn\'t quite understand that. Try typing `help` for a list of things I can help with',

  Cancel: randMessage(['Ok']),
  CancelError: randMessage(['There\'s nothing to cancel! Type `help` to see a list of things you can do']),

  Help: 'Help is on the way! \n\n'+

        '*General* \n' +
        '`cancel`: cancels you out of the current task \n' +
        '`view my profile`: see your job function, manager, direct reports, and goals \n' +
        '`request feedback`: request feedback from someone on a particular goal \n\n' +

        '*Update goals* \n' +
        '`add goal`: set up new goals with associated reviewers and feedback prompts \n' +
        '`delete goal`: delete a goal from your records. Note: If a goal has already received feedback, it can no longer be deleted\n' +
        '`archive goal` : stop prompting for feedback for a particular goal. You will still be able to see prior feedback \n\n' +
        //'`edit goal` : update feedback givers and prompts for any goal \n\n' +

        '*Update your manager* \n' +
        '`change manager` `to [@lauriel]` \n' +
        '`add manager` `[@richard]` \n\n' +

        '*Update your team (for managers)*  \n' +
        '`add direct report` `[@erlich]` : add to the group of people that you manage and give feedback to. You are able to see all feedback given to your direct reports \n' +
        '`phase out direct report` `[@erlich]` : take this person out of the group of people you manage and give feedback to \n\n' +

        '*Update your feedback receivers* \n' +
        '`take me off as reviewer` `[@dinsh]` : stop giving feedback for this person \n\n' +

        '*Feedback summaries* \n' +
        '`summary` : pull up feedback history. You can specify the following options: \n\n' +
        '`weekly` `monthly` \n\n' +
          //'`from [2/20] to [3/1]`: specify a time interval \n\n' +
        '`for [@gabe]` : get feedback history for a specific person \n' +
        '`for team` : get a feedback snapshot of the whole team (for managers) \n' +
        '`for me` : get your own feedback history \n\n' +
        '`from [@peter]` : get feedback history from a person \n\n' +
        '`archived` `active` : pull feedback history for specific types of goals',

  HelpOKR: 'Help is on the way! \n\n'+

          '*General* \n' +
          '`cancel`: cancels you out of the current task \n' +
          '`view my profile`: see your job function, manager, direct reports, and OKR\'s \n' +
          '`change self assessment time`: change the time at which you are prompted for your self assessment \n\n' +

          '*OKR update summaries* \n' +
          '`summary` : pull up update history. You can specify the following options:\n\n' +

          '`for [@gabe]` : get update history for a specific person (for managers) \n' +
          '`for team` : get a snapshot of the whole team (for managers) \n' +
          '`for me` : get your own update history'
};