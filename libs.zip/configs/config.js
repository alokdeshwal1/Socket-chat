const env = process.env.NODE_ENV || 'development';
const path = require('path');
const dirname = __dirname.split(path.sep);
const configs = {
  'global': {
    'appName': 'CareerLark',
    'baseUrl': process.env.WEB_APPLICATION_URL,
    'rootPath': dirname.pop() && dirname.join(path.sep),
    'passwordLength': 10,
    'confirmationCodeLength': 15,
    'sessionSecret': process.env.SESSION_SECRET,
    'webApplicationUrl': process.env.WEB_APPLICATION_URL,
    'mongoUrl': process.env.MONGOLAB_URI,
    'redisUrl': process.env.REDIS_URL,
    'rabbitUrl': process.env.CLOUDAMQP_URL,
    'concurrency': parseInt(process.env.CONCURRENCY) || 1,               // Number of Cluster processes to fork in Server
    'workerConcurrency': parseInt(process.env.WORKER_CONCURRENCY) || 1,  // Number of Cluster processes to fork in Worker
    'botConcurrency': parseInt(process.env.BOT_CONCURRENCY) || 1,        // Number of Cluster processes to fork in Bot
    'thrifty': Boolean(process.env.THRIFTY) || false,                    // Web process also executes job queue?
    'viewCache': Boolean(process.env.VIEW_CACHE) || true,                // Cache rendered views?
    'mongoCache': Boolean(process.env.MONGO_CACHE) || 10000,             // LRU cache for mongo queries
    'botParser': {
      'confidenceTolerance': 0.5
    },
    'aws': {
      'access_key_id': process.env.AWS_ACCESS_KEY_ID,
      'secret': process.env.AWS_SECRET_ACCESS_KEY,
      'tableName': process.env.AWS_DYNAMODB_TABLE_NAME
    },
    'witAiApiKey': process.env.WITAI_API_KEY,
    'maxBotTasksPerChannel': 5,
    'feedbackRatingOptions': [
      {
        value: 1,
        emoji: ':disappointed:'
      },
      {
        value: 2,
        emoji: ':neutral_face:'
      },
      {
        value: 3,
        emoji: ':simple_smile:'
      },
      {
        value: 4,
        emoji: ':smile:'
      },
      {
        value: 5,
        emoji: ':joy:'
      }
    ],
    'botAttachmentMessageColor': {
      'feedback': '#36A64F',
      'action': '#DA552F',
      'others': '#3F2D4F'
    },
    'botReminderIntervalSec': 60*60*24,
    'botEmojiPostingWaitingSec': 10,
    'botEmojiDelay': 200,
    'selfAssessment': {
      'frequencyUserText': 'every other Friday at 10AM',
      'frequencyCron': '0 10 * * 5',
      'frequencyModifier': 'every other',
      'frequencyStartDate': '2016-05-16T22:12:29+00:00'
    },
    'google': {
      'clientId': process.env.GOOGLE_OAUTH_CLIENT_ID,
      'clientSecret': process.env.GOOGLE_OAUTH_CLIENT_SECRET,
      'apiKey': process.env.GOOGLE_API_KEY,
      'renewPushNotificationAfter': 10*60*1000, // in milliseconds
      //'renewPushNotificationAfter':  20 *24* 60*60*1000, // in milliseconds
      'calendar': {
        resourceUrl: 'https://www.googleapis.com/calendar/v3/calendars/primary/events/watch',
        unwatchResourceUrl: 'https://www.googleapis.com/calendar/v3/channels/stop',
        watchUrl: 'https://api.careerlark.com/v1/google/watch/calendar'
      },
      'gmail': {
        pubSubTopic: 'gmailPushNotification',
        resourceUrl: 'https://www.googleapis.com/gmail/v1/users/me/watch',
        watchUrl: 'https://api.careerlark.com/v1/google/watch/gmail'
      }
    },
    'integration': {
      'gmail': {
        access_type: 'offline',
        include_granted_scopes: true,
        scope: ['https://www.googleapis.com/auth/gmail.readonly']
      },
      'googleCalendar': {
        access_type: 'offline',
        include_granted_scopes: true,
        scope: ['https://www.googleapis.com/auth/calendar.readonly', 'https://www.googleapis.com/auth/userinfo.email']
      }
    }
  },
  'env:development': {
    'Mandrill': {
      'apiKey': 'n_hW7gXO9F4KVjxHxK-wNw'
    },
    'slack': {
      'clientId': process.env.SLACK_CLIENT_ID,
      'clientSecret': process.env.SLACK_CLIENT_SECRET,
      'token': process.env.SLACK_TOKEN,
      'botName': 'careerlark',
      'url' : {
        'oauthAccess': 'https://slack.com//api/oauth.access',
        'authTest': 'https://slack.com/api/auth.test',
        'usersInfo': 'https://slack.com/api/users.info',
        'rtmStart': 'https://slack.com/api/rtm.start'
      },
      'botEvents': [
        'hello',
        'message',
        'team_join',
        'user_change'
      ]
    },
    'googleProjectId': 'careerlark---dev-1252',
    'googleCloudCredentialFile': 'configs/gcloud-dev.json'
  },
  'env:trunk': {
    'Mandrill': {
      'apiKey': 'n_hW7gXO9F4KVjxHxK-wNw'
    },
    'slack': {
      'clientId': process.env.SLACK_CLIENT_ID,
      'clientSecret': process.env.SLACK_CLIENT_SECRET,
      'token': process.env.SLACK_TOKEN,
      'botName': 'careerlark-trunk',
      'url' : {
        'oauthAccess': 'https://slack.com//api/oauth.access',
        'authTest': 'https://slack.com/api/auth.test',
        'usersInfo': 'https://slack.com/api/users.info',
        'rtmStart': 'https://slack.com/api/rtm.start'
      },
      'botEvents': [
        'hello',
        'message',
        'team_join'
      ]
    },
    'googleProjectId': 'careerlark---dev-1252',
    'googleCloudCredentialFile': 'configs/gcloud-dev.json'
  },
  'env:staging': {
    'Mandrill': {
      'apiKey': 'n_hW7gXO9F4KVjxHxK-wNw'
    },
    'slack': {
      'clientId': process.env.SLACK_CLIENT_ID,
      'clientSecret': process.env.SLACK_CLIENT_SECRET,
      'token': process.env.SLACK_TOKEN,
      'botName': 'careerlark-staging',
      'url' : {
        'oauthAccess': 'https://slack.com//api/oauth.access',
        'authTest': 'https://slack.com/api/auth.test',
        'usersInfo': 'https://slack.com/api/users.info',
        'rtmStart': 'https://slack.com/api/rtm.start'
      },
      'botEvents': [
        'hello',
        'message',
        'team_join'
      ]
    },
    'googleProjectId': 'careerlark---dev-1252',
    'googleCloudCredentialFile': 'configs/gcloud-dev.json'
  },
  'env:production': {
    'Mandrill': {
      'apiKey': 'n_hW7gXO9F4KVjxHxK-wNw'
    },
    'slack': {
      'clientId': process.env.SLACK_CLIENT_ID,
      'clientSecret': process.env.SLACK_CLIENT_SECRET,
      'token': process.env.SLACK_TOKEN,
      'botName': 'careerlark',
      'url' : {
        'oauthAccess': 'https://slack.com//api/oauth.access',
        'authTest': 'https://slack.com/api/auth.test',
        'usersInfo': 'https://slack.com/api/users.info',
        'rtmStart': 'https://slack.com/api/rtm.start'
      },
      'botEvents': [
        'hello',
        'message',
        'team_join'
      ]
    },
    'googleProjectId': 'careerlark-1252',
    'googleCloudCredentialFile': 'configs/gcloud-prod.json'
  }
};

module.exports = Object.assign({}, configs.global, configs['env:'+ env]);
