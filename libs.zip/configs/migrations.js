const reload = require('require-reload')(require);
const path = require('path');
const dirApart = process.cwd().replace(require('./../configs/config').rootPath)
                              .split(path.sep)
                              .filter(item => {return item !== 'undefined'});
const prefix = dirApart.length > 0 ?
                  Array(dirApart.length).fill('..').join(path.sep) + path.sep :
                  '';
require('dotenv').config({path: `${prefix}.env`}); // load the environment variables
// overwrite the environment variable to local variable
process.env.MONGOLAB_URI = 'mongodb://localhost:27017/careerlark';
const Config = reload('./../configs/config');      // invalid the Config cache because it was loaded without env before
module.exports = {
  mongoAppDb : {
    connectionString: require('./config').mongoUrl
  }
};