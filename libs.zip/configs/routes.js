module.exports = function (router) {
  return router
    .post('/v1/slack/redirect', require('./../api/slack/redirect'))
    .post('/v1/slack/interactive-message', require('./../api/slack/interactive-message'))
    .post('/v1/google/redirect', require('./../api/google/redirect'))

    .post('/v1/google/watch/calendar', require('./../api/google/watch/calendar'))
    .post('/v1/google/watch/gmail', require('./../api/google/watch/gmail'))

    .post('/v1/slack/webhook', require('./../api/slack/webhook'))

    // this is for CodeShip to be able to verify that the app is app and running on Heroku
    .get('/', function *() {
      this.body = 'Hello! I am healthy and cute!';
    });
};
