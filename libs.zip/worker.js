const http = require('http');
const Logger = require('./libs/logger');
const throng = require('throng');
const Queue = require('./queue');
const Config = require('./configs/config');
const models = require('./models'); // preload all models so that there is no dependencies issues

http.globalAgent.maxSockets = Infinity;
throng(startJobQueue, { workers: Config.workerConcurrency });

function startJobQueue() {
  Logger.info('starting worker concurrency: %s', Config.concurrency);

  const queue = new Queue(Config, true /* start handling job */);
  queue.on('ready', beginWork);
  process.on('SIGTERM', shutdown);

  function beginWork() {
    queue.on('lost', shutdown);
    Logger.info('Worker Queue begin to work');
  }

  function shutdown() {
    Logger.info('Worker Queue shutting down');
    queue.stop();
    queue.disconnect();
    process.exit();
  }
}

