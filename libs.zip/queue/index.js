const Logger = require('./../libs/logger');
const EventEmitter = require('events').EventEmitter;
const CONSTANTS = require('./../constants/constants');
const assert = require('assert');
const Connections = require('./connections');
const Jobs = require('./jobs');
const uuid = require('node-uuid');

module.exports = Queue;

function Queue(config, handleJob) {
  EventEmitter.call(this);

  this.config = config;
  this.jobs = {};
  this.connections = Connections(config.redisUrl, config.rabbitUrl, config.mongoUrl);
  this.connections.once('ready', function() {
    this.onConnected.call(this, handleJob);
  }.bind(this));
  this.connections.once('lost', this.onLost.bind(this));
}
Queue.prototype = Object.create(EventEmitter.prototype);

Queue.prototype.onConnected = function(handleJob) {
  var queues = 0;
  var _this = this;
  var totalJobs = Object.keys(Jobs).length;

  for(var key in Jobs) {
    var job = new Jobs[key](_this.connections);
    (function(job) {
      job.create()
        .then(function(obj) {
          return handleJob ? obj.start() : true;
        })
        .then(function() {
          _this.jobs[job.queueName] = job;
          onCreate();
        })
        .catch(function(err) {
          Logger.error(__filename, '%s Queue failed to create job %j', job.queueName, err);
        });
    })(job);
  }

  function onCreate() {
    if (++queues === totalJobs) _this.onReady();
  }
};

Queue.prototype.onReady = function() {
  Logger.info('Worker Queue is ready');
  this.emit('ready');
};

Queue.prototype.onLost = function() {
  Logger.error('Worker Queue is lost');
  this.emit('lost');
};

Queue.prototype.stop = function() {
  Object.keys(this.jobs).forEach(function(key) {
    this.jobs[key].stop();
  }.bind(this));

  return this;
};

Queue.prototype.disconnect = function() {
  this.connections.disconnect();
};

Queue.prototype.queueJob = function(queueName, job) {
  return new Promise((resolve, reject) => {
    this.connections.amqb.create(queueName, { prefetch: 5 }, (err) => {
      if (err) {
        Logger.error('failed to create amqb channel %s', queueName);
        return reject(err);
      }

      try {
        this.connections.amqb.publish(queueName, Object.assign({id: uuid.v1()}, job));
      }
      catch(ex) {
        return reject(ex);
      }

      return resolve(true);
    });
  });
};