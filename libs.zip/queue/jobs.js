const fs = require('fs');
const path = require('path');
const jobs = {};
const _ = require('lodash');

function walk(dir) {
  var results = [];
  var list = fs.readdirSync(dir);
  list.forEach(function(file) {
    file = path.join(dir, file);
    var stat = fs.statSync(file);
    if (stat && stat.isDirectory()) results = results.concat(walk(file));
    else results.push(file);
  });
  return results
}

walk(path.join(__dirname, 'jobs')).forEach(function(file) {
  var klass = require(file);
  if (klass.__proto__.name === 'Job') {
    jobs[klass.name] = klass;
  }
});

// only turn these jobs for now
const whiteList = ['JobSendEmail', 'JobSlackInstallation', 'JobSummaryReport', 'JobRenewPushNotification', 'JobSummaryOkrReport'];
if (whiteList && Array.isArray(whiteList), whiteList.length > 0) {
  var filteredList = {};
  whiteList.forEach((item) => {
    if (jobs[item]) {
      filteredList[item] = jobs[item];
    }
  });
}
module.exports = filteredList || jobs;
