const jackrabbit = require('jackrabbit');
const Logger = require('./../libs/logger');
const EventEmitter = require('events').EventEmitter;
const Config = require('../configs/config');
const Bluebird = require('bluebird');
const Redis = require('redis');
const uuid = require('node-uuid');
Bluebird.promisifyAll(Redis.RedisClient.prototype);
Bluebird.promisifyAll(Redis.Multi.prototype);

function Connector(redisUrl, rabbitUrl) {
  EventEmitter.call(this);

  const _this = this;
  var readyCount = 0;

  //this.redis = Redis.createClient(redisUrl, {no_ready_check: true});
  //this.redis
  //  .on('ready', function() {
  //    Logger.info('ready', { msg: 'ready', service: 'redis' });
  //    ready();
  //  })
  //  .on('error', function(err) {
  //    Logger.error(err, { msg: err, service: 'redis' });
  //    error(err);
  //  })
  //  .on('close', function(str) {
  //    Logger.error(str, { msg: 'closed', service: 'redis' });
  //  })
  //  .on('disconnected', function() {
  //    Logger.error('disconnected', { msg: 'disconnected', service: 'redis' });
  //    lost();
  //  });

  this.amqb = jackrabbit(rabbitUrl)
    .on('connected', function() {
      Logger.info('connected', { msg: 'connected', service: 'rabbitmq' });
      ready();
    })
    .on('error', function(err) {
      Logger.error(err, { msg: err, service: 'rabbitmq' });
      this.emit('error:queue', err);
    })
    .on('disconnected', function() {
      Logger.error('disconnected', { msg: 'disconnected', service: 'rabbitmq' });
      this.emit('disconnected:queue');
    });

  this.amqb.queueJob = function(queueName, job) {
    return new Promise((resolve, reject) => {
      this.create(queueName, { prefetch: 5 }, (err) => {
        if (err) {
          Logger.error('failed to create amqb channel %s', queueName);
          return reject(err);
        }

        try {
          this.publish(queueName, Object.assign({id: uuid.v1()}, job));
        }
        catch(ex) {
          return reject(ex);
        }

        return resolve(true);
      });
    });
  };

  this.disconnect = function() {
    this.redis.quit(); // no callback
    this.amqb.close(function() {
      Logger.log('Connections disconnected');
      this.emit('close');
    }.bind(this));
  };

  this.on('error:queue', reconnectQueue.bind(this));
  this.on('disconnected:queue', reconnectQueue.bind(this));

  function ready() {
    if (++readyCount === 1) {
      _this.emit('ready');
    }
  }

  function reconnectQueue() {
    setTimeout(() => {
      this.amqb = jackrabbit(rabbitUrl)
        .on('connected', function() {
          Logger.info('connected', { msg: 'connected', service: 'rabbitmq' });
        })
        .on('error', function(err) {
          Logger.error(err, { msg: err, service: 'rabbitmq' });
          this.emit('error:queue', err);
        })
        .on('disconnected', function() {
          Logger.error('disconnected', { msg: 'disconnected', service: 'rabbitmq' });
          this.emit('disconnected:queue');
        });
    }, 1000);
  }
}

Connector.prototype = Object.create(EventEmitter.prototype);

module.exports = function(redisUrl, rabbitUrl, mongoUrl) {
  return new Connector(redisUrl, rabbitUrl, mongoUrl);
};
