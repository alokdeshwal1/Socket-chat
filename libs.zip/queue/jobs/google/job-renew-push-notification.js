'use strict';

const Job = require('./../job');
const Helper = require('./../../../libs/helper');
const assert = require('assert');
const Co = require('co');
const Logger = require('./../../../libs/logger');
const CONSTANTS = require('./../../../constants/constants');
const GooglePushNotification = require('./../../../libs/google-push-notification');
const ModelPushNotification = require('./../../../models/google-push-notification');
const ModelUser = require('./../../../models/user');
const google = require('googleapis');
const gmail = google.gmail('v1');
const Bluebird = require('bluebird');
const Config = require('./../../../configs/config');
const OAuth2 = google.auth.OAuth2;
const oauth2Client = new OAuth2(Config.google.clientId, Config.google.clientSecret, Config.baseUrl + '/google/redirect');
const trim = require('trim');
const _ = require('lodash');
Bluebird.promisifyAll(gmail.users.messages);
Bluebird.promisifyAll(gmail.users.threads);
Bluebird.promisifyAll(gmail.users.watch);
Bluebird.promisifyAll(oauth2Client);

class JobRenewPushNotification extends Job {
  constructor(connections) {
    super('JobRenewPushNotification', connections);
  }

  validate(data) {
    assert(typeof data.googlePushNotificationId === 'string', 'googlePushNotificationId (string) is required');
  }

  queue(data) {
    const id = super.queue(data);
    this.connections.amqb.publish(this.queueName, Object.assign({id: id}, data));
    return Promise.resolve(id);
  }

  handle(job, ack) {
    super.handle(job, ack);
    return new Promise(function(resolve, reject) {
      Co(function *() {
        try {
          const pn = yield ModelPushNotification.findOne({ _id: job.googlePushNotificationId,
                                                            status: CONSTANTS.DB.STATUS.ACTIVE }).populate('user');

          if (pn && pn.user && pn.user.id) {
            const user = yield ModelUser.findOne({ _id: pn.user.id, status: CONSTANTS.DB.STATUS.ACTIVE });
            const pushNS = new GooglePushNotification(user.googleOauthToken, pn.resourceUri, user.id, pn.watchTriggerUri, pn.pubSubTopic);
            const newWatchInfo = yield pushNS.renew();
            if (newWatchInfo) {
              pn.watchInfo = newWatchInfo;
              yield pn.save();
            }
          }
          else {
            Logger.warn('push notification result has no user', pn);
          }

          resolve(true);
          ack();
        }
        catch(ex) {
          Logger.error('Failed to handle renew push notification job', ex, ex.stack);
          reject(ex);
          ack();
        }
      });
    });
  }
}

module.exports = JobRenewPushNotification;
