'use strict';

const Job = require('./job');
const Helper = require('./../../libs/helper');
const assert = require('assert');
const Logger = require('./../../libs/logger');

class JobSendEmail extends Job {
  constructor(connections) {
    super('JobSendEmail', connections);
  }

  validate(data) {
    assert(typeof data.toEmail === 'string', 'toEmail (string) is required');
    assert(typeof data.toName === 'string', 'toName (string) is required');
    assert(typeof data.fromEmail === 'string', 'fromEmail (string) is required');
    assert(typeof data.fromName === 'string', 'fromName (string) is required');
    assert(typeof data.html === 'string', 'html (string) is required');
    assert(typeof data.text === 'string', 'text (string) is required');
    assert(typeof data.subject === 'string', 'subject (string) is required');
  }

  queue(data) {
    const id = super.queue(data);
    this.connections.amqb.publish(this.queueName, Object.assign({id: id}, data));
    return Promise.resolve(id);
  }

  handle(job, ack) {
    super.handle(job, ack);
    Helper.sendEmail(job).then(function(status) {
      ack();
    });
  }
}

module.exports = JobSendEmail;
