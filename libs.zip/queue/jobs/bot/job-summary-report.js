'use strict';

const Job = require('./../job');
const Helper = require('./../../../bot/libs/helper');
const assert = require('assert');
const Co = require('co');
const Logger = require('./../../../libs/logger');
const CONSTANTS = require('./../../../constants/constants');
const _ = require('lodash');
const Config = require('./../../../configs/config');
const Bot = require('./../../../bot/bot');
const ModelSlackIntegration = require('./../../../models/slack-integration');
const ModelUser = require('./../../../models/user');
const ModelFeedback = require('./../../../models/feedback');
const ModelUserGoal = require('./../../../models/user-goal');
const moment = require('moment');
const pluralize = require('pluralize');
const ucfirst = require('ucfirst');
const Util = require('util');
const BotMessages = require('./../../../configs/bot-messages');
const Join = require('join-component');
const trim = require('trim');

class JobSummaryReport extends Job {
  constructor(connections) {
    super('JobSummaryReport', connections);
  }

  validate(data) {
    assert(typeof data.slackUserId === 'string', 'slackUserId (string) is required');
    assert(typeof data.summary === 'object', 'summary (object) is required');
  }

  queue(data) {
    const id = super.queue(data);
    this.connections.amqb.publish(this.queueName, Object.assign({id: id}, data));
    return Promise.resolve(id);
  }

  handle(job, ack) {
    super.handle(job, ack);
    return new Promise((resolve, reject) => {
      Co(function *() {
        try {
          ack && ack();
          const requester = yield ModelUser.findOne({slackUserId: job.slackUserId}).populate('company slackIntegration');
          if (! requester) {
            Logger.warn(this.queueName + ' is getting job that couldn\'t find requester', job);
            return resolve(false);
          }

          const startDate = moment(job.summary.startDate).utc().format();
          const endDate = moment(job.summary.endDate).utc().format();
          const slackBotQueueName = Helper.getBotQueueName(requester.slackIntegration.teamName,
              requester.slackIntegration.teamId);
          if (! (job.summary.startDate && job.summary.endDate)) {
            return resolve(false);
          }

          const summaryStatus = job.summary.status || CONSTANTS.DB.STATUS.ACTIVE;
          if ( ! _.invert(CONSTANTS.DB.STATUS)[summaryStatus]) {
            yield this._errorMessage(slackBotQueueName, requester.slackUserId,
              Util.format(BotMessages.ActionSummaryReport.statusIsNotValid()));
            return resolve(false);
          }

          var fromUser;
          if (job.summary.fromUser) {
            fromUser = yield this._findUser(job.summary.fromUser, requester.slackIntegration.id, requester.slackUserId);
            if( ! fromUser) {
              yield this._errorMessage(slackBotQueueName, requester.slackUserId,
                Util.format(BotMessages.ActionSummaryReport.userIsNotFound(), job.summary.fromUser));
              return resolve(false);
            }
          }

          // check and make sure fromUser is in fact an advisor from the user in any of his/her goals
          if (fromUser && fromUser instanceof ModelUser && ! job.summary.isTeamSummary) {
            var totalUserGoalFromUser = yield ModelUserGoal.count({ user: requester.id, advisors: fromUser.id, status: summaryStatus });
            if ( ! totalUserGoalFromUser) {
              yield this._errorMessage(slackBotQueueName, requester.slackUserId,
                Util.format(BotMessages.ActionSummaryReport.reviewerIsNotAdvisor(), fromUser.firstName, fromUser.firstName));

              return resolve(false);
            }
          }

          // check if user is a manager or not, if yes, and under these conditions, we default it to manager's view
          if (! job.summary.isTeamSummary && ! job.summary.user) {
            const directs = yield ModelUser.count({ manager: requester.id });
            if (directs > 0) {
              job.summary.isTeamSummary = true;
            }
          }

          // for team
          if (job.summary.isTeamSummary === true) {
            yield this._generateTeamSummaryReport(job, slackBotQueueName, requester, fromUser, startDate, endDate,
                                                  summaryStatus);
          }
          else {
            yield this._generateIndividualSummaryReport(job, slackBotQueueName, requester, fromUser, startDate, endDate,
                                                        summaryStatus);
          }

          return resolve(true);
        }
        catch(ex) {
          Logger.error('Job Summary Report failed', this.queueName, ex, ex.stack);
          return reject(ex);
        }
      }.bind(this));
    });
  }

  _errorMessage(queueName, slackUserId, message) {
    return this.connections.amqb.queueJob(queueName, {
            slackUserId: slackUserId,
            task: {
              name: 'SummaryReport',
              priority: 3,
              interactions: [
                {
                  type: 'ActionMessage',
                  message: message
                }
              ]
            }
          });
  }

  _queryFeedback(userGoalId, reportUser, fromUser, startDate, endDate, summaryStatus) {
    var query = ModelFeedback.find({
                  user: reportUser.id,
                  userGoal: userGoalId,
                  createdAt: {
                    '$gte': startDate,
                    '$lte': endDate
                  }
                })
                .populate('advisor')
                .sort('createdAt');

    if (summaryStatus && summaryStatus.length > 0) {
      query.where('status', summaryStatus)
    }
    else {
      query.where('status', CONSTANTS.DB.STATUS.ACTIVE)
    }

    if (fromUser && fromUser.id) {
      query.where('advisor', fromUser.id);
    }

    return query.exec();
  }

  _generateTeamSummaryReport(job, slackBotQueueName, requester, fromUser, startDate, endDate, summaryStatus) {
    return new Promise((resolve, reject) => {
      Co(function *() {
        try {
          // find a list of direct reports for the requester
          var directs = yield ModelUser.find({ manager: requester.id, status: CONSTANTS.DB.STATUS.ACTIVE })
                                        .populate('company').sort({ firstName: -1});
          if ( ! (directs && Array.isArray(directs) && directs.length > 0)) {
            yield this._errorMessage(slackBotQueueName, requester.slackUserId, BotMessages.ActionSummaryReport.noDirectReport());
            return resolve(true);
          }

          var teamAttachmentMessages = [];
          var totalTeamFeedback = 0;
          var totalTeamGivers = 0;
          for(var i = 0; i < directs.length; i++) {
            var direct = directs[i];
            var feedbackAndCount = yield this._getFeedbackAndCount(slackBotQueueName, requester, direct, fromUser,
              startDate, endDate, summaryStatus, true /* hide feedback message */);

            if (Number(feedbackAndCount.totalFeedback) > 0) {
              totalTeamFeedback += feedbackAndCount.totalFeedback;
            }
            if (Number(feedbackAndCount.totalGivers)) {
              totalTeamGivers += feedbackAndCount.totalGivers;
            }

            if (feedbackAndCount.attachmentMessages && feedbackAndCount.attachmentMessages.length > 0) {
              var allFields = [];
              feedbackAndCount.attachmentMessages.forEach(item => {
                allFields = allFields.concat(item.fields);
              });

              teamAttachmentMessages.push({
                'fallback': 'Feedback for '+ direct.firstName,
                'pretext': '*Feedback for '+ direct.firstName +'*',
                'color': Config.botAttachmentMessageColor.feedback,
                'mrkdwn_in': ['fields', 'pretext'],
                'fields': allFields
              });
            }
            else {
              teamAttachmentMessages.push({
                'fallback': 'Feedback for '+ direct.firstName,
                'pretext': '*Feedback for '+ direct.firstName +'*',
                'color': Config.botAttachmentMessageColor.feedback,
                'mrkdwn_in': ['fields', 'pretext'],
                'fields': [
                  {
                    value: '_No feedback received yet_'
                  }
                ]
              });
            }
          }

          var messageTitle = this._getReportTitle('team', startDate, endDate, totalTeamFeedback, totalTeamGivers, fromUser && fromUser.firstName, summaryStatus);
          yield this.connections.amqb.queueJob(slackBotQueueName, {
            slackUserId: requester.slackUserId,
            task: {
              name: 'SummaryReport',
              priority: 3,
              interactions: [
                {
                  type: 'ActionMessage',
                  message: messageTitle
                },
                {
                  type: 'ActionAttachmentMessage',
                  message: teamAttachmentMessages
                }
              ]
            }
          });
        }
        catch(ex) {
          Logger.error(__filename, 'Failed to generate team summary report', ex, ex.stack);
          return reject(ex);
        }

        return resolve(true);

      }.bind(this))
    });
  }

  _generateIndividualSummaryReport(job, slackBotQueueName, requester, fromUser, startDate, endDate, summaryStatus) {
    return new Promise((resolve, reject) => {
      Co(function *() {
        try {
          var reportUser = requester;
          var requesterIsAdvisor;
          var requesterAdvisorGoals;

          // does user supply the summary.user param?
          if (job.summary.user && job.summary.user.length > 0) {
            var specifiedUser = yield this._findUser(job.summary.user, requester.slackIntegration.id, requester.slackUserId);
            if(! specifiedUser) {
              yield this._errorMessage(slackBotQueueName, requester.slackUserId, Util.format(BotMessages.ActionSummaryReport.userIsNotFound(), job.summary.user));
              return resolve(true);
            }

            // check whether requester is actually a reviewer for specified user
            requesterIsAdvisor = false;
            requesterAdvisorGoals = yield ModelUserGoal.find({ user: specifiedUser.id, advisors: requester.id, status: summaryStatus }).populate('goal');
            if (requesterAdvisorGoals.length > 0) {
              requesterIsAdvisor = true;
            }

            if ((! specifiedUser.manager || specifiedUser.manager && specifiedUser.manager.id !== requester.id) &&
                ! requesterIsAdvisor &&
                specifiedUser.id !== requester.id /* user request report for his/her self.*/) {
              yield this._errorMessage(slackBotQueueName, requester.slackUserId, Util.format(BotMessages.ActionSummaryReport.userIsNotYourDirectReport(), specifiedUser.firstName));
              return resolve(true);
            }

            reportUser = specifiedUser;
          }

          var feedbackAndCount = yield this._getFeedbackAndCount(slackBotQueueName, requester, reportUser, fromUser,
                                                                startDate, endDate, summaryStatus, false /* show feedback message */, requesterAdvisorGoals);
          var attachmentMessages = feedbackAndCount.attachmentMessages;
          var totalFeedback = feedbackAndCount.totalFeedback;
          var totalGivers = feedbackAndCount.totalGivers;

          if (attachmentMessages.length < 1) {
            if (specifiedUser && specifiedUser.id && specifiedUser.id !== requester.id) { // manager request someone's report
              this._errorMessage(slackBotQueueName, requester.slackUserId, Util.format(BotMessages.ActionSummaryReport.directReportHasNotCreateAGoal(), specifiedUser.firstName));
            }
            else {
              this._errorMessage(slackBotQueueName, requester.slackUserId, BotMessages.ActionSummaryReport.hasNotCreateAGoal());
            }
          }
          else {
            var messageTitle = this._getReportTitle(reportUser.firstName, startDate, endDate, totalFeedback, totalGivers, fromUser && fromUser.firstName, summaryStatus, {
                                  requesterIsAdvisor: requesterIsAdvisor,
                                  requesterAdvisorGoals: requesterAdvisorGoals
                                });
            yield this.connections.amqb.queueJob(slackBotQueueName, {
              slackUserId: requester.slackUserId,
              task: {
                name: 'SummaryReport',
                priority: 3,
                interactions: [
                  {
                    type: 'ActionMessage',
                    message: messageTitle
                  },
                  {
                    type: 'ActionAttachmentMessage',
                    message: attachmentMessages
                  }
                ]
              }
            });
          }
        }
        catch (ex) {
          Logger.error(__filename, 'Failed to generate indivual summary report', ex, ex.statck);
          return reject(ex);
        }

        return resolve(true);
      }.bind(this))
    });
  }

  _getFeedbackAndCount(slackBotQueueName, requester, reportUser, fromUser, startDate, endDate, summaryStatus, hideFeedbackMessage, specifiedGoals) {
    assert(typeof reportUser === 'object', 'reportUser (object) is required');
    return new Promise((resolve, reject) => {
      Co(function *() {

        // get list of user's goals
        var userGoals;
        if (specifiedGoals && Array.isArray(specifiedGoals) && specifiedGoals.length > 0) {
          userGoals = specifiedGoals;
        }
        else {
          userGoals = yield ModelUserGoal.find({ user: reportUser.id, status: summaryStatus }).populate('goal').sort({ createdAt: -1 });
        }
        userGoals = _.sortBy(userGoals, item => {
          return (item.isGeneral) ? -1 : item.createdAt;
        });

        if (! (userGoals && Array.isArray(userGoals))) {
          yield this._errorMessage(slackBotQueueName, requester.slackUserId, BotMessages.ActionSummaryReport.hasNotCreateAGoal());
          return resolve(true);
        }

        var attachmentMessages = [];
        var totalFeedback = 0;
        var givers = [];
        for(var i = 0; i < userGoals.length; i++) {
          var feedbacks = yield this._queryFeedback(userGoals[i].id, reportUser, fromUser, startDate, endDate, summaryStatus);
          givers = givers.concat(_.pluck(feedbacks, 'advisor.id'));
          var goalTitle = userGoals[i].goal && userGoals[i].goal.name || userGoals[i].name;
          totalFeedback = totalFeedback + feedbacks.length;
          var field;
          if (userGoals[i].isGeneral === true) {
            field = Helper.buildSummaryReportGeneralField(goalTitle, feedbacks, hideFeedbackMessage);
          }
          else {
            field = Helper.buildSummaryReportField(goalTitle, feedbacks, hideFeedbackMessage);
          }
          if (field) {
            attachmentMessages.push(field);
          }
        }
        var totalGivers = _.uniq(givers).length;

        return resolve({
          attachmentMessages: attachmentMessages,
          totalGivers: totalGivers,
          totalFeedback: totalFeedback
        });

      }.bind(this));
    });
  }

  *_findUser(inputUserString, slackIntegrationId, requesterSlackUserId) {
    try {
      var user;

      // fix for summary for me or summary for i
      inputUserString = trim(inputUserString.toLowerCase());
      if (inputUserString === 'me' || inputUserString === 'i') {
        user = yield ModelUser.findOne({
          slackUserId: requesterSlackUserId,
          slackIntegration: slackIntegrationId,
          status: CONSTANTS.DB.STATUS.ACTIVE
        }).populate('manager');
      }
      else if (inputUserString.indexOf('<') === 0) {
        var userSlackId = /<@([a-zA-Z0-9.\-_]*)>/ig.exec(inputUserString);
        if (Array.isArray(userSlackId) && userSlackId[1]) {
          user = yield ModelUser.findOne({
            slackUserId: userSlackId[1].toUpperCase(),
            slackIntegration: slackIntegrationId,
            status: CONSTANTS.DB.STATUS.ACTIVE
          }).populate('manager');
        }
      }
      else {
        user = yield ModelUser.findOne({
          slackUserNameLower: inputUserString.toLowerCase(),
          slackIntegration: slackIntegrationId,
          status: CONSTANTS.DB.STATUS.ACTIVE
        }).populate('manager');
      }

      if ( ! user) {
        user = yield ModelUser.findOne({
          slackUserId: inputUserString.toUpperCase(),
          slackIntegration: slackIntegrationId,
          status: CONSTANTS.DB.STATUS.ACTIVE
        }).populate('manager');
      }

      return user;
    }
    catch (ex) {
      Logger.error('Failed to execute _findUser', ex, ex.stack);
    }
  }

  _getReportTitle(name, startDate, endDate, totalFeedback, totalGivers, fromUserFirstName, summaryStatus, requesterAdvisorInfo) {
    var stringFromDate = moment(startDate).format('M/D');
    var stringToDate = moment(endDate).format('M/D');
    var messageTitle;
    if (stringFromDate === stringToDate) {
      messageTitle = Util.format('*Feedback for %s %s*\n*%s* %s from *%s* %s', name,
        'Today', totalFeedback,
        pluralize('response', totalFeedback), totalGivers, pluralize('giver', totalGivers));
    }
    else if (fromUserFirstName) {
      messageTitle = Util.format('*Feedback for %s (%s-%s)*\n*%s* %s from *%s*', name,
        stringFromDate, stringToDate, totalFeedback,
        pluralize('response', totalFeedback), fromUserFirstName);
    }
    else {
      messageTitle = Util.format('*Feedback for %s (%s-%s)*\n*%s* %s from *%s* %s', name,
        stringFromDate, stringToDate, totalFeedback,
        pluralize('response', totalFeedback), totalGivers, pluralize('giver', totalGivers));
    }

    if (summaryStatus && summaryStatus !== CONSTANTS.DB.STATUS.ACTIVE) {
      messageTitle = '*'+ ucfirst(summaryStatus) +'* '+ messageTitle;
    }

    if (requesterAdvisorInfo && requesterAdvisorInfo.requesterIsAdvisor && requesterAdvisorInfo.requesterAdvisorGoals) {
      var goalNames = requesterAdvisorInfo.requesterAdvisorGoals.map(item => {
        return item.name || item.goal && item.goal.name;
      });

      messageTitle = Util.format('You\'re a reviewer for %s on %s. Here\'s a summary of the feedback you’ve given\n',
                                  name, Join(goalNames, ', and')) + messageTitle;
    }

    return messageTitle;
  }


}

module.exports = JobSummaryReport;
