'use strict';

const assert = require('assert');
const Errors = require('./../../libs/errors');
const Logger = require('./../../libs/logger');
const uuid = require('node-uuid');

class Job {
  constructor(queueName, connections) {
    assert(typeof queueName === 'string', 'Queue name (String) is required');
    assert(typeof connections === 'object', 'Connections (Object) is required');

    this.queueName = queueName;
    this.connections = connections;
  }

  create() {
    var _this = this;
    return new Promise(function(resolve, reject) {
      _this.connections.amqb.create(_this.queueName, { prefetch: 5 }, function(err) {
        Logger.info('creating amqb channel %s', _this.queueName);
        if (err) {
          Logger.error('failed to create amqb channel %s', _this.queueName);
          return reject(err);
        }
        resolve(_this);
      });
    });
  }

  start() {
    try {
      Logger.info('start %s amqb', this.queueName);
      this.connections.amqb.handle(this.queueName, this.handle.bind(this));
    }
    catch (ex) {
      Logger.error('failed to start amqb %s', this.queueName);
      throw new Errors.AmqpFailedToStart();
    }

    return Promise.resolve(this);
  }

  destroy(cb) {
    this.connections.amqb.destroy(this.queueName, cb);
  }

  stop() {
    this.connections.amqb.ignore(this.queueName);
  }

  queue(data) {
    assert(typeof data === 'object', 'Data is not defined');
    Logger.info('queuing %s job: %j', this.queueName, data);
    this.validate(data);
    return uuid.v1();
  }

  handle(job, ack) {
    Logger.info('processing %s job: %j', this.queueName, job);
    try {
      this.validate(job);
    }
    catch (ex) {
      ack && ack();
      Logger.error(__filename, 'Job failed validation', ex, ex.stack, job);
    }
  }
}

module.exports = Job;
