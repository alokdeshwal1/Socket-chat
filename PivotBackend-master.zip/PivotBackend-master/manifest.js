var Confidence = require('confidence');
var Config = require('./hapi-config');


var criteria = {
    env: process.env.NODE_ENV
};


var manifest = {
    $meta: 'This file defines the plot device.',
    server: {
        debug: {
            request: ['error']
        },
        connections: {
            routes: {
                security: true
            }
        },
      cache: [
        {
          name: 'redisCache',
          engine: require('./server/hapi-lib/catbox-redis.js'),
          host: Config.get('/redis/redisParsed/hostname'),
          port: Config.get('/redis/redisParsed/port'),
          password: Config.get('/redis/redisParsed/password'),
          database: Config.get('/redis/redisParsed/database'),
          redisClient: require('./server/plugins/pivot-redis.js').getRedisClient,
          partition: 'pvt-oc'
        }
      ]
    },
    connections: [{
        port: Config.get('/port/web'),
        labels: ['web']
    }],
    plugins: {
        'visionary': {
            engines:
              { jade: 'jade', 'html': 'handlebars',
                jsx: {
                  module: require('hapi-react-views'),
                  path: './aqua/server/web'
                }
              },
          path: './views',
          defaultExtension: 'jsx',
          path: './views',
          relativeTo: __dirname
        },
        './server/plugins/pivot-mongoose.js': { monkeyPatch: true },
        './server/plugins/pivot-redis.js': { },
        './server/plugins/nominatim.js': { },
        'hapi-auth-basic': {},
        'hapi-auth-bearer-token': {},
        './server/models': { },
        './server/plugins/pivot-pre.js': { },
        './server/auth.js': { },
        './server/api/index': { basePath: '/api' },
        './server/web/index': {},
/*      'hapi-swagger': {
        protocol: Config.get("/port/protocol"),
        apiVersion: require('./package').version,
        endpoint: '/swaggerdoc',
        pathPrefixSize: 3
      } */
  // Aqua
      'hapi-require-https': {},
      /*'mrhorse': {
       policyDirectory: __dirname + '/policies'
       },*/
      'yar': {cookieOptions: {password: Config.get("/cookieSecret")}},
      'hapi-auth-cookie': {},
      /*
       'crumb': {
       restful: true
       },
       'lout': {},
       */
      'visionary': {
        engines: {
          jsx: {
            module: require('hapi-react-views'),
            path: './aqua/server/web'
          },
          'html': 'handlebars'
        },
        /* Default must be jsx, as Aqua assume it */
        defaultExtension: 'jsx',
        path: './views',
        relativeTo: __dirname
      },
      'hapi-mongo-models': {
        mongodb: Config.get('/hapiMongoModels/mongodb'),
        models: {
          Account: './aqua/server/models/account',
          AdminGroup: './aqua/server/models/admin-group',
          Admin: './aqua/server/models/admin',
          AuthAttempt: './aqua/server/models/auth-attempt',
          Session: './aqua/server/models/session',
          Status: './aqua/server/models/status',
          User: './aqua/server/models/user'
        },
        autoIndex: Config.get('/hapiMongoModels/autoIndex')
      },
      './aqua/server/auth': {basePath: '/aqua'},
      './aqua/server/mailer': {basePath: '/aqua'},
      './aqua/server/api/accounts': {basePath: '/aqua/api'},
      './aqua/server/api/admin-groups': {basePath: '/aqua/api'},
      './aqua/server/api/admins': {basePath: '/aqua/api'},
      './aqua/server/api/auth-attempts': {basePath: '/aqua/api'},
      './aqua/server/api/contact': {basePath: '/aqua/api'},
      './aqua/server/api/index': {basePath: '/aqua/api'},
      './aqua/server/api/login': {basePath: '/aqua/api'},
      './aqua/server/api/logout': {basePath: '/aqua/api'},
      './aqua/server/api/sessions': {basePath: '/aqua/api'},
      './aqua/server/api/signup': {basePath: '/aqua/api'},
      './aqua/server/api/statuses': {basePath: '/aqua/api'},
      './aqua/server/api/users': {basePath: '/aqua/api'},
      './aqua/server/web/about': {basePath: '/aqua'},
      './aqua/server/web/account': {basePath: '/aqua'},
      './aqua/server/web/admin': {basePath: '/aqua'},
      './aqua/server/web/contact': {basePath: '/aqua'},
      './aqua/server/web/home': {basePath: '/aqua'},
      './aqua/server/web/login': {basePath: '/aqua'},
      './aqua/server/web/public': {basePath: '/aqua'},
      './aqua/server/web/signup': {basePath: '/aqua'},
      'hapi-swaggered': {
        stripPrefix: '/api/v1',
        host: Config.get("/port/host"),
        endpoint: '/swaggerdoc',
        info: {
          title: 'Pivot API',
          version: '0.0.1'
        }
      },
      'hapi-swaggered-ui': {
        title: 'Pivot API',
        path: '/api/doc'
      }
    }
};


var store = new Confidence.Store(manifest);


exports.get = function (key) {

    return store.get(key, criteria);
};


exports.meta = function (key) {

    return store.meta(key, criteria);
};
