global.Promise = require('bluebird');
Promise.longStackTraces();
var mongoose = require('mongoose');
mongoose.Promise = Promise;

var Composer = require('./index');
var Config = require('./hapi-config.js');

var elasticsearch = require('elasticsearch');

Composer(function (err, server) {

  server.app.esClient = new elasticsearch.Client({
    host: Config.get("/elasticsearch/url")
  });

  if (err) {
        throw err;
    }

  /*
  server.on('response', function (request) {
    if (request.payload && !request.payload._readableState)
      console.log('Request payload:', request.payload);
    if (request.params)
      console.log('Request Params: ', request.params);
    if (request.query)
      console.log('Request Query: ', request.query);
    //console.log('Response payload:', request.response.source);
  });
*/
  server.start(function () {
    console.log('Server running at:', server.info.uri);
  });
});
