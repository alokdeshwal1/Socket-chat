/**
 * Created by keary on 10/12/15.
 */
'user strict';
var recluster = require('recluster'),
  path = require('path');
var Config = require('./hapi-config.js');


var options = {
  workers: Config.get("/cluster/workers")
}
var cluster = recluster(path.join(__dirname, 'server.js'), options);
cluster.run();

process.on('SIGUSR2', function() {
  console.log('Got SIGUSR2, reloading cluster...');
  cluster.reload();
});

console.log("spawned cluster, kill -s SIGUSR2", process.pid, "to reload");
