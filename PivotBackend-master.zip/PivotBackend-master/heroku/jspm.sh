#!/bin/bash

echo configuring jspm
JSPM_CMD="node_modules/.bin/jspm"

npm install -g jspm-bower-endpoint

$JSPM_CMD registry create bower jspm-bower-endpoint


echo "github auth token: $GITHUB_AUTH_TOKEN"

$JSPM_CMD config registries.github.remote https://github.jspm.io
$JSPM_CMD config registries.github.auth $GITHUB_AUTH_TOKEN
$JSPM_CMD config registries.github.maxRepoSize 100
$JSPM_CMD config registries.github.handler jspm-github

$JSPM_CMD install
