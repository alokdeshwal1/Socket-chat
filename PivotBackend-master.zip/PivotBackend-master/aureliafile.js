/**
 * Created by keary on 9/1/15.
 */
var aurelia = require('aurelia-cli');

var config = {
  js: {
    "dist/app-bundle": {
      modules: [
        '*',
        'lib/*',
        'pivot/*',
        'aurelia-bootstrapper',
//        'aurelia-http-client',
        'aurelia-router',
        'aurelia-animator-css',
        'aurelia-http-client',
        'aurelia-templating-binding',
        'aurelia-templating-resources',
        'aurelia-templating-router',
        'aurelia-loader-default',
        'aurelia-history-browser',
        'paulvanbladel/aurelia-auth',
        'benib/aurelia-leaflet',
        'jquery',
        'leaflet',
        'lodash',
        'swagger-js',
	'aurelia-validation',
	'bootbox',
	'hgoebl/mobile-detect.js',
	'block-ui',
	'es6-promisify',
	'taye/interact.js',
	'moment'
      ],
      options: {
        inject: true,
        minify: false,
        mangle: false,
        sourceMaps: false
      }
    }
  },
  template: {
    "dist/app-bundle": {
      pattern: 'dist/**/*.html',
      options: {
        inject: true
      }
    }
  }
}
aurelia.command('bundle', config);
aurelia.command('unbundle', config);
