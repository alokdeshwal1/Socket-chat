var Confidence = require('confidence');


var criteria = {
    env: process.env.NODE_ENV
};

var mongoDbUrl = process.env.MONGODB_URI || process.env.MONGOLAB_URI;
var redisUrl = process.env.REDIS_URL || process.env.REDISCLOUD_URL;

var config = {
  $meta: 'This file configures the plot device.',
  projectName: 'pivot',

  port: {
    web: {
      $filter: 'env',
      test: 9000,
      production: process.env.PORT || 5000,
      $default: process.env.PORT || 5000
    },
    protocol: process.env.SITE_PROTOCOL || 'https',
    host: process.env.SITE_HOST || 'localhost'
  },
  baseUrl: {
    $filter: 'env',
    $meta: 'values should not end in "/"',
    production: process.env.SITE_PROTOCOL + "://" + process.env.SITE_HOST,
    $default: process.env.SITE_PROTOCOL + "://" + process.env.SITE_HOST
  },
  mongodb: {
    url: mongoDbUrl
  },
  authAttempts: {
    forIp: 50,
    forIpAndUser: 7
  },
  cookieSecret: {
    $filter: 'env',
    production: process.env.COOKIE_SECRET,
    $default: process.env.COOKIE_SECRET
  },
  hapiMongoModels: {
    $filter: 'env',
    production: {
      mongodb: {
        url: mongoDbUrl,
        options: {
          server: {
            auto_reconnect: true
          }
        }
      },
      autoIndex: false
    },
    test: {
      mongodb: {
        url: 'mongodb://localhost:27017/aqua-test'
      },
      autoIndex: true
    },
    $default: {
      mongodb: {
        url: process.env.MONGODB_URI || process.env.MONGOLAB_URI
      },
      autoIndex: true
    }
  },
  oauth: {
    accessTokenExpireSeconds: 60 * 60 * 24 * 7,
    jwtSecret: process.env.JWT_SECRET
  },
  "mapquest": {
      "consumerKey": process.env.MAPQUEST_CONSUMERKEY || "MJoFbRhyeIiuhqlEk18WrfxgcubGUXUI",
    "nominatimUrl": "https://open.mapquestapi.com/nominatim",
    /*
    osmTiles = {
      base: [
        {
          id: 'OSM Tiles',
          type: 'tile',
          url: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
          options: {
            attribution: '&copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors, <a href="http://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>'
          }
        }
      ],
      overlay: []
    }
    */
    tileProvider: {
      base: [
        {
          id: 'mqOSM Tiles',
          type: 'tile',
          url: 'https://otile{s}-s.mqcdn.com/tiles/1.0.0/{type}/{z}/{x}/{y}.png',
          options: {
            subdomains: '1234',
            type: 'osm',
            attribution: '&copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors, <a href="http://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>' + ', ' +
            'Tiles &copy; <a href="http://www.mapquest.com/" target="_blank">MapQuest</a> <img src="http://developer.mapquest.com/content/osm/mq_logo.png" />'
          }
        }
      ],
      overlay: []
    }
  },
  elasticsearch: {
    url: process.env.SEARCHBOX_URL
  },
  s3: {
    key: process.env.S3_KEY,
    secret: process.env.S3_SECRET,
    bucket: process.env.S3_BUCKET,
    prefix: process.env.S3_PREFIX,
    cloudfront: process.env.S3_CLOUDFRONT
  },
  redis: {
    redisUrl: redisUrl,
    redisParsed: redisUrl ? require("redis-url").parse(redisUrl) : undefined,
  },
  limits: {
    minSeperation: 10
  },
  cluster: {
    workers: process.env.WEB_CONCURRENCY || require('os').cpus().length
  },
  passwordResetTimeout: 2* 60 * 60 * 24, // 2 days,

};


var store = new Confidence.Store(config);


exports.get = function (key) {

    return store.get(key, criteria);
};


exports.meta = function (key) {

    return store.meta(key, criteria);
};
