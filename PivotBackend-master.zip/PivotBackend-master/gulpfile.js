// all gulp tasks are located in the ./build/tasks directory
// gulp configuration is in files in ./build directory
var requireDir = require('require-dir');
var gulp =  require('gulp');
// aqua
//global.inProduction = process.env.NODE_ENV === 'production';
//requireDir('./aqua/gulp');

// aurelia
requireDir('build/tasks');

gulp.task( 'build-aqua',  function () {
  return gulp.src( './aqua/gulpfile.js', { read: false } )
    .pipe( require('gulp-chug')({
      tasks:  [ 'build', 'media' ]
    } ));
});
