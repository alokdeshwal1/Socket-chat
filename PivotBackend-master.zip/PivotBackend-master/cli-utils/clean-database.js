/**
 * Created by keary on 8/17/15.
 */

//XLSX = require('xlsx');
var mongoose = require('mongoose');
var Config = require('../hapi-config.js');
var _ = require('lodash');
var Async = require('async');
var geo = require('../server/api/util/geo.js');
var Promise = require('bluebird');
var path = require('path');
var elasticsearch = require('elasticsearch');
var gsu = require('geojson-utils');

var server = {
  app: { }
};

server.app.esClient = new elasticsearch.Client({
  host: Config.get("/elasticsearch/url")
});

var models = { };

require('../server/models').register({
  expose: function(key, value) {
    models[key] = value;
  }
}, server, function() { });

var options = {
  server: {
    poolSize: 5,
    auto_reconnect: true,
    socketOptions: { keepAlive: 1 }
  },
  replset: {
    socketOptions: { keepAlive: 1 }
  }
};

function doClean() {

  mongoose.models['Location'].remove({}).then(function() {
    //return mongoose.models['Landmark'].remove({});
    return mongoose.models['Location'].collection.dropAllIndexes();
  }).then(function() {
    //return mongoose.models['Media'].remove({});
    return Promise.resolve();
  }).then(function() {
    return mongoose.models['TourStop'].remove({});
  }).then(function() {
    console.log('collection removed')
  });

  setTimeout(function() { process.exit(0); }, 1000);
  //process.exit(0);
}

var mapping = {
  "landmark": {
    "properties": {
      "name": {
        "type": "string"
      },
      "institution": {
        "type": "string"
      },
      "thumbnailUrl": {
        "type": "string",
        "include_in_all": false,
        "index": "no"
      },
      "description": {
        "type": "string",
        "include_in_all": false,
        "index": "no"
      },
      "shortDescription": {
        "type": "string",
        "include_in_all": false,
        "index": "no"
      },
      "locations": {
        "type": "object",
        "properties": {
          /*
          "name": {
            "type": "string",
            "include_in_all": false,
            "index": "no"
          },
          */
          "geo_latlon": {
            "type": "geo_point",
            "precision": "1km",
            "tree": "quadtree",
            "lat_lon": true
          }
        }
      }
    }
  }
}


function rebuildESIndex(indexName) {

  return new Promise(function(resolve, reject) {
    var settings = null;
    var typeName = 'landmark';
    server.app.esClient.indices.delete({index: indexName}, function() {

      server.app.esClient.indices.create({index: indexName, body: settings}, function (err) {
        if (err) {
          return reject(err);
        }

        server.app.esClient.indices.putMapping({
          index: indexName,
          type: typeName,
          body: mapping
        }, function(err) {
          if (err) {
            return reject(err);
          }
          return resolve();

        });
      });
    });
  });
}

return  mongoose.connect(Config.get("/mongodb/url"), options, function(err) {
  if (err) {
    console.error('Failed to connect to mongo on startup');
    process.exit(-1);
  }

  return rebuildESIndex('landmarks').then(function() {
    return rebuildESIndex('landmarks-edit');
  }).then(function() {
    doClean();

  }).then(null, function(err) {
    console.log(err);
    process.exit(-1);

  });


});
