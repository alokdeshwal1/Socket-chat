/**
 * Created by keary on 8/17/15.
 */

XLSX = require('xlsx');
var mongoose = require('mongoose');
var Config = require('../hapi-config.js');
var _ = require('lodash');
var Async = require('async');
var geo = require('../server/api/util/geo.js');
var Promise = require('bluebird');
var path = require('path');
var elasticsearch = require('elasticsearch');
var gsu = require('geojson-utils');

var server = {
  app: { }
};

server.app.esClient = new elasticsearch.Client({
  host: Config.get("/elasticsearch/url")
});

var models = { };

require('../server/models').register({
  expose: function(key, value) {
    models[key] = value;
  }
}, server, function() { });

var filename = '/Users/keary/S3Sync/public/sample-data.xlsx';

var options = {
  server: {
    poolSize: 5,
    auto_reconnect: true,
    socketOptions: { keepAlive: 1 }
  },
  replset: {
    socketOptions: { keepAlive: 1 }
  }
};

function trimArray(ar)
{
  var newAr = [ ];
  _.each(ar, function(a) {
    newAr.push(a.trim());
  })
  return newAr;

}
function commaToArray(str) {
  if (!str)
    return [];
  var parts = trimArray(str.split(','));
  parts = _.map(parts, function(str) {
    return str.trim();
  });
  parts = _.reject(parts, function(s) { return !s });
  return parts;
}

function toPoint(loc) {
  var pts = commaToArray(loc);
  if (!pts || pts.length != 2)
    return false;

  var lat = Number(pts[0]);
  var lon = Number(pts[1]);
  if (lat === NaN || lon === NaN)
    return false;

  if (lat < -90 || lat > 90)
    return false;
  if (lon < -180 || lon > 180)
    return false;

  return [lon, lat];

}

function toBearing(startLat,startLong,endLat,endLong){

  function radians(n) {
    return n * (Math.PI / 180);
  }
  function degrees(n) {
    return n * (180 / Math.PI);
  }

  startLat = radians(startLat);
  startLong = radians(startLong);
  endLat = radians(endLat);
  endLong = radians(endLong);


  var dLong = endLong - startLong;

  var dPhi = Math.log(Math.tan(endLat/2.0+Math.PI/4.0)/Math.tan(startLat/2.0+Math.PI/4.0));
  if (Math.abs(dLong) > Math.PI){
    if (dLong > 0.0)
      dLong = -(2.0 * Math.PI - dLong);
    else
      dLong = (2.0 * Math.PI + dLong);
  }

  return (degrees(Math.atan2(dLong, dPhi)) + 360.0) % 360.0;
}

function circleToPolygon(center, radius)
{
  var lng = center[0];
  var lat = center[1];
  var points = 16;

  var d2r = geo.d2r;   // degrees to radians
  var r2d = geo.r2d;   // radians to degrees
  var earthsradius = geo.earthsradius; // 3963 is the radius of the earth in meters

  radius = Number(radius);

  //var radius = 1;             // radius in miles

  // find the raidus in lat/lon
  var rlat = (radius / earthsradius) * r2d;
  var rlng = rlat / Math.cos(lat * d2r);

  var extp = new Array();
  for (var i=0; i < points+1; i++) // one extra here makes sure we connect the
  {
    var theta = Math.PI * (i / (points/2));
    var ex = lng + (rlng * Math.cos(theta)); // center a + radius x * cos(theta)
    var ey = lat + (rlat * Math.sin(theta)); // center b + radius y * sin(theta)
    extp.push([ex, ey]);
  }

  return extp;
}

function toLatLon(geoJson) {
  var pt;

  if (geoJson.type == 'Polygon')
    pt = gju.centroid(geoJson);
  else
    pt = geoJson;
  var latlon = {
    lat: pt.coordinates[1],
    lon: pt.coordinates[0]
  }
  return latlon;

}
function importOneMedia(media, done) {
  console.log("Media: " + media.landmark);
  if (!media.landmark || media.landmark.substr(0, 1) == '#')
    return done(new Error("No landmark for media"));

  var landmarks = media.landmark.split('|');
  landmarks = _.map(landmarks, function(landmark) {
    return landmark.trim();
  });
  var locations = (media.location || media.landmark).split('|');
  locations = _.map(locations, function(locations) {
    return locations.trim();
  });
  console.log("Locs", locations);

  /*
  if (!landmarks.length)
    return done(new Error("No landmark for media"));
  */

  var type = media.type || 'photo';
  var caption = media.caption || '';
  var description = media.description || '';

  var relevanceStartDate = media.datestart;
  var relevanceEndDate = media.dateend;

  var meta = { };
  if (media.dateTaken)
    meta.dateTaken = media.datetaken;

  var bearings = [ ];
  if (media.bearingtoreference)
    bearings = trimArray(media.bearingtoreference.split(','));
  var url = media.url;
  if (!url)
    return done(new Error("Media must have URL"));

  //var s3Url = 'https://d3thf8pek1godm.cloudfront.net/';
  //var s3Url =  'https://s3.amazonaws.com/com.unwiredappeal.pivot/'
  if (url.substr(0, 4) != 'http') {
    url = "s3://bucket.name/" + encodeURIComponent(url);
    //url =  s3Url + encodeURIComponent(url);
  }

  var parsedUrl = require('url').parse(url);
  //console.log(parsedUrl);
  var ext = path.extname(parsedUrl.pathname);
  var name = decodeURIComponent(path.basename(parsedUrl.pathname, ext));
  console.log(name);

  var Media = mongoose.models['Media'];
  var Landmark = mongoose.models['Landmark'];
  var Location = mongoose.models['Location'];

  Async.auto({
    media: function(done, results) {
      var mediaRecord = new Media();
      mediaRecord.type = type;
      mediaRecord.caption = caption.trim();
      mediaRecord.name = name;
      mediaRecord.description = description.trim();
      mediaRecord.relevanceStartDate = relevanceStartDate;
      mediaRecord.relevanceEndDate = relevanceEndDate;
      mediaRecord.url = url;
      mediaRecord.meta = meta;
      if (type == 'panorama' && bearings.length) {
        mediaRecord.panoramaInfo = {
          bearing: bearings[0]
        }
      } else if (type == 'augmented') {
        mediaRecord.arInfo = {
          bearing: bearings[0]
        }
      }
      return mediaRecord.save(function(err, mediaRecord){
        return done(err, mediaRecord);
      });
    },
    landmarks: function(done, results) {
      return Landmark.find({ 'name': { '$in': landmarks } }, function(err, landmarks) {
        return done(err, landmarks);
      });
    },
    locations: function(done, results) {
      return Location.find({ 'name': { '$in': locations } }, function(err, locations) {
        return done(err, locations);
      });
    },
    vantagePoint: function(done, results) {
      if (!media.vantagepoint)
        return done();
      return Location.findOne({ 'name': media.vantagepoint }, function(err, vantage) {
        return done(err, vantage);
      });
    },
    updateMediaRefs: [ 'vantagePoint', 'media', 'landmarks', 'locations', function(done, results) {
      //name: { type: String },
      //id: {type: [Schema.ObjectId], ref: 'Location'},
      //info: {
      //  bearingToReference: { type: Number }
      //}
      if (!results.landmarks.length && !results.locations.length)
        return done();
      var addLandmarks = _.map(results.landmarks, function(landmark, idx) {
        var info = { };
        if (type == 'photo' && bearings.length > idx)
          info.bearingToReferencePt = bearings[idx];
        return {
          id: landmark._id,
          name: landmark.name,
          info: info
        }
      });
      var addLocations = _.map(results.locations, function(loc) {
        { return { id: loc._id, name: loc.name, geo_latlon: toLatLon(loc.loc.geo_location) } };
      });
      console.log("locs", addLocations);
      var update = {
        '$push': {
          'landmarks': {
            '$each': addLandmarks
          },
          'locations': {
            '$each': addLocations
          }
        }
      };

      if (results.vantagePoint) {
        update['$set'] = {
          vantagePoint: {
            name: results.vantagePoint.name,
            id: results.vantagePoint._id,
            geo_location: results.vantagePoint.loc.geo_location

          }
        }
      }
      Media.findByIdAndUpdate(results.media._id, update, function(err, result) {
        return done(err);
      });

    }],
    updateLandmarkRefs: [ 'media', 'landmarks', function(done, results) {
      if (!results.landmarks.length)
        return done();

      var promises = _.map(results.landmarks, function(landmark) {
        var update = {
          '$push': {
            'media': {
              id: results.media._id,
              type: results.media.type,
              caption: results.media.caption
            }
          }
        }
        return Landmark.findByIdAndUpdate(landmark._id, update);
      });
      return Promise.all(promises).then(function() {
        return done();
      }, function(err) {
        return done(err);
      });

    }]
  }, function(err, results) {
    done();
  });
}

function importOneLocation(loc, done) {
  var name = loc.name.trim();
  if (!name || name.substr(0, 1) == '#') {
    console.log("Entry has no name -- skipping");
    return done(new Error("no_name"));
  }
  console.log("Importing: " + name);

  var types = commaToArray(loc.type);
  if (!types || !types.length) {
    console.log("  Error: Location must have at least one type");
    return done(new Error("no_type"));
  }

  var existingLocation = false;
  var pt = toPoint(loc.location);
  if (!pt) {
    if (loc.location) {
      existingLocation = loc.location;
    } else {
      console.log("   Error:  No location specified");
      return done(new Error("no_loc"));
    }
  }

  var radius = loc.boundary;

  var geoJson;
  var asEntered;
  if (radius) {
    var pts = trimArray(radius.split(','));
    if (pts.length == 1) {
      asEntered = {
        type: 'Circle',
        coordinates: pt,
        radius: radius
      }
      geoJson = {
        type: 'Polygon',
        coordinates: [circleToPolygon(pt, radius)]
      }
    } else if (pts.length == 4) {
      var nw = [pts[1], pts[0]];
      var se = [pts[3], pts[2]];
      geoJson = asEntered = {
        type: 'Polygon',
        coordinates: [ nw, [ nw[0], se[1] ], se, [ se[0], nw[1] ],  nw ]
      }
    } else
      return done(new Error("bad_boundary"));
  } else {
    geoJson = asEntered = {
      type: 'Point',
      coordinates: pt
    }
  }

  var bearing;
  var refPt = toPoint(loc.refdir);
  var ref;
  if (refPt) {
    ref = toBearing(pt[1], pt[0], refPt[1], refPt[0]);
  } else
    ref = loc.refdir;
  if (ref !== undefined) {
    ref = ref.toString().trim();
    ref = Number(ref);
    if (ref !== NaN && ref >= 0 && ref < 360)
      bearing = ref;
  }

  /*
  var caption;
  if (loc.caption)
    caption = loc.caption.trim();
  */

  var landmarks;

  if (loc.landmark)
    landmarks = loc.landmark.split('|');
  if (landmarks && landmarks.length == 0)
    landmarks = null;

  function trimLC(str) {
    if (!str)
      return undefined;
    return str.toString().trim(); // .toLowerCase();
  }

  var Location = mongoose.models['Location'];
  var Landmark = mongoose.models['Landmark'];

  Async.auto({
    location: function(done, results) {
      if (existingLocation) {
        return Location.findOne({ 'name': loc.location }, function(err, loc) {
          return done(err, loc);
        })
      } else {
        var locRecord = new Location();

        locRecord.name = name;
        //locRecord.type = types;
        /*
        if (bearing !== undefined)
          locRecord.referenceDir = bearing;
        */
        //locRecord.caption = caption || name;
        if (loc.street || loc.street2 || loc.city || loc.province || loc.postal) {
          locRecord.streetAddress = {
            street: trimLC(loc.street),
            street2: trimLC(loc.street2),
            city: trimLC(loc.city),
            province: trimLC(loc.province),
            postal: trimLC(loc.postal)
          }
        }
        //locRecord.description = loc.locdescription || loc.description;
        locRecord.loc = {
          asEntered: asEntered,
          geo_location: geoJson
        };

        return locRecord.save(function(err, locRecord) {
          return done(err, locRecord);
        })

      }
    },
    landmarks: function(done, results) {
      if (!landmarks && !_.contains(types, 'landmark'))
        return done(null, [ ]);

      // Create a fresh landmark
      if (!landmarks) {
        var landmarkRec = new Landmark();
        landmarkRec.name = name;
         if (bearing !== undefined)
           landmarkRec.referenceDir = bearing;
        landmarkRec.description = loc.description;
        landmarkRec.locations = [ ];
        return landmarkRec.save(function(err, landmark) {
          return done(err, [ landmark ]);
        });
      } else {
        // Find landmarks
        return Landmark.find({ 'name': { '$in': landmarks } }, function(err, landmarks) {
          return done(err, landmarks);
        });
      }
      return done(null, [ ]);
    },
    updateLocationRefs: ['location', 'landmarks', function(done, results) {
      if (!results.landmarks.length)
        return done();
      var addLandmarks = _.map(results.landmarks, function(landmark) {
        return {
          id: landmark._id,
          name: landmark.name,
        }
      });
      var update = {
        '$push': {
          'landmarks': {
            '$each': addLandmarks
          }
        }
      };
      Location.findByIdAndUpdate(results.location._id, update, function(err, result) {
        return done(err);
      });
    }],
    updateLandmarkRefs: ['location', 'landmarks', function(done, results) {
      if (!results.landmarks.length)
        return done();

      var promises = _.map(results.landmarks, function(landmark) {
        var update = {
          '$push': {
            'locations': {
              locationId: results.location._id,
              name: results.location.name,
              geo_latlon: toLatLon(results.location.loc.geo_location)
            }
          }
        }
        return Landmark.findByIdAndUpdate(landmark._id, update, { new: true });
      });
      return Promise.all(promises).then(function() {
        return done();
      }, function(err) {
        return done(err);
      });
    }]

  }, function(err, results) {
    if (err)
      console.log(err);
    else {
      console.log("ref loc: " + results.location._id);
      console.log("ref landmarks: " + _.map(results.landmarks, function(landmark) { return landmark._id }).join(','));
    }
    done();
  });
}

function importOneTourStop(tour, done, sheetDb) {
  var tourName = tour.tourname.trim();
  if (!tourName || tourName.substr(0, 1) == '#') {
    console.log("Entry has no tourName -- skipping");
    return done(new Error("no_name"));
  }

  var tourStopName = tour.tourstopname.trim();
  if (!tourStopName) {
    console.log("Entry has no tourStopName -- skipping");
    return done(new Error("no_name"));
  }

  var stopSequence = (tour.tourstopsequence || '').trim();

  if (!sheetDb.tourNames)
    sheetDb.tourNames = { };

  if (!sheetDb.tourNames[tourName])
    sheetDb.tourNames[tourName] = { };

  var tourId = mongoose.Types.ObjectId();
  if (sheetDb.tourNames[tourName].id)
    tourId = sheetDb.tourNames[tourName].id;
  else
    sheetDb.tourNames[tourName].id = tourId;


  console.log("Importing: " + tourName + "(" + tourId + "):" + tourStopName);

  var existingLocation = false;
  var pt = toPoint(tour.stoplocation);
  if (!pt) {
    if (tour.stoplocation) {
      existingLocation = tour.stoplocation;
    } else {
      console.log("   Error:  No location specified");
      return done(new Error("no_loc"));
    }
  }

  var geoJson;
  var asEntered;
  geoJson = asEntered = {
      type: 'Point',
      coordinates: pt
    }


  var refLocations= [ ];
  if (tour.referencedlocations)
    refLocations = tour.referencedlocations.split('|');
  if (refLocations.length == 0) {
    if (existingLocation)
      refLocations = [existingLocation];
  }

  var description = (tour.description || '').trim();
  var defaultModernPhoto = (tour.defaultmodernphoto || '').trim();
  var defaultHistoricalPhoto = (tour.defaulthistoricalphoto || '').trim();


  var Location = mongoose.models['Location'];
  var TourStop = mongoose.models['TourStop'];
  var Media = mongoose.models['Media'];

  Async.auto({
    location: function(done, results) {
      if (existingLocation) {
        return Location.findOne({ 'name': existingLocation }, function(err, loc) {
          return done(err, loc);
        })
      } else {
        var locRecord = new Location();

        locRecord.name =  tourStopName;
        //locRecord.type = [ 'tour' ];
        /*
         if (bearing !== undefined)
         locRecord.referenceDir = bearing;
         */
        //locRecord.caption = tourStopName;
        /*
        if (loc.street || loc.street2 || loc.city || loc.province || loc.postal) {
          locRecord.streetAddress = {
            street: trimLC(loc.street),
            street2: trimLC(loc.street2),
            city: trimLC(loc.city),
            province: trimLC(loc.province),
            postal: trimLC(loc.postal)
          }
        }
        */
        //locRecord.description = loc.locdescription || loc.description;
        locRecord.loc = {
          asEntered: asEntered,
          geo_location: geoJson
        };

        return locRecord.save(function(err, locRecord) {
          return done(err, locRecord);
        })

      }
    },
    refLocations: [ 'location', function(done, results) {
      if (!refLocations || refLocations.length == 0)
        return done([]);

      return Location.find({'name': { '$in': refLocations}}, function(err, locations) {
        return done(err, locations);
      })
    }],
    media: function(done, results) {
      var media = [ ];

      if (defaultHistoricalPhoto)
        media.push(defaultHistoricalPhoto);
      if (defaultModernPhoto)
        media.push(defaultModernPhoto);
//      console.log(media);

      return Media.find({'name': { '$in': media}}, function(err, medias) {
//        console.log(medias);
        return done(err, medias);
      })

    },
    tourStop: [ 'refLocations', 'location', function(done, results) {
      var stop = new TourStop();
      stop.tourName = tourName;
      stop.tourStopName = tourStopName;
      stop.tourId = tourId;
      stop.tourStopSequence = stopSequence;
      //institutionId: { type: String },
      if (defaultHistoricalPhoto) {
        var media = _.find(results.media, function(m) { return m.name == defaultHistoricalPhoto });
        if (media)
          stop.defaultHistoricalMedia = media._id;
      }
      if (defaultModernPhoto) {
        var media = _.find(results.media, function(m) { return m.name == defaultModernPhoto });
        if (media)
          stop.defaultModernMedia = media._id;
      }
      console.log(stop.defaultHistoricalMedia);
      console.log(stop.defaultModernMedia);

      stop.description = description;
      stop.locations = _.map(results.refLocations, function(loc) { return { id: loc._id, name: loc.name, geo_latlon: toLatLon(loc.loc.geo_location) } });
      stop.tourStopLocation = { id: results.location._id, name: results.location.name };
      return stop.save(function(err, tourStop) {
        return done(err, tourStop);
      })
    }],
    updateLocation: [ 'location', 'tourStop', function(done, results) {
      var update = {
        '$push': {
          'tourInfo': {
            //institutionId: tourStop.institutionId.toString(),
            tourStopId: results.tourStop._id,
            tourName: results.tourStop.tourName,
            tourId: results.tourStop.tourId,
            tourStopName: results.tourStop.tourStopName,
            tourStopSequence: results.tourStop.tourStopSequence
          },
          type: 'tour'
        }
      };

      Location.findByIdAndUpdate(results.location._id, update, function(err, result) {
        return done(err);
      });

    }]

  }, function(err, results) {
    if (err)
      console.log(err);
    else {
    }
    done();
  });


}

function setDefaultPhotos(done) {
  models.Landmark.mongooseModel.find({}, function(err, landmarks) {
    if (err) {
      console.log(err);
      done(err);
    }
    Async.eachSeries(landmarks, function(landmark, callback) {
      console.log("Setting default photo for: " + landmark.name) ;
      var mediaIds = _.map(landmark.media, function(media) {  return media.id });

      return mongoose.models.Media.find({ '_id': { '$in': mediaIds }}).then(function(media) {
        media = _.filter(media, function(m) { return m.type == 'photo'});
        media = _.sortBy(media, function(m) { return m.relevanceStartDate });

        if (!media.length)
          return Promise.resolve();
        var historicalMedia, currentMedia;

        if (media.length == 1) {
          if (media[0].relevanceStartDate < '1970')
            historicalMedia = media[0];
          else
            currentMedia = media[0];
        } else {
          var oldest = media[0];
          var newest = media[media.length-1];
          historicalMedia = oldest;
          currentMedia = newest;
        }

        var set = { };
        if (historicalMedia)
          set['defaultHistoricalMedia']  = historicalMedia._id;
        if (currentMedia)
          set['defaultModernMedia']  = currentMedia._id;

        var thumbnailMedia = (historicalMedia || currentMedia);
        if (thumbnailMedia)
          set['thumbnailUrl'] = thumbnailMedia.url;
        console.log(set);

        return models.Landmark.mongooseModel.findByIdAndUpdate(landmark._id, { '$set': set }, { new: true });

      }).then(function() {
        callback();
      })
    }, function(err) {
      console.log("Done setting default photos");
      done();
    });

  })

}

function importSheet(sheet, func, done) {
  var sheetJson = XLSX.utils.sheet_to_json(sheet);
  var sheetDb = { };
  Async.eachSeries(sheetJson, function(entry, cb) {
    func(_.transform(entry, function (result, val, key) {
      result[key.toLowerCase()] = val;
      }), function(err) {
        cb();
    }, sheetDb);
  }, done);
}

function runImport(filename) {
  console.log("Importing: " + filename);

  mongoose.models['Location'].remove({}).then(function() {
    return mongoose.models['Landmark'].remove({});
  }).then(function() {
    return mongoose.models['Media'].remove({});
  }).then(function() {
    return mongoose.models['TourStop'].remove({});
  }).then(function() {
      console.log('collection removed')
    var workbook = XLSX.readFile(filename);

    var sheets = _.map(workbook.Sheets, function(sheet, key) {
      return {
        name: key,
        sheet: sheet
      }
    });
    Async.eachSeries(sheets, function(sheet, done) {
      var type;

      var importFunc;
      if (sheet.name.substr(0, 3) == 'loc')
        importFunc = importOneLocation;
      else if (sheet.name.substr(0, 5) == 'media' || sheet.name.substr(0, 5) == 'photo') {
        importFunc = importOneMedia;
      } else if (sheet.name.substr(0, 4) == 'tour') {
        importFunc = importOneTourStop;
      }


      if (importFunc) {
        console.log("Importing: " + sheet.name);
        importSheet(sheet.sheet, importFunc, function () {
          console.log("Sheet done.");
          done();
        });
      } else
        return done();
    }, function() {
      setDefaultPhotos(function() { console.log("All Done."); setTimeout(function() {         process.exit(0);}, 500); });


      return;

      stream = models.Landmark.mongooseModel.synchronize()
        , count = 0;

      stream.on('data', function(err, doc){
        count++;
      });
      stream.on('close', function(){
        console.log('indexed ' + count + ' documents!');
        process.exit(0);
      });
      stream.on('error', function(err){
        console.log(err);
      });
    });
  });


  //process.exit(0);
}


return  mongoose.connect(Config.get("/mongodb/url"), options, function(err) {
  if (err) {
    console.error('Failed to connect to mongo on startup');
    process.exit(-1);
  }

  server.app.esClient.indices.delete({index: 'landmarks'}, function() {
    models.Landmark.createMappings(function(err, result) {
      console.log(err);
      console.log(result);
      runImport(filename);
    });
  });



});
