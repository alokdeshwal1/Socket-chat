/**
 * Created by keary on 8/17/15.
 */
"use strict";

//XLSX = require('xlsx');
var mongoose = require('mongoose');
var Config = require('../hapi-config.js');
var _ = require('lodash');
var Async = require('async');
var geo = require('../server/api/util/geo.js');
var Promise = require('bluebird');
var path = require('path');
var elasticsearch = require('elasticsearch');
var gsu = require('geojson-utils');
var http = require('http');
var knox = require('knox');

//var srcMongoUrl = 'mongodb://localhost:27017/pivot';
//var srcMediaPrefix = 'media/kg-local/';

var src = 'devel';
var dst = 'staging';

var cleanDestDb = true;

var config = {
  local: {
    bucket: 'com.unwiredappeal.pivot',
    mongoUrl: 'mongodb://localhost:27017/pivot',
    mediaPrefix: 'media/kg-local/',
    esPrefix: '',
    esUrl: 'http://127.0.0.1:9200',
    s3key: 'AKIAISXJKG3UK6OSQPSQ',
    s3secret: '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'
  },
  'local-test': {
    bucket: 'com.unwiredappeal.pivot',
    mongoUrl: 'mongodb://localhost:27017/test-pivot',
    mediaPrefix: 'media/keary-test/',
    esPrefix: 'test-',
    esUrl: 'http://127.0.0.1:9200',
    s3key: 'AKIAISXJKG3UK6OSQPSQ',
    s3secret: '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'
  },
  devel: {
    bucket: 'com.unwiredappeal.pivot',
    mongoUrl: 'mongodb://heroku_sbz22k5s:72raevjuqvarpddu4pi6op3ks3@ds051593-a1.mongolab.com:51593/heroku_sbz22k5s', // ,ds051593-a1.mongolab.com:51593/heroku_sbz22k5s?replicaSet=rs-ds051593',
    mediaPrefix: 'media/devel',
    esPrefix: '',
    esUrl: 'https://paas:96550baf69c3e0f1dcdb4529be48766b@fili-us-east-1.searchly.com',
    s3key: 'AKIAISXJKG3UK6OSQPSQ',
    s3secret: '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'
  },
  staging: {
    bucket: 'com.pivottheworld.pivotcms',
    mongoUrl: 'mongodb://heroku_p8p378r7:m2baig8t5j1urm2mfsr2gh9cvu@ds045970.mongolab.com:45970/heroku_p8p378r7',
    mediaPrefix: 'media/staging/',
    esPrefix: '',
    esUrl: 'http://paas:0808b76ff10d7426f0b91a2282ff5c6f@fili-us-east-1.searchly.com',
    s3key: 'AKIAJHM3CLTP4SJDD5IA',
    s3secret: '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'
  },
  production: {
    bucket: 'com.pivottheworld.pivotcms',
    mongoUrl: 'mongodb://heroku_35l9bcf7:8dcu2vvsbqc5f1ln5msjc2dkok@ds033334-a0.mongolab.com:33334/heroku_35l9bcf7', // ,ds033334-a1.mongolab.com:33334/heroku_35l9bcf7?replicaSet=rs-ds033334',
    mediaPrefix: 'media/prod/',
    esPrefix: '',
    esUrl: 'http://paas:d00eaf00b1e963500e8db7465ccbf278@fili-us-east-1.searchly.com',
    s3key: 'AKIAJHM3CLTP4SJDD5IA',
    s3secret: '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'
  }
}

var srcBucket = config[src].bucket;
var srcMongoUrl = config[src].mongoUrl;
var srcMediaPrefix = config[src].mediaPrefix;

//var dstEsPrefix = 'test-';
//var destMediaPrefix = 'media/keary-test/';
//var destMongoUrl = 'mongodb://localhost:27017/test-pivot';
//var destESUrl = 'http://127.0.0.1:9200';
//var destS3Secret = 'y/VKZRsOVyZC01amwOs9y/XH9U7t9TdKjiNYi8wO';
//var destS3Key = 'AKIAISXJKG3UK6OSQPSQ';
var destBucket = config[dst].bucket;
var dstEsPrefix = config[dst].esPrefix;
var destMongoUrl = config[dst].mongoUrl;
var destMediaPrefix = config[dst].mediaPrefix;
var destESUrl = config[dst].esUrl;
var destS3Secret = config[dst].s3secret;
var destS3Key = config[dst].s3key;


console.log(destMediaPrefix);

var knoxClient = knox.createClient({
  key: destS3Key
  , secret: destS3Secret
  , bucket: destBucket
});

var currentDb;

var hapiMongoModel = require('hapi-mongo-models');
hapiMongoModel.BaseModel.connect = function(config, callback) {
  hapiMongoModel.BaseModel.db = currentDb;
  callback(null, hapiMongoModel.BaseModel.db);
};


var server = {
  app: { },
  plugins: { 'all': { } },
  after: function() { },
  expose: function(name, obj) {
    server.plugins['all'][name] = obj;
  }
};

server.app.esClient = new elasticsearch.Client({
  host: destESUrl
});

var models = { };

require('../server/models').register({
  expose: function(key, value) {
    models[key] = value;
  }
}, server, function() { });

var options = {
  server: {
    poolSize: 5,
    auto_reconnect: true,
    socketOptions: { keepAlive: 1 }
  },
  replset: {
    socketOptions: { keepAlive: 1 }
  }
};


function updateSearchIndex(indexName, landmark, rec, loc) {

  var typeName = 'landmark';
  return new Promise(function(resolve, reject) {
    if (rec.isDeleted)
      return resolve();
    var thumb;
    if (landmark.defaultInfoCard && landmark.defaultInfoCard.defaultMediaId) {
      var media = rec.media.id(landmark.defaultInfoCard.defaultMediaId);
      if (media) {
        thumb = (media.sizedUrls && media.sizedUrls.length) ?
          media.sizedUrls[0].url : media.url;
      }
    }
    var obj = {
      name: landmark.name,
      description: landmark.defaultInfoCard ? landmark.defaultInfoCard.description : '',
      shortDescription: landmark.shortDescription,
      thumbnailUrl: thumb,
      institution: loc.institution || 'pivot',
      locations: [{
        _id: loc._id.toString(),
        //name: rec.name,
        geo_latlon: rec.loc.geo_latlon
      }]
    }
    server.app.esClient.index({
      index: indexName,
      type: typeName,
      id: landmark._id.toString(),
      body: obj
    }, function (err) {
      if (err)
        return reject(err);
      else
        return resolve();
    });
  });
}
function doIndexLocations() {

  return new Promise(function(resolve, reject) {
    var stream = mongoose.models['Location'].find().stream();

    stream.on('data', function (location) {
      // Apply to edit index.
      return location.save().then(function(_location) {
        location = _location;
        var promises = [ ];
        _.each(location['edit'].landmarks, function(l) {
          promises.push(updateSearchIndex(dstEsPrefix + 'landmarks-edit', l, location['edit'], location));
        });
        return Promise.all(promises);
      }).then(function() {
        var promises = [];
        _.each(location['published'].landmarks, function (l) {
          promises.push(updateSearchIndex(dstEsPrefix + 'landmarks', l, location['published'], location));
        })
        return Promise.all(promises);
      });
    }).on('error', function (err) {
      return reject(err);
      // handle the error
    }).on('close', function () {
      console.log("Done index locations");
      return resolve();
      // the stream is closed
    });

  });
}

var mapping = {
  "landmark": {
    "properties": {
      "name": {
        "type": "string"
      },
      "institution": {
        "type": "string"
      },
      "thumbnailUrl": {
        "type": "string",
        "include_in_all": false,
        "index": "no"
      },
      "description": {
        "type": "string",
        "include_in_all": false,
        "index": "no"
      },
      "shortDescription": {
        "type": "string",
        "include_in_all": false,
        "index": "no"
      },
      "locations": {
        "type": "object",
        "properties": {
          /*
          "name": {
            "type": "string",
            "include_in_all": false,
            "index": "no"
          },
          */
          "geo_latlon": {
            "type": "geo_point",
            "precision": "1km",
            "tree": "quadtree",
            "lat_lon": true
          }
        }
      }
    }
  }
}


function rebuildESIndex(indexName) {

  return new Promise(function(resolve, reject) {
    var settings = null;
    var typeName = 'landmark';
    server.app.esClient.indices.delete({index: indexName}, function() {

      function c() {

        server.app.esClient.indices.create({index: indexName, body: settings}, function (err) {
          if (err) {
            return reject(err);
          }

          server.app.esClient.indices.putMapping({
            index: indexName,
            type: typeName,
            body: mapping
          }, function (err) {
            if (err) {
              return reject(err);
            }
            return resolve();

          });
        });
      }

      return setTimeout(c, 2000);
    });
  });
}

function writeDestRecords()
{
  var promises = [ ];
  _.each(mongoCollections, function(mg, name) {
    promises.push(new Promise(function(resolve, reject) {
      mg.collection.insert(mg.data, function(err) {
        if (err) {
          console.log("Err inserting into " + name);
          return reject(err);
        }
        else
          return resolve();
      });
    }));
  });
  return Promise.all(promises);
}

function clearDestDb() {
  if (!cleanDestDb)
    return Promise.resolve();

  console.log("ClearDestDb");

  /*
  function walk(currentDirPath, callback) {
    var fs = require('fs'), path = require('path');
    fs.readdirSync(currentDirPath).forEach(function(name) {
      var filePath = path.join(currentDirPath, name);
      var stat = fs.statSync(filePath);
      if (stat.isFile()) {
        callback(filePath, stat);
      } else if (stat.isDirectory()) {
        walk(filePath, callback);
      }
    });
  }
  */

  var deleteFuncs = [ ];
  var deleteIndexFuncs = [ ];
  var BaseModel = require('hapi-mongo-models').BaseModel;


  /*
  walk(path.join(__dirname, '../aqua/server/models'), function(filePath, stat) {
    var mod = require(filePath);
    if (mod._collection) {
      console.log("hapi model: " + mod._collection);
      deleteFuncs.push(mod.deleteMany.bind(mod, {}));
      deleteIndexFuncs.push(function(done) {
        var collection = BaseModel.db.collection(mod._collection);
        collection.dropIndexes(function(err) {

          return done();
        })
      })
    }
    else {
      //console.log(mod);
    }
  });
  */

  _.each(server.plugins.all, function(mod) {
    if (mod._collection) {
      deleteFuncs.push(mod.deleteMany.bind(mod, {}));
      deleteIndexFuncs.push(function(done) {
        var collection = BaseModel.db.collection(mod._collection);
        collection.dropIndexes(function(err) {

          return done();
        })
      })
    }
  });


  _.each(models, function(combinedModel) {
    var model = combinedModel.mongooseModel;
    if (model) {
      deleteFuncs.push(model.remove.bind(model, {}));
      deleteIndexFuncs.push(function (done) {
        model.collection.dropAllIndexes(function (err) {
          return done();
        })
      });
    }
  });

  console.log("Removing...");

  var promise = new Promise(function(resolve, reject) {
    Async.auto({
      /*connectHapiMongoModels: function (done) {

        BaseModel.connect({ url: Config.get("/mongodb/url") }, done);
      },
      connectMongoose: function(done) {
        return  mongoose.connect(Config.get("/mongodb/url"), { }, done);
      },*/
      clean: [/*'connectHapiMongoModels', 'connectMongoose', */function (done) {
        return Async.parallel(deleteFuncs, done);
      }],
      cleanIndexes: [ 'clean', function(done) {
        return Async.parallel(deleteIndexFuncs, done);
      }]
    }, function (err, results) {

      //mongoose.connection.close();
      //results.connectHapiMongoModels.close();
      if (err) {
        console.error('Failed to remove database collections.', err);
        return reject(err);
      } else {
        console.log("Removed!");
        return resolve(err);
      }
    });
  });

  return promise;

}
function writeDestDb() {
  //return Promise.resolve();
  return new Promise(function(resolve, reject) {
    if (mongoose.connection)
      mongoose.connection.replica = false;
    return  mongoose.connect(destMongoUrl, options, function(err) {
      if (err) {
        console.log("Couldn't connect to dest");
        return reject(err);
      }

      currentDb = mongoose.connection;
      hapiMongoModel.BaseModel.db = currentDb;

      if (err)
        return reject(err);

      return clearDestDb().then(function() {
        return writeDestRecords();
      }).then(function() {
        return rebuildESIndex(dstEsPrefix + 'landmarks');
      }).then(function() {
        return rebuildESIndex(dstEsPrefix + 'landmarks-edit');
      }).then(function() {
        return doIndexLocations();
      }).then(function() {
        mongoose.disconnect(function() {
          return resolve();
        });
      }, function(err) {
        return reject(err);
      });
    });
  });
}



function realUrl(url) {
  if (!url)
    return undefined;
  var parsedUrl = parse(url);
  if (parsedUrl.protocol == 'http:' || parsedUrl.protocol == 'https:')
    return url;

  if (parsedUrl.protocol == 's3:') {
    url = Config.get("/baseUrl") + "/storage/media/s3" + parsedUrl.pathname;
    return url;
  } else {
    return undefined;
  }
}

var s3UrlsToCopy = { };

function fixAndRecordUrl(url) {

  var parse = require('url').parse;


  if (!url || url.substr(0, 3) != 's3:')
    return url;

  var encSrcPrefix = encodeURIComponent(srcMediaPrefix);
  var encDstPrefix = encodeURIComponent(destMediaPrefix);

  var reg = new RegExp("s3://(.*)/" + encSrcPrefix + "([0-9a-fA-F]{24})");
  var dst = url.replace(reg, "s3://\$1/" + encDstPrefix + "\$2");

  reg = new RegExp("s3://(.*)/" + srcMediaPrefix + "([0-9a-fA-F]{24})");
  dst = dst.replace(reg, "s3://\$1/" + encDstPrefix + "\$2");

  reg = new RegExp("s3://[^/]*/(.*)");
  dst = dst.replace(reg, "s3://" + destBucket + "/\$1");


  var srcPath = parse(url).pathname;
  var dstPath = parse(dst).pathname;
  var srcUrl = 'http://s3.amazonaws.com/' + srcBucket  + srcPath;
  s3UrlsToCopy[srcUrl] = decodeURIComponent(dstPath);

  return dst;

};

var mongoCollections = { };
var copyCollections = [
  'accounts', 'users', 'admins', 'adminGroups',
  'locations', 'mediastorages'
];

function readSrcCollections() {

  var promises = [ ];
  _.each(copyCollections, function(name) {
    promises.push(new Promise(function(resolve, reject) {
      var obj = mongoCollections[name];
      obj.data = [ ];
      var stream = obj.collection.find().stream();

      stream.on('data', function (d) {
        //console.log("Got data", d);
        obj.data.push(d);
      }).on('error', function (err) {
        console.log("Err reading " + name + ":" + err);
        return reject(err);
        // handle the error
      }).on('end', function () {
        console.log("Done reading: " + name);
        return resolve();
        // the stream is closed
      });
    }));
  });

  console.log("Returning all promises");
  return Promise.all(promises).then(function() {
    // Fix records
    _.each(mongoCollections.mediastorages.data, function(ms) {
      var src = ms.path;
      var reg = new RegExp("^" + srcMediaPrefix + "([0-9a-fA-F]{24})");
      var dst = src.replace(reg, destMediaPrefix + "\$1");
      ms.path = dst;
      ms.bucket = destBucket;
      //console.log("changed " + src + " to " + ms.path);
    });

    _.each(mongoCollections.locations.data, function(location) {
      _.each(['edit', 'published'], function(type) {
        var obj = location[type];
        _.each(obj.media, function(media) {
          media.url = fixAndRecordUrl(media.url);
          _.each(media.sizedUrls, function(su) {
            su.url = fixAndRecordUrl(su.url);
          });
        });
      });
    });

    return Promise.resolve();
  })
}
function readSrcDb() {
  return new Promise(function(resolve, reject) {
    return  mongoose.connect(srcMongoUrl, options, function(err) {
      if (err) {
        console.log("Can't opens src db");
        return reject(err);
      }

      currentDb = mongoose.connection;
      hapiMongoModel.BaseModel.db = currentDb;

      _.each(server.plugins.all, function(mod) {
        if (mod._collection) {
          if (_.contains(copyCollections, mod._collection)) {
            mongoCollections[mod._collection] = {
              collection: hapiMongoModel.BaseModel.db.collection(mod._collection)
            }
          }
        }
      });

      _.each(models, function(combinedModel) {
        var model = combinedModel.mongooseModel;
        if (model) {
          if (_.contains(copyCollections, model.collection.name)) {
            mongoCollections[model.collection.name] = {
              collection: model.collection
            }
          }
        }
      });

      return readSrcCollections().then(function() {
        return Promise.resolve();
      }).then(function() {
        mongoose.disconnect(function() {
          return resolve();
        });
      }, function(err) {
        return reject(err);
      });
    });
  });
}


var checkUrlExists = function (Url, callback) {
  console.log("Checking url: " + Url)
  var http = require('http'),
    url = require('url');
  var options = {
    method: 'HEAD',
    host: url.parse(Url).host,
    port: 80,
    path: url.parse(Url).pathname
  };
  var req = http.request(options, function (r) {
    callback( r.statusCode== 200);});
  req.end();
}

function copyS3Records() {
  var promise = Promise.resolve();

  _.each(s3UrlsToCopy, function(pathname, url) {
    var dstUrl = 'http://s3.amazonaws.com/' + destBucket  + pathname;

    promise = promise.then(function() {
      return new Promise(function(resolve, reject) {
        checkUrlExists(dstUrl, function(exists) {
          if (exists)
            return resolve();
          console.log("Copying " + url + " to " + pathname);
          http.get(url, function(res){
            if (!res || res.statusCode != 200) {
              console.log("Failed to copy s3 url: " + url);
              return resolve();
            }
            var headers = {
              'Content-Length': res.headers['content-length']
              , 'Content-Type': res.headers['content-type']
            };
            knoxClient.putStream(res, pathname, headers, function(err, res){
              if (err) {
                console.log("S3 put failed for url: " + url);
                return resolve();
              }
              res.destroy();
              return resolve();
              // check `err`, then do `res.pipe(..)` or `res.resume()` or whatever.
            });
          });
        });

      });
    });
  });
  return promise;
}

function registerHapiMongoModels() {
  return new Promise(function(resolve, reject) {
    hapiMongoModel.register(server, {
      mongodb: true,
      models: {
        Account: '../aqua/server/models/account',
        AdminGroup: '../aqua/server/models/admin-group',
        Admin: '../aqua/server/models/admin',
        AuthAttempt: '../aqua/server/models/auth-attempt',
        Session: '../aqua/server/models/session',
        Status: '../aqua/server/models/status',
        User: '../aqua/server/models/user'
      },
      autoIndex: true
    }, function(err) {
      if (err)
        return reject(err);
      else
        return resolve(err);
    })
  });
}


return registerHapiMongoModels().then(function() {
  return readSrcDb();
}).then(function() {
    return writeDestDb();
}).then(function() {
    return copyS3Records();
}).then(function() {
    console.log("Finished.");
}).then(null, function(err) {
  console.log(err.stack);
    console.log("Error!", err);
});

