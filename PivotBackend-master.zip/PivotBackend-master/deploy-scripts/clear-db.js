#!/usr/bin/env node

var fs = require('fs');
var path = require('path');
var Async = require('async');
var Promptly = require('promptly');
var Mongodb = require('mongodb');
var Handlebars = require('handlebars');
var Config = require('./config.js');
var _ = require('lodash');
var mongoose = require('mongoose');

var models = { };

require('../server/models').register({
  expose: function(key, value) {
    models[key] = value;
  }
}, { }, function() { });

function walk(currentDirPath, callback) {
    var fs = require('fs'), path = require('path');
    fs.readdirSync(currentDirPath).forEach(function(name) {
        var filePath = path.join(currentDirPath, name);
        var stat = fs.statSync(filePath);
        if (stat.isFile()) {
            callback(filePath, stat);
        } else if (stat.isDirectory()) {
            walk(filePath, callback);
        }
    });
}

var deleteFuncs = [ ];
var deleteIndexFuncs = [ ];
var BaseModel = require('hapi-mongo-models').BaseModel;


walk(path.join(__dirname, '../aqua/server/models'), function(filePath, stat) {
    var mod = require(filePath);
    if (mod._collection) {
        deleteFuncs.push(mod.deleteMany.bind(mod, {}));
        deleteIndexFuncs.push(function(done) {
            var collection = BaseModel.db.collection(mod._collection);
            collection.dropIndexes(function(err) {

                return done();
            })
        })
    }
    else {
        //console.log(mod);
    }
});


_.each(models, function(combinedModel) {
  var model = combinedModel.mongooseModel;
  if (model) {
    deleteFuncs.push(model.remove.bind(model, {}));
    deleteIndexFuncs.push(function (done) {
      model.collection.dropAllIndexes(function (err) {
        return done();
      })
    });
  }
});

console.log("Removing...");

Async.auto({
    connectHapiMongoModels: function (done) {

        BaseModel.connect({ url: Config.get("/mongodb/url") }, done);
    },
    connectMongoose: function(done) {
        return  mongoose.connect(Config.get("/mongodb/url"), { }, done);
    },
    clean: ['connectHapiMongoModels', 'connectMongoose', function (done) {
         return Async.parallel(deleteFuncs, done);
    }],
    cleanIndexes: [ 'clean', function(done) {
        return Async.parallel(deleteIndexFuncs, done);
    }]
}, function (err, results) {

    mongoose.connection.close();
    results.connectHapiMongoModels.close();
    if (err) {
        console.error('Failed to remove database collections.', err);
    } else
        console.log("Removed!");
});
