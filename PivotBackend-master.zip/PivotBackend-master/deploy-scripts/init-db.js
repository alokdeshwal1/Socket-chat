#!/usr/bin/env node
var Fs = require('fs');
var Path = require('path');
var Async = require('async');
var Promptly = require('promptly');
var Mongodb = require('mongodb');
var Handlebars = require('handlebars');
var aquaConfig = require('./config.js');


var isDev = true;

if (process.env.SITE_HOST) {
    var type = (process.env.SITE_HOST).split('.')[0];
    isDev = (type != 'pivot');
}

var defaults = {
    rootEmail: 'keary@mindless.com',
    rootPassword: 'sundance',
    rootName: 'Keary Griffin',
    apiUser: isDev ? 'Pp4A9BN6pfXvIMPalA3noQkdfLon94Do' : '4p1xgDLFZ3y5JU1rFfol6K0M51NC26yn',
    apiPassword: isDev ? '3DTWgaGc1K25Fe2Vx9I7ZBwd7R5f3QTR' : 'o5v0LiX5NVb0tJ99PMFU7cXAA5tHAG6g'
};

defaults.apiEmail = defaults.apiUser + '@pivottheworld.com';

Async.auto({
    mongodbUrl: [function (done, results) {

	return done(null, aquaConfig.get('/hapiMongoModels/mongodb').url);
    }],
    testMongo: ['rootPassword', function (done, results) {

        Mongodb.MongoClient.connect(results.mongodbUrl, {}, function (err, db) {

            if (err) {
                console.error('Failed to connect to Mongodb.');
                return done(err);
           }

            db.close();
            done(null, true);
        });
    }],
    rootEmail: ['mongodbUrl', function (done, results) {
        /*
	console.log("MongoDB: " + results.mongodbUrl);
        Promptly.prompt('Root user email:', done);
        */
        return done(null, defaults.rootEmail);
    }],
    rootPassword: ['rootEmail', function (done, results) {
        /*
        Promptly.password('Root user password:', { default: null }, done);
        */
        return done(null, defaults.rootPassword);
    }],
    setupRootUser: ['rootPassword', function (done, results) {

        var BaseModel = require('hapi-mongo-models').BaseModel;
        var User = require('../aqua/server/models/user');
        var Admin = require('../aqua/server/models/admin');
        var AdminGroup = require('../aqua/server/models/admin-group');
        var Account = require('../aqua/server/models/account');

        Async.auto({
            connect: function (done) {

                BaseModel.connect({ url: results.mongodbUrl }, done);
            },
            clean: ['connect', function (done) {
		/*
                Async.parallel([
                    User.deleteMany.bind(User, {}),
                    Admin.deleteMany.bind(Admin, {}),
                    AdminGroup.deleteMany.bind(AdminGroup, {}),
                    Account.deleteMany.bind(Account, {})
                ], done); */
		return done(null, true);
            }],
            adminGroup: ['clean', function (done) {

                AdminGroup.create('Root', done);
            }],
            apiGroup: ['clean', function (done) {

                AdminGroup.create('Trusted API Group', done);
            }],
            admin: ['clean', function (done) {

                Admin.create('Root Admin', done);
            }],
            apiAdmin: ['clean', function (done) {

                Admin.create(defaults.apiUser, done);
            }],
            user: ['clean', function (done, dbResults) {

                User.create(results.rootEmail, results.rootPassword, results.rootEmail, done);
            }],
            account: ['clean', function (done, dbResults) {

                Account.create(defaults.rootName, done);
            }],
            apiUser: ['clean', function (done, dbResults) {

                User.create(defaults.apiUser, defaults.apiPassword, defaults.apiEmail, done);
            }],
            adminMembership: ['admin', 'adminGroup', function (done, dbResults) {

                var id = dbResults.admin._id.toString();
                var update = {
                    $set: {
                        groups: {
                            root: 'Root'
                        }
                    }
                };

                Admin.findByIdAndUpdate(id, update, done);
            }],
            apiMembership: ['apiAdmin', 'apiGroup', function (done, dbResults) {

                var id = dbResults.apiAdmin._id.toString();
                var update = {
                    $set: {
                        groups: {
                            'trusted-api-group': 'Trusted API Group'
                        }
                    }
                };

                Admin.findByIdAndUpdate(id, update, done);
            }],
            linkUser: ['admin', 'user', 'account', function (done, dbResults) {

                var id = dbResults.user._id.toString();
                var update = {
                    $set: {
                        'roles.admin': dbResults.admin._id.toString(),
                        'roles.account': dbResults.account._id.toString()
                    }
                };

                User.findByIdAndUpdate(id, update, done);
            }],
            linkAdmin: ['admin', 'user', function (done, dbResults) {

                var id = dbResults.admin._id.toString();
                var update = {
                    $set: {
                        userId: dbResults.user._id
                    }
                };

                Admin.findByIdAndUpdate(id, update, done);
            }],
            linkApiUser: ['apiAdmin', 'apiUser', function (done, dbResults) {

                var id = dbResults.apiUser._id.toString();
                var update = {
                    $set: {
                        'roles.admin': dbResults.apiAdmin._id.toString()
                    }
                };

                User.findByIdAndUpdate(id, update, done);
            }],
            linkApiAdmin: ['apiAdmin', 'apiUser', function (done, dbResults) {

                var id = dbResults.apiAdmin._id.toString();
                var update = {
                    $set: {
                        userId: dbResults.apiUser._id
                    }
                };

                Admin.findByIdAndUpdate(id, update, done);
            }],

            linkAccount: ['account', 'user', function (done, dbResults) {

                var id = dbResults.account._id.toString();
                var update = {
                    $set: {
                        userId: dbResults.user._id
                    }
                };

                Account.findByIdAndUpdate(id, update, done);
            }],
            rootGroupPermissions: ['adminGroup', function (done, dbResults) {

                var id = dbResults.adminGroup._id.toString();
                var update = {
                    $set: {
                        permissions: {
                            'root': true
                        }
                    }
                };

                AdminGroup.findByIdAndUpdate(id, update, done);
            }],
            apiGroupPermissions: ['apiGroup', function (done, dbResults) {

                var id = dbResults.apiGroup._id.toString();
                var update = {
                    $set: {
                        permissions: {
                            'api': true,
                            'trusted-api': true
                        }
                    }
                };

                AdminGroup.findByIdAndUpdate(id, update, done);
            }]

        }, function (err, dbResults) {

            if (err) {
                console.error('Failed to setup root user.');
                return done(err);
            }

            done(null, true);
        });
    }]
}, function (err, results) {

    if (err) {
        console.error('Setup failed.');
        console.error(err);
        return process.exit(1);
    }

    console.log('Setup complete.');
    process.exit(0);
});
