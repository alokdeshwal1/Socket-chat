var React = require('react/addons');
var ClassNames = require('classnames');


var Component = React.createClass({
    tabClass: function (tab) {

        return ClassNames({
            active: this.props.activeTab === tab
        });
    },
    render: function () {

        return (
            <div className="navbar navbar-default navbar-fixed-top">
                <div className="container">
                    <div className="navbar-header">
                        <a className="navbar-brand" href="/aqua/">
                            <img
                                className="navbar-logo"
                                src="/aqua/public/media/logo-square.png"
                            />
                            <span className="navbar-brand-label">Aqua</span>
                        </a>
                    </div>
                    <div className="navbar-collapse collapse">
                    {/*
                        <ul className="nav navbar-nav">
                            <li className={this.tabClass('home')}>
                                <a href="/aqua/">Home</a>
                            </li>
                            <li className={this.tabClass('about')}>
                                <a href="/aqua/about">About</a>
                            </li>
                            <li className={this.tabClass('signup')}>
                                <a href="/aqua/signup">Sign up</a>
                            </li>
                            <li className={this.tabClass('contact')}>
                                <a href="/aqua/contact">Contact</a>
                            </li>
                        </ul>
                        */}
                        <ul className="nav navbar-nav navbar-right">
                            <li className={this.tabClass('login')}>
                                <a href="/aqua/login">Sign in</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        );
    }
});


module.exports = Component;
