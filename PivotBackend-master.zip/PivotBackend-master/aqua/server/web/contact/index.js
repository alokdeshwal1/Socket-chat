var Hoek = require('hoek');

exports.register = function (plugin, options, next) {

    options = Hoek.applyToDefaults({ basePath: '' }, options);

    plugin.route({
        method: 'GET',
        path: options.basePath + '/contact',
        handler: function (request, reply) {

            reply.view('contact/index');
        }
    });


    next();
};


exports.register.attributes = {
    name: 'web/contact'
};
