var Hoek = require('hoek');

exports.register = function (plugin, options, next) {

    options = Hoek.applyToDefaults({ basePath: '' }, options);

    plugin.route({
        method: 'GET',
        path: options.basePath + '/admin/{glob*}',
        config: {
            auth: {
                strategy: 'session',
                scope: 'admin'
            }
        },
        handler: function (request, reply) {

            reply.view('admin/index');
        }
    });


    next();
};


exports.register.attributes = {
    name: 'web/admin'
};
