var Hoek = require('hoek');

exports.register = function (plugin, options, next) {

    options = Hoek.applyToDefaults({ basePath: '' }, options);

    plugin.route({
        method: 'GET',
        path: options.basePath + '/account/{glob*}',
        config: {
            auth: {
                strategy: 'session',
                scope: 'account'
            }
        },
        handler: function (request, reply) {

            reply.view('account/index');
        }
    });


    next();
};


exports.register.attributes = {
    name: 'web/account'
};
