var Hoek = require('hoek');
var path = require('path');
exports.register = function (plugin, options, next) {

    options = Hoek.applyToDefaults({ basePath: '' }, options);

    plugin.route({
        method: 'GET',
        path: options.basePath + '/public/{param*}',
        handler: {
            directory: {
                path: path.join(__dirname, '../../public'),
                listing: true
            }
        }
    });


    next();
};


exports.register.attributes = {
    name: 'public'
};
