var Hoek = require('hoek');


exports.register = function (plugin, options, next) {

    options = Hoek.applyToDefaults({ basePath: '' }, options);

    plugin.route({
        method: 'GET',
        path: options.basePath + '/about',
        handler: function (request, reply) {

            reply.view('about/index');
        }
    });


    next();
};


exports.register.attributes = {
    name: 'web/about'
};
