var Hoek = require('hoek');

exports.register = function (plugin, options, next) {

    options = Hoek.applyToDefaults({ basePath: '' }, options);

    plugin.route({
        method: 'GET',
        path: options.basePath + '/login/{glob*}',
        config: {
            auth: {
                mode: 'try',
                strategy: 'session'
            },
            plugins: {
                'hapi-auth-cookie': {
                    redirectTo: false
                }
            }
        },
        handler: function (request, reply) {

            if (request.params.glob !== 'logout' &&
                request.auth.isAuthenticated) {

                if (request.auth.credentials.user.roles.admin) {
                    return reply.redirect('/aqua/admin');
                }

                return reply.redirect('/aqua/account');
            }

            var response = reply.view('login/index');
            response.header('x-auth-required', true);
        }
    });


    next();
};


exports.register.attributes = {
    name: 'web/login'
};
