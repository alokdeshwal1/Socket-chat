var Hoek = require('hoek');

exports.register = function (plugin, options, next) {

    options = Hoek.applyToDefaults({ basePath: '' }, options);

    plugin.route({
        method: 'GET',
        path: options.basePath + '/signup',
        handler: function (request, reply) {

            reply.view('signup/index');
        }
    });


    next();
};


exports.register.attributes = {
    name: 'web/signup'
};
