var Joi = require('joi');
var ObjectAssign = require('object-assign');
var BaseModel = require('hapi-mongo-models').BaseModel;
var StatusEntry = require('./status-entry');
var NoteEntry = require('./note-entry');

Joi.objectId = require('joi-objectid');


var Account = BaseModel.extend({
    constructor: function (attrs) {

        ObjectAssign(this, attrs);
    }
});


Account._collection = 'accounts';


Account.schema = Joi.object().keys({
    _id: Joi.object(),
    userId: Joi.object(),
    fullName: Joi.string().allow(['', null]),
    displayName: Joi.string().required(),
    lc_displayName: Joi.string().lowercase().required(),
    status: Joi.object().keys({
        current: StatusEntry.schema,
        log: Joi.array().items(StatusEntry.schema)
    }),
    notes: Joi.array().items(NoteEntry.schema),
    verification: Joi.object().keys({
        complete: Joi.boolean(),
        token: Joi.string()
    }),
    timeCreated: Joi.date()
});


Account.indexes = [
    [{ 'userId': 1 }],
    [{ 'displayName': 1 }],
    [{ 'lc_displayName': 1 }],
    [{ 'displayName': 'text' }]
];


Account.create = function (name, callback) {

    //var nameParts = name.trim().split(/\s/);
    var displayName, profilePic;

    if (typeof name == 'object') {
        displayName = name.displayName || name.name
        name = name.name;
    } else {
        displayName = name;
    }

    var lcDisplayName = displayName.toLowerCase();

    var document = {
        fullName: name,
        displayName: displayName,
        lc_displayName: lcDisplayName,
        timeCreated: new Date()
    };

    this.insertOne(document, function (err, docs) {

        if (err) {
            return callback(err);
        }

        callback(null, docs[0]);
    });
};

module.exports = Account;
