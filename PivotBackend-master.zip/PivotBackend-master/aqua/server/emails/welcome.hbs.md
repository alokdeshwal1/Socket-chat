### Welcome Aboard

Thanks for signing up. As requested, your account has been created.
Here are your login credentials:

| Details   |              |
| ---------:|:------------ |
| Username: | {{username}} |
| Email:    | {{email}}    |

Love,

The Plot Device
