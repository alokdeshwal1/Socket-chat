var FluxConstant = require('flux-constant');


module.exports = FluxConstant.set([
    'SERVER_ACTION',
    'VIEW_ACTION'
]);
