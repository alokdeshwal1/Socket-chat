var React = require('react/addons');
var ReactRouter = require('react-router');


var Component = React.createClass({
    render: function () {

        return (
            <ReactRouter.RouteHandler />
        );
    }
});


module.exports = Component;
