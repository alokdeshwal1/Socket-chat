var Gulp = require('gulp');


Gulp.task('default', ['watch', 'build', 'nodemon', 'media']);
