/**
 * Created by keary on 8/24/15.
 */
/**
 * Created by keary on 8/14/15.
 */
'use strict';

var Joi = require('joi');
Joi.objectId = require('joi-objectid');
var _ = require('lodash');
var mongoose = require('mongoose');
var paginate = require('mongoose-range-paginate');
var Boom = require('boom');
var geo = require('./util/geo.js');
var Async = require('async');
var helpers = require('./util/helpers.js');
var apiCommon = require('./api-common.js');
var rest = require('restler');
var Config = require.main.require('./hapi-config.js');

exports = module.exports = function(server, options) {

  function searchMap(request, reply) {
    //request.query.limit = 4;
    var landmarkPromise = apiCommon.searchLandmarks(request).then(function(result) {
      var locations = [];
      _.each(result.landmarks, function (landmark) {
        _.each(landmark.locations, function (loc) {
          locations.push({
            description: landmark.landmark.name,
            latitude: loc.geo_latlon.lat,
            longitude: loc.geo_latlon.lon,
            //zoom: 16,
            type: 'pivot-location',
            locationId: loc.id
          })
        })
      });
      return Promise.resolve(locations);
    });

    //var mapPromise = Promise.resolve([]);
    var mapPromise = new Promise(function(resolve, reject) {
      if (!request.query.search || request.query.search.length < 3)
        return resolve([]);
      return request.server.methods.nominatimCompletionSearch(request.query.search, function(err, result) {
        if (err)
          return reject(err);
        else
          return resolve(result);
      });
  }).catch(function(err) {
        console.log("nominatim err", err);
        return Promise.resolve([]);
    });

    return Promise.all([landmarkPromise, mapPromise]).then(function(results) {
      return reply({ results: results[0].concat(results[1])} );
    }).catch(function(err) {
      return errors.returnError(err, reply);
    });
  }


  var pre = server.plugins['pivot-pre'];

  return [
    {
      method: 'GET',
      path: options.basePath + '/v1/map/search',
      config: {
        validate: {
          query: Joi.object().keys({
            search: Joi.string().allow("").description("Term to search for"),
            latitude: Joi.number().optional().min(-90).max(90).description("latitude of current location"),
            longitude: Joi.number().optional().min(-180).max(180).description('longitude of current location'),
            limit: Joi.number().optional().default(4).description("maximum number of results per type"),
            version: Joi.string().valid('edit').valid('published').default('published')
            //more: Joi.string().optional().description("if included, returns only results not included in previous request that returned this more value")
          }).and('latitude', 'longitude')
        },
        auth: {
          strategies: ['user-basic', 'user-bearer' ],
          scope: [ 'user', 'api', 'trusted-api' ]
        },
        description: 'Search map',
        tags: ['api', 'mobile'],
        notes:  'Search map' ,
        response: {
          schema: Joi.object().keys({results: Joi.array().min(0).items(Joi.object().keys({
            description: Joi.string(),
            latitude: Joi.number(),
            longitude: Joi.number(),
            //zoom: 16,
            type: Joi.string(),
            locationId: Joi.string(),
            bounds: Joi.array().optional().min(2).max(2).items(
              Joi.array().min(2).max(2).items(Joi.number())
            )
          }).meta({className: "MapSearchResult"}))
        }).meta({className: "MapSearchResponse"}),
          modify: true
        }
      },
      handler: searchMap
    }
  ];
}
