var Hoek = require('hoek');
var Joi = require('joi');
var _ = require('lodash');

exports.register = function (server, options, next) {
  options = Hoek.applyToDefaults({ basePath: '' }, options);

  function loadRoutes(routes) {
    if (!routes)
      return;
    if (!Array.isArray(routes))
      routes = [ routes ];

    _.each(routes, function(route) {
      server.route(route);
    })

  }
  loadRoutes(require('./locations.js')(server, options));
  //loadRoutes(require('./media.js')(server, options));
  loadRoutes(require('./landmarks.js')(server, options));
  loadRoutes(require('./tours.js')(server, options));
  loadRoutes(require('./auth-endpoint.js')(server, options));
  loadRoutes(require('./media-storage.js')(server, options));
  loadRoutes(require('./map.js')(server, options));
  loadRoutes(require('./admin.js')(server, options));

  next();
};


exports.register.attributes = {
    name: 'api'
};
