/**
 * Created by keary on 9/16/15.
 */

'use strict';

var Joi = require('joi');
Joi.objectId = require('joi-objectid');
var Boom = require('boom');
var mongoose = require('mongoose');
var moment = require('moment');
var s3Utils = require('./util/s3.js');
var helpers = require('./util/helpers.js');
var Config = require.main.require('./hapi-config.js');
var _ = require('lodash');

//var restError = require('./util/errors.js');

function createMedia(request, reply) {

  var mediaRecord = new mongoose.models['MediaStorage']();
  var expires = moment().add(1,'hour');
  var id = mediaRecord._id.toString();

  var puts = [ ];
  var orig = s3Utils.generatePut(id, request.payload.contentType, expires.toDate());
  for (var i=0;i<request.payload.additional;i++) {
    puts.push(s3Utils.generatePut(id + '.' + (i).toString(), request.payload.contentType, expires.toDate()));
  }
  puts.push(orig);

  mediaRecord.userId = request.auth.credentials.userId;
//  mediaRecord.category = request.payload.category;
  mediaRecord.contentType = request.payload.contentType;
  mediaRecord.path = orig.name;
  mediaRecord.addCount = request.payload.additional;

  mediaRecord.save(function(err) {
    if (err)
      reply(Boom.badImplementation(err));
    else {
      var ret = {
        expires: helpers.dateToIso(expires.toDate()),
        storageId: {
          type: 's3',
          path: orig.name,
          mediaId: id
        },
        urls: _.map(puts, function(put) {
          return {
            putUrl: put.signedUrl,
            url: helpers.generateS3Url(put.name),
            contentUrl: s3Utils.url(put.name),
          }
        })
      };
      return reply(ret);
    }
  });

}

function redirectMedia(request, reply) {
  return reply.redirect(s3Utils.url(request.params.path));

}

module.exports = module.exports = function(server, options) {
  return [
    {
      path: options.basePath + '/v1/storage/media',
      method: 'POST',
      handler: createMedia,
      config: {
        auth: {
          strategies: ['user-basic', 'user-bearer'],
          scope: 'cms'
        },
        validate: {
          payload: Joi.object().keys({
            contentType: Joi.string().required().description('mime type'),
            additional: Joi.number().optional().default(0)
          }).meta({className:"CreateStorageMedia"})
        },
        description: 'Create an uploadable S3 URL',
        tags: ['api'],
        notes: 'Create an uploadable S3 URL',
        response: {
          schema: Joi.object().keys({
            expires: Joi.date().iso(),
            storageId: server.plugins['pivot-models'].common.storageIdModel,
            urls: Joi.array().items(Joi.object().keys({
              putUrl: Joi.string(),
              contentUrl: Joi.string(),
              url: Joi.string()
            }).meta({className: 'S3PutUrl'}))
          }).meta({className: 'CreateStorageMediaResponse'}),
          modify: true
        }
      }
    },
    {
      path: '/storage/media/s3/{path*}',
      method: 'GET',
      handler: redirectMedia,
      config: {
        description: 'Retrieve a media item (rediret)',
        tags: ['media']
      }

    }
  ]
}
