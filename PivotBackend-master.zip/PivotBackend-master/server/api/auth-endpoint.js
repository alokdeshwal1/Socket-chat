/**
 * Created by keary on 9/2/15.
 */
'use strict';

var Joi = require('joi');
Joi.objectId = require('joi-objectid');
var _ = require('lodash');
var mongoose = require('mongoose');
var paginate = require('mongoose-range-paginate');
var Boom = require('boom');
var geo = require('./util/geo.js');
var Async = require('async');
var errors = require('./util/errors.js');
var Config = require.main.require('./hapi-config.js');
var email = require('./util/email.js');

exports = module.exports = function(server, options) {

  return [
    {
      method: 'POST',
      path: options.basePath + '/v1/auth/login',
      config: {
        /*
         auth: {
         strategies: ['user-basic' ],
         scope: [ 'user', 'trusted-api' ]
         },
         */
        validate: {
          payload: Joi.object().keys({
            username: Joi.string().required().description("username"),
            password: Joi.string().required().description("password"),
          }).rename('email', 'username', {ignoreUndefined: true}),
          query: {
            client_id: Joi.string().description('API key').optional()
          }
        },
        description: 'login and receive JWT access token',
        tags: ['api', 'mobile'],
        notes: 'login and receive JWT access token',
        response: {
          schema: {
            access_token: Joi.string().required(),
            expires_in: Joi.number()
          },
          modify: true
        },
        pre: [{
          assign: 'clientId',
          method: function (request, reply) {
            if (!request.query.client_id)
              return reply();
            return request.server.plugins['pivot-auth'].verifyClientId(request.query.client_id, function (err, clientId) {
              if (err)
                return reply(Boom.badImplementation(err));
              if (!clientId)
                return reply(errors.err("invalid_client"));
              return reply(clientId);
            });
          }
        }]
      },
      handler: function(request, reply) {
        server.plugins['pivot-auth'].usernamePasswordValidate(request.payload.username, request.payload.password, request.pre.clientId, function(err, isValid, ctx) {
          if (err)
            return reply(Boom.badImplementation(err));
          if (!isValid)
            return reply(errors.err("invalid_grant"));

          server.plugins['pivot-auth'].generateTokens(ctx, {}, function(err, result) {
            if (err)
              return reply(Boom.badImplementation());
            console.log(result);
            return reply({
              access_token: result.access_token,
              expires_in: result.expires_in
            });
          })
        });

      }
    },
    {
      method: 'PUT',
      path: options.basePath + '/v1/user/me/password',
      config: {
        auth: {
          strategies: ['user-basic', 'alt-auth' ],
          scope: [ 'user', 'forgotpw' ]
        },
        validate: {
          payload: Joi.object().keys({
            oldPassword: Joi.string().description("old password"),
            password: Joi.string().required().description("password"),
          }).meta({className: 'ChangePassword'})
        },
        description: 'Change password',
        tags: ['api'],
        notes: 'Change password',
        pre: [{
          assign: 'password',
          method: function (request, reply) {

            var User = request.server.plugins['hapi-mongo-models'].User;

            User.generatePasswordHash(request.payload.password, function (err, hash) {

              if (err) {
                return reply(err);
              }

              reply(hash);
            });
          }
        }]
      },
      handler: function(request, reply) {

        function changePassword()
        {

          var User = request.server.plugins['hapi-mongo-models'].User;
          var id = request.auth.credentials.userId;
          var update = {
            $set: {
              password: request.pre.password.hash
            }
          };
          var options = {
            //fields: User.fieldsAdapter('username email')
          };

          User.findByIdAndUpdate(id, update, options, function (err, user) {
            if (err) {
              return reply(err);
            }

            var auth = request.server.plugins['pivot-auth'];

            var jti;
            if (request.auth.credentials.type == 'altauth')
              jti = request.auth.credentials.jti;

            return auth.deleteToken(jti, function (err) {
              return reply({});
            });

          });

        }


        if (request.auth.credentials.type == 'altauth') {
          return changePassword();
        } else {
          server.plugins['pivot-auth'].usernamePasswordValidate(request.auth.credentials.username, request.payload.oldPassword, function (err, isValid, ctx) {
            console.log(ctx);
            if (err)
              return reply(Boom.badImplementation(err));
            if (!isValid)
              return reply(Boom.unauthorized());

            return changePassword();
          });
        }
      }
    },
    {
      method: 'POST',
      path: '/api/v1/user/forgotpassword',
      config: {
        auth: false,
        validate: {
          payload: {
            email: Joi.string().email().required()
          },
        },
        description: 'request forgotten password',
        tags: ['api'],
        notes: ['request forgotten password'],
        pre: [{
          assign: 'emailExistsCheck',
          method: function (request, reply) {

            var User = request.server.plugins['hapi-mongo-models'].User;
            var conditions = {
              username: request.payload.email
            };

            User.findOne(conditions, function (err, user) {

              if (err) {
                return reply(err);
              }

              if (user)
                return reply(user);
              return reply(false);
            });
          }
        }]
      },
      handler: function (request, reply) {

        /* Just return if account doesn't exist */
        if (!request.pre.emailExistsCheck)
          return reply({});

        var auth = request.server.plugins['pivot-auth'];

        var userId = request.pre.emailExistsCheck._id.toString();
        auth.generateTokens({
          userId: userId,
          scope: [ 'forgotpw' ],
          email: request.pre.emailExistsCheck.username
        }, { save: true, type: 'altauth', expireSeconds: Config.get('/passwordResetTimeout') }, function(err, token) {
          if (err)
            return done(Boom.badImplementation(err));
          var url = Config.get("/baseUrl") + '/index.html?app=forgotpw&token=' + token.access_token;

          email.sendTemplate('forgot-password', request.payload.email, {
            password_reset_url: url
          }, function (err, result) {
            console.log(err);
            console.log(result);
          });

          return reply({});
        });
      }
    },
  ];
}
