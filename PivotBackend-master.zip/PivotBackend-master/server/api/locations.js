/**
 * Created by keary on 8/14/15.
 */
'use strict';

var Joi = require('joi');
Joi.objectId = require('joi-objectid');
var _ = require('lodash');
var mongoose = require('mongoose');
var paginate = require('mongoose-range-paginate');
var Boom = require('boom');
var geo = require('./util/geo.js');
var geohash = require('./lib/geohash.js');
var Async = require('async');
var errors = require('./util/errors.js');
var Config = require.main.require('./hapi-config.js');
var apiCommon = require('./api-common.js');
var gju = require('geojson-utils');

exports = module.exports = function(server, options) {

  function generateLocConstraints(constraints, request, rec) {
    var includeType = request.query.includeType;
    var excludeType = request.query.excludeType;

    // Hack to make API testing easier from API DOC page
    if (includeType && includeType.length == 1)
      includeType = includeType[0].split(',');
    if (excludeType && excludeType.length == 1)
      excludeType = excludeType[0].split(',');

    if (_.contains(excludeType, 'landmark'))
      constraints[rec + '.landmarks.0'] = {"$exists": false};
    if (_.contains(excludeType, 'tour'))
      constraints[rec +'.tourInfo.0'] = {"$exists": false};
    if (_.contains(excludeType, 'region'))
      constraints[rec + '.loc.geo_location.type'] = {"$eq": "Point"};

    var ors = [];
    var c;
    if (_.contains(includeType, 'landmark')) {
      c = {};
      c[rec+'.landmarks.0'] = {"$exists": true};
      ors.push(c);
    }
    if (_.contains(includeType, 'tour')) {
      c = {};
      c[rec+'.tourInfo.0'] = {"$exists": true};
      ors.push(c);
    }
    if (_.contains(includeType, 'region')) {
      c = {};
      c[rec + '.loc.geo_location.type'] = {"$ne": "Point"};
      ors.push(c);
    }

    if (ors.length) {
      var oldConstraints = constraints;
      var orConstraints = {
        '$or': ors
      }
      constraints = {'$and': [oldConstraints, orConstraints]};
    }

    return constraints;

  }

  function getWithinLocations(request, reply) {
    var rec = request.query.version;
    /*
     var constraints = {
     "loc.geo_location": {
     "$geoWithin": { "$centerSphere": [ [request.query.longitude, request.query.latitude],  request.query.radius/geo.earthsradius] }
     }
     };
     */
    var coords;
    if (typeof request.query.seLongitude !== 'undefined' && typeof request.query.seLongitude !== 'undefined')
      coords = [ [ request.query.longitude, request.query.latitude ], [ request.query.longitude, request.query.seLatitude ], [ request.query.seLongitude, request.query.seLatitude ], [ request.query.seLongitude, request.query.latitude ], [ request.query.longitude, request.query.latitude ]]
    else if (request.query.radius) {
      if (false && request.query.radius >= 4526000)
        coords = [[-180, -90], [180, -90], [180, 90], [-180, 90], [-180, -90]];
      else
        coords = geo.circleToPolygon([request.query.longitude, request.query.latitude], request.query.radius);
    }
    else
      return reply(Boom.badRequest());

    var constraints = { };
    constraints[rec + '.loc.geo_location'] =
      {
        '$geoIntersects': {
          '$geometry':
          {
            type: 'Polygon',
            coordinates: [ coords ],
            crs: {
              type: "name",
              properties: { name: "urn:x-mongodb:crs:strictwinding:EPSG:4326" }
            }
          }
        }
      };

    if (rec == 'published') {
      constraints[rec + '.isDeleted'] = {'$ne': true};
      constraints[rec + '.isHidden'] = {'$ne': true};
    }


    var constraints = generateLocConstraints(constraints, request, rec);

    /*
     if (request.query.postedBy_displayName) {
     constraints['postedBy.displayName'] = { $in: request.query.postedBy_displayName };
     }
     */

    // use any field name in your model, in this case we sort by 'timestamp'
    var sortKey = '_id';
    var sort = '-' + sortKey;

    var paginateOptions = {
      limit: request.query.limit,
      sort: sort
    }

    if (request.query.more) {
      var more = request.query.more.split(':');
      if (more.length == 2) {
        paginateOptions.startId = mongoose.Types.ObjectId(more[0]);
        paginateOptions.startKey = mongoose.Types.ObjectId(more[1]);
      }
    }

    var limit = request.query.limit;
    var query = mongoose.models.Location.find().where(constraints);

    return paginate(query, paginateOptions).exec(function (err, locations) {
        if (err) {
          return reply(Boom.badImplementation(err));
        }

        Async.map(locations, function(location, done) {
          return location.toRestObject({ type: rec}).then(function(loc) {
            done(null, loc);
          }).then(null, function(err) {
            done(err);
          });
        }, function(err, result) {
          if (err)
            return reply(Boom.badImplementation(err.toString()));

          var ret = {
            features: result
          };
          if (locations.length == limit) {
            ret.more = locations[limit-1]._id.toString() + ":" + locations[limit-1][sortKey].toString()
          }
          return reply(ret);
        });
      }
    );
  }

  function searchLocations(request, reply) {
    var rec = request.query.version;
    var constraints = { };
    if (request.query.institution)
      constraints['institution'] = request.query.institution;
    if (request.query.startsWith)
      constraints[rec + '.lc_info.name'] = new RegExp(request.query.startsWith);
    if (request.query.pendingChanges)
      constraints.pendingChanges = { '$eq': request.query.pendingChanges };

    console.log(constraints);

    if (rec == 'published') {
      constraints[rec + '.isDeleted'] = {'$ne': true};
      constraints[rec + '.isHidden'] = {'$ne': true};
    }

    var sortKey = rec + '.lc_info.name';
    var sort = sortKey; // '-' + sortKey;

    var paginateOptions = {
      limit: request.query.limit,
      sort: sort
    }

    if (request.query.more) {
      var more = request.query.more.split(':');
      if (more.length == 2) {
        paginateOptions.startId = mongoose.Types.ObjectId(more[0]);
        paginateOptions.startKey = more[1];
      }
    }

    var limit = request.query.limit;
    var query = mongoose.models.Location.find().where(constraints);

    return paginate(query, paginateOptions).exec(function (err, locations) {
        if (err) {
          return reply(Boom.badImplementation(err));
        }

        Async.map(locations, function(location, done) {
          return location.toRestObject({ type: rec}).then(function(loc) {
            done(null, loc);
          }).then(null, function(err) {
            done(err);
          });
        }, function(err, result) {
          if (err) {
            console.log(err.stack);
            return reply(Boom.badImplementation(err.toString()));
          }

          var ret = {
            features: result
          };
          if (locations.length == limit) {
            ret.more = locations[limit-1]._id.toString() + ":" + locations[limit-1].get(sortKey).toString()
          }
          return reply(ret);
        });
      }
    );
  }


  /*
  function getNearestLocations(request, reply) {
    var rec = 'edit';

    var nearConstraint = {
      "$near": {
        '$geometry': {
          type: 'Point',
          coordinates: [ request.query.longitude, request.query.latitude ]
        }
      }
    };


    if (request.query.radius)
      nearConstraint['$near']['$maxDistance'] = request.query.radius

    var constraints = {
      'loc.geo_location': nearConstraint
    }


    constraints = generateLocConstraints(constraints, request, rec);

    var limit = request.query.limit;
    var query = mongoose.models.Location.find().where(constraints).limit(limit);

    return query.exec(function (err, locations) {
      if (err) {
        return reply(Boom.badImplementation(err));
      }

      Async.map(locations, function(location, done) {
        return location.toRestObject().then(function(loc) {
          done(null, loc);
        }).then(null, function(err) {
          done(err);
        });
      }, function(err, result) {
        if (err)
          return reply(Boom.badImplementation(err.toString()));

        var ret = {
          features: result
        };
        return reply(ret);
      });
    });
  }
  */
  function getLocation(request, reply) {

    var rec = request.query.version;

    var location = request.pre.Location;

    if (rec == 'published' && (request.pre.Location[rec].isDeleted || request.pre.Location[rec].isHidden))
      return reply(Boom.notFound());

    return location.toDetailRestObject({
      tourId: request.query.tourId,
      type: rec
    }).then(function (loc) {
      if (!request.query.includeHiddenMedia) {
        loc.media = _.reject(loc.media, function(m) { return m.showIn == 'hide' } );
      }
      return reply(loc);
    }).then(null, function (err) {
      if (err.isBoom)
        return reply(err);
      return reply(Boom.badImplementation(err.toString()));
    });
  }

  function fixupLocation(loc) {
    /*
     obj.loc = {
     asEntered: geoJson,
     geo_location: geoJson
     };
     */
    var centroid = loc.geo_location;
    if (loc.geo_location.type != 'Point')
      centroid = gju.centroid(loc.geo_location);
    var latitude = centroid.coordinates[1];
    var longitude = centroid.coordinates[0];
    loc.geo_latlon = {
      lat: latitude,
      lon: longitude
    }
    loc.geohash = geohash.encodeGeoHash(latitude, longitude);

  }

  function setLocationData(location, fieldToSet, data) {
    location.set(fieldToSet, data);
  }

  function deleteByMongoId(options, id, cb) {
    var index = options.index,
      type = options.type,
      client = options.client,
      tries = options.tries;

    client.delete({
      index: index,
      type: type,
      id: id
    }, function(err, res) {
      if (err && err.message.indexOf('404') > -1) {
        setTimeout(function() {
          if (tries <= 0) {
            return cb(err);
          } else {
            options.tries = --tries;
            deleteByMongoId(options, id, cb);
          }
        }, 500);
      } else {
        cb(err);
      }
    });
  }

  function deleteFromSearchIndex(indexName, landmark, rec, locId) {
    return new Promise(function (resolve, reject) {
      var typeName = 'landmark';
      options = {};
      options.index = indexName;
      options.type = typeName;
      options.client = server.app.esClient;
      options.tries = 3;

      deleteByMongoId(options, landmark._id.toString(), function (err) {
        if (err)
          return reject(err);
        else
          return resolve();
      });
    });
  }

  function updateSearchIndex(indexName, landmark, rec, loc) {

    var typeName = 'landmark';
    return new Promise(function(resolve, reject) {
      if (rec.isDeleted)
        return resolve();
      var thumb;
      if (landmark.defaultInfoCard && landmark.defaultInfoCard.defaultMediaId) {
        var media = rec.media.id(landmark.defaultInfoCard.defaultMediaId);
        if (media) {
          thumb = (media.sizedUrls && media.sizedUrls.length) ?
            media.sizedUrls[0].url : media.url;
        }
      }
      var obj = {
        name: landmark.name,
        description: landmark.defaultInfoCard ? landmark.defaultInfoCard.description : '',
        shortDescription: landmark.shortDescription,
        thumbnailUrl: thumb,
        institution: loc.institution || 'pivot',
        locations: [{
          _id: loc._id.toString(),
          //name: rec.name,
          geo_latlon: rec.loc.geo_latlon
        }]
      }
      server.app.esClient.index({
        index: indexName,
        type: typeName,
        id: landmark._id.toString(),
        body: obj
      }, function (err) {
        if (err)
          return reject(err);
        else
          return resolve();
      });
    });
  }

  function auditAndApply(request, location, description) {
    var auditRecord = new server.plugins['pivot-models'].AuditLog.mongooseModel();

    location.edit.version = auditRecord._id;
    location.originalEditVersion = auditRecord._id;
    if (request.query.publish) {
      setLocationData(location, 'published', location.toObject()['edit']);
      if (!description)
        description = 'Publish';
      else
        description = description + " & Publish";
    }

    location.pendingChanges = !location.published.version || location.edit.version.toString() != location.published.version.toString();

    auditRecord.userId = request.auth.credentials.userId ? mongoose.Types.ObjectId(request.auth.credentials.userId) : null;
    auditRecord.username = request.auth.credentials.username;
    auditRecord.email = request.auth.credentials.email;
    auditRecord.institution = request.auth.credentials.institution;
    auditRecord.description = description;
    auditRecord.objectType = 'Location';
    auditRecord.objectId = location._id;
    auditRecord.isPublish = !!request.query.publish;
    auditRecord.data = (location.toObject())['edit'];


    return auditRecord.save().then(function() {
      return location.save();
    }).then(function(_location) {
      location = _location;
      // Apply to edit index.
      var promises = [ ];
      _.each(location['edit'].landmarks, function(l) {
        promises.push(updateSearchIndex('landmarks-edit', l, location['edit'], location));
      })
      return Promise.all(promises);
    }).then(function() {
      if (request.query.publish) {
        var promises = [ ];
        _.each(location['published'].landmarks, function(l) {
          if (location['published'].isHidden)
            promises.push(deleteFromSearchIndex('landmarks', l, location['published'], location));
          else
            promises.push(updateSearchIndex('landmarks', l, location['published'], location));
        })
        return Promise.all(promises);
      }
      else
        return Promise.resolve();
    }).then(function() {
      return Promise.resolve(location);
    })
  }
  function createLocation(request, reply) {
    /*
     name: Joi.string().required(),
     latitude: Joi.number().required().min(-90).max(90).description("latitude"),
     longitude: Joi.number().required().min(-180).max(180).description('longitude'),
     streetAddress: server.plugins['pivot-models'].common.addressModel.optional(),
     createNewLandmark: Joi.boolean().default(false),
     */

    var rec = 'edit';
    var locationRecord = new server.plugins['pivot-models'].Location.mongooseModel();
    //locationRecord['edit'] = { };
    //locationRecord['published'] = { };

    var obj = locationRecord[rec];
    obj.name = request.payload.name;
    obj.streetAddress = request.payload.streetAddress;
    var geoJson =  {
      type: 'Point',
      coordinates: [request.payload.longitude, request.payload.latitude]
    };

    obj.loc = {
      asEntered: geoJson,
      geo_location: geoJson,
    };
    fixupLocation(obj.loc);

    obj.type = [ ];

    if (request.auth.credentials.institution)
      locationRecord.institution = request.auth.credentials.institution;

    var landmarkRecord;
    if (request.payload.createNewLandmark) {
      landmarkRecord = obj.landmarks.create();
      landmarkRecord.name = request.payload.name;
      landmarkRecord.defaultInfoCard = {
        description: request.payload.landmarkDescription
      }
      obj.landmarks.push(landmarkRecord);
      obj.type.push('landmark');
    }

    if (request.payload.proximityRadius !== undefined)
      obj.proximityRadius = request.payload.proximityRadius;

    console.log(obj.proximityRadius, request.payload.proximityRadius);

    // Start off with the published record showing as "deleted".
    if (rec == 'edit')
      locationRecord.published.isDeleted = true;

    return auditAndApply(request, locationRecord, 'Location Created').then(function() {
      return locationRecord.toDetailRestObject({ type: rec });
    }).then(function(location) {
      return Promise.resolve(reply(location));
    }).then(null, function(err) {
      console.log(err);
      console.log(err.stack);
      return errors.returnError(err, reply);
    });
  }

  function deleteLandmarkFromLocation(request, reply) {
    var rec = 'edit';

    var location = request.pre.Location;
    var obj = location[rec];
    var landmark = obj.landmarks.id(request.params.landmarkId);
    if (!landmark)
      return errors.returnError('not_found', reply);

    landmark.remove();

    return auditAndApply(request, location, 'Remove landmark').then(function(location) {
      return location.toDetailRestObject({type: rec});
    }).then(function(details) {
      return reply(details);
    }).then(null, function(err) {
      return errors.returnError(err, reply);
    });
  }

  function deleteLocation(request, reply) {
    console.log("Delete", request.query);
    var rec = 'edit';
    var location = request.pre.Location;

    if (!request.pre.Location.published.version || request.query.publish) {
      console.log("Permanent delete!");
      return auditAndApply(request, location, 'Permanently remove location').then(function() {
        var promises = [ ];
        var types = ['edit'];
        if (request.query.publish)
          types.push('published');
        _.each(types, function(type) {
          var index = (type == 'edit') ? 'landmarks-edit' : 'landmarks';
          _.each(location[type].landmarks, function (l) {
            promises.push(deleteFromSearchIndex(index, l, location[type], location._id));
          })
        });
        return Promise.all(promises);
      }).then(function () {
        return location.remove();
      }).then(function() {
        return reply({});
      }).then(null, function (err) {
        console.log(err.stack);
        return errors.returnError(err, reply);
      })
    } else {
      location[rec].isDeleted = true;
      return auditAndApply(request, location, 'Delete location').then(function(location) {
        return location.toDetailRestObject({type: rec});
      }).then(function(location) {
        return reply(location);
      }).then(null, function (err) {
        console.log(err.stack);
        return errors.returnError(err, reply);
      })

    }
  }

  function newLandmarkForLocation(request, reply) {
    var rec = 'edit'

    var locationRecord = request.pre.Location;
    var obj = locationRecord[rec];
    var landmarkRecord = locationRecord.landmarks.create();

    landmarkRecord.name = request.payload.name;
    landmarkRecord.defaultInfoCard = {
      description: request.payload.description
    }
    landmarkRecord.shortDescription = request.payload.shortDescription;

    obj.landmarks.push(landmarkRecord);
    return auditAndApply(request, locationRecord, 'Added landmark').then(function() {
      return locationRecord.toDetailRestObject({type: rec});
    }).then(function(location) {
      return reply(location);
    }).then(null, function(err) {
      return errors.returnError(err, reply);
    });

    // Add this landmark to the location

  }

  function newMediaForLocation(request, reply) {
    var rec = 'edit'
    // Create the media
    var mediaRecord = request.pre.Location[rec].media.create();
    mediaRecord.type = request.payload.type;
    mediaRecord.url = request.payload.sizedUrls[request.payload.sizedUrls.length-1].url;
    mediaRecord.sizedUrls = request.payload.sizedUrls;
    mediaRecord.showIn = request.payload.showIn;

    var location = request.pre.Location;
    var obj = location[rec];
    obj.media.push(mediaRecord);
    var promises = [ auditAndApply(request, location, 'Media added') ];

    // Update the storageId
    if (request.payload.storageId && request.payload.storageId.mediaId) {
      var update = {
        '$set': {
          isUsed: true,
      //    bucket: 'keary'
        }
      }

      promises.push(server.plugins['pivot-models'].MediaStorage.mongooseModel.findByIdAndUpdate(request.payload.storageId.mediaId, update, { new: true }));
    }

    var ret = { };

    return Promise.all(promises).then(function(results) {
      return request.pre.Location.toDetailRestObject({ type: rec});
    }).then(function(locationRest) {
      return reply(locationRest);
    }).then(null, function(err) {
      console.log(err);
      console.log(err.stack);
      return errors.returnError(err, reply);
    });
  }


  function putLocation(request, reply) {
    var rec = 'edit';
    // name, lat/lon, streetAddress
    var location = request.pre.Location;
    var obj = location[rec];
    var promises =  [ ];
    var updated = false;

    if (obj.isDeleted) {
      obj.isDeleted = false;
      updated = true;
    }
    if (request.payload.name && request.payload.name != obj.name) {
      updated = true;
      if (request.query.modifyLinkedLandmark) {
        _.each(obj.landmarks, function(landmark) {
            if (landmark.name == obj.name)
              landmark.name = request.payload.name;
        });
      }

      obj.name = request.payload.name;
    }

    if (request.payload.maintainerNotes !== undefined) {
      updated = true;
      obj.maintainerNotes = request.payload.maintainerNotes;
    }

    if (request.payload.latitude) {
      updated = true;
      var geoJson =  {
        type: 'Point',
        coordinates: [request.payload.longitude, request.payload.latitude]
      };

      obj.loc = {
        asEntered: geoJson,
        geo_location: geoJson
      };
      fixupLocation(obj.loc);
    }

    if (request.payload.streetAddress) {
      updated = true;
      obj.streetAddress = request.payload.streetAddress;
    }

    if (request.payload.proximityRadius !== undefined) {
      updated = true;
      obj.proximityRadius = request.payload.proximityRadius;
    }

    var promise;

    var desc = '';
    if (updated)
      desc = 'Location properties edited';
    else if (request.payload.isHidden !== undefined) {
      obj.isHidden = request.payload.isHidden;
      desc = obj.isHidden ? 'Location hidden' : 'Location unhidden';
      updated = true;
    }

    var versionSame = location.published.version && (location.edit.version.toString() == location.published.version.toString());
    if (!updated && (!request.query.publish || versionSame))
      promise = Promise.resolve(location);
    else {
      promise = auditAndApply(request, location, desc);
    }

    return promise.then(function() {
      return location.toDetailRestObject({type: rec});
    }).then(function(loc) {
      return reply(loc);
    }).then(null, function(err) {
      return errors.returnError(err, reply);
    });

    return reply({});
  }

  function putLocationLandmark(request, reply) {
    var rec = 'edit';

    var location = request.pre.Location;
    var obj = location[rec];
    var landmark = obj.landmarks.id(request.params.landmarkId);
    if (!landmark)
      return reply(Boom.notFound());

    if (request.payload.constructionDate !== undefined)
      landmark.constructionDate = request.payload.constructionDate;
    if (request.payload.removalDate !== undefined)
      landmark.removalDate = request.payload.removalDate;
    if (request.payload.shortDescription !== undefined)
      landmark.shortDescription = request.payload.shortDescription;
    var defaultInfoCard = { };
    if (landmark.defaultInfoCard)
      defaultInfoCard = _.extend({ }, landmark.defaultInfoCard);

    if (request.payload.description !== undefined)
      defaultInfoCard.description = request.payload.description;
    if (request.payload.defaultMediaId && obj.media.id(request.payload.defaultMediaId))
      defaultInfoCard.defaultMediaId = request.payload.defaultMediaId;

    landmark.defaultInfoCard = defaultInfoCard;

    return auditAndApply(request, location, 'Landmark properties edited').then(function(location) {
      //return reply(location.landmarkObject(request.params.landmarkId, rec));
      return location.toDetailRestObject({type: rec});
    }).then(function(detail) {
      return reply(detail);
    }).then(null, function(err) {
      console.log(err.stack);
      return reply(Boom.badImplementation(err.toString()));
    });

  }

  function putMedia(request, reply) {
    var rec = 'edit';
    var location = request.pre.Location;
    var obj = location[rec];
    var media = obj.media.id(request.params.mediaId);
    if (!media)
      return reply(Boom.notFound());

    if (request.payload.relevanceStartDate !== undefined)
      media.relevanceStartDate = request.payload.relevanceStartDate;
    if (request.payload.caption !== undefined)
      media.caption = request.payload.caption;
    if (request.payload.showIn)
      media.showIn = request.payload.showIn;

    return auditAndApply(request, location, 'Media properties edited').then(function(location) {
      return location.toDetailRestObject({type: rec});
    }).then(function(ret) {
      return reply(ret);
    }).then(null, function(err) {
     return reply(Boom.badImplementation(err.toString()));
     });

  }

  function deleteMedia(request, reply) {
    var rec = 'edit';
    var location = request.pre.Location;
    var obj = location[rec];
    var media = obj.media.id(request.params.mediaId);
    if (!media)
      return reply(Boom.notFound());

    media.remove();

    return auditAndApply(request, location, 'Media removed').then(function(location) {
      return location.toDetailRestObject({type: rec});
    }).then(function(location) {
      return reply(location);
    }).then(null, function(err) {
     return reply(Boom.badImplementation(err.toString()));
     });
  }

  var preLocationVersion = {
    assign: 'preLocationVersion',
    method: function(request, reply) {
      var version = request.query.version;
      request.pre.Location.originalEditVersion = request.pre.Location.edit.version;
      if (version == 'published') {
        setLocationData(request.pre.Location, 'edit', request.pre.Location.toObject()['published']);
        return reply();
      } else if (version == 'edit') {
        return reply();
      } else {
        return server.plugins['pivot-models'].AuditLog.mongooseModel.findById(version).then(function(al) {
          if (!al || al.objectId.toString() != request.pre.Location._id.toString())
            return reply(Boom.notFound());
          setLocationData(request.pre.Location, 'edit', al.data);
          request.query.version = 'edit';
          return reply();
        });
      }
    }
  }

  var publishAdminOnly = {
    assign: 'publishAdminOnly',
    method: function(request, reply) {
      if (request.query.publish && !_.contains(request.auth.credentials.scope, 'cms-admin'))
        return reply(Boom.forbidden());
      return reply();
    }
  }


  var pre = server.plugins['pivot-pre'];

  return [
    {
      method: 'GET',
      path: options.basePath + '/v1/locations/within',
      config: {
        validate: {
          query: {
            latitude: Joi.number().required().min(-90).max(90).description("latitude"),
            longitude: Joi.number().required().min(-180).max(180).description('longitude'),
            radius: Joi.number().optional().default(800).description("Radius of the search in meters (if not using bounding box)"),
            seLatitude: Joi.number().min(-90).max(90).optional().description("Latitude of SE corner of bounding box (if not using radius)"),
            seLongitude: Joi.number().min(-180).max(180).optional().description("Longitude of SE corner of bounding box (if not using radius)"),
            includeType: Joi.array().single().optional().items(Joi.string().allow("region").allow("tour").allow("landmark").allow("vantage")).description("Array of types"),
            excludeType: Joi.array().single().optional().items(Joi.string().allow("region").allow("tour").allow("landmark").allow("vantage")).description("Array of types"),
            limit: Joi.number().optional().default(1000).description("maximum number of results"),
            more: Joi.string().optional().description("if included, returns only results not included in previous request that returned this more value"),
            version: Joi.string().optional().valid('published').valid('edit').default("published").description("Retrieve published/edit version")
          }
        },
         auth: {
           strategies: ['user-basic', 'user-bearer' ],
           scope: [ 'user', 'api', 'trusted-api' ]
         },
        description: 'Find all locations within an area',
        tags: ['api', 'mobile'],
        notes:
          'Radius is used to construct a rough polygon for the search area (16-sided polygon)\n' +
          'Returned results are in no particular order so they can be paged.\n' +
          'To sort them by nearest, use /nearest (but nearest can not be paged)'
        ,
        response: {
          schema: Joi.object().keys(
            {
              more: Joi.string().optional().description("If returned, there are more results.  Pass this value to the next call."),
              features: Joi.array().items(server.plugins['pivot-models'].Location.restModel).required()
            }).meta({className: "WithinSearchResult"}),
          modify: true
        }
      },
      handler: getWithinLocations
    },
    {
      method: 'GET',
      path: options.basePath + '/v1/locations/search',
      config: {
        validate: {
          query: {
            institution: Joi.string().optional().description("Include only institutional locations"),
            startsWith: Joi.string().lowercase().optional().description("name starts with"),
            limit: Joi.number().optional().default(1000).description("maximum number of results"),
            more: Joi.string().optional().description("if included, returns only results not included in previous request that returned this more value"),
            version: Joi.string().optional().valid('published').valid('edit').default("published").description("Retrieve published/edit version"),
            pendingChanges: Joi.boolean().optional()
          }
        },
        auth: {
          strategies: ['user-basic', 'user-bearer' ],
          scope: [ 'user', 'api', 'trusted-api' ]
        },
        description: 'Search locations',
        tags: ['api' ],
        notes:
        'Radius is used to construct a rough polygon for the search area (16-sided polygon)\n' +
        'Returned results are in no particular order so they can be paged.\n' +
        'To sort them by nearest, use /nearest (but nearest can not be paged)'
        ,
        response: {
          schema: Joi.object().keys(
            {
              more: Joi.string().optional().description("If returned, there are more results.  Pass this value to the next call."),
              features: Joi.array().items(server.plugins['pivot-models'].Location.restModel).required()
            }).meta({className: "WithinSearchResult"}),
          modify: true
        }
      },
      handler: searchLocations
    },
    {
      method: 'GET',
      path: options.basePath + '/v1/locations/nearest',
      config: {
        validate: {
          query: {
            latitude: Joi.number().required().min(-90).max(90).description("latitude"),
            longitude: Joi.number().required().min(-180).max(180).description('longitude'),
            radius: Joi.number().optional().description("If included limit radius of the search in meters"),
            includeType: Joi.array().single().optional().items(Joi.string().allow("region").allow("tour").allow("landmark").allow("vantage")).description("Array of types"),
            excludeType: Joi.array().single().optional().items(Joi.string().allow("region").allow("tour").allow("landmark").allow("vantage")).description("Array of types"),
            limit: Joi.number().optional().default(100).description("maximum number of results"),
            version: Joi.string().optional().valid('published').valid('edit').default("published").description("Retrieve published/edit version")
          }
        },
        auth: {
          strategies: ['user-basic', 'user-bearer' ],
          scope: [ 'user', 'api', 'trusted-api' ]
        },
        description: 'DEPRECATED: Find locations nearest a point',
        tags: ['api', 'mobile'],
        notes:
          'DEPRECATED: Find all locations near a point\n' +
          'Returned results are sorted by distance'
        ,
        response: {
          schema: Joi.object().keys(
            {
              features: Joi.array().items(server.plugins['pivot-models'].Location.restModel).required(),
              more: Joi.string().optional().description("If returned, there are more results.  Pass this value to the next call."),
            }).meta({className: "NearestSearchResult"}),
          modify: true
        }
      },
      handler: getWithinLocations
    },
    {
      method: 'GET',
      path: options.basePath + '/v1/locations/{id}',
      config: {
        validate: {
          params: {
            id: Joi.objectId().required().description("location ID to retrieve"),
          },
          query: {
            tourId: Joi.string().optional().description("Optional tour id of tour user is on"),
            version: Joi.string().optional().default("published").description("Retrieve published/edit version"),
            includeHiddenMedia: Joi.boolean().optional().default(false)
            //full_tour: Joi.boolean().optional().default(false).description("Load full tour info"),
            //full_landmark: Joi.boolean().optional().default(false).description("Load full landmark info")
          }
        },
        auth: {
          strategies: ['user-basic', 'user-bearer' ],
          scope: [ 'user', 'api', 'trusted-api' ]
        },
        description: 'Retrieve details (photos/landmarks/etc) location by id',
        tags: ['api', 'mobile'],
        notes:  'Retrieve details (photos/landmarks/etc) location by id' ,
        response: {
          schema: server.plugins['pivot-models'].Location.locationDetailsModel.required(),
          modify: true
        },
        pre: [
          pre.retrieveRecord('Location', 'id'),
          preLocationVersion
        ]
      },
      handler: getLocation
    },
    {
      method: 'PUT',
      path: options.basePath + '/v1/locations/{id}',
      config: {
        validate: {
          params: {
            id: Joi.objectId().required().description("location ID to retrieve"),
          },
          query: {
            modifyLinkedLandmark: Joi.boolean().default(false).optional().description("Rename landmark w/same name"),
            version: Joi.string().optional().default("edit").description("published/edit version"),
            publish: Joi.boolean().optional().default(false).description("publish after change")
            //full_tour: Joi.boolean().optional().default(false).description("Load full tour info"),
            //full_landmark: Joi.boolean().optional().default(false).description("Load full landmark info")
          },
          payload: Joi.object().keys({
            name: Joi.string().trim().optional(),
            latitude: Joi.number().optional().min(-90).max(90).description("latitude"),
            longitude: Joi.number().optional().min(-180).max(180).description('longitude'),
            proximityRadius: Joi.number().optional().description("Radius for proximity checking in meteres"),
            streetAddress: server.plugins['pivot-models'].common.addressModel.optional(),
            maintainerNotes: Joi.string().trim().optional().allow(""),
            isHidden: Joi.boolean().optional()
          }).and('latitude', 'longitude').meta({className:"ModifyLocation"})
        },
        auth: {
          strategies: ['user-basic', 'user-bearer' ],
          scope: [ 'cms' ]
        },
        description: 'Modify location details',
        tags: ['api'],
        notes:  'Modify location details' ,
        response: {
          schema: server.plugins['pivot-models'].Location.locationDetailsModel.required(),
          modify: true
        },
        pre: [
          publishAdminOnly,
          pre.retrieveRecord('Location', 'id'),
          preLocationVersion,
          {
            assign: 'checkLocationName',
            method: function (request, reply) {
              if (!request.payload.name)
                return reply();
              return server.plugins['pivot-models'].Location.mongooseModel.findOne({
                '$or': [
                  {'edit.name': request.payload.name },
                  {'published.name': request.payload.name},
                  {'edit.lc_info.name': request.payload.name.toLowerCase() },
                  {'published.lc_info.name': request.payload.name.toLowerCase()}
                ],
                _id: { "$ne": mongoose.Types.ObjectId(request.params.id) }
              }).then(function(location) {
                if (location)
                  return errors.returnError('duplicate_location', reply);
                else
                  return reply();
              }).then(null, function(err) {
                return errors.returnError(err, reply);
              });
            }
          },
          {
            assign: 'noCloseLocations',
            method: function(request, reply) {
              return reply();
              if (request.payload.latitude === undefined)
                return reply();
              var query = {
                'loc.geo_location': {
                  "$near": {
                    '$maxDistance': Config.get('/limits/minSeperation'),
                    '$geometry': {
                      type: 'Point',
                      coordinates: [request.payload.longitude, request.payload.latitude]
                    }
                  }
                },
                '_id': { '$ne': mongoose.Types.ObjectId(request.params.id) }
              };

              return server.plugins['pivot-models'].Location.mongooseModel.findOne(query).then(function(location) {
                if (location)
                  return errors.returnError('too_close', reply);
                else
                  return reply();
              }).then(null, function(err) {
                return errors.returnError(err, reply);
              });
            }
          }]
      },
      handler: putLocation
    },
    {
      method: 'POST',
      path: options.basePath + '/v1/locations',
      config: {
        validate: {
          query: {
            publish: Joi.boolean().optional().default(false).description("publish after change")
          },
          payload:  Joi.object().keys({
            name: Joi.string().trim().required(),
            latitude: Joi.number().required().min(-90).max(90).description("latitude"),
            longitude: Joi.number().required().min(-180).max(180).description('longitude'),
            proximityRadius: Joi.number().optional().description("Radius for proximity checking in meteres"),
            streetAddress: server.plugins['pivot-models'].common.addressModel.optional(),
            createNewLandmark: Joi.boolean().default(false),
            landmarkDescription: Joi.string().trim()
          }).meta({className:"CreateNewLocation"}),
        },
        auth: {
          strategies: ['user-basic', 'user-bearer' ],
          scope: [ 'cms' ]
        },

        description: 'Create a new location',
        tags: ['api'],
        notes:  'Create a new location' ,
        response: {
          schema: server.plugins['pivot-models'].Location.locationDetailsModel,
          modify: true
        },
        pre: [
          publishAdminOnly,
          {
            assign: 'checkLocationName',
            method: function (request, reply) {
              return server.plugins['pivot-models'].Location.mongooseModel.findOne({
                  '$or': [
                    {'edit.name': request.payload.name },
                    {'published.name': request.payload.name},
                    {'edit.lc_info.name': request.payload.name.toLowerCase() },
                    {'published.lc_info.name': request.payload.name.toLowerCase()}
                  ],
                }
              ).then(function(location) {
                if (location)
                  return errors.returnError('duplicate_location', reply);
                else
                  return reply();
              }).then(null, function(err) {
                return errors.returnError(err, reply);
              });
            }
          },
          {
            assign: 'noCloseLocations',
            method: function(request, reply) {
              return reply();
              var query = {
                'loc.geo_location': {
                  "$near": {
                    '$maxDistance': Config.get('/limits/minSeperation'),
                    '$geometry': {
                      type: 'Point',
                      coordinates: [request.payload.longitude, request.payload.latitude]
                    }
                  }
                }
              };

              return server.plugins['pivot-models'].Location.mongooseModel.findOne(query).then(function(location) {
                if (location)
                  return errors.returnError('too_close', reply);
                else
                  return reply();
              }).then(null, function(err) {
                return errors.returnError(err, reply);
              });

            }
          }
        ]
      },
      handler: createLocation
    },
    {
      method: 'DELETE',
      path: options.basePath + '/v1/locations/{id}',
      config: {
        validate: {
          query: {
            version: Joi.string().optional().default("edit").description("published/edit version"),
            publish: Joi.boolean().optional().default(false).description("publish after change")
          },
          params: {
            id: Joi.objectId().required().description("location ID to delete"),
          }
        },
        auth: {
          strategies: ['user-basic', 'user-bearer' ],
          scope: [ 'cms' ]
        },
        description: 'Delete location',
        tags: ['api'],
        notes:  'Delete location' ,
        response: {
          schema: server.plugins['pivot-models'].Location.locationDetailsModel.required(),
          modify: true
        },
        pre: [
          pre.retrieveRecord('Location', 'id'),
          publishAdminOnly
        ],
        /*
        pre: [
          {
            assign: 'location',
            method: function (request, reply) {
              return server.plugins['pivot-models'].Location.mongooseModel.findById(request.params.id).then(function(location) {
                if (!location)
                  return errors.returnError('not_found', reply);
                else
                  return reply(location);
              }).then(null, function(err) {
                return errors.returnError(err, reply);
              });
            }
          }
        ]
        */
      },
      handler: deleteLocation
    },
    {
      method: 'POST',
      path: options.basePath + '/v1/locations/{id}/landmark',
      config: {
        validate: {
          query: {
            version: Joi.string().optional().default("edit").description("published/edit version"),
            publish: Joi.boolean().optional().default(false).description("publish after change")
          },
          payload:  Joi.object().keys({
            name: Joi.string().trim().required(),
            description: Joi.string().trim().allow(''),
            shortDescription: Joi.string().trim().allow('')
          }).meta({className:"CreateNewLandmarkForLocation"}),
          params: {
            id: Joi.objectId().required().description("location id to add landmark to"),
          }
        },
        auth: {
          strategies: ['user-basic', 'user-bearer' ],
          scope: [ 'cms' ]
        },

        description: 'Create a new landmark at a location',
        tags: ['api'],
        notes:  'Create a new landmark at a location',
        response: {
          schema: server.plugins['pivot-models'].Location.locationDetailsModel.required(),
          modify: true
        },
        pre: [
          publishAdminOnly,
          pre.retrieveRecord('Location', 'id'),
          preLocationVersion,

        ]
      },
      handler: newLandmarkForLocation
    },
    {
      method: 'POST',
      path: options.basePath + '/v1/locations/{id}/media',
      config: {
        validate: {
          query: {
            version: Joi.string().optional().default("edit").description("published/edit version"),
            publish: Joi.boolean().optional().default(false).description("publish after change")
          },
          payload:  Joi.object().keys({
            sizedUrls: Joi.array().min(1).items(server.plugins['pivot-models'].common.SizedURL),
            storageId: server.plugins['pivot-models'].common.storageIdModel.optional(),
            attachToLandmarks: Joi.boolean().default(true),
            type: Joi.string().default("photo").allow("photo"),
            showIn: Joi.string().default("hide").allow("slider").allow("modern").allow('hide')
          }).meta({className:"CreateNewMediaForLocation"}),
          params: {
            id: Joi.objectId().required().description("location id to add media to"),
          }
        },
        auth: {
          strategies: ['user-basic', 'user-bearer' ],
          scope: [ 'cms' ]
        },

        description: 'Create new media at a location',
        tags: ['api'],
        notes:  'Create a new media at a location',
        response: {
          schema: server.plugins['pivot-models'].Location.locationDetailsModel.required(),
          modify: true
        },
        pre: [
          pre.retrieveRecord('Location', 'id'),
          preLocationVersion,
          publishAdminOnly
        ]
      },
      handler: newMediaForLocation
    },
    {
      method: 'PUT',
      path: options.basePath + '/v1/locations/{id}/media/{mediaId}',
      config: {
        validate: {
          query: {
            version: Joi.string().optional().default("edit").description("published/edit version"),
            publish: Joi.boolean().optional().default(false).description("publish after change")
          },
          params: {
            mediaId: Joi.objectId().required().description("media ID to update"),
            id: Joi.objectId().required().description("locationId"),
          },
          payload: Joi.object().keys({
            caption: Joi.string().allow("").trim().optional(),
            relevanceStartDate: Joi.string().optional(),
            showIn: Joi.string().optional().allow("slider").allow("modern").allow('hide')
          }).meta({className: "ModifyMedia"})
        },
        auth: {
          strategies: ['user-basic', 'user-bearer' ],
          scope: [ 'cms' ]
        },
        description: 'Set media properties by id',
        tags: ['api'],
        notes:  'Set media properties by id' ,
        response: {
          schema: server.plugins['pivot-models'].Location.locationDetailsModel.required(),
          modify: true
        },
        pre: [
          publishAdminOnly,
          pre.retrieveRecord('Location', 'id'),
          preLocationVersion
        ]
      },
      handler: putMedia
    },
    {
      method: 'DELETE',
      path: options.basePath + '/v1/locations/{id}/media/{mediaId}',
      config: {
        validate: {
          query: {
            version: Joi.string().optional().default("edit").description("published/edit version"),
            publish: Joi.boolean().optional().default(false).description("publish after change")
          },
          params: {
            mediaId: Joi.objectId().required().description("media ID to update"),
            id: Joi.objectId().required().description("locationId"),
          },
        },
        auth: {
          strategies: ['user-basic', 'user-bearer' ],
          scope: [ 'cms' ]
        },
        description: 'delete media',
        tags: ['api'],
        notes:  'delete media' ,

        pre: [
          publishAdminOnly,
          pre.retrieveRecord('Location', 'id'),
          preLocationVersion
        ]
      },
      handler: deleteMedia
    },
    {
      method: 'DELETE',
      path: options.basePath + '/v1/locations/{id}/landmark/{landmarkId}',
      config: {
        validate: {
          query: {
            version: Joi.string().optional().default("edit").description("published/edit version"),
            publish: Joi.boolean().optional().default(false).description("publish after change")
          },
          params: {
            id: Joi.objectId().required().description("location to remove from"),
            landmarkId: Joi.objectId().required().description("landmark to remove from this location"),
          }
        },
        auth: {
          strategies: ['user-basic', 'user-bearer' ],
          scope: [ 'cms' ]
        },

        description: 'Remove landmark fron location',
        tags: ['api'],
        notes:  'Remove landmark fron location',
        response: {
          schema: server.plugins['pivot-models'].Location.locationDetailsModel.required(),
          modify: true
        },
        pre: [
          publishAdminOnly,
          pre.retrieveRecord('Location', 'id'),
          preLocationVersion
        ]
      },
      handler: deleteLandmarkFromLocation
    },
    {
      method: 'PUT',
      path: options.basePath + '/v1/locations/{id}/landmark/{landmarkId}',
      config: {
        validate: {
          query: {
            version: Joi.string().optional().default("edit").description("published/edit version"),
            publish: Joi.boolean().optional().default(false).description("publish after change")
          },
          params: {
            landmarkId: Joi.objectId().required().description("landmark ID to update"),
            id: Joi.objectId().required().description("locationId"),
          },
          payload: Joi.object().keys({
            shortDescription: Joi.string().allow("").trim().optional(),
            description: Joi.string().allow("").trim().optional(),
            defaultMediaId: Joi.string(),
            constructionDate: Joi.string(),
            removalDate: Joi.string()
          }).meta({className: "ModifyLandmark"})
        },
        auth: {
          strategies: ['user-basic', 'user-bearer' ],
          scope: [ 'cms' ]
        },
        description: 'Set landmark properties by id',
        tags: ['api'],
        notes:  'Set landmark properties by id' ,
        response: {
          schema: server.plugins['pivot-models'].Location.locationDetailsModel.required(),
          modify: true
        },
        pre: [
          publishAdminOnly,
          pre.retrieveRecord('Location', 'id'),
          preLocationVersion
        ]
      },
      handler: putLocationLandmark
    }
  ];
}
