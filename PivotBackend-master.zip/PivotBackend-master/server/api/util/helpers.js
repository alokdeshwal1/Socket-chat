/**
 * Created by keary on 9/16/15.
 */
'use strict';
var moment = require('moment');
var parse = require('url').parse;
var Config = require('../../../hapi-config.js');
exports.dateToIso = function(date) {
  return moment(date).utc().format("YYYY-MM-DDTHH:mm:ss.SSS") + "Z";
};

exports.realUrl = function(url) {
  if (!url)
    return undefined;
  var parsedUrl = parse(url);
  if (parsedUrl.protocol == 'http:' || parsedUrl.protocol == 'https:')
    return url;

  if (parsedUrl.protocol == 's3:') {
    url = Config.get("/baseUrl") + "/storage/media/s3" + parsedUrl.pathname;
    return url;
  } else {
    return undefined;
  }
}

exports.generateS3Url = function(path) {
  var url = "s3://" + Config.get("/s3/bucket") + '/' + encodeURIComponent(path);
  return url;
}
