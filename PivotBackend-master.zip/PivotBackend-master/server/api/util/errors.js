/**
 * Created by keary on 6/26/15.
 */
'use strict'
var Boom = require('boom');
var _ = require('lodash');

var errors = {
  email_taken: {
    message: "The e-mail address must be unique",
    statusCode: 409
  },
  bad_email: {
    message: 'Invalid e-mail format',
    statusCode: 400
  },
  duplicate_landmark: {
    message: "Landmark name must be unique",
    statusCode: 409
  },
  duplicate_location: {
    message: "Location name must be unique",
    statusCode: 409
  },
  invalid_clientid: {
    message: "Invalid ClientID",
    statusCode: 401
  },
  invalid_token: {
    statusCode: 404,
    message: "Token not valid"
  },
  forbidden: {
    statusCode: 403,
    message: "Operation forbidden"
  },
  not_found: {
    statusCode: 404,
    message: "Not Found"
  },
  bad_request: {
    statusCode: 400,
    message: 'Invalid request'
  },
  /* OAuth */
  invalid_grant: {
    statusCode: 400,
    error_description: 'Incorrect username/password or token'
  },
  invalid_client: {
    statusCode: 401,
    error_description: 'Invalid OAuth ClientID'
  },
  unsupported_grant_type: {
    statusCode: 400,
    error_description: 'Invalid grant type'
  },
  too_close: {
    statusCode: 400,
    message: "Another location already exists very close to this latitude/longitude"
  }
}

var errorFunc = exports.err = function(errorType, responseObject) {

  var error = errors[errorType];

  if (!error)
    return Boom.badImplementation();

  var b = Boom.create(error.statusCode, error.message);

  if (!responseObject)
    responseObject = { };
  else if (typeof responseObject == 'string')
    responseObject = { message: responseObject };

  if (!responseObject.hasOwnProperty("statusCode"))
    responseObject.statusCode = error.statusCode;

  if (!responseObject.hasOwnProperty("message"))
    responseObject.message = error.message || error.error_description || b.output.payload.message;

  if (!responseObject.hasOwnProperty("error"))
    responseObject.error = errorType;

  if (!responseObject.hasOwnProperty("error_class"))
    responseObject.error_class = error.error_class || b.output.payload.error;

  if (!responseObject.hasOwnProperty("error_description") && error.error_description)
    responseObject.error_description = error.error_description;

  b.output.payload = responseObject;
  return b;
}

exports.returnError = function(err, reply, message) {
  if (typeof err === 'object' && err.isBoom)
    return reply(err);

  if (typeof err === 'string' && errors[err])
    return reply(errorFunc(err, message));

  return reply(Boom.badImplementation(err));

}
