/**
 * Created by keary on 9/16/15.
 */
/**
 * Created by keary on 6/14/15.
 */
'use strict';
var knox = require('knox');
var moment = require('moment');
var crypto = require('crypto');
var  url = require('url');
//var uuid = require('node-uuid');
var Config = require('../../../hapi-config.js');
//var helper = require('./helper.js');

var S3Client = knox.createClient({ key: Config.get("/s3/key"), secret: Config.get("/s3/secret"), bucket: Config.get("/s3/bucket")});
var cloudFront = Config.get("/s3/cloudfront");

exports.url = function(path) {
  if (cloudFront) {
    return cloudFront + '/' + path;
  } else {
    return S3Client.url(path);
  }
}

exports.generatePut = function(objectId, contentType, expires) {

  var name = Config.get("/s3/prefix") + objectId.toString();
  var signedUrl = S3Client.signedUrl(name, expires, {contentType: contentType, verb: 'PUT' });

  return { name: name, signedUrl: signedUrl, url: S3Client.url(name) };
};
