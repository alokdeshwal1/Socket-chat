/**
 * Created by keary on 8/24/15.
 */
/**
 * Created by keary on 8/14/15.
 */
'use strict';

var Joi = require('joi');
Joi.objectId = require('joi-objectid');
var _ = require('lodash');
var mongoose = require('mongoose');
var paginate = require('mongoose-range-paginate');
var Boom = require('boom');
var geo = require('./util/geo.js');
var Async = require('async');
var helpers = require('./util/helpers.js');
var apiCommon = require('./api-common.js');
var errors = require('./util/errors.js');
var moment = require('moment');

exports = module.exports = function(server, options) {


  function getAuditLog(request, reply) {

    return request.pre.AuditLog.toRestObject().then(function(logEntry) {
      return reply(logEntry);
    }).then(null, function(err) {
      if (err.isBoom)
        return reply(err);
      return reply(Boom.badImplementation());
    })
  }

  function auditLogsForLocation(request, reply) {
    var constraints = {
      objectType: 'Location',
      objectId: mongoose.Types.ObjectId(request.params.id)
    };

    var sortKey = 'createdAt';
    var sort = '-' + sortKey;

    var paginateOptions = {
      limit: request.query.limit,
      sort: sort
    }

    if (request.query.more) {
      var more = request.query.more.split(/:(.+)?/);
      if (more.length >= 2) {
        paginateOptions.startId = mongoose.Types.ObjectId(more[0]);
        paginateOptions.startKey = moment.utc(more[1]).toDate();
      }

    }

    var limit = request.query.limit;
    var query = mongoose.models.AuditLog.find().where(constraints);

    return paginate(query, paginateOptions).exec(function (err, logs) {
        if (err) {
          return reply(Boom.badImplementation(err));
        }

        Async.map(logs, function(log, done) {
          return log.toRestObject().then(function(log) {
            done(null, log);
          }).then(null, function(err) {
            done(err);
          });
        }, function(err, result) {
          if (err) {
            console.log(err.stack);
            return reply(Boom.badImplementation(err.toString()));
          }

          var ret = {
            logs: result
          };
          if (logs.length == limit) {
            ret.more = logs[limit-1]._id.toString() + ":" + moment.utc(logs[limit-1].get(sortKey)).format();
          }
          return reply(ret);
        });
      }
    );
  }




  var pre = server.plugins['pivot-pre'];

  return [
    {
      method: 'GET',
      path: options.basePath + '/v1/admin/audit/{id}',
      config: {
        validate: {
          params: {
            id: Joi.objectId().required().description("landmark ID to retrieve")
          }
        },
        auth: {
          strategies: ['user-basic', 'user-bearer' ],
          scope: [ 'cms-admin' ]
        },

        description: 'Retrieve audit log entry',
        tags: ['api' ],
        notes:  'Retrieve audit log entry' ,
        response: {
          schema: server.plugins['pivot-models'].AuditLog.restModel.required(),
          modify: true
        },
        pre: [
          pre.retrieveRecord('AuditLog', 'id')
        ]
      },
      handler: getAuditLog
    },
    {
      method: 'GET',
      path: options.basePath + '/v1/admin/audit/location/{id}',
      config: {
        validate: {
          query: {
            limit: Joi.number().optional().default(250).description("maximum number of results"),
            more: Joi.string().optional().description("if included, returns only results not included in previous request that returned this more value"),
          },
          params: {
            id: Joi.objectId().description("location id")
          }
        },
        auth: {
          strategies: ['user-basic', 'user-bearer' ],
          scope: [ 'cms-admin' ]
        },
        description: 'Retrieve audit logs for a location',
        tags: ['api' ],
        notes: 'Retrieve audit logs for a location',
        response: {
          schema: Joi.object().keys(
            {
              more: Joi.string().optional().description("If returned, there are more results.  Pass this value to the next call."),
              logs: Joi.array().items(server.plugins['pivot-models'].AuditLog.restModel).required()
            }).meta({className: "AuditLogLocationResult"}),
          modify: true
        },
      },
      handler: auditLogsForLocation
    },

  ];
}
