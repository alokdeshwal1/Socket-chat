/**
 * Created by keary on 8/24/15.
 */
/**
 * Created by keary on 8/14/15.
 */
'use strict';

var Joi = require('joi');
Joi.objectId = require('joi-objectid');
var _ = require('lodash');
var mongoose = require('mongoose');
var paginate = require('mongoose-range-paginate');
var Boom = require('boom');
var geo = require('./util/geo.js');
var Async = require('async');
var helpers = require('./util/helpers.js');
var apiCommon = require('./api-common.js');
var errors = require('./util/errors.js');

exports = module.exports = function(server, options) {

  function getLandmark(request, reply) {

    var type = request.query.version;
    console.log(type);
    var q = { };

    q[type + '.landmarks'] =  { '$elemMatch': { '_id': mongoose.Types.ObjectId(request.params.id) } }

    var landmark;
    var obj;
    return mongoose.models.Location.findOne(q).then(function(location) {
      if (!location)
        return Promise.reject(Boom.notFound());
      obj = location[type];
      landmark = location.landmarkObject(request.params.id, type);
      return location.toDetailRestObject({ type: type });
    }).then(function(location) {
      landmark.media = location.media;
      if (!request.query.includeHiddenMedia) {
        landmark.media = _.reject(landmark.media, function(m) { return m.showIn == 'hide' } );
      }
      landmark.locations = [ { id: location.location.properties.id, name: location.location.properties.name, geo_latlon: location.location.properties.geo_latlon}]
      return reply(landmark);
    }).then(null, function(err) {
      console.log(err.stack);
      if (err.isBoom)
        return reply(err);
      else
        return reply(Boom.badImplementation(err.toString()));
    });
  }

  function searchLandmarks(request, reply) {

    return apiCommon.searchLandmarks(request).then(function(result) {
      return reply(result);
    }).then(null, function(err) {
      console.log(err);
      console.log(err.stack);
      return errors.returnError(err, reply);
    });
  }


  var pre = server.plugins['pivot-pre'];

  return [
    {
      method: 'GET',
      path: options.basePath + '/v1/landmark/{id}',
      config: {
        validate: {
          query: {
            version: Joi.string().valid('published').valid('edit').default('published').optional(),
            includeHiddenMedia: Joi.boolean().optional().default(false)
          },
          params: {
            id: Joi.objectId().required().description("landmark ID to retrieve")
          }
        },
        auth: {
          strategies: ['user-basic', 'user-bearer' ],
          scope: [ 'user', 'api', 'trusted-api' ]
        },

        description: 'Retrieve landmark by id',
        tags: ['api', 'mobile'],
        notes:  'Retrieve landmark by id' ,
        response: {
          schema: server.plugins['pivot-models'].Landmark.restModel.required(),
          modify: true
        }
      },
      handler: getLandmark
    },
    {
      method: 'GET',
      path: options.basePath + '/v1/landmark/search',
      config: {
        validate: {
          query: Joi.object().keys({
            search: Joi.string().allow("").description("Term to search for"),
            latitude: Joi.number().optional().min(-90).max(90).description("latitude of current location"),
            longitude: Joi.number().optional().min(-180).max(180).description('longitude of current location'),
            limit: Joi.number().optional().default(50).description("maximum number of results"),
            more: Joi.string().optional().description("if included, returns only results not included in previous request that returned this more value"),
            version: Joi.string().optional().valid('published').valid('edit').default("published").description("Retrieve published/edit version")
          }).and('latitude', 'longitude')
        },
        auth: {
          strategies: ['user-basic', 'user-bearer' ],
          scope: [ 'user', 'api', 'trusted-api' ]
        },
        description: 'Search landmarks',
        tags: ['api', 'mobile'],
        notes:  'Search landmarks' ,
        response: {
          schema: Joi.object().keys({
            landmarks: Joi.array().min(0).items(Joi.object().keys({
              landmark: Joi.object().keys({
                id: Joi.string(),
                name: Joi.string(),
              }).meta({className: "shortLandmark"}),
              locations: Joi.array().min(0).items(server.plugins['pivot-models'].common.locationReferenceModel),
              score: Joi.number(),
              thumbnailUrl: Joi.string().allow('').uri(),
              description: Joi.string().allow('')
            }).meta({className: "LandmarkSearchResult"})),
            more: Joi.string().optional().description("If returned, there are more results.  Pass this value to the next call.")
          }).meta({className: 'LandmarkSearchResults'}),
          modify: true
        }
      },
      handler: searchLandmarks
    }
  ];
}
