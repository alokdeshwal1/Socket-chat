/**
 * Created by keary on 9/24/15.
 */
"use strict";

var _ = require('lodash');
var mongoose = require('mongoose');
var helpers = require('./util/helpers.js');

var shortDesc = exports.shortDesc = function(desc) {
  if (!desc)
    return desc;
  if (desc.length <= 58)
    return desc;
  return desc.substr(0, 58).trim() + "...";
}

exports.searchLandmarks = function(request) {

  var server = request.server;

  var haveLocation;
  var latitude, longitude;
  if (request.query.latitude === undefined || request.query.longitude === undefined)
    haveLocation = false;
  else {
    latitude = Number(request.query.latitude);
    longitude = Number(request.query.longitude);
    haveLocation = true;
  }

  var searchTerm = request.query.search;

  if (!haveLocation && !searchTerm)
    return Promise.resolve({ landmarks: [ ] });

  var landmark = request.server.plugins['pivot-models'].Landmark.mongooseModel;
  var from = Number(request.query.more || 0);
  var limit = request.query.limit;

  var query;

  if (searchTerm)
    query = {
      "bool": {
        "should": [{
          "match": {
            "name": {
              "query": searchTerm,
              "type": "phrase_prefix",
              "slop": 3,
              "boost": 2
            }
          }
        },
          {
            "match": {
              "name": {
                "query": searchTerm,
                "fuzziness": "2",
                "operator":  "and"
              }
            }
          }
        ]
      }
    };
  else
    query = { "match_all": { } };
  var queryBody;
  if (haveLocation) {
    queryBody = {
      "function_score": {
        "functions": [
          {
            "gauss": {
              "locations.geo_latlon": {
                "origin": latitude + ", " + longitude,
                "scale": "50mi"
              }
            },
            weight: 3
          }
        ],
        "query": query,
        "boost_mode": "sum"
      }
    }
  } else {
    queryBody = query;
  }

  var esQuery = {
    body: {
      query: queryBody
    },
    index: (request.query.version == 'edit') ? 'landmarks-edit' : 'landmarks',
    type: 'landmark',
    from: from,
    size: limit
  };


  return new Promise(function(resolve, reject) {

    server.app.esClient.search(
      esQuery ,function(err, results) {
        if (err || !results || !results.hits) {
          return reject(Boom.badImplementation(err));
        }
        else {
          var ret = {
            landmarks: [ ]
          };
          if (results.hits.total > from + limit)
            ret.more = (from + limit).toString();
          _.each(results.hits.hits, function(hit) {
            var thumbnailUrl = hit._source.thumbnailUrl;
            if (!thumbnailUrl)
              thumbnailUrl = "s3://bucket.name/assets/no-image-available.png";
            var landmark = {
              landmark: {
                id: hit._id.toString(),
                name: hit._source.name,
              },
              score: hit._score,
              locations: [ ],
              thumbnailUrl: helpers.realUrl(thumbnailUrl),
              description: hit._source.shortDescription || ''//hit._source.description
            };
            /*
            if (landmark.description && landmark.description.length > 58) {
              landmark.description = shortDesc(landmark.description);
            }
            */
            _.each(hit._source.locations, function(loc) {
              landmark.locations.push({
                id: loc._id,
                //name: loc.name,
                geo_latlon: loc.geo_latlon
              });
            });

            ret.landmarks.push(landmark);
          })
        }
        return resolve(ret);
      });
  });
}

