/**
 * Created by keary on 9/13/15.
 */
/**
 * Created by keary on 8/24/15.
 */
/**
 * Created by keary on 8/14/15.
 */
'use strict';

var Joi = require('joi');
Joi.objectId = require('joi-objectid');
var _ = require('lodash');
var mongoose = require('mongoose');
var paginate = require('mongoose-range-paginate');
var Boom = require('boom');
var geo = require('./util/geo.js');
var Async = require('async');
var Promise = require('bluebird');

function getTours(request, reply) {
  return mongoose.models.TourStop.find().distinct('tourId').then(function(tourIds) {
    return new Promise(function(resolve, reject) {
      Async.map(tourIds, function(tourId, done) {
        return mongoose.models.TourStop.findOne({ 'tourId': tourId}).then(function(tour) {
          return done(null, {
            tourId: tour.tourId,
            tourName: tour.tourName
          });
        }).catch(function(err) {
          return done(err);
        })
      }, function(err, results) {
        if (err)
          return reject(err);
        else
          return resolve(results);
      });
    });
  }).then(function(results) {
    return reply({
      tours: results
    });
  }).catch(function(err) {
    if (err.isBoom)
      return reply(err);
    return reply(Boom.badImplementation(err));
  });
}

function getTourStopsById(request, reply) {
  return mongoose.models.TourStop.find({ 'tourId': request.params.id}).then(function(tourStops) {
    if (!tourStops.length)
      return Promise.reject(Boom.notFound());

    return Promise.all(_.map(tourStops, function(tourStop) {
      return tourStop.toRestObject();
    }));
  }).then(function(tourStops) {

    var tour = {
      tourId: tourStops[0].tourId,
      tourName: tourStops[0].tourName
    };

    return reply({
      tour: tour,
      tourStops: tourStops
    })

  }).catch(function(err) {
    if (err.isBoom)
      return reply(err);
    return reply(Boom.badImplementation(err));
  });
}

exports = module.exports = function(server, options) {

  return [
    {
      method: 'GET',
      path: options.basePath + '/v1/tours',
      config: {
        /*
        validate: {
          params: {
            id: Joi.objectId().required().description("media ID to retrieve"),
          }
        },
        */
        auth: {
          strategies: ['user-basic', 'user-bearer' ],
          scope: [ 'user', 'api', 'trusted-api' ]
        },
        description: 'Retrieve lists of tours',
        tags: ['api'],
        notes: 'Retrieve lists of tours',
        response: {
          schema:  Joi.object().keys({
            tours: Joi.array().min(0).items(server.plugins['pivot-models'].common.tourReferenceModel)
          }).meta({className: "GetToursResponse"}),
          modify: true
        }
      },
      handler: getTours
    },
    {
      method: 'GET',
      path: options.basePath + '/v1/tours/{id}',
      config: {
        validate: {
          params: {
            id: Joi.string().required().description("TourId to retrieve")
          }
        },
        auth: {
          strategies: ['user-basic', 'user-bearer' ],
          scope: [ 'user', 'api', 'trusted-api' ]
        },
        description: 'Retrieve Stops on a tour',
        tags: ['api'],
        notes: 'Retrieve stops on a tour',
        response: {
          schema:  Joi.object().keys({
            tour: server.plugins['pivot-models'].common.tourReferenceModel,
            tourStops: Joi.array().min(0).items(server.plugins['pivot-models'].TourStop.restModel)
          }).meta({className: "GetTourByIdResponse"}),
          modify: true
        }
      },
      handler: getTourStopsById
    }
  ];
}
