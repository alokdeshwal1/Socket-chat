/**
 * Created by keary on 9/18/15.
 */
'use strict';

//var Config = require.main.require('./hapi-config.js');
var errors = require('../api/util/errors.js');


exports.register = function (server, options, next) {

  options = options || { };

  server.expose('retrieveRecord', function(modelName, idName, type, allowNull) {
    return {
      assign: modelName,
      method: function (request, reply) {
        type = type || 'params';
        var id = request[type][idName];
        if (allowNull && !id)
          return reply();
        return server.plugins['pivot-models'][modelName].mongooseModel.findById(id).then(function (record) {
          if (!record)
            return errors.returnError('not_found', reply);
          else
            return reply(record);
        }).catch(function (err) {
          return errors.returnError(err, reply);
        });
      }
    }

  });


  next();
};


exports.register.attributes = {
  name: 'pivot-pre'
};
