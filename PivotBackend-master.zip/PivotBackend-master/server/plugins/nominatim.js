/**
 * Created by keary on 9/25/15.
 */
'use strict';

var rest = require('restler');
var Config = require.main.require('./hapi-config.js');
var _ = require('lodash');

exports.register = function (server, options, next) {

  options = options || {};

  function nominatimCompletionSearch(search, done) {
    search = search.toLowerCase();
    var options = {
      format: 'json',
      key: Config.get("/mapquest/consumerKey"),
      limit: 4,
      addressdetails: 0,
      q: search,
      "accept-language": "en"
    }
    var nurl = Config.get("/mapquest/nominatimUrl") + '/v1/search.php';
    rest.get(nurl, {
      timeout:7000,
      query: options
    }).on('timeout', function() {
      return done(new Error("timeout"));
    }).on('complete', function(result, response) {
      if (result instanceof Error)
        return done(result);
      if (!response || response.statusCode != 200)
        return done(new Error("Error retrieving locations"));

      return done(null, _.map(result, function(nom) {
        return {
          description: nom.display_name,
          latitude: Number(nom.lat),
          longitude: Number(nom.lon),
          type: 'location',
          bounds: [ [nom.boundingbox[0], nom.boundingbox[2]],
            [nom.boundingbox[1], nom.boundingbox[3]]]
        }
      }));
    });
}

  server.method('nominatimCompletionSearch', nominatimCompletionSearch, {
    cache: {
      cache: 'redisCache',
      expiresIn: 10 * 24 * 60 * 60 * 1000, // 10 days
      //staleIn: Config.get('/cache/defaultCacheStale'),
      //staleTimeout: Config.get('/cache/defaultCacheStaleTimeout'),
      segment: 'ncs'
    },
    generateKey: function(id) { return id.toLowerCase(); }
  });

  return next();


}

exports.register.attributes = {
  name: 'nominatim'
};
