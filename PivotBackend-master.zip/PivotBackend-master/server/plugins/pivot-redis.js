/**
 * Created by keary on 9/17/15.
 */

var Config = require.main.require('./hapi-config.js');
var redisClient;

exports.register = function (server, options, next) {

  options = options || { };
  var redis = require('redis-url').connect(Config.get("/redis/redisUrl"));

  redis.on('connect', function() {
    console.log("Redis connected.");
  });

  redis.on('ready', function() {
    console.log("Redis ready.");
  });

  redis.on('error', function(e) {
    console.log("Redis error.", e);
  });

  redis.on('end', function() {
    console.log("Redis ended.");
  });

  server.expose('redisClient', redis);
  server.app.redisClient = redis;
  redisClient = redis;


  next();
};

exports.getRedisClient = function() {
  return redisClient;
}

exports.register.attributes = {
  name: 'pivot-redis'
};
