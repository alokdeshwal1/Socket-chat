/**
 * Created by keary on 9/17/15.
 */
var Config = require.main.require('./hapi-config.js');

exports.register = function (server, options, next) {

  options = options || { };

  var mongoose = require('mongoose');

  var mongoConnected = false;

  var connectWithRetry = function() {
    var options = {
      server: {
        poolSize: 5,
        auto_reconnect: false,
        reconnectTries: 5,
        reconnectInterval: 1000,
        socketOptions: {keepAlive: 1}
      },
      replset: {
        socketOptions: {keepAlive: 1}
      }
    };
    return  mongoose.connect(Config.get("/mongodb/url"), options, function(err) {
      if (err) {
        console.error('Failed to connect to mongo on startup - retrying in 5 sec', err);
//            setTimeout(connectWithRetry, 5000);
      } else
        mongoConnected = true;
    });
  };

  var db = mongoose.connection;

  server.expose('db', db);
  server.expose('mongoose', mongoose);

  db.on('connecting', function() {
    console.log('connecting to MongoDB...');
  });

  db.on('error', function(error) {
    console.error('Error in MongoDb connection: ' + error);
    mongoose.disconnect();
  });
  db.on('connected', function() {
    console.log('MongoDB connected!');
  });
  db.once('open', function() {
    console.log('MongoDB connection opened!');
  });
  db.on('reconnected', function () {
    console.log('MongoDB reconnected!');
  });
  db.on('disconnected', function() {
    console.log('MongoDB disconnected!');
    mongoConnected = false;
    setTimeout(connectWithRetry, 5000);
  });


  db.once('open', function() {
    if (options.monkeyPatch) {
      var hapiMongoModel = require('hapi-mongo-models');
      hapiMongoModel.BaseModel.connect = function(config, callback) {
        hapiMongoModel.BaseModel.db = db;
        callback(null, hapiMongoModel.BaseModel.db);
      };
    }
    console.log("MongoDB connected.  continuing hapi.");
    next();
  });

  connectWithRetry();


//  next();
};


exports.register.attributes = {
  name: 'pivot-mongoose'
};
