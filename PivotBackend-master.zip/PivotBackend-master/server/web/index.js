var Config = require.main.require('./hapi-config.js');

exports.register = function (server, options, next) {

  server.route({
      method: 'GET',
      path: '/',
      handler: function (request, reply) {
          //return reply.view('index.html');
        return reply().redirect('/index.html');
      }
  });

  server.route({
    method: 'GET',
    path: '/application.json',
    handler: function (request, reply) {
      var config = {
        "name": "Pivot The World",
        "mapquest": Config.get("/mapquest"),
        "swaggerUrl": Config.get("/baseUrl") + "/swaggerdoc"
      };
      return reply(config);
    }
  });


  if (process.env.BROWSERSYNC_PROXY) {

    var host;
    var port = 80;
    var p = process.env.BROWSERSYNC_PROXY.split(':');

    host = p[0];
    if (p.length > 1)
      port = p[1];

    server.route([
      {
        method: '*',
        path: '/{param*}',
        handler: {
          proxy: {
            host: host,
            port: port,
            //uri: process.env.BROWSERSYNC_PROXY,
            protocol: 'http',
            passThrough: true,
            xforward: true
          }
        }
      }
    ]);
  } else {
    server.route({
      method: 'GET',
      path: '/{param*}',
      handler: {
        directory: {
          path: 'www'
        }
      }
    });

  }


    next();
};


exports.register.attributes = {
    name: 'web'
};
