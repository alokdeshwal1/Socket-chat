'use strict';

var mongoose = require('mongoose');
var Joi = require('joi');
var Promise = require('bluebird');
var Schema = mongoose.Schema;
var _ = require('lodash');
var common = require('./common.js');
var mediaModel = require('./media-model.js');
var landmarkModel = require('./landmark-model.js');
var tourModel = require('./tourstop-model.js');
var timestamps = require('mongoose-timestamp');

var server;

var locationProperties = Joi.object().keys({
  id: Joi.string().required().description("Location ID"),
  name: Joi.string().required().description("Location name"),
  locationType: Joi.array().items(Joi.string().allow("region").allow("tour").allow("landmark").allow("vantage").allow("panorama")).description("Array of types"),
  caption: Joi.string().description("Caption for map display"),
  streetAddress: common.addressModel,
  //landmarks: Joi.array().min(0).items(common.landmarkReferenceModel),
  landmarks: Joi.array().min(0).items(landmarkModel.restModel),
  geo_latlon: common.latLonModel,
  tourInfo: Joi.array().min(0).items(tourModel.restModel),
  institution: Joi.string().allow(''),
  pendingChanges: Joi.boolean().optional(),
  proximityRadius: Joi.number().optional()

}).meta({className: 'LocationProperties'});

var locationRestSchema = Joi.object().keys({
  type: Joi.string().required().allow('Feature'),
  geometry: common.geoJson,
  properties: locationProperties
}).meta({className: 'Location'});

var locationDetailsModel = Joi.object().keys({
  location: locationRestSchema,
  defaultInfoCard: common.infoCardSchema,
  //landmarks: Joi.array().min(0).items(landmarkModel.restModel),
  media: Joi.array().min(0).items(mediaModel.restModel),
  maintainerNotes: Joi.string().allow(""),
  isDeleted: Joi.boolean(),
  isHidden: Joi.boolean(),
  editVersion: Joi.string().allow(''),
  publishedVersion: Joi.string().allow(''),
  thisVersion: Joi.string().allow(''),
}).meta({className: 'LocationDetails'});

var locationDataSchema = {
  name: {type: String},
  lc_info: { },
  //  type: { type: Array },
  loc: {
    asEntered: {type: mongoose.Schema.Types.Mixed},
    geo_location: {type: mongoose.Schema.Types.Mixed},
    geo_latlon: common.latLonModel,
    geohash: ''
  },
  //caption: { type: String },
  streetAddress: {type: mongoose.Schema.Types.Mixed}, /*{
   street: {type: String },
   street2: {type: String },
   city: {type: String },
   province: {type: String },
   postal: {type: String }
   }*/
  landmarks: [{
    name: "",
    defaultInfoCard: {},
    shortDescription: "",
    constructionDate: "",
    removalDate: "",
    internal: { }
  }],
  tourInfo: [
    {
      _id: {type: mongoose.Schema.Types.ObjectId},
      tourName: "",
      tourId: "",
      tourStopName: "",
      tourStopSequence: ""
    }
  ],
  proximityRadius: Number,
  maintainerNotes: {type: String},
  media: [mediaModel.mongooseSchema],
  isDeleted: mongoose.Schema.Types.Boolean,
  isHidden: mongoose.Schema.Types.Boolean,
  version: mongoose.Schema.Types.ObjectId,
};

var LocationSchema = mongoose.Schema({
  edit: locationDataSchema,
  published: locationDataSchema,
  institution: '',
  pendingChanges: mongoose.Schema.Types.Boolean,
});
LocationSchema.plugin(timestamps);

LocationSchema.index({ 'edit.loc.geo_location': '2dsphere'});
LocationSchema.index({ 'edit.name': 1 }, { unique: false }); // schema level
LocationSchema.index({ 'edit.location._id': 1 }); // schema level
LocationSchema.index({ 'published.loc.geo_location': '2dsphere'});
LocationSchema.index({ 'published.name': 1 }, { unique: false }); // schema level
LocationSchema.index({ 'published.location._id': 1 }); // schema level

LocationSchema.index({ 'institution': 1 }); // schema level

LocationSchema.methods.toRestObject = function(options) {
  options = options || { };
  var type = options.type || 'edit';
  var obj = this[type];
  var ret = {
    type: 'Feature',
    geometry: obj.loc.geo_location,
    properties: {
      id: this._id.toString(),
      name: obj.name,
      institution: this.institution,
      locationType: [],
      caption: /*this.caption || */obj.name,
      proximityRadius: obj.proximityRadius,
      streetAddress: obj.streetAddress,
      landmarks: _.map(obj.landmarks, function(landmark) {
        return {
          name: landmark.name,
          id: landmark._id.toString()
        }
      }),
      tourInfo: _.map(obj.tourInfo, function(tour) {
        return {
          //institutionId: tour.institutionId.toString(),
          id: tour._id,
          tourName: tour.tourName,
          tourId: tour.tourId.toString(),
          tourStopName: tour.tourStopName,
          tourStopSequence: tour.tourStopSequence
        }
      }),
      geo_latlon: common.toGeoLatLon(obj.loc.geo_location),
      pendingChanges: this.pendingChanges
    }
  };

  if (obj.landmarks && obj.landmarks.length)
    ret.properties.locationType.push('landmark');
  if (obj.tourInfo && obj.tourInfo.length)
    ret.properties.locationType.push('tour');
  if (obj.loc.geo_location.type != 'Point')
    ret.properties.locationType.push('region');

  return Promise.resolve(ret);
}

function toLatLon(geoJson) {
  var pt;

  if (geoJson.type == 'Polygon')
    pt = gju.centroid(geoJson);
  else
    pt = geoJson;
  var latlon = {
    lat: pt.coordinates[1],
    lon: pt.coordinates[0]
  }
  return latlon;

}

function landmarkToRestObject(landmark) {
  if (!landmark)
    return landmark;
  var l = _.extend({ }, landmark.toObject());
  l.id = l._id.toString();
  delete l._id;
  delete l.internal;
  return l;
}

LocationSchema.methods.landmarkObject = function(id, type) {
  var type = type || 'edit';
  var obj = this[type];
  return landmarkToRestObject(obj.landmarks.id(id));
}

LocationSchema.virtual('originalEditVersion').get(function () {
  return this.__originalEditVersion;
}).set(function (originalEditVersion) {
  this.__originalEditVersion = originalEditVersion;
});

LocationSchema.methods.toDetailRestObject = function(options) {
  options = options || { };
  var type = options.type || 'edit';
  var self = this;
  var obj = this[type];
  var ret = { };
  return self.toRestObject(options).then(function(basicLocationObject) {
    ret.location = basicLocationObject;
    ret.maintainerNotes = obj.maintainerNotes;
    ret.publishedVersion = self.published.version ? self.published.version.toString() : '';
    ret.editVersion = self.originalEditVersion ? self.originalEditVersion.toString() : self.edit.version.toString() ;
    ret.thisVersion = (type == 'edit') ? self.edit.version.toString()  : ret.publishedVersion;
    ret.isDeleted = obj.isDeleted;
    ret.isHidden = obj.isHidden;

    ret.location.properties.landmarks = _.map(obj.landmarks, landmarkToRestObject);
    var defaultInfoCard;

    var landmarks = ret.location.properties.landmarks || [];
    if (!defaultInfoCard && ret.location.properties.landmarks && ret.location.properties.landmarks.length)
      defaultInfoCard = ret.location.properties.landmarks[0].defaultInfoCard;
    if (defaultInfoCard)
      ret.defaultInfoCard = defaultInfoCard;
    var promises = _.map(obj.media, function (media) {
      return media.toRestObject();
    })
    return Promise.all(promises);
  }).then(function(medias) {
    ret.media = medias;
  }).then(function() {
    //console.log(JSON.stringify(ret, null, 4));
    return Promise.resolve(ret);
  });
}

LocationSchema.pre('save', function(next) {
  var self = this;
  _.each(['published', 'edit'], function(type) {
    var rec = self[type];
    if (!rec.lc_info)
      rec.lc_info = { };
    rec.lc_info.name = rec.name ? rec.name.toLowerCase() : '';
    rec.lc_info.streetAddress = { };
    _.each(rec.streetAddress, function(val, key) {
      rec.lc_info.streetAddress[key] = val.toLowerCase();
    });

    _.each(rec.landmarks, function(landmark) {
      if (!landmark.internal)
        landmark.internal = { };
      if (!landmark.internal.lc_info)
        landmark.internal.lc_info = { };
      landmark.internal.lc_info.name = landmark.name.toLowerCase();
    });
  });
  next();
});

//LocationSchema.index({ objectId: -1, dataType: -1}); // schema level
//LocationSchema.index({ objectId: -1, accountId: -1, dataType: -1  }, { unique: true }); // schema level

  var myexports = module.exports = {
    init: function(_server) { server = _server; return myexports; },
    mongooseModel: mongoose.model('Location', LocationSchema),
    restModel: locationRestSchema,
    locationDetailsModel: locationDetailsModel
  };
