/**
 * Created by keary on 9/16/15.
 */
/**
 * Created by keary on 6/15/15.
 */
'use strict';
var mongoose = require('mongoose');
var timestamps = require('mongoose-timestamp');
var Config = require('../../hapi-config.js');

var server;

var MediaStorageSchema = mongoose.Schema({
  userId: mongoose.Schema.ObjectId,
  type: { type: String, default: 's3' },
  category: { type: String, default: 'photo' },
  addCount: { type: Number, deafult: 0 },
  contentType: String,
  path: String,
  bucket: { type: String, default: Config.get("/s3/bucket") },
  isUsed: { type: Boolean, default: false },
  isDeleted: { type: Boolean, default: false },
  mediaId: mongoose.Schema.ObjectId
});
MediaStorageSchema.plugin(timestamps);



var myexports = module.exports = {
  init: function(_server) { server = _server; return myexports },
  mongooseModel: mongoose.model('MediaStorage', MediaStorageSchema),
  //restModel: mediaRestSchema
};
