/**
 * Created by keary on 8/16/15.
 */
var common = require('./common.js');


exports.register = function (server, options, next) {
  server.expose('Media', require('./media-model.js').init(server));
  server.expose('Location', require('./location-model.js').init(server));
  server.expose('Landmark', require('./landmark-model.js').init(server));
  //server.expose('Media', require('./media-model.js').init(server));
  server.expose('Token', require('./token-model.js').init(server));
  server.expose('TourStop', require('./tourstop-model.js').init(server));
  server.expose('MediaStorage', require('./media-storage-model.js').init(server));
  server.expose('AuditLog', require('./audit-log-model.js').init(server));
  server.expose('common', common);
  next();
}


exports.register.attributes = {
  name: 'pivot-models'
};
