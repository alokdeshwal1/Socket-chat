'use strict';

var mongoose = require('mongoose');
var Joi = require('joi');
var Promise = require('bluebird');
var Schema = mongoose.Schema;
var mediaModel = require('./media-model.js');
var locationModel = require('./location-model.js');
var common = require('./common.js');

var _ = require('lodash');

var server;

var tourStopRestSchema = Joi.object().keys({
  id: Joi.string(),
  //institutionId: Joi.string(),
  tourName: Joi.string(),
  tourId: Joi.string().description("ID of the tour"),
  tourStopName: Joi.string(),
  tourStopSequence: Joi.string().allow("").optional(),
  defaultInfoCard: common.infoCardSchema,
  //locations: Joi.array().min(0).items(common.locationReferenceModel).description("Array of locations visible from tour stop"),
  //tourStopLocation: common.locationReferenceModel.description("Location ID of tour stop")
}).meta({className: 'TourStop'});

var TourStopSchema = mongoose.Schema({
  tourName: { type: String },
  tourId: { type: String },
  tourStopName: { type: String },
  tourStopSequence: { type: String },
  institutionId: { type: String },
  defaultHistoricalMedia: { type: mongoose.Schema.Types.ObjectId },
  defaultModernMedia: { type: mongoose.Schema.Types.ObjectId },
  defaultMedia: { type: mongoose.Schema.Types.ObjectId },
  description: { type: String  },
  //locations: [ common.locationReferenceModel ],
  //tourStopLocation: { }
});

TourStopSchema.index({ tourName: 1, tourStopName: 1 }, { unique: true }); // schema level
TourStopSchema.index({ tourId: 1, tourStopName: 1 }, { unique: true }); // schema level


TourStopSchema.methods.toRestObject = function() {
  var ret = {
    id: this._id.toString(),
    //institutionId: this.institutionId,
    tourId: this.tourId,
    tourName: this.tourName,
    tourStopName: this.tourStopName,
    tourStopSequence: this.tourStopSequence,
    defaultInfoCard: {
      description: this.description
    },
    /*
     tourStopLocation: {
      id: this.tourStopLocation.id.toString(),
      name: this.tourStopLocation.name
    },
    locations: _.map(this.locations, function(loc) {
      return { id: loc._id.toString(), name: loc.name, geo_latlon: loc.geo_latlon }
    })
    */
  };

  if (this.defaultMedia)
    ret.defaultInfoCard.defaultMediaId = this.defaultMedia.toString();
  else if (this.defaultHistoricalMedia)
    ret.defaultInfoCard.defaultMediaId = this.defaultHistoricalMedia.toString();
  else if (this.defaultModernMedia)
    ret.defaultInfoCard.defaultMediaId = this.defaultModernMedia.toString();

  return Promise.resolve(ret);
}

//LandmarkSchema.index({ objectId: -1, dataType: -1}); // schema level
//LandmarkSchema.index({ objectId: -1, accountId: -1, dataType: -1  }, { unique: true }); // schema level

  var myexports = module.exports = {
    init: function(_server) { server = _server; return myexports },
    mongooseModel: mongoose.model('TourStop', TourStopSchema),
    restModel: tourStopRestSchema
  };
