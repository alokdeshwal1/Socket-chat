'use strict';

var mongoose = require('mongoose');
var Joi = require('joi');
var Promise = require('bluebird');
var Schema = mongoose.Schema;
var mediaModel = require('./media-model.js');
var common = require('./common.js');
var Config = require('../../hapi-config.js');


var _ = require('lodash');

var server;

var landmarkRestSchema = Joi.object().keys({
  id: Joi.string(),
  name: Joi.string(),
  defaultInfoCard: common.infoCardSchema,
  shortDescription: Joi.string().allow(""),
  media: Joi.array().min(0).items(mediaModel.restModel),
  constructionDate: Joi.string().allow(''),
  removalDate: Joi.string().allow(''),
  locations: Joi.array().min(0).items(common.locationReferenceModel)
}).meta({className: 'Landmark'});

/*
var LandmarkSchema = mongoose.Schema({
  name: { type: String,  es_indexed: true },
  defaultHistoricalMedia: { type: mongoose.Schema.Types.ObjectId },
  defaultModernMedia:{ type: mongoose.Schema.Types.ObjectId },
  defaultMedia: { type: mongoose.Schema.Types.ObjectId },
  thumbnailUrl: { type: String, es_indexed: true, es_index: "no", es_include_in_all: false },
  referenceDir: {  },
  description: { type: String, es_indexed: true, es_index: "no", es_include_in_all: false },
  shortDescription: { type: String, es_indexed: true, es_index: "no", es_include_in_all: false  },
  locations: [{
    _id: { type: mongoose.Schema.Types.ObjectId, es_type: 'string', es_indexed: true, es_index: "no", es_include_in_all : false},
    name: { type: String, es_indexed: true, es_index: "no", es_include_in_all : false },
    geo_latlon: { type: Schema.Types.Mixed,
      es_indexed: true,
      es_type: "geo_point",
      es_lat_lon: true,
      es_tree: "quadtree",
      es_precision: "1km"
    },
    locationSpecificData: { },
  }],
  //media: []
});
*/

//LandmarkSchema.index({ name: 1 }, { unique: true }); // schema level

//LandmarkSchema.plugin(mongoosastic,{ esClient: esClient });
/*
LandmarkSchema.methods.toRestObject = function(options) {
  var options = options || { };
  var ret = {
    id: this._id.toString(),
    name: this.name,
    defaultInfoCard: {
      description: this.description,
    },
    locations: _.map(this.locations, function(loc) {
      return { id: loc._id.toString(), geo_latlon: loc.geo_latlon }
    }),
    media: [ ],
    shortDescription: this.shortDescription || '',
    locationSpecificData: { }
  };
  _.each(this.locations, function(loc) {
    ret.locationSpecificData[loc._id.toString()] = loc.locationSpecificData || { }
  });

  ret.referenceDirs = { };
  _.each(ret.locations, function(loc) {
    ret.referenceDirs[loc.id.toString()] = 0;
  });
  //referenceDir: this.referenceDir,

  if (this.defaultMedia)
    ret.defaultInfoCard.defaultMediaId = this.defaultMedia.toString();
  else if (this.defaultHistoricalMedia)
    ret.defaultInfoCard.defaultMediaId = this.defaultHistoricalMedia.toString();
  else if (this.defaultModernMedia)
    ret.defaultInfoCard.defaultMediaId = this.defaultModernMedia.toString();

  var q = { 'landmarks': { '$elemMatch': { '_id': this._id } } };
  return Promise.resolve([]).then(function (medias) {
    var promises;
    if (options.skipLandmarkMedia) {
      promises =
        _.map(medias, function(m) {
          return Promise.resolve({
            id: m._id.toString(),
            //type: m.type,

          });
        });
    } else {
      promises = _.map(medias, function (media) {
        return media.toRestObject();
      });
    }
    return Promise.all(promises);
  }).then(function (medias) {
    ret.media = medias;
  }).then(function () {
    if (ret.defaultInfoCard.defaultMediaId) {
      if (!_.find(ret.media, function(m) { return m.id == ret.defaultInfoCard.defaultMediaId } ))
        ret.defaultInfoCard.defaultMediaId = undefined;
    }
    console.log("LandmarkRet", ret.media);
    return Promise.resolve(ret);
  });
}
*/
//var LandmarkModel = mongoose.model('Landmark', LandmarkSchema);

/*
function createMappings(cb) {
  LandmarkModel.createMapping(function(err, mapping){
    if (err)
      console.log("error creating Landmark Mapping", err);
    cb(err);
  });
}
*/
//LandmarkSchema.index({ objectId: -1, dataType: -1}); // schema level
//LandmarkSchema.index({ objectId: -1, accountId: -1, dataType: -1  }, { unique: true }); // schema level

  var myexports = module.exports = {
    init: function(_server) { server = _server; return myexports },
    //mongooseModel: LandmarkModel,
    restModel: landmarkRestSchema,
    //createMappings: createMappings
  };
