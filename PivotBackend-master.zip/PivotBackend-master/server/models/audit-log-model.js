/**
 * Created by keary on 9/16/15.
 */
/**
 * Created by keary on 6/15/15.
 */
'use strict';
var mongoose = require('mongoose');
var timestamps = require('mongoose-timestamp');
var Config = require('../../hapi-config.js');
var Joi = require('joi');
var moment = require('moment');

var server;
var AuditLogSchema = mongoose.Schema({
  userId: mongoose.Schema.ObjectId,
  username: '',
  email: '',
  institution: '',
  description: '',
  objectType: '',
  objectId: mongoose.Schema.ObjectId,
  isPublish: mongoose.Schema.Types.Boolean,
  data: { }
});
AuditLogSchema.plugin(timestamps);

var auditLogRestModel = Joi.object().keys({
  editId: Joi.string(),
  userId: Joi.string().allow(''),
  username: Joi.string().allow(''),
  email: Joi.string().allow(''),
  institution: Joi.string().allow(''),
  description: Joi.string().allow(''),
  objectType: Joi.string(),
  objectId: Joi.string(),
  isPublish: Joi.boolean(),
  createdAt: Joi.string().allow('')
});

AuditLogSchema.methods.toRestObject = function(options) {
  var ret = {
    editId: this._id.toString(),
    userId: this.userId.toString(),
    username: this.username,
    email: this.email,
    institution: this.institution,
    description: this.description,
    objectType: this.objectType,
    objectId: this.objectId.toString(),
    isPublish: this.isPublish,
    createdAt: moment.utc(this.createdAt).format()
  }

  return Promise.resolve(ret);
}
var myexports = module.exports = {
  init: function(_server) { server = _server; return myexports },
  mongooseModel: mongoose.model('AuditLog', AuditLogSchema),
  restModel: auditLogRestModel
};
