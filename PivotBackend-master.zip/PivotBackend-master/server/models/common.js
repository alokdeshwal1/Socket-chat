/**
 * Created by keary on 8/26/15.
 */

var Joi = require('joi');
var gsu = require('geojson-utils');
var mongoose = require('mongoose');

exports.geoJson = Joi.object().description("GeoJSON location description").keys({
  type: Joi.string().description("GeoJSON shape type").allow('Polygon').allow('Point'),
  coordinates: Joi.array().description("Coordinates. Order is lon,lat")
}).meta({className: 'GeoJSON'});

exports.infoCardSchema = Joi.object().keys({
  description: Joi.string().allow(''),
  //historicalMediaId: Joi.string(),
  //modernMediaId: Joi.string()
  defaultMediaId: Joi.string()
}).description("Information card").meta({className: "InfoCard"});

exports.tourReferenceModel = Joi.object().keys({
  tourName: Joi.string(),
  tourId: Joi.string()
}).meta({className: 'TourReference'})

var latLonModel = exports.latLonModel = Joi.object().keys({
  lat: Joi.number(),
  lon: Joi.number()
});

exports.locationReferenceModel = Joi.object().keys({
  id: Joi.string().description("Location id"),
  name: Joi.string().allow('').optional().description("Location name"),
  geo_latlon: latLonModel
}).meta({className: 'LocationReference'});

exports.locationReferenceModelMongoose = {
  _id: { type: mongoose.Schema.Types.ObjectId },
  geo_latlon: { }
};

exports.landmarkReferenceModel = Joi.object().keys({
  id: Joi.string(),
  //name: Joi.string().allow('')
}).meta({className: 'LandmarkReference'});

exports.landmarkReferenceModelMongoose = {
  _id: { type: mongoose.Schema.Types.ObjectId },
};

exports.storageIdModel = Joi.object().keys({
  type: Joi.string().default('s3'),
  mediaId: Joi.string(),
  path: Joi.string()
}).meta({className: 'StorageId'});

exports.addressModel = Joi.object().description("Street address").keys({
  street: Joi.string(),
  street2: Joi.string(),
  city: Joi.string(),
  province: Joi.string(),
  postal: Joi.string(),
  country: Joi.string()
}).meta({className: 'Address'});

exports.locationSpecificDataModel = Joi.object().keys({
  constructionDate: Joi.string().allow(''),
  removalDate: Joi.string().allow('')
});

exports.toGeoLatLon = function(geoJson) {
  var pt;

  if (geoJson.type == 'Polygon')
    pt = gju.centroid(geoJson);
  else
    pt = geoJson;
  var latlon = {
    lat: pt.coordinates[1],
    lon: pt.coordinates[0]
  }
  return latlon;
}

exports.SizedURL = Joi.object().keys({
  url: Joi.string().required(),
  sizeType: Joi.string().optional(),
  width: Joi.number().optional(),
  height: Joi.number().optional()
}).meta({className: 'SizedURL'});
