'use strict';

var mongoose = require('mongoose');
var Joi = require('joi');
var Promise = require('bluebird');
var Schema = mongoose.Schema;
//var Config = require('../../hapi-config.js');
var _ = require('lodash');
var common = require('./common.js');
var helpers = require('../api/util/helpers.js');

var server;

var mediaRestSchema = Joi.object().keys({
  id: Joi.string(),
  type: Joi.string().allow("photo").allow("website").allow("panorama").allow("augmented"),
  caption: Joi.string().allow(''),
  description: Joi.string().min(0).allow(''),
  relevanceStartDate: Joi.string(),
  relevanceEndDate: Joi.string(),
  url: Joi.string().uri(),
  sizedUrls: Joi.array().items(common.SizedURL),
  showIn: Joi.string(),
  meta: Joi.object().keys({
    photoTakenDate: Joi.string(),
    photographerName: Joi.string().allow(''),
    copyrightInformation: Joi.string().allow(''),
    photographerWebsite: Joi.string().allow('')
  }).pattern(/.*/, Joi.any()).meta({className: 'PhotoMetadata'}).description("Additional metadata for this photo")
}).meta({className: 'Media'});

var MediaSchema = mongoose.Schema({
  type: { type: String },
  caption: { type: String },
  description: { type: String },
  relevanceStartDate: { type: String },
  relevanceEndDate: { type: String },
  url: { type: String },
  showIn: { type: String },
  sizedUrls: [],
  meta: { type: Schema.Types.Mixed },
});

MediaSchema.methods.toRestObject = function() {
  var ret = {
    id: this._id.toString(),
    type: this.type,
    caption: this.caption,
    description: this.description,
    relevanceStartDate: this.relevanceStartDate,
    relevanceEndDate: this.relevanceEndDate,
    meta: this.meta,
  };

  ret.showIn = this.showIn ? this.showIn : 'slider';

  ret.sizedUrls = _.map(this.sizedUrls, function(su) {
    var ret = _.extend({ }, su);
    ret.url = helpers.realUrl(su.url);
    return ret;
  });
  if (ret.sizedUrls.length)
    ret.url = ret.sizedUrls[ret.sizedUrls.length-1].url;
  else if (this.url) {
    ret.url = helpers.realUrl(this.url);
    ret.sizedUrls = [{
      url: ret.url,
      sizeType: 'original'
    }]
  }

  return Promise.resolve(ret);

}

var myexports = module.exports = {
  init: function(_server) { server = _server; return myexports; },
  //mongooseModel: mongoose.model('Location', LocationSchema),
  mongooseSchema: MediaSchema,
  restModel: mediaRestSchema,
  //locationDetailsModel: locationDetailsModel
};
