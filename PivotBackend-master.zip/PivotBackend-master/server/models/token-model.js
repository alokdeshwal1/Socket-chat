/**
 * Created by keary on 9/1/15.
 */

'use strict';
var server;

var mongoose = require('mongoose');
var timestamps = require('mongoose-timestamp');

var TokenSchema = mongoose.Schema({
  expires: Date,
  jti: String,
  styp: String,
  sctx: {
  },
  isRevoked: { type: Boolean, default: false }
});
TokenSchema.plugin(timestamps);

TokenSchema.index({ jti: 1 }); // schema level

  var myexports = module.exports = {
    init: function(_server) { server = _server; return myexports },
    mongooseModel: mongoose.model('Token', TokenSchema),
  };
