/**
 * Created by keary on 9/1/15.
 */

var Async = require('async');
var _ = require('lodash');
var Config = require.main.require('./hapi-config');
var mongoose = require('mongoose');
var fs = require('fs');
var path = require('path');

var moment = require('moment');
var jwt = require('jsonwebtoken');

var jwtSecret = Config.get("/oauth/jwtSecret");

var permissions = [ 'root', 'api', 'trusted-api', 'cms', 'cms-admin' ];
var server;
var tokenExpireSeconds = Config.get("/oauth/accessTokenExpireSeconds");

function jwtContext(user, clientId, cb) {

  if (typeof clientId == 'function') {
    cb = clientId;
    clientId = '';
  }

  return user.hydrateRoles(function(err, roles) {
    if (err)
      return cb(err);
    var account = (roles && roles.account) ? roles.account : null;
    var admin = (roles && roles.admin) ? roles.admin : null;

    var ctx = {
      userId: user._id.toString(),
      accountId: account ? account._id.toString() : '',
      displayName: account ? account.displayName : '',
      email: user.email,
      username: user.username,
      scope: [ 'user', 'user-' + user._id.toString() ]
    }

    if (account) {
      ctx.scope.push('account');
      ctx.scope.push('account-' + account._id.toString());
    }
    var fillPermissions = [ ];
    var hydrateGroups = function(cb) {
      cb(null, []);
    }
    if (admin) {
      ctx.scope.push('admin');
      ctx.adminId = admin._id.toString();
      ctx.scope.push('admin-' + admin._id.toString());
      fillPermissions = permissions;
      hydrateGroups = _.bind(admin.hydrateGroups, admin);
    }

    hydrateGroups(function(err, groups) {
      ctx.institution = '';
      _.each(groups, function(group) {
        var name = group.name;
        if (name.substr(0, 12) == 'institution-') {
          ctx.institution = name.substr(12);
          ctx.scope.push(name);
        }
      });
      if (clientId)
        ctx.clientId = clientId;

      Async.eachSeries(fillPermissions, function(perm, done) {
        admin.hasPermissionTo(perm, function(err, hasPermission) {
          if (!err && hasPermission)
            ctx.scope.push(perm);
          return done(err);
        });
      }, function(err) {
        return cb(null, ctx);
      });
    });

  });
  //return done(null, user ? { userId: user._id, isActive: user.isActive, username: user.username, roles: user.roles  } : null);
}
exports.jwtContext = jwtContext;

var verifyClientId = function(clientId, done) {
  var User = server.plugins['hapi-mongo-models'].User;

  User.findByUsername(clientId, function (err, user) {

    if (err) {
      return done(err);
    }
    if (!user || !user.isActive)
      return done(null, null);

    jwtContext(user, function(err, ctx) {
      if (err)
        return done(err);

      if (!_.contains(ctx.scope, 'api'))
        return done(null, null);

      return done(null, clientId);
    });

  });
}

function usernamePasswordValidate(username, password, clientId, callback) {

  if (typeof clientId == 'function') {
    callback = clientId;
    clientId = '';
  }

  Async.auto({
    user: function (done) {
      var User = server.plugins['hapi-mongo-models'].User;

      User.findByCredentials(username, password, function (err, user) {

        if (err) {
          return done(err);
        }
        if (!user || !user.isActive)
          return done(null, null);

        return jwtContext(user, clientId, function(err, ctx) {
          return done(err, ctx);
        });
      });
    }
  }, function (err, results) {

    if (err) {
      return callback(err);
    }

    if (!results.user) {
      return callback(null, false);
    }

    callback(null, true, results.user);
  });
}
exports.usernamePasswordValidate = usernamePasswordValidate;

function contextForUser(userId, clientId, callback) {

  Async.auto({
    user: function (done) {
      var User = server.plugins['hapi-mongo-models'].User;

      User.findById(userId, function (err, user) {

        if (err) {
          return done(err);
        }
        if (!user || !user.isActive)
          return done(null, null);

        return jwtContext(user, clientId, function(err, ctx) {
          return done(err, ctx);
        });
      });
    }
  }, function (err, results) {

    if (err) {
      return callback(err);
    }

    if (!results.user) {
      return callback(null, false);
    }

    callback(null, true, results.user);
  });
}

function generateJti() {
    var buf = new Buffer(16);
    require('node-uuid').v4({ }, buf);
    var jti = require('urlsafe-base64').encode(buf);

    return jti;
}

function saveToken(claims, expiresInSeconds, done) {

  var token = new mongoose.models['Token']();
  if (expiresInSeconds)
    token.expires = moment().add(expiresInSeconds, 'seconds').toDate();
  token.jti = claims.jti;
  token.sctx = claims.sctx;
  token.styp = claims.styp;

  return token.save(done);
}

function generateTokens(ctx, options, done) {

  var options = options || { };
  var typ = options.type || 'access';
  var expireSecs = options.expireSeconds || tokenExpireSeconds;
  var generateRefresh = options.generateRefresh;


  var jwtOptions = {
    expiresInSeconds: expireSecs,
    subject: ctx.userId
  };

  var claims = {
    styp: typ,
    sctx: ctx,
    jti: generateJti()
  };

  var save = saveToken;
  if (!options.save)
    save = function(x, y, done) { done(); };

  return save(claims, jwtOptions.expiresInSeconds, function(err) {
    if (err)
      return done(err);

    var result = {
      "access_token": jwt.sign(claims, jwtSecret, jwtOptions),
      "expires_in": tokenExpireSeconds,
      "token_type": "Bearer",
      "scope":null,
      user_id: ctx.userId,
      account_id: ctx.accountId
    };

    if (generateRefresh) {
      var refresh_jwtOptions = {
        subject: ctx.userId
      };
      /*
       if (options.refreshTokenExpireSeconds)
       refresh_jwtOptions.expiresInSeconds = options.refreshTokenExpireSeconds;
       */
      var refresh_claims = {
        styp: 'refresh',
        sctx: {
          userId: ctx.userId,
          accountId: ctx.accountId,
          clientId: ctx.clientId
        },
        jti: generateJti()
      };
      if (ctx.isAnon)
        refresh_claims.sctx.isAnon = true;

      return saveToken(refresh_claims, 0, function(err) {
        if (err)
          return done(err);
        result.refresh_token = jwt.sign(refresh_claims, jwtSecret, refresh_jwtOptions);
        return done(null, result);
      });
    }
    else
      return done(null, result);

  });
};

function decodeJwt(token, checkDatabase, done) {
  if (typeof checkDatabase == 'function') {
    done = checkDatabase;
    checkDatabase = false;
  }

  var decoded;
  try {
    decoded = jwt.verify(token, jwtSecret);

    if (decoded && typeof checkDatabase == 'string' && decoded.styp != checkDatabase)
      checkDatabase = false;

    if (!decoded || !checkDatabase)
      return done(null, decoded);
    mongoose.models['Token'].findOne({ 'jti': decoded.jti }, function (err, tokenRecord) {
      if (err) return done(err);
      if (!tokenRecord || tokenRecord.isRevoked)
        return done(null, null);
      return done(null, decoded);
    })

  } catch(err) {
    return done(null, null);
  }
}

function deleteToken(decoded, done) {
  if (!decoded)
    return done();

  var jti = (typeof decoded == 'string') ? decoded : decoded.jti;
  var query = { jti:  jti };
  return mongoose.models['Token'].update(query, { isRevoked: true }, done);
}

exports.register = function (_server, options, next) {
  server = _server;

  options = options || { };
  server.expose('usernamePasswordValidate', usernamePasswordValidate);
  server.expose('verifyClientId', verifyClientId);
  server.expose('jwtContext', jwtContext);
  server.expose('generateTokens', generateTokens);
  server.expose('decodeJwt', decodeJwt);
  server.expose('contextForUser', contextForUser);
  server.expose('deleteToken', deleteToken);



  server.auth.strategy('user-basic', 'basic', {
    validateFunc: usernamePasswordValidate
  });

  server.auth.strategy('user-bearer', 'bearer-access-token', {
    allowQueryToken: true,              // optional, true by default
    allowMultipleHeaders: false,        // optional, false by default
    accessTokenName: 'access_token',    // optional, 'access_token' by default
    validateFunc: function (token, callback) {

      // For convenience, the request object can be accessed
      // from `this` within validateFunc.
      var request = this;

      var decoded;
      try {
        decoded = jwt.verify(token, jwtSecret);
        if (!decoded || decoded.styp != 'access')
          return callback(null, false);

        return callback(null, true, _.extend({jti: decoded.jti, type: decoded.styp}, decoded.sctx));
      } catch (err) {
        return callback(null, false);
      }

    }
  });

  server.auth.strategy('alt-auth', 'bearer-access-token', {
    allowQueryToken: true,              // optional, true by default
    allowMultipleHeaders: false,        // optional, false by default
    accessTokenName: 'token',    // optional, 'access_token' by default
    validateFunc: function (token, callback) {

      // For convenience, the request object can be accessed
      // from `this` within validateFunc.
      var request = this;

      decodeJwt(token, 'altauth', function (err, decoded) {
        if (!decoded || (decoded.styp != 'altauth' && decoded.styp != 'access'))
          return callback(null, false);
        return callback(null, true, _.extend({jti: decoded.jti, type: decoded.styp}, decoded.sctx));
      });

    }
  });


  /*
   If this is a 401/Unauthorized response, respond with just Basic as possible authentication
   methods.  We also support "Bearer", but the client should know that already, and when testing
   with the browser, this makes it easier to test.  (Browser doesn't prompt for username/password
   when both Basic and Bearer are returned.
   */
  server.ext('onPreResponse', function (request, reply) {

    var response = request.response;
    if (response.isBoom && request.path.substr(0, 5) != '/api/') {
      //request.response.output.payload = request.server.app.errorPayload;

      return reply.continue();
    }
    if (response.isBoom && response.output.statusCode == 401 && response.output.headers
      && response.output.headers['WWW-Authenticate'] && !request.headers['x-pivot-api-caller']) {
      response.output.headers['WWW-Authenticate'] = 'Basic';
      return reply.continue();
    }

    return reply.continue();
  });

  next();
};


exports.register.attributes = {
  name: 'pivot-auth'
};
