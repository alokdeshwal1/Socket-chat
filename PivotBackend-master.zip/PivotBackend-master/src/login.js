"use strict";
import {AuthService} from 'paulvanbladel/aurelia-auth';
import {inject} from 'aurelia-framework';
import {Router} from 'aurelia-router';
import {PivotClient} from 'lib/pivot-client';
import {SimpleDialog} from 'lib/simple-dialog';

@inject(AuthService, Router, PivotClient, SimpleDialog)
export class Login{
	constructor(auth, router, pivotClient, simpleDialog){
		this.auth = auth;
    this.router = router;
    this.pivotClient = pivotClient;
    this.fetchPivotClient = pivotClient.init(true);
    this.simpleDialog = simpleDialog;
  };

	heading = 'Login';
	
	email='';
	password='';
  error='';
  recoverPassword = false;
  alertClass = 'alert-danger';
  errorAlertClass = 'alert-danger';
  successAlertClass = 'alert-success';

	login(){
		return this.auth.login(this.email, this.password)
		.then(response=>{
			console.log("success logged " + response);
      this.router.navigate('pivot-select');
		})
		.catch(err=>{
			console.log("login failure");
      this.alertClass = this.errorAlertClass;
      this.error = "Incorrect username or password.";
		});
	};
	
	authenticate(name){
		return this.auth.authenticate(name, false, null)
		.then((response)=>{
			console.log("auth response " + response);
		});
	}

  dismiss() {
    this.alertClass = this.errorAlertClass;
    this.error = '';
  }

  recover() {
    var self = this;
    this.dismiss();
    var promise = this.fetchPivotClient.then(function(pivotClient) {
      return pivotClient.user.post_user_forgotpassword({ EmailModel: { email: self.email } });
    }).then(function(results) {
      self.recoverPassword = false;
      self.error = 'If the e-mail entered was a valid Pivot The World account, then an e-mail with password recovery instructions has been sent.';
      self.alertClass = self.successAlertClass;
    }, function(err) {
      console.log(err);
      self.error = 'There was an error with the password recovery attempt.';
      self.alertClass = self.errorAlertClass;
    });

    this.simpleDialog.blockUntil(promise);


  }

  switchToRecover() {
    this.dismiss();
    this.recoverPassword = true;
    return false;
  }

  returnToLogin() {
    this.dismiss();
    this.recoverPassword = false;
    return false;
  }
}
