/**
 * Created by keary on 9/4/15.
 */
'use strict';
import {inject, computedFrom} from 'aurelia-framework';
import {EventAggregator} from 'aurelia-event-aggregator';
import {PivotClient} from 'lib/pivot-client';
import {Configure} from 'aurelia-configuration';
import {Router} from 'aurelia-router';
import {Validation} from 'aurelia-validation';
import {SimpleDialog} from 'lib/simple-dialog';
import {countryCodes} from 'lib/countries.js'
import {FileAPI} from 'fileapi'
import {HttpClient} from 'aurelia-http-client';

import moment from 'moment'
import promisify from 'es6-promisify';
import interact from 'taye/interact.js';
//import dragula from 'dragula';

let FileAPI_getInfo = promisify(FileAPI.getInfo);
let FileAPI_Image_transform = promisify(FileAPI.Image.transform);

import gju from 'geojson-utils';
import _ from 'lodash'
import $ from 'jquery'
import Leaflet from 'leaflet';

@inject(EventAggregator, Router, SimpleDialog, PivotClient, Configure, Validation, Leaflet, HttpClient)
export class LandmarkEditMain {

  toursDisabled = true;
  viewContainer;
  pictureListGroup;
  mediaMap = { };
  isCmsAdmin = true;
  publishedVersion;
  editVersion;
  thisVersion;


  constructor(EventAggregator, router, simpleDialog, pivotClient, configure, validation, leaflet, http) {
    let self = this;
    this.eventAggregator = EventAggregator;
    this.pivotClient = pivotClient;
    this.fetchPivotClient = pivotClient.init();
    this.L = leaflet;
    this.router = router;
    this.config = configure
    this.simpleDialog = simpleDialog;
    this.validation = validation;
    this.http = http;
    this.countryCodes = [].concat(countryCodes);
    this.parentModel = this;
    this.showLog = false;

    this.privileges = pivotClient.getPrivileges();
    console.log(this.privileges);
    this.userContext = this.pivotClient.getUserContext();
    console.log(this.userContext);
    console.log("isCms: ", this.pivotClient.hasPrivilege('cms'));
    this.isCmsAdmin = this.pivotClient.hasPrivilege('cms-admin');

    this.locationNameValidator = function(subject) {
      return this.validation.on(subject)
        .ensure('input')
        .isNotEmpty()
        .hasMinLength(3);
    }.bind(this);

    this.locationNameSave = function(name) {
      return self.modifyLocation({ name: name }).then(function(loc) {
        /*
        return self.loadLocation(loc).then(function() {
          return Promise.resolve(false);
        });
        */
        self.location.name = loc.location.properties.name;
        _.each(loc.location.properties.landmarks, function(l) {
            let landmark = _.find(self.location.landmarks, { id: l.id });
          if (landmark)
            landmark.name = l.name;
        });
        return Promise.resolve(false);
      });

    }

    this.toggleHidden = function() {
      return self.modifyLocation({ isHidden: !self.location.isHidden }).then(function(loc) {
        /*
         return self.loadLocation(loc).then(function() {
         return Promise.resolve(false);
         });
         */
        self.location.isHidden = loc.isHidden;
        return Promise.resolve(false);
      });

    }

    this.locationAddressSave = function() {
      return self.modifyLocation({ streetAddress: self.location.streetAddress }).then(function(loc) {
        return Promise.resolve(true);
      });
    }

    var exclamation = "\uf06a";
    /*
    this.locationAddressValidator = function() {
      return this.validation.on(this)
        .ensure('location.streetAddress.street')
        .isNotEmpty().withMessage(exclamation)
        .hasMinLength(3).withMessage(exclamation);
    }.bind(this);
    //validator.bind="locationAddressValidator"

    */

    this.landmarkDescriptionValidator = function(index) {
      //let prop = 'location.landmarks__' + index.toString() + '.locationSpecificData.constructionDate';
      let conprop = self.landmarkProp(index, 'constructionDate');
      let removeprop = self.landmarkProp(index, 'removalDate');

      return self.validation.on(self).ensure(conprop).canBeEmpty()
        .isLessThan(Number(moment().year()) + 1).withMessage(exclamation)
        .matches(/^-?\d{4}$/).withMessage(exclamation)
        .ensure(removeprop).canBeEmpty()
        .isLessThan(Number(moment().year()) + 1).withMessage(exclamation)
        .matches(/^-?\d{4}$/).withMessage(exclamation)
    }

    this.maintainerNotesSave = function(notes) {
      return self.modifyLocation({ maintainerNotes: notes }).then(function(loc) {
          return Promise.resolve(true);
      });
    };

    this.landmarkDescriptionSave = function(index) {
      let update = {
        description: self.location.landmarks[index].defaultInfoCard.description,
        shortDescription: self.location.landmarks[index].shortDescription,
        constructionDate: self.location.landmarks[index].constructionDate,
        removalDate: self.location.landmarks[index].removalDate,
      }

      //update.locationSpecificData[self.locationId] = self.location.landmarks[index].locationSpecificData;

      return self.modifyLandmark(index, update).then(function(landmark) {
        return Promise.resolve(true);
      });
    }

    this.locationLocationSave = function() {
      return self.modifyLocation({ latitude: self.latitude, longitude: self.longitude, proximityRadius: self.location.proximityRadius ? self.location.proximityRadius : 0 }).then(function(loc) {
        return Promise.resolve(true);
      });
    }

    this.disableDragFunction = function(event) {
      event.stopPropagation();
      event.preventDefault();
    }

    this.dropFunction = function(event) {
      let files = event.originalEvent.target.files || event.originalEvent.dataTransfer.files;
      if (files && files.length) {
        event.stopPropagation();
        event.preventDefault();
        self.filesDropped(files);
      }
    }
  }


  landmarkProp(index, propName) {
    let prop =  'location.landmarks__' + index.toString() + '.' + propName;
    return prop;

  }

  editMedia(media) {
    this.currentMediaEdit = media;
  }

  @computedFrom('publishedVersion', 'thisVersion')
  get isCurrentRevision() {
    return this.publishedVersion == this.thisVersion;
  }
  updateLocation(loc) {
    var self = this;
    this.publishedVersion = loc.publishedVersion;
    this.editVersion = loc.editVersion;
    this.thisVersion = loc.thisVersion;
    if (this.isCmsAdmin) {
      this.currentAuditLogEntry =  { };
      this.auditLogs = [ ];
      let pivotClient;
      return this.fetchPivotClient.then(function(_pivotClient) {
        pivotClient = _pivotClient;
        return pivotClient.admin.get_admin_audit_id({id: self.thisVersion });
      }).then(function(result) {
        self.currentAuditLogEntry = result.obj;
        return pivotClient.admin.get_admin_audit_location_id({ id: self.locationId });
      }).then(function(result) {
        self.auditLogs = result.obj.logs;
      });
    }
  }

  sortMedia() {
    this.location.media = _.sortBy(this.location.media, function(m) { return m.relevanceStartDate });
  }

  finishMediaEdit(media) {
    if (!media) {
      this.currentMediaEdit = false;
      return;
    }

    var self = this;
    let args = { id: this.locationId, mediaId: media.id, ModifyMedia: {
      relevanceStartDate: media.relevanceStartDate,
      caption: media.caption,
      showIn: media.showIn
    }};

    return this.fetchPivotClient.then(function(pivotClient) {
      return pivotClient.locations.put_locations_id_media_mediaId(args);
    }).then(self.handlePivotResult, self.handlePivotError).then(function(loc) {
      self.updateLocation(loc);
      var newMedia = _.find(loc.media, function(m) { return m.id == media.id });
      self.mediaMap[newMedia.id] = newMedia;
      _.each(self.location.media, function(m, idx) {
        if (m.id == newMedia.id)
          self.location.media[idx] = newMedia;
      })
      self.sortMedia();
      self.currentMediaEdit = undefined;
    });
  }

  setDefaultPhoto(index, mediaId) {
    let self = this;
    if (self.location.landmarks[index].defaultMediaId == mediaId)
      return;
    return self.modifyLandmark(index, {
      defaultMediaId: mediaId,
    }).then(function(landmark) {
      landmark.media = self.location.media;
      self.location.landmarks[index] = landmark;
      return Promise.resolve(false);
    });
  }
  setupInteract() {
    let self = this;
    let clone;
    function setClonePosition(event) {
      clone.css('left', event.pageX + 'px');
      clone.css('top', event.pageY + 'px');
    }

    interact('.photo-draggable')
      .draggable({
        manualStart: false,
        inertia: false,
        // keep the element within the area of it's parent
        /*
         restrict: {
         restriction: "parent",
         endOnly: true,
         elementRect: { top: 0, left: 0, bottom: 1, right: 1 }
         },
         */

        onstart: function(event) {
          clone = $(event.target).clone();
          setClonePosition(event);
          clone.addClass('drag-ghost');
          $('body').append(clone);
        },
        // call this function on every dragmove event
        onmove: function (event) {
          setClonePosition(event);
        },
        // call this function on every dragend event
        onend: function (event) {
          clone.remove();
          clone = null;
        }
      }).styleCursor(false);

    interact('.dropzone').dropzone({
      // only accept elements matching this CSS selector
      accept: '.photo-draggable',
      // Require a 75% element overlap for a drop to be possible
      //overlap: 0.75,

      // listen for drop related events:

      ondropactivate: function (event) {
        // add active dropzone feedback
        event.target.classList.add('drop-active');
      },
      ondragenter: function (event) {
        var draggableElement = event.relatedTarget,
          dropzoneElement = event.target;

        // feedback the possibility of a drop
        dropzoneElement.classList.add('drop-target');
        draggableElement.classList.add('can-drop');
      },
      ondragleave: function (event) {
        // remove the drop feedback style
        event.target.classList.remove('drop-target');
        event.relatedTarget.classList.remove('can-drop');
      },
      ondrop: function (event) {
        var mediaId = $(event.relatedTarget).attr('data-mediaid');
        var landmarkIndex = $(event.target).attr('data-landmark-index');
        self.setDefaultPhoto(landmarkIndex, mediaId);
      },
      ondropdeactivate: function (event) {
        // remove active dropzone feedback

        event.target.classList.remove('drop-active');
        event.target.classList.remove('drop-target');
      }
    });
  }

  attached() {
    $(this.viewContainer).on('dragover dragleave', this.disableDragFunction);
    $(this.viewContainer).on('drop', this.dropFunction);

    this.setupInteract();
    //this.setupDragula();
  }

  detached() {
    $(this.viewContainer).off('dragover dragleave', this.disableDragFunction);
    $(this.viewContainer).off('drop', this.dropFunction);
  }

  handlePivotResult(result) {
    return Promise.resolve(result.obj);
  }

  handlePivotError(err) {
    var message;
    if (err.obj instanceof Error && err.obj.response && err.obj.response.body)
      message = err.obj.response.body.message;
    if (!message)
      message = "Unable to save";
    return Promise.reject(new Error(message));
  }

  publish() {
    if (this.location.isDeleted)
      return this.removeLocation(true);
    else
      return this.modifyLocation({}, true).then(function(loc) {

      });

  }
  modifyLocation(set, publish) {
    var self = this;
    var version = 'edit';
    if (publish || this.thisVersion != this.editVersion)
      version = this.thisVersion;

    let args = {
      publish: publish || false,
      version: version,
      id: this.locationId, modifyLinkedLandmark: true, ModifyLocation: set
    };
    return this.fetchPivotClient.then(function(pivotClient) {
      return pivotClient.locations.put_locations_id(args);
    }).then(self.handlePivotResult, self.handlePivotError).then(function(loc) {
      self.updateLocation(loc);
      return Promise.resolve(loc);
    });
  }

  modifyLandmark(index, set) {
    var self = this;
    let args = { id: this.locationId, landmarkId: this.location.landmarks[index].id, ModifyLandmark: set};
    return this.fetchPivotClient.then(function(pivotClient) {
      return pivotClient.locations.put_locations_id_landmark_landmarkId(args);
    }).then(self.handlePivotResult, self.handlePivotError).then(function(loc) {
      self.updateLocation(loc);
      return Promise.resolve(loc);
    });
  }


  activate(params, routeConfig) {
  }

  loadLocation(loc, version) {
    var self = this;
    var pivotClient;
    let loadPromise;

    this.currentMediaEdit = undefined;

    version = version || 'edit';
    if (loc)
      loadPromise = Promise.resolve(loc);
    else
      loadPromise = this.fetchPivotClient.then(function(_pivotClient) {
        pivotClient = _pivotClient;
        return pivotClient.locations.get_locations_id({ id: self.locationId, version: version, includeHiddenMedia: true });
      }).then(function(result) {
        return result.obj;
      });

    var p = loadPromise.then(function(_location) {
      self.updateLocation(_location);
      let location = {
        geo: _location.location,
        media: _location.media,
        maintainerNotes: _location.maintainerNotes,
        isDeleted: _location.isDeleted,
        isHidden: _location.isHidden
      }
      Object.assign(location, _location.location.properties);
      if (!location.streetAddress)
        location.streetAddress = { };
      if (location.streetAddress.country)
        location.streetAddress.country = location.streetAddress.country.toUpperCase();
      var centroid = location.geo.geometry;
      if (location.geo.geometry.type != 'Point')
        centroid = gju.centroid(location.geo.geometry);
      self.latitude = centroid.coordinates[1];
      self.longitude = centroid.coordinates[0];
      let mediaMap = { };
      _.each(location.media, function(m) {
        mediaMap[m.id] = m;
      });
      var promises = [ ];
      _.each(location.landmarks, function(landmark, idx) {
        landmark.media = location.media;
        /*
        _.each(landmark.media, function(m) {
          if (!mediaMap[m.id]) {
            mediaMap[m.id] = true;
            promises.push(pivotClient.media.get_media_id({id: m.id}).then(function (result) {
              mediaMap[m.id] = result.obj;
            }));
          }
        });
        */
        //landmark.locationSpecificData = landmark.locationSpecificData[self.locationId] || { };
        location['landmarks__' + idx] = landmark;

      });
      return Promise.all(promises).then(function() {
        self._location = _location;
        self.location = location;
        self.sortMedia();
        self.mediaMap = mediaMap;
        return Promise.resolve();
      });
    });

    return p;
  }
  canActivate(params, routeConfig) {
    let self = this;

    if (!this.isCmsAdmin && !this.pivotClient.hasPrivilege('cms')) {
      return self.simpleDialog.alert("Operation not permitted.").then(function() {
        return Promise.resolve(false);
      });
    }

    /*
     this.userService.getUser(params.id)
     .then(user => {
     routeConfig.navModel.setTitle(user.name);
     });
     */

    this.locationId = params.id;
    var p = this.loadLocation();

    return this.simpleDialog.blockUntil(p).then(function() {
      if (!self.isCmsAdmin && self.userContext.institution && self.location.institution != self.userContext.institution) {
        return reject(false);
      }
    }).then(function() {
        return Promise.resolve(true);
        //self.router.navigateToRoute("pivot-select");
    }).catch(function(err) {
      console.log(err);
      return self.simpleDialog.alert("Error trying to retrieve Pivot Point").then(function() {
        return Promise.resolve(false);
      });
    })
  }

  mediaUrl(mediaId) {
    let url;
    if (mediaId) {
      let media = this.mediaMap[mediaId];
      if (media) {
        if (media.type == 'photo')
          url = media.sizedUrls[0].url;
        else if (media.type == 'website')
          url = '/static/img/web-browser-icon.png'
      }
    }
    if (url)
      return url;
    else
      return "/static/img/no-image-available.png";
  }

  media(mediaId) {
    if (!mediaId)
      return { };
    return this.mediaMap[mediaId];
  }

  undeleteLocation() {
    var self = this;
    return this.modifyLocation({}).then(function(loc) {
      self.loadLocation(loc);
    });
  }

  confirmDelete()  {
    return this.simpleDialog.confirm("Are you sure you wish to permanently remove this location?");
  }

  removeLocation(publish) {
    publish = !!publish;
    var self = this;
    var confirm;
    if (publish || !this.publishedVersion)
      confirm = this.confirmDelete();
    else
      confirm = Promise.resolve();
    return confirm.then(function() {
      let p = self.fetchPivotClient.then(function(pivotClient) {
        return pivotClient.locations.delete_locations_id({
          id: self.locationId,
          publish: publish
        });
      }).then(function(result) {
        if (result.obj && result.obj.location)
          return self.loadLocation(result.obj);
        else
          self.router.navigateToRoute("pivot-select");
      }).catch(function(err){
        console.log(err);
        var message;
        if (err.obj instanceof Error && err.obj.response && err.obj.response.body)
          message = err.obj.response.body.message;
        if (!message)
          message = "There was an error deleting this Pivot Point";
        self.errorMessage = message;
      });
      return self.simpleDialog.blockUntil(p);


    }).catch(function(err) {

    });
  }

  removeMedia(media) {
    var self = this;
    return this.simpleDialog.confirm("Are you sure you wish to permanently remove this photo?").then(function() {
      let p = self.fetchPivotClient.then(function(pivotClient) {
        return pivotClient.locations.delete_locations_id_media_mediaId({
          mediaId: media.id,
          id: self.locationId

        });
      }).then(self.handlePivotResult, self.handlePivotError)
      .then(function(loc) {
        self.updateLocation(loc);
        delete self.mediaMap[media.id];
        self.location.media = _.reject(self.location.media, function(m) { return m.id == media.id } );
        _.each(self.location.landmarks, function(landmark) {
          landmark.media = _.reject(self.location.media, function(m) { return m.id == media.id } );
          if (landmark.defaultInfoCard.defaultMediaId == media.id)
            landmark.defaultInfoCard.defaultMediaId = undefined;
        });

        if (self.currentMediaEdit.id == media.id)
          self.currentMediaEdit = null;
      }).catch(function(err){
        console.log(err);
        var message;
        if (err.obj instanceof Error && err.obj.response && err.obj.response.body)
          message = err.obj.response.body.message;
        if (!message)
          message = "There was an error deleting this media";
        self.errorMessage = message;
      });
      return self.simpleDialog.blockUntil(p);
    }).catch(function(err) {

    });
  }


  fileSelected($event) {
    //let reader = new FileReader();
    //let file = this.$event.target.files[0];
    //reader.readAsDataURL(file);
    //this.fileName = file.name;
    //reader.onload = () => {
    //  this.file = reader.result;
    //};
    let files = $event.target.files;
    this.filesDropped(files);
  }

  importOneFile(file) {
    var self = this;
    return FileAPI_getInfo(file).then(function(info) {
      console.log("info", info);
      if (info && info.width && info.height) {
        var uploadSizes= [ {
          sizeType: 'original',
          width: info.width,
          height: info.height
        } ];

        var maxResField = 'width';
        var maxRes = info.width;
        if (info.height > info.width) {
          maxResField = 'height';
          maxRes = info.height;
        }

        var currentRes = maxRes;
        var sizes = [
          { size: 1920, sizeType: 'large' },
          { size: 1920/2, sizeType: 'medium' },
          { size: 1920/4, sizeType: 'small' },
          { size: 1920/8, sizeType: 'thumbnail' },
        ];
        _.each(sizes, function(s) {
          if (s.size < maxRes) {
            var w = s.size, h = s.size;
            if (maxResField == 'height')
              w = (h * info.width) / info.height;
            else
              h = (w * info.height) / info.width;
            uploadSizes.unshift({
              sizeType: s.sizeType,
              width: Math.round(w),
              height: Math.round(h),
            });
          }
        });

        //var totalPercent = uploadSizes.length * 100;

        var el = $('<div class="upload-blockui"><h1><i class="fa fa-circle-o-notch fa-spin"></i>&nbsp;<span class="growl-text"></span></h1><div class="progress"><div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div></div></div>');
        el.find('.growl-text').text("Uploading: " + file.name);
        el.find('.progress').css('display', 'none');
        self.simpleDialog.blockUI(el);

        var transform = [ ];
        _.each(uploadSizes, function(us) {
          let t = { };
          if (us.sizeType != 'original')
            t= {
              type: file.type,
              width: us.width,
              height: us.height
            };
          transform.push(t);
        });

        let storageId;
        let pivotClient;
        return self.fetchPivotClient.then(function(_pivotClient) {
          pivotClient = _pivotClient;
          return pivotClient.storage.post_storage_media({ CreateStorageMedia: {
            contentType: file.type,
            additional: uploadSizes.length-1
          }});
        }).then(function(result) {
          storageId = result.obj.storageId;
          let urls = result.obj.urls;
          _.each(uploadSizes, function(us, idx) {
            us.extra= {
              putUrl: urls[idx].putUrl
            },
            us.url = urls[idx].url;
          });
          return FileAPI_Image_transform(file, transform, true);
        }).then(function(canvases) {
          var promises = [ ];
          _.each(canvases, function(canvas, idx) {
            promises.push(new Promise(function(resolve, reject) {
              canvases[idx].toBlob(function(blob) {
                if (blob)
                  return resolve(blob);
                else
                  return reject("No blob");
              }, file.type)
            }));
          })
          return Promise.all(promises);
        }).then(function(blobs) {
          var savePromises = [];
          _.each(uploadSizes, function (us, idx) {
            savePromises.push(
              self.http.createRequest(us.extra.putUrl)
                .asPut()
                .withContent(blobs[idx])
                //.withParams(queryDict)
                //.withHeader("Content-Type", file.type)
                .send()
            );
          });
          return Promise.all(savePromises);
        }).then(function(results) {
          _.each(uploadSizes, function(us) {
            delete us.extra;
          });
          return pivotClient.locations.post_locations_id_media({
            CreateNewMediaForLocation: {
              sizedUrls: uploadSizes,
              storageId: storageId,
              attachToLandmarks: true,
              type: 'photo'
            },
            id: self.locationId
          });
        }).then(self.handlePivotResult, self.handlePivotError)
        .then(function(loc) {
          self.updateLocation(loc);
          _.each(loc.media, function(m) {
            if (!self.mediaMap[m.id]) {
              self.location.media.push(m);
              self.mediaMap[m.id] = m;
              if (!self.currentMediaEdit)
                self.currentMediaEdit = m;
            }
          })
          self.sortMedia();
            /*
            _.each(self.location.landmarks, function(l) {
              l.media.push(media);
            });
            */

          setTimeout(function() {
            $(self.pictureListGroup).scrollLeft(9999);
          }, 250);
          self.simpleDialog.unblockUI();
          return Promise.resolve();
        }).catch(function(err) {
          self.simpleDialog.unblockUI();
          console.log(err);
          return Promise.reject();
        });
      }
      else
        return Promise.reject();
    });
}
  filesDropped(files) {
    let self = this;
    if (!files || !files.length)
      return;
    var promise = Promise.resolve();
    var errorFiles = [];
    var successFiles = [];

    _.each(files, function(f) {
      promise = promise.then(function () {
        return self.importOneFile(f).then(function() {
          successFiles.push(f.name);
          return Promise.resolve();
        });
      }).catch(function (err) {
        errorFiles.push(f.name);
        return Promise.resolve();
      });
    });

    return promise.then(function() {
      function generateGrowlMessage(heading, list) {
        let html = $('<div class="growlUI"><h1 class="growl-heading"></h1><ul class="list-unstyled growl-list"></ul></div>');
        html.find('.growl-heading').text(heading);
        _.each(list, function(f, idx) {
          var newEl = $('<li></li>').text(f);
          html.find('.growl-list').append(newEl);
        });
        return html;
      }
      var errMsgPromise = Promise.resolve();
      if (errorFiles.length) {
        var el = generateGrowlMessage("Failed to upload some files", errorFiles);
        self.simpleDialog.growlError(el);
        errMsgPromise = new Promise(function(resolve, reject) {
          setTimeout(resolve, 1500);
        });
      }

      if (!successFiles.length)
        return;

      return errMsgPromise.then(function() {
        var el = generateGrowlMessage("Succesfully uploaded", successFiles);
        self.simpleDialog.growl(el);
      })

    });
  }

  toggleAdmin() {
    console.log("toggle");
    this.showLog = !this.showLog;
  }

  selectRevision(logEntry) {
    console.log("SelectRev", logEntry);
    return this.loadLocation(null, logEntry.editId);
  }

  classForLog(logEntry) {
    if (logEntry.editId == this.thisVersion)
      return "active";
    else if (logEntry.isPublish)
      return "info";
  }

}
