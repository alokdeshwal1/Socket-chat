/**
 * Created by keary on 9/30/15.
 */
"use strict";

import {inject, computedFrom} from 'aurelia-framework';
import {Validation} from 'aurelia-validation';
import $ from 'jquery'

@inject(Validation)
export class PivotMediaEdit {

  constructor(validation){
    this.validation = validation;

    var exclamation = "\uf06a";

    this.validate = this.validation.on(this).ensure('relevanceStartDate').canBeEmpty()
      .isLessThan(Number(moment().year()) + 1).withMessage(exclamation)
      .matches(/^-?\d{4}$/).withMessage(exclamation);
  }

  activate(model){

    this.parent = model.parent;
    this.original = model.media;
    if (!this.original)
      return;

    this.media = JSON.parse(JSON.stringify(model.media));
    this.caption = this.media.caption;
    this.relevanceStartDate = this.media.relevanceStartDate;
    this.showIn = this.media.showIn;

    this.mediaUrl = this.media.sizedUrls[Math.min(2, this.media.sizedUrls.length-1)].url;
    console.log(this.mediaUrl);
  }

  cancelEdit() {
    this.parent.finishMediaEdit(false);
  }

  removeMedia() {
    this.parent.removeMedia(this.media);
  }

  apply() {
    var self = this;
    if (!this.isDirty)
      return this.cancelEdit();
    return this.validate.validate().then(function() {
      self.media.caption = self.caption;
      self.media.relevanceStartDate = self.relevanceStartDate;
      self.media.showIn = self.showIn;
      console.log(self.media);
      return self.parent.finishMediaEdit(self.media);
    });
  }
  @computedFrom('caption', 'relevanceStartDate', 'showIn')
  get isDirty() {
    if (!this.original || !this.media)
      return true;
    return (this.caption !=  this.original.caption ||
      this.relevanceStartDate != this.original.relevanceStartDate ||
      this.showIn != this.original.showIn);
  }

  @computedFrom('caption', 'relevanceStartDate')
  get thumbnailHeading() {
    var heading = this.caption || '';
    if (this.relevanceStartDate)
      heading = heading + ' ' + this.relevanceStartDate;
    return heading.trim();
  }

  clickThumbnail() {
    $('#thumbnail-modal').modal('show');
    return false;
  }

}
