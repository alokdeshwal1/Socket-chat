"use strict";

//import {computedFrom} from 'aurelia-framework';
import {ObserverLocator, inject, computedFrom, bindable, TaskQueue} from 'aurelia-framework';
import {EventAggregator} from 'aurelia-event-aggregator';
import {PivotClient} from 'lib/pivot-client';
import {Router} from 'aurelia-router';
import gju from 'geojson-utils';
import {Configure} from 'aurelia-configuration';
import {LocationService} from 'lib/location-service'

import Leaflet from 'leaflet';
import _ from 'lodash'
import $ from 'jquery'

@inject(EventAggregator, PivotClient, Leaflet,
  Router, Configure, LocationService, ObserverLocator, TaskQueue)
export class LandmarksSelect{

  @bindable searchText = '';
  leafletMapEvents = ['load', 'viewreset', 'moveend',
    'click', 'dblclick', 'popupopen', 'popupclose', 'zoomstart' ];
  map;
  popupsOpen = 0;
  defaultZoomLevel = 13;
  searchSuggestions = [];
  dropdownFocus;
  searchForm;
  searchInput
  searchHasFocus;
  fullListLocations = [ ];
  listSearchText = '';


  constructor(EventAggregator, pivotClient, leaflet, router,
              configure, locationService, observerLocator, TaskQueue) {
    this.eventAggregator = EventAggregator;
    this.pivotClient = pivotClient;
    this.fetchPivotClient = pivotClient.init();
    this.L = leaflet;
    this.router = router;
    this.config = configure
    this.locationService = locationService;
    this.observerLocator = observerLocator;
    this.taskQueue = TaskQueue;

    let self = this;

    this.hasCmsPriv = this.pivotClient.hasPrivilege('cms-admin') || this.pivotClient.hasPrivilege('cms');
    this.isCmsAdmin = this.pivotClient.hasPrivilege('cms-admin');
    this.userInstitution = this.pivotClient.getUserContext().institution;

    this.outsideClickFunction = function(event) {
      let form = $('.search-form')[0];
      if (!$.contains(form, event.target))
        this.dropdownFocus = false;
    }.bind(this);

    this.clickedInSearchForm = function(event) {
      event._pivotClickedInForm = true;
      return true;
    }.bind(this);

    this.updateSearchBox = _.debounce(this._updateSearchBox.bind(this), 500);

    this.setHasFocus = function(val) {
      console.log("SettingHasFocus: " + val);
      self.searchHasFocus = val;
      console.log("searchHasFocusChanged(" + val + ")", self.searchHasFocus);
      let hasFocus = self.searchHasFocus;
      console.log(hasFocus);
      if (hasFocus)
        self.dropdownFocus = true;
      else {

        setTimeout(function () {
          if (!self.searchHasFocus)
            self.dropdownFocus = false;
        }, 250);
      }
    }

    this.fetchPivotClient.then(function(pivotClient) {
      return pivotClient.locations.get_locations_search({ institution: self.institution, version: 'edit' });
    }).then(function(results) {
      self.fullListLocations = _.sortBy(results.obj.features, function(f) {
        return !f.properties.pendingChanges + f.properties.name;
      });
    });

  }

  removeMarkers() {
    if (this.map) {
      if (this.markers)
        this.map.removeLayer(this.markers);
      this.markers = new this.L.FeatureGroup();
      this.markerMap = { };
      this.map.addLayer(this.markers);
    }
  }

  onEachFeature(feature, marker) {
    if (feature.properties && feature.geometry.type == 'Point') {
      marker.options.title = feature.properties.caption;

      //var el = $('<a/>').attr('href', this.router.generate('pivot-edit', { id: feature.properties.id })).text(feature.properties.caption);

      var el = $('<div class="pivot-map-popup"/>');
      el.append($('<b/>').text(feature.properties.caption));
      el.append("<br/>");
      var btn = $('<a class="btn btn-xs btn-primary"/>').attr('href', this.router.generate('pivot-edit', { id: feature.properties.id })).text("Edit");
      var btnDiv = $('<div class="pivot-map-popup-edit-container"/>');
      btnDiv.append(btn);
      if (this.hasCmsPriv && (this.isCmsAdmin || !this.userInstitution || this.userInstitution == feature.properties.institution))
        el.append(btnDiv);
      marker.bindPopup(el[0]);

      /*
      marker.on('mouseover', function (e) {
        this.openPopup();
      });
      marker.on('mouseout', function (e) {
        this.closePopup();
      });
      */
    }
  }

  installMarker(feature) {
    var self = this;
    if (!self.markerMap[feature.properties.id]) {
      self.markerMap[feature.properties.id] = {
        locationId: feature.properties.id
      };
      if (feature.geometry.type == 'Polygon') {
        var newFeature = gju.centroid(feature.geometry);
        feature.geometry = newFeature;
        feature.coordinates = newFeature.coordinates;
      }
      var marker = self.L.geoJson(feature, {
        onEachFeature: _.bind(self.onEachFeature, self)
      });
      marker.addTo(self.markers);
      self.markerMap[feature.properties.id].marker = marker;
    }
    if (self.autoOpenLocationId == feature.properties.id) {
      self.markerMap[feature.properties.id].marker.openPopup();
      self.autoOpenLocationId = null;
    }
    return self.markerMap[feature.properties.id];
  }
  reloadMarkers(payload) {
    var self = this;
    //this.removeMarkers();
    var nw = payload.map.getBounds().getNorthWest().wrap();
    var se = payload.map.getBounds().getSouthEast().wrap();
    if (nw.equals(se))
      return;
    return this.fetchPivotClient.then(function(pivotClient) {
      return pivotClient.locations.get_locations_within({
        latitude: nw.lat, longitude: nw.lng, seLatitude: se.lat, seLongitude: se.lng, limit: 2000,
        includeType: 'landmark', excludeType: 'region',
        version: 'edit'
      });
    }).then(function(ret) {
      _.each(ret.obj.features, function (feature) {
        self.installMarker(feature);
      });
    }).catch(function(err){
      console.log("err", err);
    });
  }


  clickTriggered(payload) {

    if (!this.hasCmsPriv)
      return;

    var el = $('<div class="pivot-map-popup"/>');
    el.append($('<b/>').text("Lat: " + payload.latlng.lat + ", " + "Lon: " + payload.latlng.lng));
    el.append("<br/>");
    var btn = $('<a class="btn btn-xs btn-primary"/>').attr('href', this.router.generate('pivot-new', { latitude: payload.latlng.lat, longitude: payload.latlng.lng })).text("New Pivot Point");
    var btnDiv = $('<div class="pivot-map-popup-edit-container"/>');
    btnDiv.append(btn);
    el.append(btnDiv);
    /*
    var desc = "Create new Pivot Point/Landmark for:" +
        "<br/>" +
        "Lat: " + payload.latlng.lat + ", " + "Lon: " + payload.latlng.lng;
    var el = $('<a/>').attr('href', this.router.generate('pivot-new', { latitude: payload.latlng.lat, longitude: payload.latlng.lng })).html(desc);
    */
    payload.map.openPopup(el[0], payload.latlng);
  }
  setClickTimer( payload )
  {
    this.clearClickTimer();
    this.clickTimer = setTimeout( _.bind(this.clickTriggered, this, payload), 500 );
  }

  clearClickTimer()
  {
    if (this.clickTimer)
    {
      clearTimeout( this.clickTimer );
      this.clickTimer = null;
    }
  }

  leafleftEvents = {
    load: function(payload) {
      this.map = payload.map;
      this.removeMarkers();
      setTimeout(function invalidate() {
        let height = payload.map.getContainer().clientHeight;
        if (!height)
          return setTimeout(invalidate, 100);
        payload.map.invalidateSize(false)
      }, 100);
    },
    viewreset: function(payload) {
      setTimeout(_.bind(this.clearClickTimer, this), 0);
      //this.removeMarkers();
      //this.reloadMarkers(payload);
    },
    moveend: function(payload) {
      setTimeout(_.bind(this.clearClickTimer, this), 0);
      this.reloadMarkers(payload);
    },
    zoomstart: function(payload) {
      console.log("ZoomStart");
      this.removeMarkers();
    },
    click: function(payload) {
      this.clearClickTimer();
      if (this.popupsOpen)
        return;
      this.setClickTimer(payload);
    },
    dblclick: function(payload) {
      console.log("Clearing cick timer");
      setTimeout(_.bind(this.clearClickTimer, this), 0);
    },
    popupopen: function(payload) {
      this.popupsOpen++;
      console.log("Curent pop: " + this.popupsOpen);
    },
    popupclose: function(payload) {
      this.popupsOpen--;
      console.log("Curent pop: " + this.popupsOpen);
      setTimeout(_.bind(this.clearClickTimer, this), 200);
    }
  }
  attached() {
    this.disposeLeafletEvents = this.eventAggregator.subscribe('aurelia-leaflet', (payload) => {
      if (this.leafleftEvents[payload.type])
        this.leafleftEvents[payload.type].call(this, payload);
    });
    this.disposeLocationEvents = this.eventAggregator.subscribe('location-service', (payload) => {
      this.currentLocation = {
        lat: this.locationService.currentLocation.latitude,
        lon: this.locationService.currentLocation.longitude
      }
      if (false && payload && this.map)
        this.map.panTo(new this.L.LatLng(payload.location.latitude, payload.location.longitude));
    });

    if (this.locationService.currentLocation) {
      //console.log(this.locationService.currentLocation);
      this.currentLocation = {
        lat: this.locationService.currentLocation.latitude,
        lon: this.locationService.currentLocation.longitude
      }
    }

    this.searchSuggestions = [ ];

    $(document).on('click', this.outsideClickFunction);
    $(this.searchForm).on('click', this.clickedInSearchForm);

  }

  detached() {
    this.disposeLeafletEvents();
    this.disposeLocationEvents();
    $(document).off('click', this.outsideClickFunction);
    $(this.searchForm).off('click', this.clickedInSearchForm);

  }

  homeLocation() {
    if (this.map)
      this.map.setView(new this.L.LatLng(this.currentLocation.lat, this.currentLocation.lon), this.defaultZoomLevel);

  }

  @computedFrom('locationService', 'defaultZoomLevel')
  get mapOptions() {
    let lat = 42.374373, lon = -71.116404;
    //let lat = 31, lon = 35;

    if (this.locationService.currentLocation) {
      //console.log(this.locationService.currentLocation);
      lat = this.locationService.currentLocation.latitude;
      lon = this.locationService.currentLocation.longitude;
    }
    return {
      center: {
        // 42.374373, -71.116404
        lat: lat,
        lng: lon,
      },
      dragging: true,
      zoomControl: true,
      touchZoom: true,
      scrollWheelZoom: true,
      doubleClickZoom: true,
      boxZoom: true,
      zoomLevel: this.defaultZoomLevel,
      minZoom: 2,
      worldCopyJump: true,
      maxBounds: this.L.latLngBounds(this.L.latLng(-90, -180), this.L.latLng(90, 180))
    };
  }

  get mapLayers() {
    return this.config.get("mapquest.tileProvider");
  }

  _updateSearchBox() {
    let self = this;
    let currentText = this.searchText;
    if (self.lastSuggestionText == currentText) {
      this.isSearching = false;
      return;
    }
    if (!currentText) {
      this.searchSuggestions = [];
      this.lastSuggestionText = '';
      this.isSearching = false;
      return;
    }
    this.isSearching = true;

    let lat, lon;
    if (this.map) {
      let center = this.map.getCenter();
      lat = center.lat;
      lon = center.lng;
    }
    var p = this.fetchPivotClient.then(function(pivotClient) {
      return pivotClient.map.get_map_search({
        latitude: lat, longitude: lon, search: currentText,
        version: 'edit'
      });
    }).then(function(result) {
      var locations = result.obj.results;
      _.each(locations, function(loc) {
        if (loc.type.substr(0, 5) == 'pivot')
          loc.icon = 'building-o';
        else
          loc.icon = 'map-o';
      });
      return Promise.resolve(locations);
    })

    //var promises = [ n, p ];

    return p.then(function(results) {
      if (self.searchText != currentText)
        return setTimeout(self.updateSearchBox.bind(self), 0);
      self.isSearching = false;
      self.searchSuggestions = results;
      self.lastSuggestionText = currentText;
    }).catch(function(err) {
      console.log("Error retrieving search results");
      return setTimeout(self.updateSearchBox.bind(self), 0);
    });
  }


  searchTextChanged() {
    if (!this.searchText) {
      this.searchSuggestions = [];
      this.lastSuggestionText = '';
      return;
    }

    if (this.isSearching) {
      console.log("Already searching");
      return;
    }
    this.updateSearchBox();
  }

  @computedFrom('searchSuggestions', 'dropdownFocus')
  get showDropdown() {
    let ret = (this.searchSuggestions.length > 0) && this.dropdownFocus;
    return ret;
  }

  searchSuggestion(item) {
    let self = this;
    this.dropdownFocus = false;
    this.searchText = item.description;

    if (this.map) {
      this.autoOpenLocationId = item.locationId;
      if (item.bounds)
        this.map.fitBounds(item.bounds);
      else {
        let zoom = item.zoom || 16;
        this.map.setView(new this.L.LatLng(item.latitude, item.longitude), zoom);
      }

      if (item.locationId) {
        let marker = self.markerMap[item.locationId];
        if (marker) {
          this.autoOpenLocationId = null;
          marker.marker.openPopup();
        }
      }
    }
  }

  searchSuggestionKey(e, item, index) {
    if (e.keyCode == 13) {
      e.target.blur();
      this.searchSuggestion(item);
      return false;
    } else if (e.keyCode == 38 && index == 0) {
      //this.searchHasFocusArray[999] = true;
      $(this.searchInput).focus();
      return false;
    } else if (e.keyCode == 27) {
      this.clearSearch();
      $(this.searchInput).focus();
      return false;
    }
    return true;
  }
  searchSubmit() {
    if (this.searchSuggestions.length) {
      this.searchSuggestion(this.searchSuggestions[0]);
    }
  }

  clearSearch(event) {
    //event.target.blur();
    this.searchText = '';
    //this.dropdownFocus = false;
  }

  @computedFrom('fullListLocations', 'listSearchText')
  get listLocations() {
    if (!this.listSearchText)
      return this.fullListLocations;

    var results = [];
    var s = this.listSearchText.toLowerCase();
    _.each(this.fullListLocations, function(l) {
      if (l.properties.name.toLowerCase().indexOf(s) >= 0)
        results.push(l);
    });
    return results;
  }

  searchKeypress(e) {
    if (e.keyCode == 13) {
      if (this.searchSuggestions.length) {
        e.target.blur();
        this.searchSuggestion(this.searchSuggestions[0]);
        //this.searchHasFocus = false;
      }
      return false;
    } else if (e.keyCode == 40) { //down
      var els = $('.search-row li a');
      if (els) {
        $(els[0]).focus();
      }
      return false;
    } else if (e.keyCode == 27) {
      this.clearSearch();
      return false;
    }
    return true;
  }
}


