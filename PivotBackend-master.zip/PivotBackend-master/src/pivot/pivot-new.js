/**
 * Created by keary on 9/4/15.
 */
'use strict';

import {inject} from 'aurelia-framework';
import {PivotClient} from 'lib/pivot-client';
import {Router} from 'aurelia-router';
import {Validation} from 'aurelia-validation';
import {Nominatim} from 'lib/nominatim';

import _ from 'lodash'
import $ from 'jquery'
import Leaflet from 'leaflet';

@inject(PivotClient, Router, Validation, Nominatim)
export class PivotNew {

  map;
  lat;
  lon;
  locationName;
  isDuplicate;
  isDirty;

  constructor(pivotClient, router, validation, nominatim) {
    this.fetchPivotClient = pivotClient.init();
    this.router = router;
    this.nominatim = nominatim;
    this.validation = validation.on(this)
      .ensure('locationName')
      .isNotEmpty()
      .hasMinLength(3)
      .passes(this.checkDup.bind(this))
      .withMessage("Duplicate landmark/location name");
  }

  checkDup(val) {
    console.log(val);
    return !this.isDuplicate;
  }

  create() {
    console.log("Create!");

    this.isDuplicate = false;
    this.validation.validate() //the validate will fulfil when validation is valid, and reject if not
      .then( () => {
        console.log("Validated!");

        return this.createNewLandmark();
      }).catch(function(err) {
        console.log(err);
      });
  }

  cancel() {
    this.router.navigateToRoute("pivot-select");
  }

  createNewLandmark() {
    let self = this;
    this.isSaving = true;
    function clearDuplicate() {
      self.isDuplicate = false;
    }

    let streetAddress;

    return this.nominatim.reverse({
      latitude: self.lat,
      longitude: self.lon
    }).then(function (httpResult) {
      console.log(httpResult);
      if (httpResult && httpResult.statusCode == 200 && httpResult.content && httpResult.content.address) {
        var result = httpResult.content.address;
        console.log(result);
        streetAddress = { };
        streetAddress.street = result.road;
        streetAddress.city = result.city || result.town;
        streetAddress.province = result.state;
        streetAddress.postal = result.postcode;
        streetAddress.country = result.country_code;
        console.log(streetAddress);
      }
    }).then(function() {
      return self.fetchPivotClient;
    }).then(function(pivotClient) {
        var createNewLocation=  {
          name: self.locationName,
          latitude: self.lat,
          longitude: self.lon,
          createNewLandmark: true,
        }
        if (self.proximityRadius)
          createNewLocation.proximityRadius = self.proximityRadius;
      
        if (streetAddress)
          createNewLocation.streetAddress = streetAddress;

        return pivotClient.locations.post_locations({
          CreateNewLocation: createNewLocation
        });
    }).then(function(result) {
      self.isSaving = false;
      console.log(result);
      let id = result.obj.location.properties.id;
      self.router.navigateToRoute("pivot-edit", { id: id});
    }).catch(function(err){
      console.log(err);
      self.isSaving = false;
      console.log(err);
      if (err.status == 409) {
        self.isDuplicate = true;
        return self.validation.validate().then(function () {
          clearDuplicate();
        }, clearDuplicate)
      } else {
        var message;
        if (err.obj instanceof Error && err.obj.response && err.obj.response.body)
          message = err.obj.response.body.message;
        if (!message)
          message = "There was an error creating a new Pivot Point.";
        self.errorMessage = message;
      }
    });
  }

  attached() {
  }

  activate(params, routeConfig) {
    /*
    this.userService.getUser(params.id)
      .then(user => {
        routeConfig.navModel.setTitle(user.name);
      });
    */
    this.lat = params.latitude;
    this.lon = params.longitude;
    this.proximityRadius = '';

    console.log(this)
  }

  detached() {
  }
}
