/*
var configForDevelopment = {
  providers: {
    google: {
      clientId: '239531826023-ibk10mb9p7ull54j55a61og5lvnjrff6.apps.googleusercontent.com'
    }
    ,
    linkedin:{
      clientId:'778mif8zyqbei7'
    },
    facebook:{
      clientId:'1452782111708498'
    }
  }
};

var configForProduction = {
  providers: {
    google: {
      clientId: '239531826023-3ludu3934rmcra3oqscc1gid3l9o497i.apps.googleusercontent.com'
    }
    ,
    linkedin:{
      clientId:'7561959vdub4x1'
    },
    facebook:{
      clientId:'1653908914832509'
    }

  }
};
 */
import {Router} from 'aurelia-router';

//var config ;
/*
if (window.location.hostname==='localhost') {
  config = configForDevelopment;
}
else{
  config = configForProduction;
}
*/
var config = {
  baseUrl: '/',
  loginRedirect: '',
  logoutRedirect: '',
  loginUrl: '/api/v1/auth/login',
  tokenName: 'access_token'
};

export default config;
