import {inject} from 'aurelia-framework';
import {Configure} from 'aurelia-configuration';
import {SwaggerPromiseClient} from './lib/swagger-promise'

@inject(Configure)
export class Welcome{
  heading = 'Welcome to Pivot The World!';

  constructor(config) {
    this.config = config;
    console.log(this.config.get("name"));

  }
}

