import {AuthService} from 'paulvanbladel/aurelia-auth';
import {inject} from 'aurelia-framework';
import {Router} from 'aurelia-router';
import {PivotClient} from 'lib/pivot-client';

@inject(AuthService, Router, PivotClient)
export class Logout{
	constructor(authService, router, pivotClient){
		this.authService = authService;
    this.router = router;
    this.pivotClient = pivotClient;
	};
	
  activate(){
    this.pivotClient.logout();

		this.authService.logout(this.router.generate('welcome'))
		.then(response=>{
			console.log("ok logged out on  logout.js");
		})
		.catch(err=>{
			console.log("error logged out  logout.js");

		});
	}
}
