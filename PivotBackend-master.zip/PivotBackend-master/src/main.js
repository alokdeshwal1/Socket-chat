import config from './authConfig';
import _ from 'lodash'

let allowedApps = [ 'app', 'forgotpw' ];
export function configure(aurelia) {

  var qd = {};
  location.search.substr(1).split("&").forEach(function(item) {var s = item.split("="), k = s[0], v = s[1] && decodeURIComponent(s[1]); (k in qd) ? qd[k].push(v) : qd[k] = [v]});
  var app;
  if (qd['app'])
    app = qd['app'][0];
  if (!app || !_.contains(allowedApps, app))
    app = null;


  aurelia.use
    .standardConfiguration()
    .developmentLogging()
    .plugin('aurelia-animator-css').plugin('paulvanbladel/aurelia-auth', (baseConfig)=>{
      baseConfig.configure(config);
    }).plugin('aurelia-configuration', (config)=>{
      config.setDirectory('');
      config.setConfig('application.json');
    }).plugin('benib/aurelia-leaflet', {LeafletDefaultImagePath: "jspm_packages/github/Leaflet/Leaflet@0.7.5/dist/images"
    }).plugin('aurelia-validation'); //Add this line to load the plugin
  ;
  aurelia.start().then(a => a.setRoot(app ? app : 'app'));
}
