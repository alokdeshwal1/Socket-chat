
export class Settings{
}

