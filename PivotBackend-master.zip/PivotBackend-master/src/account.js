"use strict";

import {AuthService} from 'paulvanbladel/aurelia-auth';
import {inject, computedFrom} from 'aurelia-framework';
import {Router} from 'aurelia-router';
import {PivotClient} from 'lib/pivot-client';
import {SimpleDialog} from 'lib/simple-dialog';

@inject(AuthService, Router, PivotClient, SimpleDialog)
export class Account{

  userContext;
  newPassword = '';
  repeatNewPassword = '';
  password = '';
  passwordChanged = false;

	constructor(auth, router, pivotClient, simpleDialog){
		this.auth = auth;
    this.router = router;
    this.pivotClient = pivotClient;
    this.fetchPivotClient = pivotClient.init();
    this.simpleDialog = simpleDialog;

    this.userContext = this.pivotClient.getUserContext();
    console.log(this.userContext);

  };


  @computedFrom('repeatNewPassword', 'newPassword')
  get passwordsMatch() {
    return this.repeatNewPassword == this.newPassword;
  }

  @computedFrom('repeatNewPassword', 'newPassword', 'password')
  get changePasswordReady() {
    return (this.legalLength && this.passwordsMatch && this.password)
  }

  @computedFrom('newPassword')
  get legalLength() {
    return this.newPassword.length >= 6;
  }



    error='';
  dismiss() {
    this.error = '';
  }

  changePassword() {
    this.dismiss();
    var self = this;

    var promise = this.fetchPivotClient.then(function(pivotClient) {
      return pivotClient.user.put_user_me_password({ ChangePassword: { oldPassword: self.password, password: self.newPassword } });
    }).then(function(results) {
      self.passwordChanged = true;
    }, function(err) {
      console.log(err);
      self.error = 'Unable to change password.  Please check your current password and try again.';
    });

    this.simpleDialog.blockUntil(promise);

    return false;

    }
}
