"use strict";

import {bindable} from 'aurelia-framework';
import {inject} from 'aurelia-framework';
import {AuthService} from 'paulvanbladel/aurelia-auth';
import {ObserverLocator} from 'aurelia-binding';  // or 'aurelia-framework'

@inject(AuthService, ObserverLocator)
export class NavBar {
  _isAuthenticated=false;
  @bindable router = null;

  constructor(auth, observerLocator){
    this.auth = auth;
    this.observerLocator = observerLocator;
  }

  attached() {
    // subscribe to the "bar" property's changes:
    this.authSubscription = this.observerLocator
      .getObserver(this, 'isAuthenticated')
      .subscribe(this.onAuthChanged.bind(this));
  }

  detached() {
    if (this.authSubscription)
      this.authSubscription();
  }

  onAuthChanged() {
    console.log("Auth Changed: ", this.auth.isAuthenticated());
    if (this.router.currentInstruction.config.auth && !this.auth.isAuthenticated()) {
      console.log("logged out on auth page, redirecting...");
      this.router.navigate(this.auth.auth.getLoginRoute());
    }
    //router.currentInstruction.config
  }
  //@computedFrom(this.auth)
  get isAuthenticated(){
    return this.auth.isAuthenticated();
  }
}
