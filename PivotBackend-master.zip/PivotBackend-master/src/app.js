import 'bootstrap';
import 'bootstrap/css/bootstrap.css!';
import {AuthorizeStep} from 'paulvanbladel/aurelia-auth';
import {Configure} from 'aurelia-configuration';
import {inject} from 'aurelia-framework';
import {LocationService} from 'lib/location-service'

@inject(Configure, LocationService)
export class App {
  configureRouter(config, router){
    config.title = 'Pivot The World';
    config.addPipelineStep('authorize', AuthorizeStep); // Add a route filter to the authorize extensibility point.
    config.map([
      { route: ['','welcome'],  name: 'welcome',      moduleId: 'welcome',      nav: true, title:'Welcome' },
      { route: 'pivot-select',   name: 'pivot-select', moduleId: './pivot/pivot-select',  nav: true, title:'Pivot Points', auth:true },
      { route: 'account',   name: 'account', moduleId: './account',  nav: true, title:'Account', auth:true },
      { route: 'pivot-edit/:id',   name: 'pivot-edit', moduleId: './pivot/pivot-edit',  nav: false, title:'Edit Pivot Point', auth:true },
      { route: 'pivot-new/:latitude/:longitude',   name: 'pivot-new', moduleId: './pivot/pivot-new',  nav: false, title:'New Pivot Point', auth:true },
//      { route: 'tours',   name: 'tours', moduleId: 'tours',  nav: true, title:'Tours', auth:true },
      //{ route: 'settings',   name: 'settings', moduleId: 'settings',  nav: true, title:'Settings', auth:true },
      { route: 'login',  name: 'login', moduleId: 'login',       nav: false, title:'Login' },
      { route: 'logout', name: 'logout', moduleId: 'logout',       nav: false, title:'Logout' }
      /*
      { route: 'users',         name: 'users',        moduleId: 'users',        nav: true, title:'Github Users' },
      { route: 'child-router',  name: 'child-router', moduleId: 'child-router', nav: true, title:'Child Router' }
      */
    ]);

    this.router = router;
  }

  constructor(config, locationService) {
    this.config = config;
    var qd = {};
    location.search.substr(1).split("&").forEach(function(item) {var s = item.split("="), k = s[0], v = s[1] && decodeURIComponent(s[1]); (k in qd) ? qd[k].push(v) : qd[k] = [v]})
    this.config.set("queryParams", qd);
    var useAdvanced = true;
    if (qd['advanced'] !== undefined)
      useAdvanced = qd['advanced'];
    this.config.set("advanced", useAdvanced);
  }
}
