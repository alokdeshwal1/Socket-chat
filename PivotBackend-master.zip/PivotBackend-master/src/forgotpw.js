"use strict";
import 'bootstrap';
import 'bootstrap/css/bootstrap.css!';

import {AuthService} from 'paulvanbladel/aurelia-auth';
import {inject, computedFrom} from 'aurelia-framework';
import {Router} from 'aurelia-router';
import {PivotClient} from 'lib/pivot-client';
import {SimpleDialog} from 'lib/simple-dialog';

@inject(AuthService, Router, PivotClient, SimpleDialog)
export class Account{

  userContext;
  newPassword = '';
  repeatNewPassword = '';
  passwordChanged = false;

	constructor(auth, router, pivotClient, simpleDialog){
		this.auth = auth;
    this.router = router;
    this.pivotClient = pivotClient;

    var qd = {};
    location.search.substr(1).split("&").forEach(function(item) {var s = item.split("="), k = s[0], v = s[1] && decodeURIComponent(s[1]); (k in qd) ? qd[k].push(v) : qd[k] = [v]});
    this.token = null;
    if (qd['token'])
      this.token = qd['token'][0];

    if (!this.token) {
      window.location = '/index.html';
      return;
    }

    this.fetchPivotClient = pivotClient.init(false, this.token);
    this.simpleDialog = simpleDialog;


  };


  @computedFrom('repeatNewPassword', 'newPassword')
  get passwordsMatch() {
    return this.repeatNewPassword == this.newPassword;
  }

  @computedFrom('repeatNewPassword', 'newPassword')
  get changePasswordReady() {
    return (this.legalLength && this.passwordsMatch);
  }

  @computedFrom('newPassword')
  get legalLength() {
    return this.newPassword.length >= 6;
  }



    error='';
  dismiss() {
    this.error = '';
  }

  changePassword() {
    this.dismiss();
    var self = this;

    var promise = this.fetchPivotClient.then(function(pivotClient) {
      return pivotClient.user.put_user_me_password({ ChangePassword: { password: self.newPassword } });
    }).then(function(results) {
      self.passwordChanged = true;
    }, function(err) {
      console.log(err);
      self.error = 'Unable to change password.  Have you already reset your password?';
    });

    this.simpleDialog.blockUntil(promise);

    return false;

    }
}
