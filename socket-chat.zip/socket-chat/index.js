

var express = require('express');
var app = express();
var path = require('path');
var http = require('http').Server(app);
var io = require('socket.io')(http);
app.use(express.static(__dirname + '/views'));
var sequence = 1;
var clients = [];
var sockets = {};
var users = {};
app.get('/', function(req, res){
   res.sendFile(path.join(__dirname+'/index.html'));
});

io.on('connection', function(socket){
	socket.on('init', function(username) {
		users[username] = socket.id;
		sockets[socket.id] = { username : username, socket : socket.id }	
	})
	 socket.on('private message', function(to,username,message) {
        // Lookup the socket of the user you want to private message, and send them your message
        /*console.info(to);
        console.log(message);
        console.log(users);*/
        socket.to(users[to]).emit('msg',username,message);
        /*sockets[users[to]].emit(
            'message', 
            { 
                message : message, 
                from : sockets[socket.id].username 
            }
        );*/
    });
  /*console.info('New client connected (id=' + socket.id + ').');
  clients.push(socket);
  socket.on('chat message', function(msg){
  	console.log(socket.id);
  	io.to(socket.id).emit('chat message', msg);
	//io.emit('chat message', msg);
  });*/
  	socket.on('bzy', function(to,justHide){
  		if(justHide != '') {
  			socket.to(users[to]).emit('bzy','justHide');	
  		} else {
  			socket.to(users[to]).emit('bzy');	
  		}
  		
  	 	//socket.broadcast.emit('bzy');
    });
  socket.on('disconnect', function(){
  	/*var index = users.indexOf(socket);
    if (index != -1) {
        clients.splice(index, 1);
        console.info('Client gone (id=' + socket.id + ').');
    }*/
  	//io.emit('disconn_msg','user disconnected');
  });
});
/*setInterval(function() {
    var randomClient;
    if (clients.length > 0) {
        randomClient = Math.floor(Math.random() * clients.length);
        clients[randomClient].emit('chat message', sequence++);
    }
}, 1000);*/

http.listen(3000, function(){
  console.log('listening on *:3000');
});